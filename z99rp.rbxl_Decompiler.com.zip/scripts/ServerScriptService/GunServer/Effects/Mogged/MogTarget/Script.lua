while wait() do
	script.Parent.Position = script.Parent.Parent.Parent.Position + Vector3.new(0,3,0)
end
