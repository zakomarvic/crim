local part = script.Parent

local Settings = {
	DPS = 15;

	MainDmg = 10;

	RagdollTime = 0.35;
	AddTime = 1;

	DmgDB = 0.5;	
	BurnTime = 1.5;
}

local dbs = {}

part.BurningSound:Play()

local function beamChar(char)
	local humanoid = char:FindFirstChildOfClass("Humanoid")
	if not humanoid then return end
	
	if not char:FindFirstChild("BurningScript") then
		local dir = game.ServerStorage.Storage.Scripts
		local bS = dir.BurningScript:Clone()
		bS.Dmg.Value = Settings.DPS
		bS.Time.Value = Settings.BurnTime
		bS.Parent = char
		bS.Disabled = false
	end
	
	local vf = _G.GVF(char.Name)
	
	if vf and not dbs[humanoid] then
		--local c = Instance.new("BoolValue",Humanoid)
		--c.Name = "MolotovDmged"
		--game.Debris:AddItem(c,Settings.DmgDB + (0 or x))

		dbs[humanoid] = true
		delay(Settings.DmgDB,function()
			dbs[humanoid] = nil
		end)
		
		--_G.SMains.RagdollChar(char,Settings.RagdollTime)
		
		char.BurningScript.Time.Value = char.BurningScript.Time.Value + Settings.AddTime

		local dmg = Settings.MainDmg

		if vf then
			dmg =  dmg * vf.FireProof.Value
		end
		
		local downed = _G.DownedCheck(char)

		dmg = dmg * _G.GetDmgMulti1(char)

		if downed then
			dmg = dmg / 2
		elseif humanoid.Health - dmg <= 15 then
			dmg = humanoid.Health - 15
		end

		humanoid:TakeDamage(dmg)

		if vf and not vf.Grabbing.Value then
			_G.FlinchChar(char,humanoid,0.1,true,true)
		end	
	end
end

part.Touched:Connect(function(touchedPart)
	beamChar(touchedPart.Parent)
end)