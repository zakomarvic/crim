return {
	NoDataSaving = true;

	KillXPMulti = 1;
	KillCashMulti = 0;

	DeathCashDropMulti = 0; --0.286

	LootCashMulti = 0;
	MaxScrapsMulti = 0;
	MaxCratesMulti = 0;

	SafesDisabled = true;
	RegistersDisabled = true;
	DowningDisabled = true;

	NoInventories = true;
	NoCashDrop = true;
	NoBounties = true;
	RemoveScraps = true;
	NoCash = true;
	NoIncognito = true;
	NoPassItems = false;

	UI_RemoveBounty = true;
	--UI_RemoveStoreButton = true;
	UI_RemoveDropCashButton = true;
	UI_RemoveAllowance = true;
	UI_RemoveBank = true;

	RemoveATMs = true;
	RemoveVendingMachines = true;
	DisableRandomEvents = true;
	NoXPGain = true;

	DisableBuyersProtection = true;
	RemoveDealers = false;

	GlobalStocks = true;
	GlobalStock_ShopTitle = "GLOBAL SHOP";
	GlobalStock_HolderColor = Color3.fromRGB(39, 39, 39);
	GlobalStock_CustomRestockTime = 10e10;

	DisableBank = true;
	UnlockAll = true;
	
	CustomItemStatsEnabled = true;
	
	BuyZonesEnabled = true;

	DefaultMap = "04-INFECTED";
	
	Shop_DisableGunDropping = true;
	Shop_DisableMeleeDropping = true;
	
	Shop_OneGunOnly = true;
	Shop_OneMeleeOnly = true;
	
	--CanUseArmoryItemsWithoutPass = true;
	
	NoDoorsAutoRegen = true;
	
	AllowAllAccessories = true;
	
	--DisableSpawningWithGamepassItems = true;
};