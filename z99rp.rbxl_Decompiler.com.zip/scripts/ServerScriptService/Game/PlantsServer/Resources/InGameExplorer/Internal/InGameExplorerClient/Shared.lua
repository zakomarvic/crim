local Fusion = require(script.Parent.Modules.Fusion)

local LocalPlayerName = game:GetService("Players").LocalPlayer.Name

local Shared = {
	SelectedInstance = Fusion.Value(nil),
	ToolEnabled = Fusion.Value(false),
	ConsoleEnabled = Fusion.Value(true),
	WidgetEnabled = Fusion.Value(false),
	ExportFrameEnabled = Fusion.Value(false),
	
	CurrentReplicator = Fusion.Value(LocalPlayerName),
	ListeningReplicator = Fusion.Value(false)
}



return Shared
