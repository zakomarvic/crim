-- SERVER

local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
--
local container = require(script:WaitForChild("Container"))
local LCS = {}
_G.LCS = LCS
--
function LCS.init()
	task.spawn(function() 
		_G.YieldUntilGameCompleteLoad()
		--
		game:GetService("RunService").Heartbeat:Connect(function(delta) 
			for _, cobj in ipairs(container.bucket) do
				cobj:cycle(delta)
			end
		end)
		--
		container.sortLootModules()
	end)
end
--
function LCS.spawn(cframe: CFrame, variant: string)
	--
	local lcon = script.LootContainerTemplate:Clone()
	lcon:PivotTo(cframe)
	lcon.Parent = workspace.Map.LootContainers
	--
	return container.new(lcon, variant)
end
--
return LCS