-- SERVER

local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
--
local assets = game:GetService("ReplicatedStorage").PlantsStorage.Assets
local sounds = assets.Sounds.LootContainer.WeaponsLocker
--
return {
	--
	loot = "Scrap",
	model = script.locker,
	poffset = Vector3.new(0, 2.75, -1.25),
	--
	regenerationTime = {720, 1200},
	maxItems = 7,
	minPower = 3,
	maxPower = 9,
	absoluteMaxPower = 70,
	--
	isTheft = true,
	cashBoost = 0.80, -- +80% Cash
	powerStartMultiplier = 0.6,
	powerTickEverySeconds = {70, 180},
	powerTickIncreaseRange = {3, 8},
	--
	onOpen = function(container, model)
		_G.PlaySound(sounds.open, model.Base, (math.random(90, 110)/100)*1.1)
		local HAngle = math.random(110, 130)
		local HCFrame = (CFrame.new(0.679, 0, 0.169) * CFrame.Angles(0, math.rad(-HAngle), 0))
		framework.networking.toClients(nil, false, "Tween", {model.Base.Door, {0.275, Enum.EasingStyle.Sine,Enum.EasingDirection.Out, 0, false, _G.Random(0.03, 0.075, 1000)}, {C1 = HCFrame}})
	end,
	--
	onClose = function(container, model)
		_G.PlaySound(sounds.open, model.Base, (math.random(80, 90)/100)*1.1)
		_G.PlaySound(sounds.close, model.Base, (math.random(95, 105)/100)*1.1, 0.25)
		framework.networking.toClients(nil, false, "Tween", {model.Base.Door, {0.275, Enum.EasingStyle.Sine,Enum.EasingDirection.Out, 0, false, _G.Random(0.03, 0.075, 1000)}, {C1 = CFrame.new(0.679, 0, 0.169)}})
	end,
	--
	overwriteLoot = {
		--
		{name = "junk_Papers", weight = 60, power = 10, isScrap = true},
		--
		{name = "val_Lighter", weight_multiplier = 0.5},
		{name = "val_Battery", weight_multiplier = 0.3},
		{name = "val_Wires", weight = 0},
		{name = "val_Gunpowder", weight = 0},
		{name = "val_MilitaryCable", weight = 0},
		{name = "val_WeaponParts", weight = 0},
		{name = "val_Keytool", weight = 0},
		{name = "val_Jerrycan", weight = 0},
		{name = "val_Blueprint", weight_multiplier = 0.4},
		{name = "val_Documents", weight_multiplier = 1.2},
		--
	}
	--
}