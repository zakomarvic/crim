return { -- green scraps
	
	["Lockpick"] = {
		Rarity = 1;
		Chance = 10;
	};
	
	["Bayonet"] = {
		Rarity = 2;
		Chance = 9; -- %
	};
	
	["Crowbar"] = {
		Rarity = 2;
		Chance = 8; -- %
	};
	
	["Shovel"] = {
		Rarity = 2;
		Chance = 8; -- %
	};
	
	["Bat"] = {
		Rarity = 2;
		Chance = 8; -- %
	};
	
	["Golfclub"] = {
		Rarity = 1;
		Chance = 8; -- %
	};
	
	["Taiga"] = {
		Rarity = 2;
		Chance = 7; -- %
	};
	
	["Molotov"] = {
		Rarity = 2;
		Chance = 6; -- %
	};
	
	["Grenade"] = {
		Rarity = 2;
		Chance = 6; -- %
	};
	["Sawn-Off"] = {
		Rarity = 4;
		Chance = 6;
	};
	["Beretta"] = {
		Rarity = 4;
		Chance = 6; -- %
	};
	["TEC-9"] = {
		Rarity = 4;
		Chance = 6; -- %
	};
	["Uzi"] = {
		Rarity = 4;
		Chance = 6;
	};
	["SKS"] = {
		Rarity = 4;
		Chance = 6;
	};
}