
return function(model)
	if model.ClassName == "Tool" then
		model:SetAttribute("goldenkatana", true)

		local trail = script.Trail:Clone()
		model.WeaponHandle:FindFirstChild("Trail"):Destroy()
		trail.Parent = model.WeaponHandle
		trail.Attachment0 = model.WeaponHandle.T0
		trail.Attachment1 = model.WeaponHandle.T1
		
		local spark = script.Sparks:Clone()
		model.WeaponHandle.Spark:FindFirstChild("Sparks"):Destroy()
		spark.Parent = model.WeaponHandle.Spark
	end
	return true
end