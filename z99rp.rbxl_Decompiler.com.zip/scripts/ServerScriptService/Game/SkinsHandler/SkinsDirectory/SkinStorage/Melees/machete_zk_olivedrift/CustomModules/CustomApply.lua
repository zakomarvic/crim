

return function(model)
	if model.ClassName == "Tool" then
		model:SetAttribute("customModel", "machete_zk")
		
		local Directory = game:GetService("ReplicatedStorage"):WaitForChild("Storage"):WaitForChild("SkinVariants")
		local Replicated = Directory.Melees.machete_zk:Clone()
		local Handle = model:WaitForChild("WeaponHandle")
		local SA = script.Parent.Parent.SurfaceAppearance:Clone()
		SA.Parent = Replicated.WeaponHandle.ZKKnifeMesh
		Replicated.WeaponHandle.ZKKnifeMesh.TextureID = "rbxassetid://15070276224"

		Replicated.Parent = Handle
		Replicated:PivotTo(Handle.CFrame)
		Handle.ManualWeld:Destroy()
		local weld = Instance.new("WeldConstraint")
		weld.Parent = Handle
		weld.Part0 = Handle
		weld.Part1 = Replicated.WeaponHandle
		Handle.KilltrackPlacementAttachment:Destroy()
		Replicated.WeaponHandle.KilltrackPlacementAttachment.Parent = Handle
		Handle.MacheteMesh:Destroy()
	end
	return true
end