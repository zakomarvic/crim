return { -- grey scraps
	
	["Lockpick"] = {
		Rarity = 1;
		Chance = 12;
	};
	
	["Shiv"] = {
		Rarity = 1;
		Chance = 11; -- %
	};
	
	["Wrench"] = {
		Rarity = 1;
		Chance = 11; -- %
	};

	["Bayonet"] = {
		Rarity = 1;
		Chance = 11; -- %
	};

	["Golfclub"] = {
		Rarity = 1;
		Chance = 11; -- %
	};
	
	["Crowbar"] = {
		Rarity = 2;
		Chance = 10; -- %
	};

	["Shovel"] = {
		Rarity = 2;
		Chance = 10; -- %
	};

	["Molotov"] = {
		Rarity = 2;
		Chance = 9; -- %
	};
	
	["Beretta"] = {
		Rarity = 4;
		Chance = 8; -- %
	};
	
	["Sawn-Off"] = {
		Rarity = 4;
		Chance = 6; -- %
	};
	["SKS"] = {
		Rarity = 4;
		Chance = 1; -- %
	};
}