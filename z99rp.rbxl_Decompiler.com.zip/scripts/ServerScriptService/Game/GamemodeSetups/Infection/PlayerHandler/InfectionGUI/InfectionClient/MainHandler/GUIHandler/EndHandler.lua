local TS = game:GetService("TweenService")
local SoundService = game:GetService("SoundService")
local ContentProvider = game:GetService("ContentProvider")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ChatService = game:GetService("Chat")
local StarterGui = game:GetService("StarterGui")

local EndHandler = {}
EndHandler.__index = EndHandler

function EndHandler:CreateEndUI(endData)
	local endFrame = script.EndFrame:Clone()
	
	endFrame.TopBar.Desc.Text = endData.desc
	endFrame.TopBar.Desc.TextColor3 = endData.descColor3 or Color3.new(1,1,1)
	
	local sort = {}
	local topSort = {}
	
	for i,v in pairs(endData.leaderstats) do
		v.Username = i
		
		if v.wasWinner then
			table.insert(topSort,v)
		else
			table.insert(sort,v)
		end
	end
	
	table.sort(sort,function(a,b)
		return a.Profit > b.Profit
	end)
	table.sort(topSort,function(a,b)
		return a.Profit > b.Profit
	end)
	
	local function createLeaderstat(v)
		local f = script.Frame:Clone()
		f.NameLabel.Text = v.Username
		f.KillsLabel.Text = tostring(v.Kills)
		f.AssistsLabel.Text = tostring(v.Assists)
		f.ProfitLabel.Text = "$" .. tostring(v.Profit)
		
		local c
		if v.Username == self.plr.Name then
			c = Color3.fromRGB(165, 192, 255)
		elseif v.originalInfected then
			c = Color3.fromRGB(195, 255, 192)
		end
		
		if c then
			for _,x in pairs(f:GetDescendants()) do
				if x:IsA("TextLabel") then
					x.TextColor3 = c
				end
			end
		end
		
		return f
	end
	
	if #topSort > 0 then
		for i,v in pairs(topSort) do
			local s = createLeaderstat(v)
			s.LayoutOrder = i
			s.Parent = endFrame.MainFrame.ScrollingFrame
		end
		
		if #sort > 0 then
			local line = script.Linebreak:Clone()
			line.LayoutOrder = #topSort + 1

			line.Parent = endFrame.MainFrame.ScrollingFrame
		end
	end
	
	for i,v in pairs(sort) do
		local s = createLeaderstat(v)
		s.LayoutOrder = i + (#topSort + 1)
		s.Parent = endFrame.MainFrame.ScrollingFrame
	end
	
	return endFrame
end

function EndHandler:new(endData,endMusic,delayT)
	--print("EndHandler START")
	delayT = delayT or 0
	
	_G.NoSGReverbChange = true
	
	if endMusic and endMusic.Parent then
		endMusic.SoundGroup = nil
	end
	
	SoundService.AmbientReverb = Enum.ReverbType.City
	pcall(function()
		SoundService.Master.Main.Volume = 1
	end)
	
	pcall(function()
		spawn(function()
			ContentProvider:Preload("rbxassetid://11531388085")
		end)
	end)
	
	pcall(function()
		_G.sgS_effect2.Enabled = false
		_G.sgS_effect5.Enabled = false
		_G.sgS_eqA_1.Enabled = false
		_G.sgS_eqB_1.Enabled = false
	end)
	pcall(function()
		_G.deathGUI.Frame.Visible = false
		_G.deathGUI.BlackFrame.Visible = false
	end)
	
	local currentChar = self.plr.Character
	
	local uiF = EndHandler.CreateEndUI(self,endData)
	
	local t_tt = uiF.TopBar.Title.TextTransparency
	local t_tst = uiF.TopBar.Title.TextStrokeTransparency
	local d_tt = uiF.TopBar.Desc.TextTransparency
	local d_tst = uiF.TopBar.Desc.TextStrokeTransparency
	
	uiF.TopBar.Title.TextTransparency = 1
	uiF.TopBar.Title.TextStrokeTransparency = 1
	uiF.TopBar.Desc.TextTransparency = 1
	uiF.TopBar.Desc.TextStrokeTransparency = 1
	
	uiF.MainFrame.Visible = false
	
	uiF.Parent = self.gui
	uiF.Visible = true
	
	pcall(function()
		self.plr.PlayerGui.CoreGUI.Enabled = false
		self.plr.PlayerGui.CurrentGUI.Enabled = false
	end)
	
	local active = true
	
	local dofe
	local fovV
	
	local function DoSequence()
		if not active then return end
		
		local st_i = TweenInfo.new(2,Enum.EasingStyle.Quad,Enum.EasingDirection.Out)
		
		TS:Create(uiF.TopBar.Title,st_i,{TextTransparency = t_tt;TextStrokeTransparency = t_tst}):Play()
		TS:Create(uiF.TopBar.Desc,st_i,{TextTransparency = d_tt;TextStrokeTransparency = d_tst}):Play()
		
		local function DoFlicker()
			uiF.BlackScreen1.BackgroundTransparency = 1
			uiF.BlackScreen1.Visible = true
			
			local flicker_i1 = TweenInfo.new(0.1,Enum.EasingStyle.Linear,Enum.EasingDirection.Out)
			local flicker_i2 = TweenInfo.new(1,Enum.EasingStyle.Quint,Enum.EasingDirection.Out,0,false,0.025)
			TS:Create(uiF.BlackScreen1,flicker_i1,{BackgroundTransparency = 0}):Play()
			
			task.wait(0.1)
			
			TS:Create(uiF.BlackScreen1,flicker_i2,{BackgroundTransparency = 1}):Play()
		end
		
		task.wait(4)
		
		if not active then return end
		
		local vf = _G.GVF and _G.GVF()

		pcall(function()
			_G.deathGUI.Frame.Visible = false
			_G.deathGUI.BlackFrame.Visible = false
		end)
		
		spawn(DoFlicker) task.wait(0.05)
		task.wait(0.1)
		
		if not active then return end
		
		if vf then
			for i,v in pairs(vf.Currents:GetChildren()) do
				if string.find(v.Name,"CC_") then
					v:Destroy()
				end
			end

			for i,v in pairs(vf.FOVs:GetChildren()) do
				v:Destroy()
			end

			local f = Instance.new("NumberValue")
			f.Value = 40
			f.Parent = vf.FOVs
			fovV = f 
		end

		ReplicatedStorage.Values.FogAddValue.Value = -0.2
		
		dofe = Instance.new("DepthOfFieldEffect")
		dofe.FarIntensity = 1
		dofe.FocusDistance = 0.05
		dofe.InFocusRadius = 150
		dofe.NearIntensity = 0
		dofe.Parent = workspace.CurrentCamera
		
		TS:Create(dofe,TweenInfo.new(18,Enum.EasingStyle.Linear,Enum.EasingDirection.In),{InFocusRadius = 0}):Play()
		
		pcall(function()
			_G.sgS_effect2.Enabled = false
			_G.sgS_effect5.Enabled = false
			_G.sgS_eqA_1.Enabled = false
			_G.sgS_eqB_1.Enabled = false
		end)
		
		_G.NoDeathEFZ = true
		if _G.DeathEFZ_deathCamTing then
			pcall(function()
				_G.DeathEFZ_deathCamTing:Cancel()
			end)
		end
		
		uiF.MainFrame.Visible = true
		
		local cpf = script.CameraPoints
		self.cam.CameraSubject = nil
		self.cam.CameraType = Enum.CameraType.Scriptable
		self.cam.CFrame = cpf.C1.CFrame

		local t1 = TS:Create(self.cam,TweenInfo.new(9,Enum.EasingStyle.Linear,Enum.EasingDirection.InOut,0,false,0),{CFrame = cpf.C2.CFrame})
		t1:Play()
		
		task.wait(4.5)
		
		if not active then return end
		
		--pcall(function()
		
		--	StarterGui:SetCore("TopbarEnabled", true)
			
		--	if _G.GSettings and _G.GSettings.Chat then
		--		StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.Chat,true)
		--	end
		--end)
		
		spawn(DoFlicker) task.wait(0.05)
		task.wait(0.1)
		
		if not active then return end
		
		if t1 then
			t1:Cancel()
		end
		
		self.cam.CFrame = cpf.C3.CFrame
		local t2= TS:Create(self.cam,TweenInfo.new(14,Enum.EasingStyle.Linear,Enum.EasingDirection.InOut,0,false,0),{CFrame = cpf.C4.CFrame})
		t2:Play()
		
		
		task.wait(9)
		
		if not active then return end
		
		TS:Create(uiF.TopBar.Title,st_i,{TextTransparency = 1;TextStrokeTransparency = 1}):Play()
		TS:Create(uiF.TopBar.Desc,st_i,{TextTransparency = 1;TextStrokeTransparency = 1}):Play()
		
		task.wait(2)
		
		if not active then return end
		
		TS:Create(uiF.BlackScreen1,TweenInfo.new(2,Enum.EasingStyle.Linear,Enum.EasingDirection.In),{BackgroundTransparency = 0}):Play()
		
		task.wait(3)
		
		if not active then return end
		
		if self.MorseCodeHandler then
			local t = {
				Text = "INFECTION";
				TextTransparency = 1;
				TextStrokeTransparency = 1;
			}
			
			local f = function()
				local i = script.EndImage:Clone()
				i.Parent = self.gui
				i.Visible = true
				
				TS:Create(i,TweenInfo.new(3,Enum.EasingStyle.Sine,Enum.EasingDirection.In,0,false,1),{ImageTransparency = 1}):Play()
			end
			
			self.MorseCodeHandler.Do(self,t,3,1.5,"boom",f)
		end
	end
	
	delay(delayT,function()
		DoSequence()
	end)
	
	local con
	
	local function onChange()
		--print("EndHandler DESTROY")
		if con then
			con:Disconnect()
		end
		
		active = false
		
		delay(3,function()

			_G.NoSGReverbChange = false
			_G.NoDeathEFZ = false
			
			--pcall(function()
			--	ChatService:RegisterChatCallback(Enum.ChatCallbackType.OnCreatingChatWindow, function()
			--		return {BubbleChatEnabled = true, ClassicChatEnabled = false}
			--	end)
			--end)
			
			local t = false
			local m = self.I.modeV.Value
			
			repeat task.wait(0.1)
				if self.I.modeV.Value ~= m then
					delay(1,function()
						t = true
					end)
				end
				
			until self.plr.Character ~= currentChar or t
			
			ReplicatedStorage.Values.FogAddValue.Value = 0
			
			if dofe and dofe.Parent then
				dofe:Destroy()
			end
			if fovV and fovV.Parent then
				fovV:Destroy()
			end
			
			pcall(function()
				self.plr.PlayerGui.CoreGUI.Enabled = true
				self.plr.PlayerGui.CurrentGUI.Enabled = true
			end)
			if self.plr.Character and self.plr.Character:FindFirstChild("Humanoid") then
				self.cam.CameraSubject = self.plr.Character.Humanoid
			end
			
			self.cam.CameraType = Enum.CameraType.Custom
			
			uiF.MainFrame.Visible = false
			uiF.TopBar.Visible = false
			
			TS:Create(uiF.BlackScreen1,TweenInfo.new(2,Enum.EasingStyle.Linear,Enum.EasingDirection.InOut),{BackgroundTransparency = 1}):Play()
			
			delay(2,function()
				uiF:Destroy()
			end)
		end)
	end
	
	con = self.I.modeV.Changed:Connect(onChange)
end

return EndHandler