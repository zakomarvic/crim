-- Data Transfer

local https = game:GetService("HttpService")
local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
--
local skinIndexes = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Media"):WaitForChild("SkinIndexes"))
local players = require(game:GetService("ServerStorage").PlantsStorage.Objects.Player)
local compressor = require(script:WaitForChild("Compressor"))
local system = {url = nil, queue = {}, processing = false, connecting = false, autosave_os = os.clock()}
local save = {}

function system.try(url: string, headers: {[string]: any}, body: any?, depth: number)
	depth = depth or 1

	local succ, ret = pcall(function()
		return https:PostAsync(
			url or system.url,
			body and https:JSONEncode(body) or "",
			Enum.HttpContentType.ApplicationJson,
			false,
			headers
		)
	end)

	if succ then
		return ret, true
	else
		task.wait(1)
		if depth < 3 and system.url ~= nil then
			return system.try(url or system.url, headers, body, depth + 1)
		else
			local tab = {Title = "Upload Save Data"; Text = "Upload data saving servers are offline."; Duration = 20; Button1 = "Close";}
			game:GetService("ReplicatedStorage").Events.Notification:FireAllClients(tab, "Beep2")	
			system.url = nil
			system.queue = {}
			return nil, false
		end
	end

end


function system.connect(url: string)

	if (system.connecting) then return false, "Already trying to connect to a server at the moment." end
	system.connecting = true

	local _, success = system.try(url, {action = "ping"})
	if (not success) then system.connecting = false return false, "Server did not respond." end
	system.url = url
	system.connecting = false
	
	local tab = {Title = "Upload Save Data"; Text = "Upload data saving servers are online, if you have data it should be transfered soon."; Duration = 20; Button1 = "Close";}
	game:GetService("ReplicatedStorage").Events.Notification:FireAllClients(tab, "Beep2")	
	system.autosave_os = os.clock()
	
	framework.Gs.Put("Successfully connected to data transfer server!", "Save Data")
	return true, "Server has responded, successfully connected!"

end

function system.init(url: string)

	-- Players Joining

	players.added:Connect(function(player: types.player) 
		task.spawn(function() 

			table.insert(system.queue, {
				operation = "load",
				user = player.player.UserId,
			})

			table.insert(player.invokeRemoving, function() 

				local save = player:getSaveData()
				table.insert(system.queue, {
					operation = "save",
					save = save,
					user = player.player.UserId,
				})

			end)

		end)
	end)

	-- Request Handling
	
	system.autosave_os = os.clock()
	framework.services.RunService.Heartbeat:Connect(function() 
		
		if (os.clock() - system.autosave_os) >= (20*60) then
			system.autosave_os = os.clock()
			system.autosave()
		end

		if (not system.processing) then
			local request = system.queue[1]
			system.process(request)
		end

	end)

	-- Game Close

	if (system.url ~= nil) then
		game:BindToClose(function() 
			task.wait(1)
			repeat task.wait() until (#system.queue <= 0 and not system.processing)
		end)
	end

	-- Successfully Inited

	return true
end

function system.autosave()

	for _, player in ipairs(game.Players:GetChildren()) do

		local player_object: types.player = _G.CustomPlayersSystem.getPlayerBy(player)
		local save_data = player_object:getSaveData()

		table.insert(system.queue, {
			operation = "save",
			save = save_data,
			user = player.UserId,
		})

	end

end

function system.transfer(player: types.player, save)
	
	if (tostring(save.upload) == tostring(game.PlaceId)) then
		return
	end
	
	-- Transfering
	
	player.data.money.Shards = save.shards or 0
	player.data.money.Cash = save.cash
	player.data.money.Bank = save.bank
	player.data.level.Level = save.level
	player.data.level.XP = save.xp
	player.data.other.Society.Reputation = save.reputation
	player.data.other.Attributes.Strength = save.attributes.strength
	player.data.other.Attributes.Endurance = save.attributes.endurance
	player.data.other.Attributes.Agility = save.attributes.agility
	player.data.other.Attributes.Altruism = save.attributes.altruism
	player.data.other.Traits.Boons = save.traits.boons
	player.data.other.Traits.Flaws = save.traits.flaws
	
	player.data.other.EmotesEquipped = save.equipped_emotes or player.data.other.EmotesEquipped
	player.data.other.EmotesOwned = save.owned_emotes or player.data.other.EmotesOwned
	
	for _, skin in pairs(save.skins) do
		
		local skinSplit = string.split(skin, "/")
		local skinName = skinIndexes.output[skinSplit[1]]
		local isKilltrack = (skinSplit[3] ~= nil and skinSplit[3] ~= "" and tonumber(skinSplit[3]) and true) or false

		local newSkinId = "SK-".. _G.GenerateSequence(18, true, true, true, false)
		local newSkinData = {
			Killtrack = isKilltrack,
			KilltrackCT = (isKilltrack and tonumber(skinSplit[3])) or 0,
			Locked = false,
			SerialNum = tonumber(skinSplit[2]) or nil,
			creationTick = tick(),
			justObtained = false,
			lastObtainTick = tick(),
			skinName = skinName,
		}

		player.data.player.Cosmetics.Skins[newSkinId] = newSkinData
	end
	
	-- Finalizing
	
	local tab = {Title = "Upload Save Data"; Text = "Your upload data has been transferred."; Duration = 90; Button1 = "Close";}
	game:GetService("ReplicatedStorage").Events.Notification:FireClient(player.player, tab, "Beep2")	
	player:replicateReputation()
	player:updateAttributes()
	player:evaluateTraitPoints()
	player.data.update(true)
	player.data.doSave(true, true, true, true)
	
end

function system.process(request)

	if (system.url == nil or system.connecting) then return end
	if (system.processing) then return end

	task.spawn(function() 

		system.processing = true
		framework.Gs.RemoveFromArray(system.queue, request)

		local s, r = pcall(function() 

			if (request.operation == "load") then -- Load Operation

				local player: types.player = _G.CustomPlayersSystem.getPlayerBy(request.user)
				local container = compressor.to_base64(compressor.zlib_deflate(https:JSONEncode({user = tostring(request.user)}), {level = 9}))
				local data, success = system.try(nil, {action = "get", container = container})
				if (success) then

					data = https:JSONDecode(data)
					if (data.response) then

						local encoded = data.data
						encoded = https:JSONDecode(compressor.zlib_inflate(compressor.from_base64(encoded)))
						system.transfer(player, encoded)
						framework.Gs.Put(string.format("Save data got and transfered for %s!", tostring(request.user)))

					else

						local save_data = player:getSaveData()
						framework.Gs.Put(string.format("Save data was not found for %s, creating request to save template data.", tostring(request.user)), "Save Data")
						table.insert(system.queue, {operation = "save", save = save_data, user = request.user})

						local tab = {Title = "Upload Save Data"; Text = "New upload save data has been created for you."; Duration = 90; Button1 = "Close";}
						game:GetService("ReplicatedStorage").Events.Notification:FireClient(player.player, tab, "Beep2")	

					end
				end

			elseif (request.operation == "save") then -- Save Operation

				local encoded = compressor.to_base64(compressor.zlib_deflate(https:JSONEncode(request.save), {level = 9}))
				local container = compressor.to_base64(compressor.zlib_deflate(https:JSONEncode({user = tostring(request.user)}), {level = 9}))
				local _, success = system.try(nil, {action = "save", container = container}, encoded)
				if (success) then
					framework.Gs.Put(string.format("Successfully saved %s's data!", tostring(request.user)), "Save Data")
				else
					framework.Gs.Put(string.format("Failed to save %s's data!", tostring(request.user)), "Save Data")
				end

			end

		end)

		task.wait(1)
		repeat task.wait() until (r ~= nil or s ~= nil)
		system.processing = false

	end)
end

_G.SaveDataTransferSystem = system
return system