return {
	
	["MaxItems"] = 1;
	["StoredAmmo_TakePerc"] = {33,200}; -- Up to this % of the stored ammo can be taken
	["Ammo_TakePerc"] = {33,200}; -- Up to this % of the ammo can be taken
	
	["ItemsTable"] = {
		["val_Lighter"] = {
			Chance = 5;
		};
		["val_Battery"] = {
			Chance = 5;
		};
		["val_Wires"] = {
			Chance = 5;
		};
		["val_Gunpowder"] = {
			Chance = 5;
		};
		["val_MilitaryCable"] = {
			Chance = 5;
		};
		--v 46%
		
		["val_Watch"] = {
			Chance = 3;
		};
		["val_SkullRing"] = {
			Chance = 3;
		};
		["val_Dogtag"] = {
			Chance = 3;
		};
		["val_Keytool"] = {
			Chance = 3;
		};
		["val_FloppyDrive"] = {
			Chance = 3;
		};
		
		--v 25%
		
		["Cola_1"] = {
			Chance = 5; -- %
		};

		["Cola_2"] = {
			Chance = 5; -- %
		};
		
		["Chips_1"] = {
			Chance = 5; -- %
		};
		
		["Chips_2"] = {
			Chance = 5; -- %
		};
		
		["ChocBar_1"] = {
			Chance = 5; -- %
		};
		
		["ChocBar_2"] = {
			Chance = 5; -- %
		};

		["Lockpick"] = {
			Chance = 5; -- %
		};
		
		["Rage-potion"] = {
			Chance = 3; -- %
		};
		
		["C4"] = {
			Chance = 2; -- %
		};
		
		["Coal"] = {
			Chance = 10; -- %
		};
		
		["Antidote"] = {
			Chance = 3; -- %
		};

		["Balisong"] = {
			Chance = 2; -- %
		};
		
		["Shiv"] = {
			Chance = 3; -- %
		};
		
		["Relic"] = {
			Chance = 0.90; -- %
		};
		
		["Beretta"] = {
			Chance = 2; -- %
			IsGun = true;
		};
	};
}