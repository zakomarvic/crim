--34GKB8495GJNNJR44FV
local Players = game:GetService("Players")
local StarterGui = game:GetService("StarterGui")

local Player = Players.LocalPlayer
local gui = script.Parent

for _,v in pairs(Player.PlayerGui:GetChildren()) do
	if v:IsA("ScreenGui") and v ~= gui then
		v.Enabled = false
	end
end

StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.All, false)