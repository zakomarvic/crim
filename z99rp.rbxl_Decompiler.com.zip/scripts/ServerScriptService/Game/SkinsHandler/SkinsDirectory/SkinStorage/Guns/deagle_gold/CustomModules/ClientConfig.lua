 



return function(config,tool)
	config.BulletSettings.Color = Color3.fromRGB(255, 238, 0)
	config.BulletSettings.TracerTransparency /= 2
	config.BulletSettings.TracerLifetime *= 1.35
	
	config.BulletSettings.TracerOffset0 = Vector3.new(-0.1125, -0.0375, -0.375); 
	config.BulletSettings.TracerOffset1 = Vector3.new(0.1125, 0.0375, 0.0375);
	
	config.BulletSettings.LightEnabled = true
	config.BulletSettings.LightColor = Color3.fromRGB(255, 238, 0)
	config.BulletSettings.LightShadows = true;
	
	config.FlashSettings.Color = Color3.fromRGB(255, 238, 0)
	config.FlashSettings.Range *= 1.35
	config.FlashSettings.Brightness *= 1.35
	
	config.BulletSettings.ShakeMulti *= 1.5
	
	config.Name = "G-Deagle"
	
	config.ReloadTime /= 1.3
	config.ReloadAnimSpeed *= 1.3
	
	return config
end