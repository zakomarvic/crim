local Calls = {}
--
Calls["NewTool"] = function(data)
	require(game:GetService("ReplicatedStorage").PlantsStorage.Objects.Tool).new(data[1], data[2])
end
--
Calls["SetLookAngles"] = function(player, data)
	local pitch=data[1]
	local yaw=data[2]
	--
	if typeof(pitch) ~= "number" or pitch ~= pitch then
		return
	end

	if typeof(yaw) ~= "number" or yaw ~= yaw then
		return
	end

	pitch = math.clamp(pitch, -1, 1)
	yaw = math.clamp(yaw, -1, 1)

	game:GetService("ReplicatedStorage").PlantsStorage.Hooks.remote:FireAllClients("SetLookAngles", {player, pitch, yaw})
end
--
return Calls