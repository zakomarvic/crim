wait(0.5)

local TS =					game:GetService("TweenService")
local PhysicsService =		game:GetService("PhysicsService")
local ReplicatedStorage =	game:GetService("ReplicatedStorage")
local ServerStorage =		game:GetService("ServerStorage")

local model = script.Parent
local assetStorage = ServerStorage.Storage.CashRegisterStuff

local eventsDir = ReplicatedStorage.Events
local eventsDir3 = ServerStorage.Events3

local values =		model.Values
local events =		model.Events

local primary = model.PrimaryPart

local healthV =	values.Health
local brokenV = values.Broken
local dropAmountV = model:WaitForChild("DropA")
local dropCountV = model:WaitForChild("DropC")
local bountyV = model:WaitForChild("BountV")
local alarmV = model:FindFirstChild("AlarmValue")

dropAmountV.Parent,dropCountV.Parent,bountyV.Parent = nil,nil,nil

local lPlayer = nil

local function alarmCheck()
	return alarmV and alarmV.Value ~= nil and alarmV.Value.Parent and alarmV.Value:FindFirstChild("Ring")
end

local function Lerp(a, b, c)
	return a + ((b - a) * c)
end

local function CalcWPerc(amt)
	local MPLAYERS = game.Players.MaxPlayers
	local MAX = amt
	local MIN = MAX / values.MPerc.Value
	
	local PLAYER_COUNT = #game.Players:GetPlayers()
	
	local c = PLAYER_COUNT / MPLAYERS 
	
	c = math.clamp(1 - c,0,1)
	c = 1 - c
	
	return Lerp(MIN,MAX,c)
end

function onDamage(dmg,player)
	if brokenV.Value then return end
	
	local hitS = assetStorage.Sounds.Hit:GetChildren()[math.random(1,#assetStorage.Sounds.Hit:GetChildren())]:Clone()
	hitS.Parent = primary
	hitS:Play()
	game.Debris:AddItem(hitS,2)
	
	if player then
		eventsDir3.nBount:Fire("KLGHJRKR90U3893KJZDGNKDFZJKNWU9023JKWRG02",player,bountyV.Value)
	end
	lPlayer = player
	
	healthV.Value = healthV.Value - dmg
end

function onBreak()
	if brokenV.Value then return end
	
	brokenV.Value = true
	
	dropAmountV:Destroy()
	dropCountV:Destroy()
	bountyV:Destroy()
	
	if alarmCheck() then
		delay(math.random(75,150) / 100,function()
			alarmV.Value.Ring:Fire(90)
		end)
	end
	
	primary.Material = Enum.Material.CorrodedMetal
	
	if model:FindFirstChild("Parts") then
		for _,v in pairs(model.Parts:GetChildren()) do
			if v.Name == "CP" or v:FindFirstChild("CP") then
				v.Material = Enum.Material.CorrodedMetal
			end
		end
	end
	
	if primary:FindFirstChild("EffectA") then
		primary.EffectA.Sparkle:Destroy()
		primary.EffectA.Smoke:Emit(20)
		primary.EffectA.Spark:Emit(15)
		spawn(function()
			while true do
				wait(math.random(500,2000) / 1000)
				primary.EffectA.Spark:Emit(math.random(3,6))
			end
		end)
	end
	
	if model:FindFirstChild("BreakM") then
		require(model.BreakM)(lPlayer)
	end
 	
	if lPlayer then
		eventsDir3.nBount:Fire("KLGHJRKR90U3893KJZDGNKDFZJKNWU9023JKWRG02",lPlayer,bountyV.Value)
		eventsDir3.AyuP:Fire("KLJ8902209SANK8234LDFG0OKJAKA984231ZZ04LGXBNBZ1U912",lPlayer,35)
	end
	
	local s1 = assetStorage.Sounds.Break:GetChildren()[math.random(1,#assetStorage.Sounds.Break:GetChildren())]:Clone()
	s1.Parent = primary
	s1:Play()
	game.Debris:AddItem(s1,2)
	
	local s2 = assetStorage.Sounds.Drop:Clone()
	s2.Parent = primary
	s2:Play()
	game.Debris:AddItem(s2,2)
	
	local dCount = math.random(dropCountV.MinValue,dropCountV.MaxValue)
	dCount = math.min(dCount,10)
	
	local n = 0
	for i = 1,dCount do	
		local dAmount = math.random(dropAmountV.MinValue,dropAmountV.MaxValue)
		
		dAmount = CalcWPerc(dAmount)
		dAmount = math.min(dAmount,1000)

		n = n + dAmount

		local ting = (model and model:FindFirstChild("RangeAdd") and model.RangeAdd.Value) or 0
		
		local CF = CFrame.new(primary.Position + (primary.CFrame.LookVector * (1.25 + ting)))
		--CF = CF * CFrame.new(0,1,0)
		--CF = CF + (CF.RightVector * (math.random(-250,250) / 100))
		CF = CF * CFrame.Angles(0,math.rad(math.random(0,360)),0)
		
		
		
		local cash = eventsDir3.D_CSH2:Invoke("8DR002",CF,1,dAmount,360)
		local force = primary.CFrame.LookVector * 15 + (primary.CFrame.RightVector * math.random(-400,400) / 100)
		_G.SMains.ForceT(cash,force,0.1,0)
		
		wait(0.15)
	end
end

function SetUp()
	dropAmountV.Parent = values
	dropCountV.Parent = values
	bountyV.Parent = values
	
	if alarmV then
		alarmV.Parent = values
	end
	
	local hCon
	hCon = healthV.Changed:Connect(function(x)
		if x <= 0 then
			hCon:Disconnect()
			onBreak()
		end		
	end)
	
	events.Damage.Event:Connect(onDamage)
end

SetUp()