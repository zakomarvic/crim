-- SERVER

local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
--
local grabbables = {binds = {}}
local characters = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Objects"):WaitForChild("Character"))
local globals = require(game:GetService("ReplicatedStorage").Modules.GetGlobals)
local hooks = game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Hooks")
local sounds = game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Assets"):WaitForChild("Sounds"):WaitForChild("Other"):WaitForChild("Grabbables")
--
function grabbables.init()
	--
	hooks.systems.grabbable.OnServerInvoke = function(player, action: string, data: {[string]: any})
		--
		if (action == "grab") then
			--
			local grabbed = data.object
			local object: BasePart = data.object
			if (not object:HasTag("Grabbable")) then
				local parent = object.Parent
				if (parent:HasTag("Grabbable")) then
					object = parent
				end
			end
			--
			local chandler = characters.getCharacterBy(player.Character)
			if (chandler == nil or chandler.character:FindFirstChildOfClass("Tool")) then return false end
			if (object:GetAttribute("IsGrabbed") == true) then return false end
			--
			local function check()
				return _G.CheckIfCan(chandler.character,"Any") and not _G.CheckIfFlinching(chandler.character,true,true)  end
			if (not check()) then return end
			--
			task.spawn(function(to) 
				--
				local function setNetworkOwner(to)
					--
					local function set(part: BasePart)
						if (not part:IsA("BasePart") or not part:CanSetNetworkOwnership()) then return end
						part:SetNetworkOwner(to)
					end
					--
					set(object)
					for _, p in ipairs(object:GetDescendants()) do
						set(p) end
					--
				end
				--
				local obinds = {}
				for _, bind in ipairs(grabbables.binds) do
					if (bind.object == object) then
						bind.onGrabbed:Fire(chandler.character)
						table.insert(obinds, bind)
					end
				end
				--
				local dc = globals.DisableModelsCollision(object, chandler.character)
				globals.PlaySound(sounds.Grab, chandler.root, globals.Random(0.9, 1.1, 100))
				object:SetAttribute("ForceLetGo", false)
				object:SetAttribute("IsGrabbed", true)
				object:SetAttribute("Grabber", player.Name)
				globals.IncrementAttribute(object, "GrabKey", 1)
				setNetworkOwner(player)
				--
				repeat
					task.wait()
					setNetworkOwner(player)
				until (not object:GetAttribute("IsGrabbed") or not check() or object:GetAttribute("ForceLetGo"))
				--
				globals.SafeDestroy(dc, 0.5)
				globals.PlaySound(sounds.LetGo, chandler.root, globals.Random(0.9, 1.1, 100))
				object:SetAttribute("ForceLetGo", false)
				object:SetAttribute("IsGrabbed", false)
				object:SetAttribute("Grabber", nil)
				--
				for _, bind in ipairs(obinds) do
					bind.onDropped:Fire(chandler.character) end
				--
				local key = object:GetAttribute("GrabKey")
				task.spawn(function() 
					--
					local key = object:GetAttribute("GrabKey")
					local stilltime = 0
					local distance = (chandler.root.Position - grabbed.Position).Magnitude
					--
					repeat
						local dt = task.wait()
						--
						if (grabbed.AssemblyLinearVelocity.Magnitude >= 1) then
							stilltime = 0
						else
							stilltime += dt
						end
						--
						if (globals.SafeCheck(chandler.root)) then
							distance = (chandler.root.Position - grabbed.Position).Magnitude
						end
						--
					until (not globals.SafeCheck(chandler.root) or object:GetAttribute("IsGrabbed") or object:GetAttribute("GrabKey") ~= key) or (stilltime >= 3 and distance >= 32)
					--
					if (key == object:GetAttribute("GrabKey") and not object:GetAttribute("IsGrabbed")) then
						setNetworkOwner(nil) end
					--
				end)
				--
			end)
			--
			return true
		elseif (action == "ungrab") then
			--
			local object = data.object
			if (object:GetAttribute("IsGrabbed") and object:GetAttribute("Grabber") == player.Name) then
				object:SetAttribute("IsGrabbed", false)
			end
			--
		end
	end
	--
end
--
function grabbables.bind(to: BasePart)
	--
	local bind = {
		object = to,
		onGrabbed = framework.signal.new(),
		onDropped = framework.signal.new(),
	} table.insert(grabbables.binds, bind)
	--
	function bind:destroy()
		bind.object = nil
		bind.onGrabbed:Destroy()
		bind.onDropped:Destroy()
		globals.RemoveFromArray(grabbables.binds, bind)
	end
	--
	return bind
end
--
_G.GrabbablesSystem = grabbables
--
return grabbables