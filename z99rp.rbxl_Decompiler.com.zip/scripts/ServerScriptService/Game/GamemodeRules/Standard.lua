return {
	DeathCashDropMulti = 0.286; --0.286
	FinishSpeedMulti = 3;
	KillHPPerc = 0.2;
	
	LeaderboardEnabled = false;
	AllowAllAccessories = true;
	LootCashMulti = 1;
	MaxCratesMulti = 6;

	DefaultMap = "07-EXTENDED";
};