-- // Services
local HttpService = game:GetService("HttpService")

-- // Var
local CommentsAPI = {}
local Response

local Settings = script.Parent:WaitForChild("Settings")
local TrelloAPIKey = Settings:WaitForChild("TrelloKey").Value
local TrelloToken = Settings:WaitForChild("TrelloToken").Value


function CommentsAPI.CreateComment(CardId,Text)
	if not CardId or not Text then
		warn("[SERVER] CommentsAPI • [CreateComment] : Required Argoment is missing (CardId, Text).")
		return false
	end
	

	local Succ, Err = pcall(function()
		HttpService:PostAsync("https://api.trello.com/1/cards/" .. CardId .. "/actions/comments?key=" .. TrelloAPIKey .. "&token=" .. TrelloToken, HttpService:JSONEncode({text  = Text}))
	end)
	
	if not Succ then
		warn("[SERVER] CommentsAPI • [CreateComment] : ", Err)
		return false
	else
		return true
	end
	

end




return CommentsAPI
