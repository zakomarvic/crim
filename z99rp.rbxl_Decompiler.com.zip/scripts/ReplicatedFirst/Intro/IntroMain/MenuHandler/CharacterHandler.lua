local m = {}

local Debris = game:GetService("Debris")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local fWait = require(ReplicatedStorage:WaitForChild("Modules").FastWait)

function m.Start()
	--warn("Character sequencing..")
	
	--warn("Character1..")
	
	local function C1()
		local function A()
			m.char1.anims.sequence:Play()

			task.delay(m.char1.anims.sequence.Length,function()
				m.char1.anims.idle:Play()
				m.char1.anims.idle.Priority = Enum.AnimationPriority.Action3
				--m.char1.model.p.Parts.Head.Light.Color = Color3.fromRGB(255, 157, 0)
			
				m.char1.anims.rage.Looped = true
				m.char1.anims.rage.Priority = Enum.AnimationPriority.Action4
				m.char1.anims.rage:Play(0.1,0.015,1)
				
				--delay(0.8,function()
				--	local p = m.char1.model.Pumpkin

				--	p.Light.Color = m.char1_pc
				--	p.GlarePart.From.PointLight.Enabled = true
				--	p.GlarePart.From.Blind.Enabled = true
				--end)
				
			end)
		end
		local function S()
			fWait(4.5)
			
			m.char1.model.Torso.WeaponHandle.TriggerA.EquipSound:Play()
			
		end
		
		task.spawn(A)
		task.spawn(S)
	end
	
	local function C2()
		local function A()
			m.char2.anims.sequence:Play()
			task.delay(m.char2.anims.sequence.Length,function()
				
				--m.char2.model.p.Parts.Head.Light.Color = Color3.fromRGB(255, 157, 0)
				
				m.char2.anims.idle:Play()
				
				--delay(0.7,function()
				--	local p = m.char2.model.Pumpkin

				--	p.Light.Color = m.char2_pc
				--	p.GlarePart.From.PointLight.Enabled = true
				--	p.GlarePart.From.Blind.Enabled = true
				--end)
			end)
		end
		local function S()
			fWait(3.35)
			m.char2.model.Torso.WeaponHandle.TriggerA.EquipSound:Play()
		end
		
		task.spawn(A)
		task.spawn(S)
	end
	
	local function C3()
		local function HitEffect()
			local hitStuff = ReplicatedStorage:WaitForChild("Storage"):WaitForChild("HitStuff")
			local hitStuffF2 = hitStuff.Main
			
			local hitPart = m.char3.hitPart
			
			local function HitPart(hitName)
				local n = "HitSounds"
				local g
				
				if hitName == "Head" then
					local dir = "HitSounds_Head"

					local s2 = hitStuffF2[dir]:GetChildren()[math.random(1,#hitStuffF2[dir]:GetChildren())]:Clone()
					s2.PlaybackSpeed = s2.PlaybackSpeed * math.random(850,1150) / 1000
					s2.Volume *= 3
					--s2.EmitterSize *= 3
					s2:Play()
					Debris:AddItem(s2)		
					s2.Parent = hitPart
				end

				local s = hitStuffF2[n]:GetChildren()[math.random(1,#hitStuffF2[n]:GetChildren())]:Clone()
				s.PlaybackSpeed = s.PlaybackSpeed * math.random(750,1250) / 1000
				s.Parent = hitPart
				--s.EmitterSize *= 3
				s.Volume *= 3
				s:Play()
				Debris:AddItem(s)

				local a = m.char3.hitPart.Pos

				------------------------------------------------

				local bloodConfig = {
					Enabled = true;
					A = { -- Main
						Amount = 		{6,8};
						Speed = 		60;
						Spread = 		{-25,25};
						Size = 			4; -- Pool Size
						WidthScale =	1;
						UpVector = 		Vector3.new(0,-20,0);
						RepeatCount =	1; -- Amount of times to repeat
						RepeatTick =	0; -- Wait time between ticks
					};
					B = { -- Bleed out effect
						Amount = 		{1,1};
						Speed = 		15;
						Spread = 		{-15,15};
						Size = 			0.5; -- Pool Size
						WidthScale =	0.4;
						UpVector = 		Vector3.new(0,0,0);
						RepeatCount =	5; -- Amount of times to repeat
						RepeatTick =	0.5; -- Wait time between ticks
					};
				}


				if bloodConfig then
					ReplicatedStorage.Events2.BloodHitEvent:Fire(a)

					ReplicatedStorage.Events2.BloodTrailEvent:Fire(
						a, -- attachment
						bloodConfig.A,
						true,
						{0.2,1}
					)
					
					ReplicatedStorage.Events2.BloodTrailEvent:Fire(
						a, -- attachment
						bloodConfig.B,
						true,
						{0.2,1}
					)
					
					--			delay(math.random(100,750) / 1000,function()			
					--				Events2.BloodTrailEvent:Fire(
					--					a, -- attachment
					--					BS.B,
					--					true
					--				)
					--			end)

				end
			end

			for i = 1,4 do
				HitPart(i == 4 and "Head" or "Torso")
			end
			
			m.char3.model.BloodWallPart1.Blood.Transparency = 0
			m.char3.model.BloodWallPart2.Blood.Transparency = 0
		end
			
		local function ShootEffect()
			local muzzle = m.char3.muzzle
			
			local numSounds		= 0
			for _, s in pairs(muzzle:GetChildren()) do
				if string.match(s.Name, "FireSound%d+") then
					numSounds	= numSounds + 1
				end
			end
			
			local fSound,fSound2
			
			local m = muzzle["FireSound" .. tostring(math.random(numSounds))]
			fSound		= m:Clone()
			fSound.Name		= "FireSound_Clone"
			fSound.Parent	= muzzle	
			Debris:AddItem(fSound, (m.TimeLength / fSound.PlaybackSpeed) + 0.5)

			if muzzle:FindFirstChild("FFireSoundTWO") then
				fSound2		= muzzle.FFireSoundTWO:Clone()
				fSound2.Name		= "FireSound_2_Clone"
				fSound2.Parent	= muzzle	
				Debris:AddItem(fSound2, (muzzle.FFireSoundTWO.TimeLength / fSound2.PlaybackSpeed) + 0.5)
			end

			if fSound then
				fSound.PlaybackSpeed = fSound.PlaybackSpeed * (math.random(900,1100) / 1000)
				fSound:Play()

				if fSound2 then
					fSound2.PlaybackSpeed = fSound2.PlaybackSpeed * (math.random(900,1100) / 1000)
					fSound2:Play()
				end
			end

			local flashSettings = {
				Enabled = 		true;
				Brightness = 	4;
				Color = 		Color3.fromRGB(255, 244, 202);
				Range = 		6;
				Shadows = 		true;
				Time = 			0.1;
			};
			
			if true then
				local f = Instance.new("PointLight")
				f.Brightness = 	flashSettings.Brightness
				f.Color = 		flashSettings.Color
				f.Shadows = 	flashSettings.Shadows
				f.Range = 		flashSettings.Range
				f.Parent = muzzle

				Debris:AddItem(f,flashSettings.Time)
			end

			if muzzle:GetAttribute("AdvancedEmitter") then
				local chance1 = nil

				for i,v in pairs(muzzle:GetChildren()) do
					if v:isA("ParticleEmitter") and not v:GetAttribute("AdvancedIgnore") then
						local count = v:GetAttribute("EmitCount") or 1 

						local gotChance = v:GetAttribute("Chance1")

						local chance = gotChance

						--if not chance1 and gotChance then
						--	chance = gotChance
						--end
						if chance and math.random(1,chance) ~= 1 then
							--do nothing
						else
							v:Emit(count)
						end
					end
				end
			else
				if muzzle:FindFirstChild("FlashEmitter") then
					muzzle.FlashEmitter:Emit(5)
				end
				if muzzle:FindFirstChild("FlashEmitter2") then
					muzzle.FlashEmitter2:Emit(5)
				end
				if muzzle:FindFirstChild("SmokeEmitter") then
					muzzle.SmokeEmitter:Emit(5)
				end
			end
				
			task.wait()
			HitEffect()
		end
		m.char3.anims.sequence:GetMarkerReachedSignal("Shoot"):Connect(ShootEffect)
		
		m.char3.anims.sequence:Play()
	end
	
	local function C4()
		m.char4.anims.idle:Play(0,1,0.6)
		m.char5.anims.idle:Play(0,1,0.6)
		
		task.delay(2,function()
			m.char4.anims.sequence:Play(0.2)
		end)
	end
	
	C1()
	C2()	
	task.delay(0.25,C3)
	C4()
end

function m.SetUp(scene,config)
	m.scene = scene
	m.config = config

	m.char1 = {}
	m.char1.model = scene:WaitForChild("CM1")
	--m.char1.soundP = m.char1.model:WaitForChild("AKM"):WaitForChild("FHandle",30)
	m.char1.anim_controller = m.char1.model:WaitForChild("Humanoid")
	m.char1.anims = {}
	m.char1.anims.sequence = m.char1.anim_controller:LoadAnimation(script:WaitForChild("CHARACTER1_INTROSEQUENCE"))
	m.char1.anims.idle = m.char1.anim_controller:LoadAnimation(script.CHARACTER1_INTRO_IDLE:Clone())
	
	m.char1.anims.rage = m.char1.anim_controller:LoadAnimation(script.CHARACTER1_RAGE:Clone())
	
	m.char2 = {}
	m.char2.model = scene:WaitForChild("CM2")
	--m.char2.soundP = m.char2.model:WaitForChild("FAL"):WaitForChild("Base")
	m.char2.anim_controller = m.char2.model:WaitForChild("Humanoid")
	m.char2.anims = {}
	m.char2.anims.sequence = m.char2.anim_controller:LoadAnimation(script.CHARACTER2_INTROSEQUENCE:Clone())
	m.char2.anims.idle = m.char2.anim_controller:LoadAnimation(script.CHARACTER2_INTRO_IDLE:Clone())
	
	m.char3 = {}
	m.char3.model = scene:WaitForChild("Killer",1000)
	m.char3.model:WaitForChild("Torso",1000)

	--m.char2.soundP = m.char2.model:WaitForChild("FAL"):WaitForChild("Base")
	m.char3.anim_controller = m.char3.model:WaitForChild("Humanoid")
	m.char3.anims = {}
	m.char3.anims.sequence = m.char3.anim_controller:LoadAnimation(script.CHARACTER3_INTROSEQUENCE:Clone())
	m.char3.handle = m.char3.model.Torso.WeaponHandle
	m.char3.muzzle = m.char3.handle.Muzzle
	m.char3.hitPart = m.char3.model:WaitForChild("BloodEmitterPart")
		
	m.char4 = {}
	m.char4.model = scene:WaitForChild("DealerMan1")
	--m.char2.soundP = m.char2.model:WaitForChild("FAL"):WaitForChild("Base")
	m.char4.anim_controller = m.char4.model:WaitForChild("Humanoid")
	m.char4.anims = {}
	m.char4.anims.sequence = m.char4.anim_controller:LoadAnimation(script.NPC_IDLE_MOVE:Clone())
	m.char4.anims.idle = m.char4.anim_controller:LoadAnimation(script.NPC_IDLE:Clone())
	
	m.char5 = {}
	m.char5.model = scene:WaitForChild("DealerMan2")
	--m.char2.soundP = m.char2.model:WaitForChild("FAL"):WaitForChild("Base")
	m.char5.anim_controller = m.char5.model:WaitForChild("Humanoid")
	m.char5.anims = {}
	m.char5.anims.sequence = m.char5.anim_controller:LoadAnimation(script.NPC_IDLE_MOVE:Clone())
	m.char5.anims.idle = m.char5.anim_controller:LoadAnimation(script.NPC_IDLE:Clone())

	m.char1.anims.sequence.Priority = Enum.AnimationPriority.Action4
	m.char2.anims.sequence.Priority = Enum.AnimationPriority.Action4
	
	m.char1.anims.sequence:Play(0,0,0)
	m.char2.anims.sequence:Play(0,0,0)
	
	m.char3.anims.sequence:Play(0,0,0)
	
	m.char4.anims.idle.Looped = true
	m.char5.anims.idle:Play(0,0,0)
	
	m.char4.anims.idle:Play(0,0,0)
	m.char5.anims.idle:Play(0,0,0)
	m.char4.anims.sequence:Play(0,0,0)
	m.char5.anims.sequence:Play(0,0,0)
	m.char1.anims.idle:Play(0,0,0)
	m.char2.anims.idle:Play(0,0,0)
	
	m.char1.model.Torso.WeaponHandle.TriggerA.EquipSound:Play()
	m.char2.model.Torso.WeaponHandle.TriggerA.EquipSound:Play()
	task.delay(0,function()
		m.char1.model.Torso.WeaponHandle.TriggerA.EquipSound:Stop()
		m.char2.model.Torso.WeaponHandle.TriggerA.EquipSound:Stop()
	end)
	
	
	script:ClearAllChildren()
	
	--m.char1_pc = m.char1.model.Pumpkin.Light.Color
	--m.char1.model.Pumpkin.Light.Color = Color3.fromRGB(10,10,10)
	
	--m.char2_pc = m.char2.model.Pumpkin.Light.Color
	--m.char2.model.Pumpkin.Light.Color = Color3.fromRGB(10,10,10)
	
--	warn("Setup CameraHandler...")
end

return m