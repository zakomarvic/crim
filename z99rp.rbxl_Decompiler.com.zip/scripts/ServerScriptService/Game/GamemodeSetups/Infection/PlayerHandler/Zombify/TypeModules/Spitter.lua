local M = {}

local ReplicatedStorage = game:GetService("ReplicatedStorage")

function M.DoAppearance(char)
	local oldShirt = char:FindFirstChildOfClass("Shirt")
	local oldPants = char:FindFirstChildOfClass("Pants")
	if oldShirt then
		oldShirt:Destroy()
	end
	if oldPants then
		oldPants:Destroy()
	end

	for i,v in pairs(char.Humanoid:GetAccessories()) do
		v:Destroy()
	end

	script.Shirt:Clone().Parent = char
	script.Pants:Clone().Parent = char

	local bC = char:FindFirstChildOfClass("BodyColors")
	local color = BrickColor.new("Dark stone grey")
	
	if bC then
		bC.HeadColor = color
		bC.LeftArmColor = color
		bC.RightArmColor = color
		bC.LeftLegColor = color
		bC.RightLegColor = color
		bC.TorsoColor = color
	end

	local h = script.SpitterRig:Clone()
	h.Parent = char
	h.Script.Disabled = false

	local face = char.Head:FindFirstChild("face")
	if face then
		face:Destroy()
	end
	local newFace = script.NewZombieFace:Clone()
	newFace.Name = "Head"
	newFace.Parent = char.Head
	
	for i,v in pairs(char.Humanoid:GetAccessories()) do
		v:Destroy()
	end
	
	script.BloodSplatter:Clone().Parent = char.Torso
	local pe = script.ParticleEmitter:Clone()
	pe.Parent = char.Torso
	pe.Enabled = true
	
	local eyes = script.InfectedEyes:Clone()
	char.Humanoid:AddAccessory(eyes)
end

function M.new(char)
	local plr = game.Players:GetPlayerFromCharacter(char)
	local hum = char.Humanoid
	
	local HP = 50
	local SPEED_ADD = 2
	local JUMPADD = 30
	local ACCEL = 1.5

	local function DoMain()
		if not hum:GetAttribute("DontChangeHP") then
			hum.MaxHealth = HP + 15
			hum.Health = hum.MaxHealth
		end

		local vF = _G.GVF(char.Name)

		if vF then
			if not hum:GetAttribute("DontChangeHP") then
				for _,v in pairs(vF.HealthValues:GetChildren()) do
					local h = HP
					if v.Name == "Head" then
						--h /= 2
					end
					v.MaxValue = h
					v.Value = v.MaxValue
				end
			end	
			
			vF.MovementSoundModifier.Value = 1.25
			vF.AccelerationModifier.Value = ACCEL
			vF.FallDamageProof.Value = 0.35
			vF.BleedProof.Value *= 2
			
			local ACCEL_MULTI = 0.4
			local ACCEL_MAX = 20

			local b1 = Instance.new("NumberValue")
			b1.Name = "ACCLTRR"
			b1.Value = ACCEL_MULTI

			local b2 = Instance.new("NumberValue")
			b2.Name = "M"
			b2.Value =ACCEL_MAX
			b2.Parent = b1
			
			b1.Parent = vF.Currents
			
			local b3 = Instance.new("NumberValue")
			b3.Value = -20
			b3.Name = "SRV_SD_"
			b3.Parent = vF.Currents	
			
			_G.AffectChar(char,"JR",math.huge,"WKVL2",-JUMPADD)
			_G.AffectChar(char,"SD",math.huge,"WKVL2",-SPEED_ADD)
		end
		
		local REMOVE_COOLDOWN = 1.5
		
		spawn(function()
			while true do
				if not char:FindFirstChild("__Spitball") then
					hum:UnequipTools()
					local zf = game.ServerStorage.Tools["__Spitball"]:Clone()
					zf.Parent = plr.Backpack
					hum:EquipTool(zf)
					zf.AncestryChanged:Wait()
				else
					char.ChildRemoved:Wait()
				end
				
				if not char:FindFirstChild("__Spitball") then
					pcall(function()
						ReplicatedStorage.Events.CrosshairBar:FireClient(plr,REMOVE_COOLDOWN)
					end)
					task.wait(REMOVE_COOLDOWN)
				end
			end
			
		end)
	
		hum:SetAttribute("ForceWalkStage",3)
		hum:SetAttribute("ZSPRN_M",0.65)
		hum:SetAttribute("NACTIVFD",true)


		local animateS = char:WaitForChild("Animate",3)
		if animateS then
			for i,v in pairs({"idle1","idle2","idle3"}) do
				for i,v in pairs(animateS[v]:GetChildren()) do
					v.AnimationId = "rbxassetid://127585051698508"
				end
			end
			for i,v in pairs({"walk1","walk2","walk3"}) do
				for i,v in pairs(animateS[v]:GetChildren()) do
					v.AnimationId = "rbxassetid://83810348098685"
				end
			end
			--for i,v in pairs({"run1","run2","run3"}) do
			--	for i,v in pairs(animateS[v]:GetChildren()) do
			--		v.AnimationId = "rbxassetid://75745553966418"
			--	end
			--end
		end
		
		for i,v in pairs(hum:GetPlayingAnimationTracks()) do
			if v:GetAttribute("IsShakeAnim") then
				--v:AdjustSpeed(0.5)
				v:AdjustSpeed(2)
				v:AdjustWeight(0.1)
			end
		end
		
		local zSounds = script.Parent.Parent.ZombieSounds:Clone()
		script.Sounds:Clone().Parent = zSounds
		zSounds.Parent = char
		zSounds.Disabled = false
		zSounds.Enabled = true
		
		local bl = script.BreathingLoop:Clone()
		bl.Parent = char.Head
		bl:Play()
	end

	if plr then
		DoMain()
	end
	
	if not M.NormalM then
		M.NormalM = require(script.Parent.Normal)
	end
	M.DoAppearance(char)
end

return M