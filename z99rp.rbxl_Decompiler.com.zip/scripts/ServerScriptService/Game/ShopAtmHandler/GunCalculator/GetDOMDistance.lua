-- services

local ServerScriptService	= game:GetService("ServerScriptService")
local ReplicatedStorage		= game:GetService("ReplicatedStorage")
local Players				= game:GetService("Players")
local Debris				= game:GetService("Debris")

local function round(n)
	--return math.floor(n + 0.5)
	return math.floor(n * 100) / 100
end

local TARGET = 1 -- target damage for distance

return function(config)
	local damage	= config.Damage
	
	local minFallOff = config.MinDropoff or 25
	local falloffDistance = config.DropoffDistance or 300
	
	local dropOff = config.Dropoff
	
	dropOff = math.min(dropOff,1)
	dropOff = math.max(dropOff,0)

	local distanceUntilMin = math.max(falloffDistance * math.log(TARGET/damage, dropOff), 0)
	--distanceUntilMin = math.min(distanceUntilMin,config.Range)

	return distanceUntilMin
end