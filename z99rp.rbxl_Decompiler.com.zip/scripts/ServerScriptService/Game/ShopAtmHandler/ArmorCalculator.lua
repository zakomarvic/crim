local Calcs = {}

local ReplicatedStorage =	game:GetService("ReplicatedStorage")
local ServerStorage = 		game:GetService("ServerStorage")

local iS = ReplicatedStorage.Storage.ItemStats

local MaxSettings = {
	MeleeProof = 1;
	BleedReduction = 1;
	BlastReduction = 1;
	FlameResistance = 1;
	Mobility = 8;
	BulletReduction = 5;
}

local function GetTool(name)
	return ServerStorage.Tools:FindFirstChild(name)
end

function Calcs:UpdateStats(name)
	local tool = GetTool(name)
	if not tool then warn("No tool found: " .. name) return end

	local Config		= tool:FindFirstChild("Config") and require(tool.Config)
	if not Config then warn("No config found: " .. name) return end
	
	if Config.IsBackpack then
		local mobilityStat = Config.WS_Multi or 1
		if Config.AccelerationModifier then
			mobilityStat += Config.AccelerationModifier
			mobilityStat /= 2
		end
		
		local bars = script.Parent.VestBars:Clone()
		bars.Name = "Bars"
		
		for i,v in pairs(bars:GetChildren()) do
			if v.Name ~= "Mobility" then
				v:Destroy()
			end
		end
		
		bars.Mobility.Value = math.floor((16 * mobilityStat) + 0.5)
		bars.Mobility.Bar.Value = mobilityStat
		
		return bars,Config
	else
		if Config.ArmoredParts[1] == "Torso" then
			local meleeStat = 1 -Config.MeleeProof.Torso
			local explosiveStat = 1 - Config.ExplosiveProof
			local fireStat = 1 - Config.FireProof
			local bleedStat = 1 - Config.BleedProof
			local slotsStat = 1 - Config.Slots
			local hpStat = Config.HP
			
			local mobilityStat = Config.WS_Multi or 1
			if Config.AccelerationModifier then
				mobilityStat += Config.AccelerationModifier
				mobilityStat /= 2
			end

			local bars = script.Parent.VestBars:Clone()
			bars.Name = "Bars"

			bars.MeleeResistance.Value = math.floor(meleeStat * 100) .. "%"
			bars.MeleeResistance.Bar.Value = meleeStat

			bars.BlastResistance.Value = math.floor(explosiveStat * 100) .. "%"
			bars.BlastResistance.Bar.Value = explosiveStat

			bars.FlameResistance.Value = math.floor(fireStat * 100) .. "%"
			bars.FlameResistance.Bar.Value = fireStat

			bars.BleedReduction.Value = math.floor(bleedStat * 100) .. "%"
			bars.BleedReduction.Bar.Value = bleedStat

			bars.Mobility.Value = math.floor((16 * mobilityStat) + 0.5)
			bars.Mobility.Bar.Value = mobilityStat

			bars.HP.Value = hpStat

			return bars,Config
		else
			local meleeStat = Config.MeleeProof.Head and 1 - (Config.MeleeProof.Head)
			local concussStat = Config.ConcussionProof and 1 - (Config.ConcussionProof)
			local explosiveStat = Config.ExplosiveProof2 and 1 - (Config.ExplosiveProof2)
			local hpStat = Config.HP

			local bars = script.Parent.HelmetBars:Clone()
			bars.Name = "Bars"

			if meleeStat then
				bars.MeleeResistance.Value = math.floor(meleeStat * 100) .. "%"
				bars.MeleeResistance.Bar.Value = meleeStat
			else
				bars.MeleeResistance:Destroy()
			end

			if concussStat then
				bars.ConcussionReduction.Value = math.floor(concussStat * 100) .. "%"
				bars.ConcussionReduction.Bar.Value = concussStat
			else
				bars.ConcussionReduction:Destroy()
			end

			if explosiveStat then
				bars.ShellShockReduction.Value = math.floor(explosiveStat * 100) .. "%"
				bars.ShellShockReduction.Bar.Value = explosiveStat
			else
				bars.ShellShockReduction:Destroy()
			end

			if hpStat then
				bars.HP.Value = hpStat
			else
				bars.HP:Destroy()
			end

			return bars,Config
		end
	end
end

return Calcs