-- SERVER

local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
--
local emotesMedia = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Media"):WaitForChild("Emotes"))
local emotes = {}
--
function emotes.init()
	_G.EmotesSystem = emotes
end
--
function emotes.play(character: Model, emote: string)
	task.spawn(function() 
		--
		local character_handler: types.character = framework.Gs.GetCharacterHandler(character)
		local character_values: types.values = framework.Gs.GVF(character.Name)
		if (emote == "" or emotesMedia[emote] == nil or character:GetAttribute("UsingEmote") and character:GetAttribute("EmoteName") == emote) then return end
		--
		local function check()
			if (not framework.Gs.SafeCheck({character, character_handler.root, character_handler.humanoid})) then return end
			if not (_G.CheckIfCan(character)) then return end
			return not character_handler.humanoid.PlatformStand and character_handler.humanoid.Health > 0 and not character_values.GiftingStatus.Value
		end if (not check()) then return end
		--
		local emote_data = emotesMedia[emote]
		local emote_temp = {}
		local emote_start_os = os.clock()
		local should_cancel = false
		local emote_health = character_handler.humanoid.Health
		--
		local a_sp = framework.Gs.AffectChar(character, "SP", math.huge, "Emote", 0)
		local a_b = framework.Gs.AffectChar(character, "B", math.huge, "Emote")
		--
		if (emote_data.animation) then
			local emote_animation: AnimationTrack = character_handler.humanoid:LoadAnimation(emote_data.animation)
			emote_animation:Play(0.1)
			emote_temp.animation = emote_animation
		end
		--
		if (emote_data.music) then
			local music = emote_data.music:Clone()
			music.Parent = character_handler.root
			music:Play()
			local base_volume = music.Volume
			framework.services.TweenService:Create(music, TweenInfo.new(0.1, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {Volume = base_volume}):Play()
			emote_temp.music = music
		end
		--
		character_handler.humanoid:UnequipTools()
		character:SetAttribute("UsingEmote", true)
		character:SetAttribute("EmoteName", emote)
		framework.Gs.IncrementAttribute(character, "EmoteKey", 1)
		local emote_key = character:GetAttribute("EmoteKey")
		local cam_head_lock = framework.Gs.Create("Model", "CamHeadLock", character)
		--
		if (emote_data.onStart) then
			emote_data.onStart(character, emote_temp)
		end
		--
		if (emote_data.loops ~= true) then
			emote_temp.animation.Stopped:Connect(function() 
				should_cancel = true
			end)
		end
		--
		if (emote_data.sync_music_on_animation_loop) then
			emote_temp.animation.DidLoop:Connect(function() 
				emote_temp.music.TimePosition = 0 
				emote_temp.music:Play()
			end)
		end
		--
		repeat
			task.wait()
			--
			if (check()) then
				character_handler.humanoid:UnequipTools()
				if (character_handler.humanoid.Health ~= emote_health) then
					if (character_handler.humanoid.Health > emote_health) then
						emote_health = character_handler.humanoid.Health
					else
						should_cancel = true
					end
				end
			else
				should_cancel = true
			end
			--
		until (should_cancel or (character:GetAttribute("EmoteKey") ~= emote_key)) or ((os.clock() - emote_start_os) >= 0.3 and character_handler.humanoid.MoveDirection.Magnitude >= 0.05)
		--
		if (emote_data.onEnd) then
			emote_data.onEnd(character, emote_temp)
		end
		--
		if (emote_temp.animation) then
			emote_temp.animation:Stop(0.1)
		end
		--
		if (emote_temp.music) then
			framework.services.TweenService:Create(emote_temp.music, TweenInfo.new(0.3, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {Volume = 0}):Play()
			framework.Gs.SafeDestroy(emote_temp.music, 0.3)
		end
		--
		framework.Gs.SafeDestroy({cam_head_lock, a_sp, a_b})
		if (character:GetAttribute("EmoteKey") == emote_key) then
			character:SetAttribute("UsingEmote", false)
			character:SetAttribute("EmoteName", nil)
		end
		--
	end)
end
--
return emotes