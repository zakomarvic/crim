local M = {}

function M.DoAppearance(char)
	local hum = char:FindFirstChildOfClass("Humanoid")
	
	local bc = char:FindFirstChildOfClass("BodyColors")

	local n = Color3.new(0.764706, 0.729412, 0.643137)

	if bc then
		local blackColors = {
			BrickColor.new("Pine Cone");
			BrickColor.new("Medium brown");
			BrickColor.new("Brown");
		}

		local x = n

		if table.find(blackColors,bc.HeadColor) then
			x = Color3.new(0.156863, 0.14902, 0.129412)
		end
		bc.HeadColor3 = bc.HeadColor3:Lerp(x,0.85)
		bc.TorsoColor3 = bc.TorsoColor3:Lerp(x,0.85)
		bc.LeftArmColor3 = bc.LeftArmColor3:Lerp(x,0.85)
		bc.RightArmColor3 = bc.RightArmColor3:Lerp(x,0.85)
		bc.LeftLegColor3 = bc.LeftLegColor3:Lerp(x,0.85)
		bc.RightLegColor3 = bc.RightLegColor3:Lerp(x,0.85)
	end

	local of = char.Head:FindFirstChild("face")
	if of then
		of:Destroy()
	end

	local ohm = char.Head:FindFirstChildOfClass("SpecialMesh")
	if ohm then
		ohm:Destroy()
	end

	for i,v in pairs(hum:GetAccessories()) do
		if v:FindFirstChildWhichIsA("BasePart") and v:FindFirstChildWhichIsA("BasePart"):FindFirstChild("FaceFrontAttachment") then
			v:Destroy()
		end
	end

	local humdesc = hum:FindFirstChildOfClass("HumanoidDescription")
	if humdesc and humdesc:GetAttribute("IsMask") then
		humdesc.FaceAccessory = ""

		local succ,err = pcall(function()
			char.Humanoid:RemoveAccessories()

			char.Humanoid:ApplyDescription(humdesc)
		end)
	end

	local hm = Instance.new("SpecialMesh")
	hm.Scale = Vector3.new(1.25,1.25,1.25)
	hm.MeshType = Enum.MeshType.Head
	hm.Parent = char.Head

	local f = script.ZombieFace:Clone()
	f.Name = "face"
	f.Parent = char.Head

	local eyes = script.InfectedEyes:Clone()
	hum:AddAccessory(eyes)

	local shirt = char:FindFirstChildOfClass("Shirt")
	local pants = char:FindFirstChildOfClass("Pants")

	if shirt then
		shirt.Color3 = shirt.Color3:Lerp(Color3.new(),0.5)
	end
	if pants then
		pants.Color3 = pants.Color3:Lerp(Color3.new(),0.5)
	end
end

function M.new(char)
	local plr = game.Players:GetPlayerFromCharacter(char)
	local hum = char.Humanoid
	
	local HP = 70
	local SPEED_ADD = 0
	local JUMPADD = 5

	local function DoMain()
		if not hum:GetAttribute("DontChangeHP") then
			hum.MaxHealth = HP + 15
			hum.Health = hum.MaxHealth
		end

		local vF = _G.GVF(char.Name)

		if vF then
			if not hum:GetAttribute("DontChangeHP") then
				for _,v in pairs(vF.HealthValues:GetChildren()) do
					local h = HP
					if v.Name == "Head" then
						h /= 2
					end
					v.MaxValue = h
					v.Value = v.MaxValue
				end
			end	

			vF.MovementSoundModifier.Value = 1.5
			vF.AccelerationModifier.Value = 0.65
			vF.FallDamageProof.Value = 0.5
			vF.BleedProof.Value *= 2
			
			local ACCEL_MULTI = 0.25
			local ACCEL_MAX = 4

			local b1 = Instance.new("NumberValue")
			b1.Name = "ACCLTRR"
			b1.Value = ACCEL_MULTI

			local b2 = Instance.new("NumberValue")
			b2.Name = "M"
			b2.Value =ACCEL_MAX
			b2.Parent = b1
			
			b1.Parent = vF.Currents
			
			_G.AffectChar(char,"JR",math.huge,"WKVL2",-JUMPADD)
			_G.AffectChar(char,"SD",math.huge,"WKVL2",-SPEED_ADD)
		end
		
		local zf = game.ServerStorage.Tools["__ZombieFists1"]:Clone()
		zf.Parent = plr.Backpack
		
		delay(1,function()
			if not hum:GetAttribute("NoAutoEquip") and _G.CheckIfCan(char) then
				hum:EquipTool(zf)
			end
			spawn(function()
				while hum and hum.Parent and hum.Health > 0 do
					if zf.Parent and zf.Parent ~= char and not hum:GetAttribute("NoAutoEquip") and _G.CheckIfCan(char) then
						hum:EquipTool(zf)
					elseif not _G.CheckIfCan(char) then
						hum:UnequipTools()
					end
					task.wait(0.35)
				end
			end)
		end)
		
		hum:SetAttribute("ForceWalkStage",3)
		hum:SetAttribute("ZSPRN_M",0.65)

		local animateS = char:WaitForChild("Animate",3)
		if animateS then
			for i,v in pairs({"idle1","idle2","idle3"}) do
				for i,v in pairs(animateS[v]:GetChildren()) do
					v.AnimationId = "rbxassetid://91707341131533"
				end
			end
			for i,v in pairs({"walk1","walk2","walk3"}) do
				for i,v in pairs(animateS[v]:GetChildren()) do
					v.AnimationId = "rbxassetid://72891423307076"
				end
			end
			--for i,v in pairs({"run1","run2","run3"}) do
			--	for i,v in pairs(animateS[v]:GetChildren()) do
			--		v.AnimationId = "rbxassetid://75745553966418"
			--	end
			--end
		end	
		
		local zSounds = script.Parent.Parent.ZombieSounds:Clone()
		script.Sounds:Clone().Parent = zSounds
		zSounds.Parent = char
		zSounds.Disabled = false
		zSounds.Enabled = true
	end

	if plr then
		DoMain()
	end
	
	M.DoAppearance(char)
end

return M