return function() 
	local SCALE_TAG = "UIScale"
	local SCALE_ATTRIBUTE = "Scale"
	local RESOLUTION_ATTRIBUTE = "Resolution"

	local DEFAULT_SCALE = 1
	local DEFAULT_RESOLUTION = 720

	local Collection = game:GetService("CollectionService")

	local camera = workspace.CurrentCamera

	local currentScale = script:GetAttribute(SCALE_ATTRIBUTE)
	if currentScale == nil then
		currentScale = DEFAULT_SCALE
		script:SetAttribute(SCALE_ATTRIBUTE, currentScale)
	end

	local resolution = script:GetAttribute(RESOLUTION_ATTRIBUTE)
	if resolution == nil then
		resolution = DEFAULT_RESOLUTION
		script:SetAttribute(RESOLUTION_ATTRIBUTE, resolution)
	end

	local multiplier = 1/resolution

	local scales = {}

	local function applyScale(scale)
		scale.Scale = currentScale
	end

	local function scaleAdded(scale)
		assert(scale:IsA("UIScale"), scale:GetFullName() .. " is not a UIScale")

		applyScale(scale)
		table.insert(scales, scale)
	end

	local function scaleRemoved(scale)
		local index = table.find(scales, scale)
		if index then
			table.remove(scales, index)
		end
	end

	local function updateScale()
		local sizeX, sizeY = camera.ViewportSize.X, camera.ViewportSize.Y
		if sizeY < sizeX then
			currentScale = multiplier * sizeY
		else
			currentScale = multiplier * sizeX
		end

		script:SetAttribute(SCALE_ATTRIBUTE, currentScale)

		for i, scale in ipairs(scales) do
			applyScale(scale)
		end
	end

	for i, scale in ipairs(Collection:GetTagged(SCALE_TAG)) do
		scaleAdded(scale)
	end

	updateScale()

	script:GetAttributeChangedSignal(RESOLUTION_ATTRIBUTE):Connect(function()
		resolution = script:GetAttribute(RESOLUTION_ATTRIBUTE)
		multiplier = 1/resolution
		updateScale()
	end)
	camera:GetPropertyChangedSignal("ViewportSize"):Connect(updateScale)
	Collection:GetInstanceAddedSignal(SCALE_TAG):Connect(scaleAdded)
	Collection:GetInstanceRemovedSignal(SCALE_TAG):Connect(scaleRemoved)
end