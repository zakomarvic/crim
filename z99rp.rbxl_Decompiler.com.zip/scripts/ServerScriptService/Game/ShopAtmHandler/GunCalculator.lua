local Calcs = {}

local ReplicatedStorage =	game:GetService("ReplicatedStorage")
local ServerStorage = 		game:GetService("ServerStorage")

local MODULES	= ReplicatedStorage:WaitForChild("Modules")
	local CONFIG	= require(MODULES.Config)

local GetDOMDistanceM = require(script.GetDOMDistance)

local MaxSettings = {
	Damage =	100;
	FireRate =	16;
	Accuracy =	45;
	Range =		1000;
	Recoil =	65;
	Mobility =	8;
	DamageRange = 5000;
}

local configs = {}

local function GetTool(name)
	return ServerStorage.Tools:FindFirstChild(name)
end

local function Round(to_round,n)
	local divided = to_round / n
	local rounded = n * math.floor(divided + 0.5)
	return rounded
end

local function GetConfig(name)
	if not configs[name] then
		local config = game.ServerStorage.ToolModules.Guns:FindFirstChild(name)
		if config then
			config = require(config)
		end
		
		configs[name] = config
		
		return config	
	else
		return configs[name]
	end
end


function Calcs:GetDamage(name)
	local tool = GetTool(name)
	if not tool then warn("No tool found: " .. name) return "N/A" end
	
	local Config		= GetConfig(name)
	if not Config then warn("No config found: " .. name) return "N/A" end
	
	local dmg = Config.Damage
	--dmg = dmg * Config.BulletsPerShot
	
	local perc = dmg / MaxSettings.Damage
	
	local minDmg = math.floor((dmg * 0.3) + 0.5)
	
	if Config.BulletsPerShot > 1 then
		dmg = tostring(math.floor(dmg + 0.5)) .. " x" .. Config.BulletsPerShot 
	end
	
	return tostring(dmg),perc
		--.. " -> " .. tostring(minDmg)
end

function Calcs:GetFireRate(name)
	local Config		= GetConfig(name)
	if not Config then warn("No config found: " .. name) return "N/A" end

	local rate = nil

	if Config.ShotgunSettings and Config.ShotgunSettings.FirePump then
		local p1 = 1 / Config.ShotgunSettings.FirePumpWait1
		local p2 = 1 / Config.ShotgunSettings.FirePumpWait2

		rate = p1 + p2 + (1 / Config.FireRate)

		rate = 1 / rate
	else
		rate = Config.FireRate
	end

	local perc = rate / MaxSettings.FireRate
	--perc = math.clamp( 1 - perc,0,1)
	--perc = 1 - perc
	perc = math.min(perc,1)
	rate = math.floor(rate * 10) / 10

	return tostring(rate),perc
end

function Calcs:GetRange(name)
	local tool = GetTool(name)
	if not tool then warn("No tool found: " .. name) return "N/A" end
	
	local Config		= GetConfig(name)
	if not Config then warn("No config found: " .. name) return "N/A" end
	
	local range = Config.Range
	
	--local perc = range / MaxSettings.Range
	--perc = math.clamp( 1 - perc,0,1)
	--perc = 1 - perc
	
	return tostring(range)
end

function Calcs:GetAccuracy(name)
	local tool = GetTool(name)
	if not tool then warn("No tool found: " .. name) return "N/A" end
	
	local Config		= GetConfig(name)
	if not Config then warn("No config found: " .. name) return "N/A" end
	
	local accuracy = Config.Spread
	
	local perc = accuracy / MaxSettings.Accuracy
	perc = math.clamp( 1 - perc,0,1)
	perc = 1 - perc
	
	return tostring(math.floor(Config.Spread  +0.5)),perc
end

function Calcs:GetMobility(name)
	local tool = GetTool(name)
	if not tool then warn("No tool found: " .. name) return "N/A" end
	
	local Config		= GetConfig(name)
	if not Config then warn("No config found: " .. name) return "N/A" end
	
	local mobility = (Config.SlowDown.Enabled and (16 - Config.SlowDown.Amount)) or 16
	
	local perc = mobility / MaxSettings.Mobility
	perc = math.clamp( 1 - perc,0,1)
	perc = 1 - perc
	
	return tostring(mobility),perc
end

function Calcs:GetAmmo(name)
	local tool = GetTool(name)
	if not tool then warn("No tool found: " .. name) return "N/A" end
	
	local Config		= GetConfig(name)
	if not Config then warn("No config found: " .. name) return "N/A" end
	
	return tostring(Config.MagSize .. "/" .. Config.StoredAmmo)
end

function Calcs:GetFireMode(name)
	local tool = GetTool(name)
	if not tool then warn("No tool found: " .. name) return "N/A" end
	
	local Config		= GetConfig(name)
	if not Config then return warn("No config found: " .. name) .. "N/A" end
	
	local fm = "N/A"
	
	
	if Config.FireModeSettings.DisplayMode ~= nil then
		fm =  tostring(Config.FireModeSettings.DisplayMode)
	elseif Config.ShotgunSettings.FirePump then
		fm = "Pump"
	else
		fm =  tostring(Config.FireModeSettings.FireMode)
	end

	if Config.FireModeSettings.CanSwitch and Config.FireModeSettings.SwitchTo then
		fm = fm .. (" | " .. Config.FireModeSettings.SwitchTo)
	end
	
	return fm
end

function Calcs:GetArmorPenetration(name)
	local tool = GetTool(name)
	if not tool then warn("No tool found: " .. name) return "N/A" end

	local Config		= GetConfig(name)
	if not Config then return warn("No config found: " .. name) .. "N/A" end

	local amt = Config.ArmorPenetration
	local perc = amt and amt/1
	

	return amt,perc
end

function Calcs:GetRecoilControl(name)
	local tool = GetTool(name)
	if not tool then warn("No tool found: " .. name) return "N/A" end

	local Config		= GetConfig(name)
	if not Config then return warn("No config found: " .. name) .. "N/A" end

	local amt = Config.Recoil
	
	local perc = amt / MaxSettings.Recoil
	perc = math.clamp( 1 - perc,0,1)
	--perc = 1 - perc

	return amt,perc
end

function Calcs:GetExplosive(name)
	local tool = GetTool(name)
	if not tool then warn("No tool found: " .. name) return "N/A" end

	local Config		= GetConfig(name)
	if not Config then return end

	return Config.RocketLauncherEnabled or Config.GrenadeLauncherEnabled
end

function Calcs:GetDamageRange(name)
	local tool = GetTool(name)
	if not tool then warn("No tool found: " .. name) return "N/A" end

	local Config		= GetConfig(name)
	if not Config then warn("No config found: " .. name) return "N/A" end

	local damageRange = GetDOMDistanceM(Config)
	
	if damageRange > 500 then
		damageRange = Round(damageRange,50)
	elseif damageRange > 50 then
		damageRange = Round(damageRange,10)
	else
		damageRange = Round(damageRange,1)
	end
	
	local perc = damageRange / MaxSettings.DamageRange
	perc = math.clamp( 1 - perc,0,1)
	perc = 1 - perc

	return damageRange,perc
end

return Calcs