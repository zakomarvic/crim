return function()
	local messaging = require(script.Parent.Parent:WaitForChild("systems"):WaitForChild("messaging"))
	local teleportationTopic = messaging:createTopic("teleportationTopic")
	--
	_G.STeleportPlayers = function(playerslist, reserveservercode, isprimary, teleportdelay)
		if (isprimary == nil) then isprimary = false end
		if (teleportdelay == nil) then teleportdelay = 1 end
		print("S TELEPORT PLAYERS RAN: ".. tostring(isprimary))
		for _, plr in ipairs(playerslist) do
			print("PLR IS IN ARRAY SUPPLIED: ".. plr) end
		--
		print("CODE PART 1")
		local tpoptions = Instance.new("TeleportOptions")
		if (reserveservercode == nil) then
			reserveservercode = game:GetService("TeleportService"):ReserveServer(game.PlaceId) end
		tpoptions.ReservedServerAccessCode = reserveservercode
		--
		print("CODE PART 2")
		local playersarray = {}
		for _, gstr in ipairs(playerslist) do
			local gplr = game.Players:FindFirstChild(gstr)
			if (gplr) then table.insert(playersarray, gplr) end
		end
		--
		print("CODE PART 3: TELEPORT DELAY FUNCTION")
		for _, plr in ipairs(playersarray) do
			print("PLR IS IN ARRAY: ".. plr.Name) end
		task.delay(teleportdelay, function() 
			--
			print("GOT TO TELPORT PART, DELAY FUNCTION RAN")
			for _, plr in ipairs(playersarray) do
				print("TELPORTING: ".. plr.Name)
			end
			--
			if (#playersarray > 0) then
				game:GetService("TeleportService"):TeleportAsync(game.PlaceId, playersarray, tpoptions) end
			if (isprimary) then
				teleportationTopic:send("teleportPlayers", {players = playerslist, reserve = reserveservercode}) end
			--
		end)
		--
		return reserveservercode
	end
	--
	teleportationTopic.onSent = function(data)
		print("Server got messaging data msg: ".. data.msg)
		if (not game:GetService("RunService"):IsStudio() and (data.serverJobId ~= game.JobId)) then
			--
			local msg = data.msg
			local msgdata = data.data
			--
			print("SAFELY RUNNING THE ONSENT")
			if (msg == "teleportPlayers") then
				print("RUNNING THE S TELEPORT PLAYERS FUNCTION")
				_G.STeleportPlayers(msgdata.players, msgdata.reserve, false, 1)
			end
			--
		end
	end
	--
end