return {
	--
	["SD"] = 2,
	["ND"] = 2,
	["SP"] = 2,
	["JR"] = 2,
	["DmgM1"] = 2,
	["MS"] = 2,
	["S_SWST"] = 2,
	["BDRM"] = 2,
	["BGDRM"] = 2,
	["BMDRM"] = 2,
	["CMAM"] = 2,
	["MHPM"] = 2,
	["MHPI"] = 2,
	--
	["DRSTNCE"] = 1,
	--
}