local TweenService = 		game:GetService("TweenService")
local ServerStorage = 		game:GetService("ServerStorage")
local PhysicsService = 		game:GetService("PhysicsService")
local CollectionService = 	game:GetService("CollectionService")
local Players = 			game:GetService("Players")
local ReplicatedStorage = 	game:GetService("ReplicatedStorage")
local RunService = 			game:GetService("RunService")
local ServerScriptService = game:GetService("ServerScriptService")

local types = require(ReplicatedStorage:WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(ReplicatedStorage:WaitForChild("PlantsStorage"):WaitForChild("Framework"))

local safeAnimationIds = require(ReplicatedStorage:WaitForChild("Assets"):WaitForChild("TastiestChips"):WaitForChild("media"):WaitForChild("SafeRagdollAnimations"))
local bloodAttachments =	ReplicatedStorage.Storage.BloodStuff.BloodAttachments
local eventsFolder = 		ReplicatedStorage.Events
local modules = ReplicatedStorage.Modules

local SetCharPhysicalPropertiesModule =	require(modules.SetCharPhysicalProperties)

local RandomAvatarM = require(ServerScriptService.RandomAvatar)

local pSoundsDir = game.ServerStorage.Storage.PlayerSounds

local function Lerp(a, b, c)
	return a + ((b - a) * c)
end

local config = {
	NoBlackBodyColor = true;

	MaxAccessorySizeMagnitude = 6;

	REGEN_RATE = 1/60; -- Regenerate this fraction of MaxHealth per second.
	REGEN_STEP = 1; -- Wait this long between each regeneration step.

}

local function Round(to_round,n)
	local divided = to_round / n
	local rounded = n * math.floor(divided)
	return rounded
end

return function(character,values,isNPC,doRandomAppearance,randomAppearanceSeed,randomAppearanceSave,hideName)
	local player = Players:GetPlayerFromCharacter(character)

	local humanoid = character:WaitForChild("Humanoid")
	local root = character:WaitForChild("HumanoidRootPart")
	local torso
	if character:GetAttribute("Shifter")==true then
		torso = character:WaitForChild("UpperTorso")
	else
		torso = character:WaitForChild("Torso")
	end

	if player or game.Players:FindFirstChild(character.Name) and player.TeamColor ~= BrickColor.new("Black") then
		humanoid.HealthDisplayType = Enum.HumanoidHealthDisplayType.AlwaysOff
		humanoid:SetStateEnabled(Enum.HumanoidStateType.FallingDown,false)
		humanoid:SetStateEnabled(Enum.HumanoidStateType.GettingUp,false)
	end

	if not (script and script.Parent) then return end

	local RagdollServer = require(script.RagdollServer)

	local ragdollTime = values:WaitForChild("RagdollTime")
	local light = script.PointLight:Clone()
	local limbs = {"Head";"Left Arm";"Right Arm";"Left Leg";"Right Leg"}

	if not character:GetAttribute("Shifter") then
		character:WaitForChild("Right Arm",1)
		character:WaitForChild("Left Arm",1)
	end

	local downedBloodA = torso:WaitForChild("WaistCenterAttachment"):Clone()
	downedBloodA.WorldCFrame = CFrame.new(downedBloodA.WorldPosition + Vector3.new(0,0.5,0),Vector3.new(0,-100,0))
	downedBloodA.Name = "DownedBloodA"
	downedBloodA.Parent = root

	local DiedE,HealthCE,CharE,RegenE,pStandE
	local brokeCons = {}

	local d = false
	local inCombat
	local ded = false
	local downBleedVal
	local hValues = {}
	local temps = {}
	local cancelRegen = false
	local lHealth = humanoid.Health
	local lastStep = 0

	local reviveGUI,bOutGUI

	values.NoDowned.Value = ServerStorage.Values.DowningDisabled.Value
	character:SetAttribute("spawnOs", os.clock())
	character:SetAttribute("passive", false)

	local function DisconnectAll()
		if d then return end
		d =  true
		DiedE:Disconnect()
		HealthCE:Disconnect()
		CharE:Disconnect()	
		pStandE:Disconnect()
		DiedE,HealthCE,CharE,DiedE,pStandE = nil,nil,nil,nil

		for _,v in pairs(brokeCons) do
			v:Disconnect()
		end

		limbs = nil

		ragdollTime = nil
	end

	local function Died()
		if ded then return end

		if humanoid and humanoid.Parent then
			humanoid:SetAttribute("DeathTick",tick())
		end

		ded = true
		--humanoid.HealthDisplayType = Enum.HumanoidHealthDisplayType.AlwaysOn
		values.Grabbed.Value = false

		if downBleedVal and downBleedVal.Parent then
			downBleedVal:Destroy()
		end
		downBleedVal = nil

		if reviveGUI and reviveGUI.Parent then
			reviveGUI:Destroy()
		end
		if bOutGUI and bOutGUI.Parent then
			bOutGUI:Destroy()
		end

		local legacyDowning = ReplicatedStorage.Values.LegacyDowningSystem.Value

		if character:FindFirstChild("Torso") and not humanoid:GetAttribute("NoDeathIcon") then
			local gui = ReplicatedStorage.Storage.GUIs.DeadGUI:Clone()
			gui.Parent = character:FindFirstChild("Torso")
			gui.Adornee = character:FindFirstChild("Torso")
			gui.PlayerToHideFrom = player
			gui.Enabled = true
		end

		if character:FindFirstChild("Head") and character.Head:FindFirstChild("DownedBreathing") then
			character.Head:FindFirstChild("DownedBreathing"):Destroy()
		end

		if not values.Handcuffed.Value then
			for _,v in pairs(humanoid:GetPlayingAnimationTracks()) do
				if (safeAnimationIds[v.Animation.AnimationId] ~= true) then
					v:Stop(0.5)
				end
			end
		end

		for _,v in pairs(character:GetDescendants()) do
			if v:IsA("BasePart") then
				pcall(function()
					if v.Name ~= "Collider" and v.Name ~= "Collide" and not v:GetAttribute("IsRagdollCollider") then
						v.CanCollide = false
						v.CollisionGroup = "RagdollCollide4"
					else
						v.CollisionGroup = "RagdollCollide3"
					end
				end)
			end
		end

		SetCharPhysicalPropertiesModule(character,0.8)

		if character:FindFirstChild("Head") then
			for _,v in pairs(character.Head:GetChildren()) do
				if v:IsA("Sound") then
					if character.Head.Transparency <0.95 and v:FindFirstChild("Vocal") then
						local t = TweenService:Create(v,TweenInfo.new(0.2,Enum.EasingStyle.Quad,Enum.EasingDirection.Out),{Volume = 0})
						t:Play()
					elseif character.Head.Transparency >= 0.95 and (v:FindFirstChild("Vocal") or v:FindFirstChild("Vocal2")) then
						v:Stop()
						v.Volume = 0
					end
				end
			end

			local con
			con = character.Head.ChildAdded:Connect(function(s)
				if s:IsA("Sound") and s:FindFirstChild("Vocal") and not s:FindFirstChild("Vocal2") then
					s.Volume = 0
				end
			end)

			RunService.Heartbeat:Wait()

			if character:FindFirstChild("Torso") then
				if (character.Torso:FindFirstChild("Neck") or character.Torso:FindFirstChild("RGAB_Neck")) and not values.Currents:FindFirstChild("DRWNS_DB") then
					local s = pSoundsDir.Head["Death" .. math.random(1,6)]:Clone()
					s.PlaybackSpeed = s.PlaybackSpeed * math.random(90,110) / 100
					s.Parent = character.Head
					s:Play()
				end
			end

			pcall(function()
				character.Head.face:Destroy()
				ServerStorage.Storage.Other.DeadFace:Clone().Parent = character.Head
			end)
		end
		if character:FindFirstChild("Torso") and not ReplicatedStorage.Values.LOutage.Value and not humanoid:GetAttribute("NoDeathIcon") then
			light.Color = Color3.new(1,0,0)
			light.Brightness = 5
			light.Range = 7
			light.Parent = character.Torso
		end

		--if character:FindFirstChild("HumanoidRootPart") then
		--	character.HumanoidRootPart.CustomPhysicalProperties = PhysicalProperties.new(3)
		--end

		DisconnectAll()		
	end

	local function DoFuncs()
		HealthCE = humanoid.HealthChanged:Connect(function(health)
			if character:GetAttribute("Shifts") and character:GetAttribute("Shifts")>0 and not character:GetAttribute("Shifting") and not character:GetAttribute("ForceShifted") then
				if health<=1 then
					character:SetAttribute("ForceShifted",true)
					humanoid:SetAttribute("SecondStatus",true)
					humanoid.Health=humanoid.MaxHealth
					health=humanoid.Health
					local FF=Instance.new("ForceField",character)
					FF.Visible=false
					ragdollTime.Value = 0
					local titan
					local speed
					--
					if character:FindFirstChild("_shiftClient") then
						titan=character["_shiftClient"]:GetAttribute("Titan")
						speed=character["_shiftClient"]:GetAttribute("Speed")
					end
					--
					ServerStorage.Events3.Shift:Fire(player,"shift",{Forced=true,Speed=speed,Titan=titan})

					local Creator = _G.GetTag(player)
					if Creator and Creator.Parent and Creator.Value and Creator.Value.Parent then
						local fakeChar = require(ServerStorage.Modules.Other.CreateViewportCharacter)(player)
						ServerStorage.Events3.nBount:Fire("KLGHJRKR90U3893KJZDGNKDFZJKNWU9023JKWRG02",Creator.Value,10)
						ServerStorage.Events3.AyuP:Fire("KLJ8902209SANK8234LDFG0OKJAKA984231ZZ04LGXBNBZ1U912",Creator.Value,500)
						ReplicatedStorage.Events.KillEvent:FireClient(Creator.Value,humanoid.DisplayName,player.UserId,"FORCE SHIFTED",nil,500,false,fakeChar)
					end
					return
				end
			end
			--
			if character:GetAttribute("UnShifting") then 
				return end
			--
			if health<=1 then
				if not (values.HealthValues.Head.Destroyed.Value or (values.HealthValues["Left Leg"].Destroyed.Value and values.HealthValues["Right Leg"].Destroyed.Value)) then
					--
					if character:GetAttribute("Resonance") and not character:GetAttribute("ResonanceProcced") then
						--
						local BV=_G.Create("BodyVelocity","Float",torso,{{"MaxForce",Vector3.new(math.huge,math.huge,math.huge)},{"Velocity",Vector3.new(0,0.75,0)}},true)
						local BG=_G.Create("BodyGyro","FloatLook",torso,{{"MaxTorque",Vector3.new(math.huge,math.huge,0)},{"CFrame",CFrame.lookAt(root.Position,root.Position+Vector3.new(0,100,0))},{"D",125}},true)
						--
						humanoid.Health=humanoid.MaxHealth
						task.spawn(function()
							local lastTick=tick()
							while (tick()-lastTick)>=0.1 do
								task.wait()
								if _G.SafeCheck(humanoid) and humanoid:GetState()~=Enum.HumanoidStateType.Dead then
									humanoid.Health=humanoid.MaxHealth
								else
									break
								end
							end
						end)
						--
						character:SetAttribute("ResonanceProcced",true)
						character:SetAttribute("FreeFly",true)
						--
						local FF=_G.Create("ForceField","BellFF",character,{{"Visible",false}})
						local HL=_G.Create("Highlight","BellHL",character,{{"FillColor",Color3.fromRGB(60,200,255)},{"FillTransparency",0.7}})
						--
						for _,v in pairs(values.HealthValues:GetChildren()) do
							if not v.Destroyed.Value then
								--
								v.Value=v.MaxValue
								v.Broken.Value=false
								--
							end
						end
						--
						ragdollTime.Value=100000
						--
						local resoAct=ServerStorage.Storage.Resonance.EFX.ResonanceActivate:Clone()
						--
						local Att0=_G.Create("Attachment","Att0",resoAct)
						local Att1=_G.Create("Attachment","Att1",root)
						--
						local alignment=_G.Create("AlignPosition","FXAlignment",resoAct,{{"Attachment0",Att0},{"Attachment1",Att1},{"Responsiveness",200},{"MaxForce",math.huge}})
						--
						resoAct.Position=root.Position
						resoAct.Parent=character
						--
						for i,v in pairs(resoAct:GetDescendants()) do
							if v:IsA("ParticleEmitter") then
								v.Enabled=true
							end
						end
						--
						resoAct.Sound:Play()
						--
						task.delay((resoAct.Sound.TimeLength/resoAct.Sound.PlaybackSpeed)-1,function()
							--
							if not _G.SafeCheck({character,player}) then
								return end
							--
							if ragdollTime.Value>1000 then
								ragdollTime.Value=1
							end
							--
							BV:Destroy()
							BG:Destroy()
							--
							FF:Destroy()
							HL:Destroy()
							--
							character:SetAttribute("FreeFly",nil)
							--
							for i,v in pairs(resoAct:GetDescendants()) do
								if v:IsA("ParticleEmitter") then
									v.Enabled=false
								end
							end
							--
							game.Debris:AddItem(resoAct,3)
							--
							_G.Resonance(player,{Character=character,Proc=true})
						end)
						--
						return
					end
					--
				end
			end
			--
			if health<15 or values.Downed.Value then
				if character:GetAttribute("Resurrection") then
					--
					local BV=_G.Create("BodyVelocity","Float",torso,{{"MaxForce",Vector3.new(math.huge,math.huge,math.huge)},{"Velocity",Vector3.new(0,0.5,0)}},true)
					local BG=_G.Create("BodyGyro","FloatLook",torso,{{"MaxTorque",Vector3.new(math.huge,math.huge,0)},{"CFrame",CFrame.lookAt(root.Position,root.Position+Vector3.new(0,100,0))},{"D",125}},true)
					--
					local FF=_G.Create("ForceField","ResFF",character,{{"Visible",false}})
					local HL=_G.Create("Highlight","BellHL",character,{{"FillColor",Color3.fromRGB(200, 255, 255)},{"FillTransparency",0.7}})
					--
					humanoid.Health=humanoid.MaxHealth
					task.spawn(function()
						local lastTick=tick()
						while (tick()-lastTick)>=0.1 do
							task.wait()
							if _G.SafeCheck(humanoid) and humanoid:GetState()~=Enum.HumanoidStateType.Dead then
								humanoid.Health=humanoid.MaxHealth
							else
								break
							end
						end
					end)
					--
					character:SetAttribute("FreeFly",true)
					character:SetAttribute("Resurrected",true)
					--
					_G.PlaySound(ServerStorage.Storage.Resonance.EFX.Resurrection.Rise,torso)
					--
					for _,v in pairs(values.HealthValues:GetChildren()) do
						if not v.Destroyed.Value then
							--
							v.Value=v.MaxValue
							v.Broken.Value=false
							--
						end
					end
					--
					ragdollTime.Value=100000
					--
					--
					local resurr=ServerStorage.Storage.Resonance.EFX.Resurrection.Aura:Clone()
					--
					local Att0=_G.Create("Attachment","Att0",resurr)
					local Att1=_G.Create("Attachment","Att1",root)
					--
					local alignment=_G.Create("AlignPosition","FXAlignment",resurr,{{"Attachment0",Att0},{"Attachment1",Att1},{"Responsiveness",200},{"MaxForce",math.huge}})
					--
					resurr.Position=root.Position
					resurr.Parent=character
					--
					task.delay(2,function()
						--
						if not _G.SafeCheck({character,player}) then
							return end
						--
						if ragdollTime.Value>1000 then
							ragdollTime.Value=0.5
						end
						--
						BV:Destroy()
						BG:Destroy()
						--
						FF:Destroy()
						HL:Destroy()
						--
						character:SetAttribute("FreeFly",nil)
						character:SetAttribute("Resurrected",nil)
						character:SetAttribute("Resurrection",nil)
						--
						for i,v in pairs(resurr:GetDescendants()) do
							if v:IsA("ParticleEmitter") then
								v.Enabled=false
							end
						end
						--
						game.Debris:AddItem(resurr,3)
						--
						_G.PlaySound(ServerStorage.Storage.Resonance.EFX.Resurrection.Ressed,torso)
					end)
					--
					return
				end
			end
			--
			if health <= 0 and not (character:GetAttribute("Resonance") and not character:GetAttribute("ResonanceProcced")) and not character:GetAttribute("Resurrection") then
				Died()
				return
			end

			local legacyDowning = ReplicatedStorage.Values.LegacyDowningSystem.Value

			if lHealth - health > 0 then
				cancelRegen = true
			end
			lHealth = health

			if health <= 15 and not values.Downed.Value then
				local n = 2

				if legacyDowning then
					n = 100000
				end

				ragdollTime.Value = ragdollTime.Value + n

				if values.NoDowned.Value then
					if not character:GetAttribute("Shifter") then
						humanoid.Health = 0
					end
					return
				end

				if character:FindFirstChild("Torso") and humanoid:GetState() ~= Enum.HumanoidStateType.Dead then
					light.Parent = character.Torso
				end
				--ragdollTime.Value = 10000000


				SetCharPhysicalPropertiesModule(character,0.8)


				values.Downed.Tick.Value = tick()
				values.Downed.Value = true
				values.Downed.Resisting.Value = false

				if downBleedVal and downBleedVal.Parent then
					downBleedVal:Destroy()
				end

				downBleedVal = _G.AffectChar(character,"Bleeding",math.huge)

				if not values.Handcuffed.Value then
					for _,v in pairs(humanoid:GetPlayingAnimationTracks()) do
						if (safeAnimationIds[v.Animation.AnimationId] ~= true) then
							v:Stop(0.5)
						end
					end
				end

				root.CanCollide = false

				_G.FlinchChar(character,humanoid,0.5,true,false,false,true)

				if inCombat then
					inCombat:Destroy()
					inCombat = nil
				end
				inCombat = _G.CombatTagChar(player,1000,"DNED")

				for i = 1,1 do
					if humanoid.Health > 0 then
						for _,v in pairs(values.Currents:GetChildren()) do
							if v.Name == "Bleeding" then
								v:Destroy() 
							end
						end

						local dd = 0

						if humanoid:GetAttribute("downdmg") then
							dd = humanoid:GetAttribute("downdmg")						
							--	print("YEAH!",dd)
							humanoid:SetAttribute("downdmg",nil)			
						end

						local n0 = math.min(humanoid.MaxHealth * 0.2173913043478261,24.99)

						local n = n0 - dd

						if n < 20 then
							n = Round(n,5)
						end
						if n < 24.9 * 0.25 then
							n = 0
						end
						n = math.min(n,n0)
						--print("SETHP:",n,dd)
						--print(n)
						humanoid.Health = n

						if legacyDowning then
							humanoid.Health = 3
						end

						--game:GetService("RunService").Heartbeat:Wait()
					end
				end

				humanoid:SetAttribute("downdmg",nil)

				--

				wait(2)

				local isLegitGonnaDie = false -- neck broken, etc retc

				if values.Downed.Value then

					--humanoid.Health = 24.99

					local function isPoisonDeath()
						return (values.Currents:FindFirstChild("POIZSKRATA") and values.Currents.POIZSKRATA.Value > 0.31)
					end

					local function UpdateGUI()
						local MH = humanoid.MaxHealth
						MH = math.max(MH,0)

						local AMH = MH - 14.99
						local AH = humanoid.Health

						local H = AH

						local calc = H / 25
						H = Lerp(0,100,calc)

						local n = H/AMH

						if _G.LimbCheck(character,"Head","Broken") 
							or (_G.LimbCheck(character,"Right Leg","Destroyed") and _G.LimbCheck(character,"Left Leg","Destroyed")) 
							or isPoisonDeath()
						then
							local Size = UDim2.new(1 - H/AMH,0,1,0)
							if bOutGUI and bOutGUI.Parent then
								bOutGUI.Frame.Bar:TweenSize(Size,Enum.EasingDirection.Out,Enum.EasingStyle.Linear,0.1)
							end
						elseif reviveGUI and reviveGUI.Parent then
							local Color1_A = Color3.fromRGB(255, 213, 0)
							local Color2_A = Color3.fromRGB(75,0,0)

							if reviveGUI and reviveGUI.Parent then
								if values.Currents:FindFirstChild("BLEOUT") then
									reviveGUI.Frame.ImageLabel.ImageColor3 = Color3.new(0.572549, 1, 0.47451)
								else
									reviveGUI.Frame.ImageLabel.ImageColor3 = Color1_A:Lerp(Color2_A,1-(n))
								end
							end
						end					
					end

					UpdateGUI()

					if _G.LimbCheck(character,"Head","Broken") 
						or (_G.LimbCheck(character,"Right Leg","Destroyed") and _G.LimbCheck(character,"Left Leg","Destroyed")) 
						or isPoisonDeath()

					then
						isLegitGonnaDie = true
						if bOutGUI and bOutGUI.Parent then
							if isPoisonDeath() then
								bOutGUI.Frame.IMG2.Visible = true
								bOutGUI.Frame.IMG1.Visible = false
								bOutGUI.Frame.TextLabel.Visible = false
								bOutGUI.Frame.Bar.BackgroundColor3 = Color3.fromRGB(53, 139, 0)
							else
								bOutGUI.Frame.IMG2.Visible = false
								bOutGUI.Frame.IMG1.Visible = true
								bOutGUI.Frame.TextLabel.Visible = true
								bOutGUI.Frame.Bar.BackgroundColor3 = Color3.fromRGB(255,0,0)
							end

							bOutGUI.Enabled = true

							reviveGUI.Enabled = false

							--
						end
						--
					else
						isLegitGonnaDie = false
						if reviveGUI and reviveGUI.Parent and not legacyDowning then
							bOutGUI.Frame.Bar.Size = UDim2.new(0,0,1,0)
							reviveGUI.Enabled = true
							bOutGUI.Enabled = false
						end
						--
					end

					if character:FindFirstChild("Head") then
						local s = character.Head:FindFirstChild("DownedBreathing")
						if s then
							s:Destroy()
						end
						s = pSoundsDir.Head.DownedBreathing:Clone()
						s.Parent = character.Head
						s:Play()
					end

					coroutine.wrap(function()
						if not legacyDowning then
							while values.Downed.Value and humanoid.Health > 0 do
								wait(math.random(70,200) / 100)
								if downedBloodA.Parent and values.Downed.Value and humanoid.Health > 0 then	
									local b = { -- Main
										Amount = 		{1,1};
										Speed = 		75;
										Spread = 		{-30,30};
										Size = 			2.5; -- Pool Size
										WidthScale =	3;
										UpVector = 		Vector3.new(0,-5,0);
										RepeatCount =	1; -- Amount of times to do
										RepeatTick =	0; -- Wait time between ticks
										MaxYAngle =		50;
									};
									_G.CreateBloodTrail(downedBloodA,b,true,{0.5,1})
								end
							end
						end
					end)()

					coroutine.wrap(function()	
						local CON
						CON = humanoid.HealthChanged:Connect(UpdateGUI)

						UpdateGUI()
						local t = tick()
						while values.Downed.Value and humanoid.Health > 0 do
							wait(2)
							if values.Downed.Value and humanoid.Health > 0 then

								local dmg = 2

								if values.Downed.Forcing.Value then
									dmg = 3
								elseif values.Downed.Resisting.Value or values.Currents:FindFirstChild("TIEDUP") then
									dmg = 0.4
								elseif values.Grabbed.Value then
									dmg = 1
								end

								local legD = false

								if legacyDowning and not isLegitGonnaDie then
									legD = true
									dmg = 0
								end

								if not legD and values.Currents:FindFirstChild("BLEOUT2") and humanoid.Health - dmg <= 0 then
									dmg = humanoid.Health - 0.01
								end

								if (_G.LimbCheck(character,"Right Leg","Destroyed") and _G.LimbCheck(character,"Left Leg","Destroyed")) then
									dmg = dmg * 5
								end

								if not legD and values.Currents:FindFirstChild("BLEOUT") then
									if humanoid.Health - dmg <= 0.01 and humanoid.Health > 0 then
										dmg = humanoid.Health - 0.01
									else
										dmg = 0.6
									end
								end

								if (_G.DoesCharAffectExist(character, "DISABLE-DOWNED-BLEEDOUT") == true) then
									dmg = 0 end

								if dmg > 0 then
									humanoid:TakeDamage(dmg)
								elseif legacyDowning and not (values and values:FindFirstChild("Currents") and values.Currents:FindFirstChild("Flinching")) then
									humanoid.Health += 1.47
								end
								--end
							end
							UpdateGUI()
						end

						--print(tick() - t)

						CON:Disconnect()

					end)()
				end
			elseif health >= 25 and values.Downed.Value then
				if not values.Grabbed.IsHandcuff.Value then
					values.Grabbed.Value = false
				end

				if ragdollTime.Value > 10000 then
					ragdollTime.Value = 0
				end

				if inCombat then
					inCombat:Destroy()
				end
				inCombat = nil

				if legacyDowning then
					humanoid.Health = math.max(humanoid.Health,45)
				end

				for i,v in pairs(values.Currents:GetChildren()) do
					if v.Name == "Flinching" or string.find(v.Name,"Flinch") then
						v:Destroy()
					end
				end

				if reviveGUI and reviveGUI.Parent then
					reviveGUI.Enabled = false
				end
				if bOutGUI and bOutGUI.Parent then
					bOutGUI.Enabled = false
				end

				if character:FindFirstChild("Head") and character.Head:FindFirstChild("DownedBreathing") then
					character.Head:FindFirstChild("DownedBreathing"):Destroy()
				end

				if downBleedVal and downBleedVal.Parent then
					downBleedVal:Destroy()
				end
				downBleedVal = nil

				SetCharPhysicalPropertiesModule(character,nil)

				--ragdollTime.Value = 0
				--ragdollTime.RagdollSwitch.Value = false
				values.Downed.Value = false
				values.Downed.Resisting.Value = false
				values.Downed.Tick.Value = 0
				root.CanCollide = true

				delay(0.25,function()
					if not values.Downed.Value and light and light.Parent then
						light.Parent = nil
					end
				end)
			end
		end)

		DiedE = humanoid.Died:Connect(function()

		end)

		CharE = character.AncestryChanged:Connect(function(_,parent)
			if not parent then
				DisconnectAll()
			end
		end)

		pStandE = humanoid.StateChanged:Connect(function(old,new)
			local c = math.random()
			nCode = c

			if new == Enum.HumanoidStateType.Climbing then
				delay(0.2,function()
					if nCode == c and values.Parent then
						values.Climbing.Value = true
					end
				end)
			else
				values.Climbing.Value = false
				nCode = 0
			end
		end)

		local function HandleDisplayItems()
			if not player then return end 

			local c1,c2,c3,c4

			local displayItemsF = Instance.new("Folder")
			displayItemsF.Name = "DisplayItems"
			displayItemsF.Parent = character

			local isInvis = false

			local cItems = {}
			local equippedTypes = {}

			local funcs = {}


			humanoid:GetAttributeChangedSignal("INVZ"):Connect(function()
				local v = humanoid:GetAttribute("INVZ")
				isInvis = v
				for i,c in pairs(player.Backpack:GetChildren()) do
					if cItems[c] then
						if v then
							funcs.HideDisplay(c)
						else
							funcs.ShowDisplay(c)
						end
					end
				end
			end)


			funcs.RemoveDisplay = function(item)
				--print("R1")
				if cItems[item] then
					--print("removing..",item)
					--print("R2")
					local c = 0
					for i,v in pairs(cItems) do
						if v.name == cItems[item].name then
							c = c + 1
						end
					end

					local name = cItems[item].name

					--print("R3",name,c)


					if c == 1 then
						--print("rem",1)
						cItems[item].model:Destroy()
					elseif c == 2 then
						--print("rem",2)
						--funcs.HideDisplay(item)					
					end

					local mode = cItems[item] and cItems[item].mode

					if equippedTypes[mode] == cItems[item] then
						equippedTypes[mode] = nil
					end

					cItems[item] = nil

					if c == 1 and displayItemsF:FindFirstChild(name) then
						displayItemsF:FindFirstChild(name):Destroy()
					end
					--print("removed item...",item)
					--cDisplays[iName] = nil

					local p = -1
					local t

					local backpack = player:FindFirstChild("Backpack")

					for i,v in pairs(cItems) do
						--print("hide_3.1",i,v)
						if v.priority >= p and v.mode == mode and v ~= cItems[item] and backpack and v.real.Parent == backpack then
							--print("hide_3.2",i,v)
							t = v
							name = i
							p = v.priority
						end
					end

					--print("hide_4",t,name)

					if t and not character:FindFirstChild(name) then
						--print("hide_5r",t,name)

						funcs.ShowDisplay(t.real)
					end
				end
			end

			funcs.CreateDisplay = function(item)
				local iName = item.Name	
				if not (cItems[item]) then
					local exists = displayItemsF:FindFirstChild(iName)
					local newItem = exists or _G.SMains.NewDisplayItem(character,item) 

					--print("created item...",iName)

					if newItem then
						local mode = (newItem:FindFirstChild("Type") and newItem["Type"].Value) or tostring(math.random())
						cItems[item] = {
							model = newItem;
							priority = (newItem:FindFirstChild("Priority") and newItem["Priority"].Value) or 1;
							mode = mode;
							real = item;
							name = iName;
							displaying = false;							
						}

						if not exists then
							for _,v in pairs(newItem:GetDescendants()) do
								if v:IsA("BasePart") then
									local b = Instance.new("NumberValue")
									b.Name = "OriginTrans"
									b.Value = v.Transparency
									b.Parent = v
								end
							end
						end
					end

					local mode = cItems[item] and cItems[item].mode
					--print("create_0",equippedTypes[mode],equippedTypes[mode] and equippedTypes[mode].priority, cItems[item] and cItems[item].priority)
					if equippedTypes[mode] and equippedTypes[mode].priority < cItems[item].priority and equippedTypes[mode].displaying then
						--print("create_1 HIDE")
						funcs.HideDisplay(equippedTypes[mode].real)
					end

					funcs.HideDisplay(item)

					return newItem
				else
					return cItems[item]
				end
			end

			funcs.HideDisplay = function(item)
				--print("hide_1",item,cItems[item])
				if cItems[item] then
					--print("hide_2",item)

					local cItem = cItems[item]

					local mode = cItems[item] and cItems[item].mode

					if equippedTypes[mode] == cItems[item] then
						equippedTypes[cItem.mode] = nil
					end

					local doHide = true

					for i,v in pairs(cItems) do
						if v ~= cItem and v.name == cItem.name and v.displaying then
							--print("hide_DONTHIDE")
							doHide = false
						end
					end

					cItems[item].displaying = false

					if doHide then
						--print("hide_3")
						for _,v in pairs(cItem.model:GetDescendants()) do
							if v:IsA("BasePart") then
								v.Transparency = 1
							end
							--
							if v:GetAttribute("EnchantEffect") then
								v:Destroy()
							end
						end

						local name
						local t
						local p = -1

						for i,v in pairs(cItems) do
							if v.priority >= p and v.mode == cItem.mode and v ~= cItem and v.real.Parent == player.Backpack then
								t = v
								name = i
								p = v.priority
							end
						end

						if t and not character:FindFirstChild(name.Name) then

							if equippedTypes[mode] and equippedTypes[mode].priority < p  then
								funcs.HideDisplay(equippedTypes[mode].real)
							end

							funcs.ShowDisplay(t.real)
						end
					end
				end
			end

			funcs.ShowDisplay = function(item)
				if humanoid.Health <= 0 then return end
				if isInvis then return end
				--print("show_0",item,cItems[item])
				if cItems[item] then
					local cItem = cItems[item]
					local mode = cItem.mode

					--print("show_1",item)

					--print("show_1.1",equippedTypes[mode],equippedTypes[mode] and equippedTypes[mode].priority,cItem.priority)
					if equippedTypes[mode] and equippedTypes[mode] ~= cItem and equippedTypes[mode].priority > cItem.priority then
						return
					end

					if equippedTypes[mode] and equippedTypes[mode] ~= cItem then
						funcs.HideDisplay(equippedTypes[mode].real)
					end

					--print("show_2")

					cItems[item].displaying = true
					equippedTypes[mode] = cItems[item]

					--print("shown item...")
					for _,v in pairs(cItem.model:GetDescendants()) do
						if v:IsA("BasePart") then
							v.Transparency = v:FindFirstChild("OriginTrans") and v.OriginTrans.Value or 0
						end
					end
					--
					if _G.SafeCheck(cItem.real) and cItem.real:GetAttribute("Enchanted") then
						require(game.ServerStorage.Modules.EnchantHandler).enchantWeapon(cItem.real:GetAttribute("Enchanted"),cItem.model)
					end
				end
			end

			c1 = character.ChildAdded:Connect(function(c)
				if not c:IsA("Tool") then return end

				--print("child added..",c.Name)

				if cItems[c] then
					funcs.HideDisplay(c)
				end
			end)

			c2 = character.ChildRemoved:Connect(function(c)
				if not c:IsA("Tool") then return end


				--print("child removed..",c.Name)

				--RunService.Heartbeat:Wait()

				if humanoid.Health <= 0 and not character:FindFirstChild(c.Name) and (not player and player.Backpack:FindFirstChild(c.Name)) then
					funcs.RemoveDisplay(c)
				elseif player and player.Backpack:FindFirstChild(c.Name) then
					funcs.ShowDisplay(c)
				end
			end)

			local function newBChild(c)
				if c and not c:IsA("Tool") then return end
				if humanoid.Health <= 0 then return end

				local i = cItems[c]

				if not i then
					i = funcs.CreateDisplay(c)
				end

				if i then
					if c.Parent ~= nil and c.Parent ~= character then
						funcs.ShowDisplay(c)
					end
				end

				local con
				con = c.AncestryChanged:Connect(function(_,parent)
					if not parent or (parent ~= player.Backpack and parent ~= player.Character) then
						RunService.Heartbeat:Wait()
						if not parent or (parent ~= player.Backpack and parent ~= player.Character) then
							con:Disconnect()
							--print("R00",c)
							funcs.RemoveDisplay(c)
							if (not player.Backpack:FindFirstChild(c.Name) and not player.Character:FindFirstChild(c.Name)) then
								--print("R09",c)
								funcs.RemoveDisplay(c)
							end
						end

						--	then
						--		print("R0",c)
						--		funcs.RemoveDisplay(c)
						--	end
						--end)
					end
				end)
			end

			for _,v in pairs(player.Backpack:GetChildren()) do
				newBChild(v)
			end

			c3 = player.Backpack.ChildAdded:Connect(newBChild)

			--c4 = player.Backpack.ChildRemoved:Connect(function(c)
			--	if not c.Parent-- or (not player.Backpack:FindFirstChild(c.Name) and not player.Character:FindFirstChild(c.Name)) 

			--	then
			--		print("R0",c)
			--		funcs.RemoveDisplay(c)
			--	end
			--end)
		end

		HandleDisplayItems()

		for _,v in pairs(values.HealthValues:GetChildren()) do
			local lValue = v.Broken.Value

			local con
			con = v.Broken:GetPropertyChangedSignal("Value"):Connect(function()
				if not v.Broken.Value and lValue then

					--character[v.Name].Massless = false

					if not _G.RagdollCheck(character) then
						if character:findFirstChild("Torso") and character.Torso:FindFirstChild(v.MotorValue.Value) then
							local x = character.Torso[v.MotorValue.Value]
							x.Enabled = true
						end
						if character:FindFirstChild(v.Name) and character[v.Name]:FindFirstChild("Collider") then
							character[v.Name].Collider.CanCollide = false
						end
					end

					local bsc = character.HumanoidRootPart.CTs:FindFirstChild("RGCT_" .. v.MotorValue.Value)
					if bsc then
						if bsc.Attachment1 ~= nil and bsc.Attachment1:FindFirstChild("OriginOri") then
							bsc.Attachment1.Orientation = bsc.Attachment1.OriginOri.Value
						end

						pcall(function()
							bsc.UpperAngle = bsc["ori_UpperAngle"].Value
							bsc.TwistLowerAngle = bsc["ori_TwistLowerAngle"].Value
							bsc.TwistUpperAngle = bsc["ori_TwistUpperAngle"].Value
						end)
					end

					local function x(v)
						if not (v and v.Parent) then return end
						for _,z in pairs(v:GetChildren()) do
							if v.Name == "BleedAttachment" then
								v:Destroy()
							end
						end						
					end

					x(character:FindFirstChild("Torso"))
					x(character:FindFirstChild("HumanoidRootPart"))
				end

				lValue = v.Broken.Value
			end)

			table.insert(brokeCons,con)
		end	

		local function DoHealing()
			if (values and values:FindFirstChild("Currents") and values.Currents:FindFirstChild("Flinching")) or character:FindFirstChild("ProtectionFF") or _G.DownedCheck(character) or character:GetAttribute("Shifter") or character:GetAttribute("SteamHealing") then
				cancelRegen = true
			end

			if not cancelRegen or (character:FindFirstChildOfClass("Tool") and character:FindFirstChildOfClass("Tool"):GetAttribute("CurseOfTheNoLifeKing")) then
				local rR = humanoid:GetAttribute("REGEN_RATE") or config.REGEN_RATE
				local rS = humanoid:GetAttribute("REGEN_STEP") or config.REGEN_STEP

				local downed = _G.DownedCheck(character)
				if downed then
					rR = 1/200
					rS = 1
				end

				local inCombat = player and _G.InCombatCheck and _G.InCombatCheck(player,false)

				local dt = task.wait(rS)
				if not cancelRegen and (tick() + 0.01) - lastStep >= rS then

					lastStep = tick()

					local dh = dt*rR*humanoid.MaxHealth

					if humanoid.Health >= humanoid.MaxHealth then
						humanoid.Health = humanoid.Health - 0.05 end

					if (_G.CharHasTrait(humanoid.Parent, "slowhealer")) then
						dh*=0.4
					elseif (_G.CharHasTrait(humanoid.Parent, "naturalrecovery")) then
						dh*=1.5
					end
					
					local hunger_factor = (values.Hunger.Value / values.Hunger.MaxValue)
					dh *= 1 - (0.7 * (1 - hunger_factor))

					task.spawn(function()
						if character:FindFirstChildOfClass("Tool") and character:FindFirstChildOfClass("Tool"):GetAttribute("CurseOfTheNoLifeKing") then
							local stressGain=7
							values.Stress.Value += math.floor(stressGain*0.6)
							values.Stress.Overtime.Value += math.floor(stressGain*0.4)
							--
							_G.CombatTagChar(character,15,"NLK",nil)
							_G.ApplyDeathLegitimacy(character, "NLK", true, 10)
							--
							if values.Stress.Value>=values.Stress.MaxValue then
								--
								values.Fatigue.Value+=stressGain*0.15
								--
								if values.Fatigue.Value>=30 then
									--
									local cd = {
										weapon="Curse of the No-Life King",
										distance=1,
										keepText=true,
									}
									_G.TagChar(character,player,10,0,nil,cd.weapon,cd.distance,cd.keepText)
									--
									framework.networking.toClients(nil,false,"HeadBubble",{char=character})
									--
									task.wait(1.45)
									--
									if _G.SafeCheck(character) then
										--
										_G.BreakJoint(character.Head,character,"Explode")
										--
									end
								end
								--
							end
						end
					end)

					humanoid.Health = math.min(humanoid.Health + dh, humanoid.MaxHealth)
					for _,v in pairs(hValues) do
						if v and v.Parent and not v.Destroyed.Value then
							local dh = dt*(rR * 1.6)*v.MaxValue 
							v.Value = math.min(v.Value + dh, v.MaxValue)

							if v.Value >= v.MaxValue and v:FindFirstChild("Broken") and v.Broken.Value and not v.Destroyed.Value then
								v.Broken.Value = false
							end
						end
					end
				else
					cancelRegen = false
					task.wait(2)						
				end
			else
				cancelRegen = false
				task.wait(2)	
			end
		end

		local function HealHandler()
			--while humanoid and humanoid.Parent and humanoid.Health > 0 do
			--	print(1)
			--	while (humanoid.Health < humanoid.MaxHealth or not _G.LimbHealthFull(character)) and humanoid:GetState() ~= Enum.HumanoidStateType.Dead and humanoid.Health > 0 do
			--		DoHealing()
			--	end

			--	humanoid.HealthChanged:Wait()
			--end

			local busy = false
			local function Process()
				if not busy and humanoid and humanoid.Parent and humanoid.Health > 0 then
					if (humanoid.Health < humanoid.MaxHealth or not _G.LimbHealthFull(character) or (character:FindFirstChildOfClass("Tool") and character:FindFirstChildOfClass("Tool"):GetAttribute("Curse of the No-Life King"))) and humanoid:GetState() ~= Enum.HumanoidStateType.Dead and humanoid.Health > 0 then
						busy = true
						DoHealing()
						busy = false
					end
				end
			end

			humanoid.HealthChanged:Connect(Process)

			local rS = humanoid:GetAttribute("REGEN_STEP") or config.REGEN_STEP			

			while task.wait(rS) do
				Process()
			end

			--for _,v in pairs(hValues) do
			--	v.Changed:Connect(Process)
			--end
		end

		spawn(HealHandler)
	end

	-- TS THE SETUP FUNCTION
	local function SetUp()
		character:SetAttribute("CharacterModel", true)

		reviveGUI = ReplicatedStorage.Storage.GUIs.ReviveGUI:Clone()
		reviveGUI.Adornee = root
		reviveGUI.PlayerToHideFrom = player
		reviveGUI.Enabled = false
		reviveGUI.Parent = root

		bOutGUI = ReplicatedStorage.Storage.GUIs.BleedOutGUI:Clone()
		bOutGUI.Adornee = root
		bOutGUI.PlayerToHideFrom = player
		bOutGUI.Enabled = false
		bOutGUI.Parent = root

		values.SpawnT.Value = tick()

		if values then
			for _,v in pairs(values.HealthValues:GetChildren()) do
				table.insert(hValues,v)
			end
		end

		if not player then
			humanoid:SetStateEnabled(Enum.HumanoidStateType.GettingUp,false)
			humanoid:SetStateEnabled(Enum.HumanoidStateType.FallingDown,false)
		end


		humanoid.MaxHealth = 115
		humanoid.Health = humanoid.MaxHealth

		-- Values Child Added

		values.Currents.ChildAdded:Connect(function(child) 
			--
			if (child.Name == "HFPS") then
				temps.ForcedPlatformStand = true
			elseif (child.Name == "HFRA") then
				temps.ForcedRootAnchored = true
			end
			--
		end)
		-- Values Child Removed

		values.Currents.ChildRemoved:Connect(function(child) 
			--
			if (child.Name == "HFPS") then
				local doesExist = _G.DoesCharAffectExist(character, "HFPS")
				if (not doesExist) then
					temps.ForcedPlatformStand = false end
			elseif (child.Name == "HFRA") then
				local doesExist = _G.DoesCharAffectExist(character, "HFRA")
				if (not doesExist) then
					temps.ForcedRootAnchored = false end
			end
			--
		end)
		-- Character Heartbeat Loop

		table.insert(brokeCons, game:GetService("RunService").Heartbeat:Connect(function(delta) 
			--
			if (temps.ForcedPlatformStand == true) then
				humanoid.PlatformStand = true end
			if (temps.ForcedRootAnchored == true) then
				root.Anchored = true end
			--
		end))
		--

		for _,v in pairs(bloodAttachments:GetChildren()) do
			v:Clone().Parent = character:FindFirstChild("Torso") or character:FindFirstChild("UpperTorso")
		end
		for _,v in pairs(ServerStorage.Storage.PlayerSounds.Head:GetChildren()) do
			if v.Name == "Coughing" or v.Name == "Coughing2" then
				v:Clone().Parent = character.Head
			end
		end
		for _,v in pairs(ServerStorage.Storage.PlayerSounds.Torso:GetChildren()) do
			if v.Name == "EquipSound" 
				or v.Name == "BlockStart" 
				or v.Name == "BlockStop" 
				or v.Name == "Execute" 
				or v.Name == "Grab"
			then
				v:Clone().Parent = character:FindFirstChild("Torso") or character:FindFirstChild("UpperTorso")
			end

		end

		for _,v in pairs(ServerStorage.Storage.PlayerSounds["Right Arm"]:GetChildren()) do
			v:Clone().Parent = character["Right Arm"]
		end

		for _,v in pairs(ServerStorage.Storage.PlayerSounds["Left Arm"]:GetChildren()) do
			v:Clone().Parent = character["Left Arm"]
		end

		for _,v in pairs(character:GetDescendants()) do
			if v:IsA("BasePart") then
				v.CollisionGroup = "Character"
			end
		end

		task.spawn(function()
			if (player == nil) then return end
			local vF=_G.GetPlayerData2(player)
			if not vF then return end
			--
			local function isOhioian(playerName)
				for _, name in ipairs(_G.Ohioians) do
					if name == playerName then
						return true
					end
				end
				return false
			end
			--
			if isOhioian(string.lower(player.Name)) then
				local language="Ohioian"
				local lang = vF.Languages:FindFirstChild(language)
				if not (lang) then
					_G.Create("BoolValue",language,vF.Languages)
					game:GetService("ReplicatedStorage").Events.ClientWarn:FireClient(player,{"You can speak and understand: "..language..". Type '/e setlang language' to change tongue language.", 10, Color3.fromRGB(154, 196, 204), Color3.new(0, 0, 0), "BEEP"})
					vF.CurrentLanguage:SetAttribute("Default",language)
				end
			end
			--
			local rank_in_group = player:GetRankInGroup(498133475)
			if (rank_in_group ~= nil and rank_in_group >= 1) then
				--
				local language="Georgian"
				local lang = vF.Languages:FindFirstChild(language)
				if not (lang) then
					_G.Create("BoolValue",language,vF.Languages)
					game:GetService("ReplicatedStorage").Events.ClientWarn:FireClient(player,{"You can speak and understand: "..language..". Type '/e setlang language' to change tongue language.", 10, Color3.fromRGB(154, 196, 204), Color3.new(0, 0, 0), "BEEP"})
				end
				--
			end
			--
		end)

		root.CanCollide = true
		if not character:GetAttribute("Shifter") then
			RagdollServer.Initilize(character,isNPC)
		end

		local nCode = 0

		if player then

			if player:FindFirstChild("Tags") then
				player.Tags:Destroy()
			end

			if humanoid.DisplayName == player.Name or humanoid.DisplayName == player.DisplayName then
				humanoid.DisplayName = player.Name
				if player.Name=="joshdbj1" then
					humanoid.DisplayName = "[👑] "..player.Name
				else
					if _G.PermsList.Creators[table.find(_G.PermsList.Creators,player.Name)] and (player.Name ~= "fragerbob" and player.Name ~= "tilovane") then
						humanoid.DisplayName = "[🛠️] "..player.Name
					end
				end
			end

			local t = tick()

			repeat task.wait(0.1)
				character.Archivable = true
				character.Parent = workspace.Characters
			until tick() - t > 10 or (not player or not player.Parent or character.Parent == workspace.Characters or d)

			if d then return end

			if player and player.Parent and character and character.Parent then
				for _,v in pairs(workspace.Characters:GetChildren()) do
					if v.Name == player.Name and v ~= character then
						v:Destroy()
					end
				end
				if character and character.Parent then
					--	humanoid.DisplayName = player.Name
					character:WaitForChild("Head").Size = Vector3.new(1.2,1,1)

					for _,v in pairs(ReplicatedStorage.Storage.FistPoints:GetChildren()) do
						v:Clone().Parent = character:FindFirstChild("Left Arm")
						v:Clone().Parent = character:FindFirstChild("Right Arm")
						v:Clone().Parent = character:FindFirstChild("Right Leg")
						v:Clone().Parent = character:FindFirstChild("Left Leg")
					end
				end
			elseif not (character and character.Parent) then
				DisconnectAll()
				character:Destroy()
			end

			if doRandomAppearance then
				RandomAvatarM.new(character,randomAppearanceSeed,randomAppearanceSave)
				task.wait()
			end

			--coroutine.wrap(function()
			if not player:HasAppearanceLoaded() and not doRandomAppearance then
				local l = false

				coroutine.wrap(function()
					player.CharacterAppearanceLoaded:Wait()
					l = true
				end)()

				local t = tick()
				repeat task.wait(0.2) until l or tick() - t >= 3
			end

			local function SizeCheckAccessory(v)
				local p = (v:IsA("Accessory") or v:IsA("Hat")) and v:FindFirstChildWhichIsA("Part") 
				if p and p.Name == "Handle" then
					if p.Size.Magnitude >= config.MaxAccessorySizeMagnitude
						--or p:FindFirstChild("BodyBackAttachment") or p:FindFirstChild("BodyFrontAttachment") or p:FindFirstChild("WaistBackAttachment") or p:FindFirstChild("WaistFrontAttachment") 
					then
						--print(p:GetFullName())
						p:Destroy()
					end
				end
				--elseif v:IsA("CharacterMesh") then
				--	if config.PackageType == "None" then
				--		v:Destroy()
				--	elseif config.PackageType == "Whitelist" then
				--		local id = v.MeshId

				--		--print(v,id)

				--		local a = false
				--		for i,z in pairs(PackageIDs) do
				--			if z == id then
				--				a = true
				--				break
				--			end
				--		end

				--		if not a then
				--			v:Destroy()
				--		end
				--	elseif config.PackageType == "All" then
				--		--
				--	end
				--end

				--local bodycolors = character:FindFirstChildOfClass("BodyColors")

				--if bodycolors and config.NoBlackBodyColor then
				--	if bodycolors.HeadColor == BrickColor.new("Really black") or bodycolors.HeadColor == BrickColor.new("Black") then
				--		bodycolors.HeadColor = BrickColor.new("Dark stone grey")
				--	end
				--	if bodycolors.LeftArmColor == BrickColor.new("Really black") or bodycolors.LeftArmColor == BrickColor.new("Black") then
				--		bodycolors.LeftArmColor = BrickColor.new("Dark stone grey")
				--	end
				--	if bodycolors.RightArmColor == BrickColor.new("Really black") or bodycolors.RightArmColor == BrickColor.new("Black") then
				--		bodycolors.RightArmColor = BrickColor.new("Dark stone grey")
				--	end
				--	if bodycolors.LeftLegColor == BrickColor.new("Really black") or bodycolors.LeftLegColor == BrickColor.new("Black") then
				--		bodycolors.LeftLegColor = BrickColor.new("Dark stone grey")
				--	end
				--	if bodycolors.RightLegColor == BrickColor.new("Really black") or bodycolors.RightLegColor == BrickColor.new("Black") then
				--		bodycolors.RightLegColor = BrickColor.new("Dark stone grey")
				--	end
				--	if bodycolors.TorsoColor == BrickColor.new("Really black") or bodycolors.TorsoColor == BrickColor.new("Black") then
				--		bodycolors.TorsoColor = BrickColor.new("Dark stone grey")
				--	end
				--end
			end

			local con1
			con1 = character.ChildAdded:Connect(SizeCheckAccessory)

			task.delay(15,function()
				con1:Disconnect()
			end)
			--end)()
		else
			if doRandomAppearance then
				RandomAvatarM.new(character,randomAppearanceSeed,randomAppearanceSave)
				task.wait()
			end

			for _,v in pairs(character:GetDescendants()) do
				if v:IsA("BasePart") and v:CanSetNetworkOwnership() and not v:GetAttribute("NoNetworkOwnerSet") then
					v:SetNetworkOwner(nil)
				end
			end	
			local con
			con = character.AncestryChanged:Connect(function(_,parent)
				if not parent then
					con:Disconnect()
					game.Debris:AddItem(values,0)
				end
			end)
		end

		DoFuncs()

		task.wait()

		if doRandomAppearance then
			humanoid:SetAttribute("HasLoaded",true)
		end

		local _s,_e = pcall(function()
			character.Head:FindFirstChildOfClass("SpecialMesh"):SetAttribute("OG_HSM",true)
		end)
		if not _s then
			warn(_e)
		end

		humanoid:SetAttribute("HasLoaded2",true)
		--
	end

	SetUp()
end