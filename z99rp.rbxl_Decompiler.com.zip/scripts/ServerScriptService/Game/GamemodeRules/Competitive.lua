return {
	KillXPMulti = 3;
	KillCashMulti = 7;
	DeathCashDropMulti = 0; --0.286
	KillHPPerc = 0.6;
	DowningDisabled = true;
	AssistsDisabled = true;

	StockMulti = 2;
	MaxScrapsMulti = 0.25;
	MaxCratesMulti = 3;
	LootCashMulti = 0.8;

	SafesDisabled = true;
	RegistersDisabled = true;

	ForceRandomAvatar = true;
	ForceRandomName = false;

	AllowAllAccessories = true;

	LeaderboardEnabled = false;

	DefaultMap = "07-EXTENDED";
};