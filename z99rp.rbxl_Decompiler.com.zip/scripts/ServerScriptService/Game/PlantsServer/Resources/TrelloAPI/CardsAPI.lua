-- // Services
local HttpService = game:GetService("HttpService")

-- // Var
local CardsAPI = {}
local Response

local Settings = script.Parent:WaitForChild("Settings")
local TrelloAPIKey = Settings:WaitForChild("TrelloKey").Value
local TrelloToken = Settings:WaitForChild("TrelloToken").Value


function CardsAPI.GetCardsOnList(ListId: string)
	if not ListId then
		warn("[SERVER] CardsAPI • [GetCardsOnList] : ListId is missing.")
		return false
	end

	local Succ, Err = pcall(function()
		Response = HttpService:GetAsync("https://api.trello.com/1/lists/" .. ListId .. "/cards?key=" .. TrelloAPIKey .. "&token=" .. TrelloToken)
	end)

	if not Succ then
		warn("[SERVER] BoardsAPI • [GetCardsOnList] : ", Err)
		return false
	else
		Response = HttpService:JSONDecode(Response)
		return Response
	end
end


function CardsAPI.GetCardOnList(ListId: string, Name: string)
	if not ListId or not Name then
		warn("[SERVER] CardsAPI • [GetCardOnList] : Required Argoment is missing (ListId, Name).")
		return false
	end

	local Cards = CardsAPI.GetCardsOnList(ListId)	

	if not Cards then
		warn("[SERVER] CardsAPI • [GetCardOnList] : Something Went wrong, try check your ListId.")
		return false
	end

	for _,Data in pairs(Cards) do
		if Name == Data.name then
			return Data.id
		end
	end

	warn("[SERVER] BoardsAPI • [GetCardOnList] : Card Not Found")
	return false
end


function CardsAPI.CreateCard(Name: string, ListId: string, BoardOptionalData)
	if not Name or not ListId then
		warn("[SERVER] CardsAPI • [CreateCard] : Required Argoment is missing (Name, ListId).")
		return false
	end
	
	if not BoardOptionalData then
		BoardOptionalData = {}
	end
	
	local DataToSend = {["Description"] = BoardOptionalData.Description or nil ,["idLabels"] = BoardOptionalData.idLabels or nil,["AttachmentLink"] = BoardOptionalData.AttachmentLink or nil}
	
	if not BoardOptionalData.Description then
		DataToSend.Description = ""
	end

	if not BoardOptionalData.idLabels then
		DataToSend.idLabels = {}
	end
	
	if not BoardOptionalData.AttachmentLink then
		DataToSend.AttachmentLink = ""
	end


	local Succ, Err = pcall(function()
		HttpService:PostAsync("https://api.trello.com/1/cards" .. "?key=" .. TrelloAPIKey .. "&token=" .. TrelloToken, HttpService:JSONEncode({name = Name, desc = DataToSend.Description, idList = ListId, idLabels = DataToSend.idLabels,urlSource = DataToSend.AttachmentLink}))
	end)

	if not Succ then
		warn("[SERVER] CardsAPI • [CreateCard] : ", Err)
		return false
	else
		return true
	end
end


function CardsAPI.UpdateCard(CardId: string, BoardOptionalData)
	if not CardId then
		warn("[SERVER] CardsAPI • [UpdateCard] : CardId is missing.")
		return false
	end
	
	if not BoardOptionalData then
		BoardOptionalData = {}
	end
	
	local DataToSend = {["name"] = BoardOptionalData.Name or nil ,["desc"] = BoardOptionalData.Description or nil,["closed"] = BoardOptionalData.Closed or nil, ["idLabels"] = BoardOptionalData.idLabels or nil, ['idList'] = BoardOptionalData.idList}

	local Succ, Err = pcall(function()
		local res = HttpService:RequestAsync({
			Url = "https://api.trello.com/1/cards/" .. CardId .. "?key=" .. TrelloAPIKey .. "&token=" .. TrelloToken,
			Method = "PUT",
			Headers = {["Content-Type"] = "application/json"},
			Body = HttpService:JSONEncode(DataToSend)
		})
	end)

	if not Succ then
		warn("[SERVER] CardsAPI • [UpdateCard] : ", Err)
		return false
	else
		return true
	end
end

function CardsAPI.DeleteCard(CardId)
	if not CardId then
		warn("[SERVER] CardsAPI • [DeleteCard] : CardId is missing.")
		return false
	end

	local Succ, Err = pcall(function()
		HttpService:RequestAsync({
			Url = "https://api.trello.com/1/cards/" .. CardId .. "?key=" .. TrelloAPIKey .. "&token=" .. TrelloToken,
			Method = "DELETE",
		})
	end)

	if not Succ then
		warn("[SERVER] CardsAPI • [DeleteCard] : ", Err)
		return false
	else
		return true
	end
end


function CardsAPI.GetAttachmentsOnCard(CardId: string)
	if not CardId then
		warn("[SERVER] CardsAPI • [GetAttachmentsOnCard] : CardId is missing.")
		return false
	end
	
	local Succ, Err = pcall(function()
		Response = HttpService:GetAsync("https://api.trello.com/1/cards/" .. CardId .. "/attachments?key=" .. TrelloAPIKey .. "&token=" .. TrelloToken)
	end)
	
	if not Succ then
		warn("[SERVER] CardsAPI • [GetAttachmentsOnCard] : ", Err)
		return false
	else
		Response = HttpService:JSONDecode(Response)
		return Response
	end
end


function CardsAPI.CreateAttachmentOnCard(CardId: string,AttachmentUrl: string)
	if not CardId or not AttachmentUrl  then
		warn("[SERVER] CardsAPI • [GetAttachmentsOnCard] : CardId or AttachmentUrl is missing.")
		return false
	end
	
	local Succ, Err = pcall(function()
		HttpService:PostAsync("https://api.trello.com/1/cards/" .. CardId .. "/attachments?key=" .. TrelloAPIKey .. "&token=" .. TrelloToken, HttpService:JSONEncode({id = CardId, url = AttachmentUrl}))
	end)

	if not Succ then
		warn("[SERVER] CardsAPI • [CreateAttachmentOnCard] : ", Err)
		return false
	else
		return true
	end
end

function CardsAPI.DeleteAttachmentOnCard(CardId: string, Attachmentid: string)
	if not CardId or not Attachmentid  then
		warn("[SERVER] CardsAPI • [DeleteAttachmentOnCard] : CardId or Attachmentid is missing.")
		return false
	end
	
	local Succ, Err = pcall(function()
		HttpService:RequestAsync({
			Url = "https://api.trello.com/1/cards/" .. CardId .. "/attachments/" .. Attachmentid .. "?key=" .. TrelloAPIKey .. "&token=" .. TrelloToken,
			Method = "DELETE",
		})
	end)
	
	if not Succ then
		warn("[SERVER] CardsAPI • [DeleteAttachmentOnCard] : ", Err)
		return false
	else
		return true
	end
end


return CardsAPI
