return function()
	warn("Plants client script run!")
	local framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
	local Controls = require(game.Players.LocalPlayer:WaitForChild("PlayerScripts"):WaitForChild("PlayerModule")):GetControls()
	-- Inits

	framework.camera.init()
	_G.Controls=Controls
	require(script:WaitForChild("Hooks"))()
	require(script:WaitForChild("Debug"))()
	-- Game
	
	_G.PlantsFramework = framework
	_G.PlantsLocalData = {}
	-- Gui

	local plantsGui = script.PlantsGui
	plantsGui.Parent = game.Players.LocalPlayer.PlayerGui
	_G.PlantsGui = plantsGui
	-- Resources
	
	script:WaitForChild("Resources")
	require(script.Resources:WaitForChild("UIScaler"))()
	-- Cycles
	
	script:WaitForChild("Cycles")
	require(script.Cycles:WaitForChild("RenderStepped"))()
	require(script.Cycles:WaitForChild("Heartbeat"))()
	-- Systems
	
	script:WaitForChild("Systems")
	require(script.Systems:WaitForChild("NotificationsSystem"))
	require(script.Systems:WaitForChild("LootContainerSystem")).init()
	require(script.Systems:WaitForChild("StatusEffects")).init()
	require(script.Systems:WaitForChild("ReputationSystem"))()
	task.spawn(function() require(script.Systems:WaitForChild("StatsSystem")) end)
	require(script.Systems:WaitForChild("MouseTipSystem"))()
	require(script.Systems:WaitForChild("GrabbablesSystems")).init()
	require(script.Systems:WaitForChild("EmotesSystem")).init()
	require(script.Resources:WaitForChild("LightningBolt"))
	require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Utilities"):WaitForChild("goo")).init()
	require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Objects"):WaitForChild("Character")).init()
	require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Objects"):WaitForChild("Stamps")).init()
	--
	require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Dependencies"))
	game:GetService("ReplicatedStorage").PlantsStorage.Hooks.remote:FireServer("ClientLoaded")
	-- Lense
	
	task.spawn(function() 
		repeat task.wait() until game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Scripts"):FindFirstChild("LenseSystem")
		require(game:GetService("ReplicatedStorage").PlantsStorage.Scripts.LenseSystem)()
	end)
	-- Resetting
	
	local resetbind = Instance.new("BindableEvent")
	_G.ResetBind = resetbind
	--
	resetbind.Event:Connect(function() 
		framework.networking.toServer(false, "ResettingCharacter") end)
	--
end