return {
["1"] = {
["GUID"] = "aa595562-0870-4bb4-ad8d-a70dbd252891", 
["Name"] = "theChromes", 
["ClassName"] = "Folder", 
["Parent"] = "%IPARENT:ReplicatedStorage/PlantsStorage/Evil/", 
["Children"] = {
["1"] = {
["GUID"] = "639ad70c-fd3a-400d-a73b-7cae9af032ac", 
["Name"] = "onex", 
["ClassName"] = "Folder"
}, 
["2"] = {
["GUID"] = "60c891fc-1e54-410c-833c-e024b37cf537", 
["Name"] = "onexR", 
["ClassName"] = "Folder", 
["Children"] = {
["1"] = {
["GUID"] = "07efc377-6387-44b9-822c-864cd2062a81", 
["Name"] = "NewTorso", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["CFrame"] = CFrame.new(-119749.000000, 999961664.000000, -176960.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["CanTouch"] = false, 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["MeshId"] = "rbxassetid://71409669745552", 
["Size"] = Vector3.new(1.999998, 2.000000, 1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "e9e96a41-ab6e-4c90-bb67-e1ebfd72a1fd", 
["Name"] = "Weld", 
["ClassName"] = "Weld", 
["Properties"] = {
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/07efc377-6387-44b9-822c-864cd2062a81", 
["C0"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000)
}, 
["Attributes"] = {
["SetPart0To"] = "Torso"
}
}
}, 
["Attributes"] = {
["FakeInvis"] = "Torso", 
["CopySkin"] = "Torso"
}
}, 
["2"] = {
["GUID"] = "55c1efe9-482a-43f2-9b15-d3684ce75c70", 
["Name"] = "NewLeftArm", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["CollisionGroup"] = "Players", 
["CFrame"] = CFrame.new(35162.000000, 1000124288.000000, 146275.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["CanTouch"] = false, 
["Massless"] = true, 
["Anchored"] = false, 
["MeshId"] = "rbxassetid://127907733900619", 
["Material"] = Enum.Material.SmoothPlastic, 
["EnableFluidForces"] = false, 
["Size"] = Vector3.new(1.000002, 2.000000, 1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "163d3aef-ac10-44ff-b8b8-10c8d0bad354", 
["Name"] = "Weld", 
["ClassName"] = "Weld", 
["Properties"] = {
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/55c1efe9-482a-43f2-9b15-d3684ce75c70", 
["C0"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000)
}, 
["Attributes"] = {
["SetPart0To"] = "Left Arm"
}
}
}, 
["Attributes"] = {
["FakeInvis"] = "Left Arm", 
["CopySkin"] = "Left Arm"
}
}, 
["3"] = {
["GUID"] = "9c22be63-abbe-44b7-9c7d-eefdc2a61c58", 
["Name"] = "NewRightLeg", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["CollisionGroup"] = "Players", 
["CFrame"] = CFrame.new(155424.000000, 999917056.000000, -90018.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["CanTouch"] = false, 
["Massless"] = true, 
["Anchored"] = false, 
["MeshId"] = "rbxassetid://112792796531825", 
["Material"] = Enum.Material.SmoothPlastic, 
["EnableFluidForces"] = false, 
["Size"] = Vector3.new(0.999998, 2.000000, 1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "bea76431-65a9-4c55-9a46-56f9045d3158", 
["Name"] = "Weld", 
["ClassName"] = "Weld", 
["Properties"] = {
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/9c22be63-abbe-44b7-9c7d-eefdc2a61c58", 
["C0"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000)
}, 
["Attributes"] = {
["SetPart0To"] = "Right Leg"
}
}
}, 
["Attributes"] = {
["FakeInvis"] = "Right Leg", 
["CopySkin"] = "Right Leg"
}
}, 
["4"] = {
["GUID"] = "7b0e0efb-29e0-42c2-b14e-d0a53b0942cd", 
["Name"] = "NewRightArm", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["CollisionGroup"] = "Players", 
["CFrame"] = CFrame.new(143452.000000, 999997632.000000, -46647.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["CanTouch"] = false, 
["Massless"] = true, 
["Anchored"] = false, 
["MeshId"] = "rbxassetid://103271567437199", 
["Material"] = Enum.Material.SmoothPlastic, 
["EnableFluidForces"] = false, 
["Size"] = Vector3.new(1.000000, 2.000000, 1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "49d46fa2-e5f3-4234-93fe-16bb31f6aed9", 
["Name"] = "Weld", 
["ClassName"] = "Weld", 
["Properties"] = {
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/7b0e0efb-29e0-42c2-b14e-d0a53b0942cd", 
["C0"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000)
}, 
["Attributes"] = {
["SetPart0To"] = "Right Arm"
}
}
}, 
["Attributes"] = {
["FakeInvis"] = "Right Arm", 
["CopySkin"] = "Right Arm"
}
}, 
["5"] = {
["GUID"] = "effb04e0-504b-4fc9-ad88-271d42f4eeac", 
["Name"] = "NewLeftLeg", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["CollisionGroup"] = "Players", 
["CFrame"] = CFrame.new(195086.000000, 1000170688.000000, -60478.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["CanTouch"] = false, 
["Massless"] = true, 
["Anchored"] = false, 
["MeshId"] = "rbxassetid://91583113200546", 
["Material"] = Enum.Material.SmoothPlastic, 
["EnableFluidForces"] = false, 
["Size"] = Vector3.new(1.000000, 2.000000, 1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "d9a87002-efba-4617-9ede-90a881833067", 
["Name"] = "Weld", 
["ClassName"] = "Weld", 
["Properties"] = {
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/effb04e0-504b-4fc9-ad88-271d42f4eeac", 
["C0"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000)
}, 
["Attributes"] = {
["SetPart0To"] = "Left Leg"
}
}
}, 
["Attributes"] = {
["FakeInvis"] = "Left Leg", 
["CopySkin"] = "Left Leg"
}
}, 
["6"] = {
["GUID"] = "fe889ea9-09f1-4e95-8467-78cb4de0debd", 
["Name"] = "M6DLowerR", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["CollisionGroup"] = "Players", 
["CFrame"] = CFrame.new(41103.000000, 999869824.000000, 145686.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["CanTouch"] = false, 
["EnableFluidForces"] = false, 
["Anchored"] = false, 
["Transparency"] = 1, 
["Massless"] = true, 
["Color"] = Color3.new(0.972549,0.972549,0.972549), 
["CastShadow"] = false, 
["Size"] = Vector3.new(0.200000, 0.200000, 0.200000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "958e6a55-923d-433c-bc27-91aac0a34b4c", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["Scale"] = Vector3.new(0.000000, 0.000000, 0.000000), 
["MeshType"] = Enum.MeshType.Brick
}
}, 
["2"] = {
["GUID"] = "8f8028f0-9b30-42e4-97d1-331690380050", 
["Name"] = "6D", 
["ClassName"] = "Motor6D", 
["Properties"] = {
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["C0"] = CFrame.new(0.250000, -1.000000, 0.500000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/fe889ea9-09f1-4e95-8467-78cb4de0debd"
}, 
["Attributes"] = {
["SetPart0To"] = "Torso"
}
}, 
["3"] = {
["GUID"] = "bb5a51c7-ed42-4795-9a70-4a03be4f7d77", 
["Name"] = "ColorP", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanCollide"] = false, 
["CollisionGroup"] = "Players", 
["CFrame"] = CFrame.new(0.931392, 1.950166, -11.390879, -0.000000, 0.000000, -1.000000, -0.000000, 1.000000, 0.000000, 1.000000, 0.000000, -0.000000), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(0.000000, -90.000000, 0.000000), 
["Anchored"] = false, 
["MeshId"] = "rbxassetid://7014168388", 
["Material"] = Enum.Material.SmoothPlastic, 
["EnableFluidForces"] = false, 
["Size"] = Vector3.new(1.153247, 1.422421, 1.181728)
}, 
["Children"] = {
["1"] = {
["GUID"] = "755978e8-306d-4b2f-afc2-1eb5025799d6", 
["Name"] = "Weldd", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/fe889ea9-09f1-4e95-8467-78cb4de0debd", 
["C0"] = CFrame.new(0.250000, -0.049805, -0.099609, -0.000000, 0.000000, -1.000000, -0.000000, 1.000000, 0.000000, 1.000000, 0.000000, -0.000000), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/bb5a51c7-ed42-4795-9a70-4a03be4f7d77"
}
}
}, 
["Attributes"] = {
["CopySkin"] = "Torso"
}
}
}
}, 
["7"] = {
["GUID"] = "df407397-2e86-4c8b-b857-55f0ecfe789d", 
["Name"] = "M6DLowerL", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["CollisionGroup"] = "Players", 
["CFrame"] = CFrame.new(137372.000000, 999946304.000000, -73787.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["CanTouch"] = false, 
["EnableFluidForces"] = false, 
["Anchored"] = false, 
["Transparency"] = 1, 
["Massless"] = true, 
["Color"] = Color3.new(0.972549,0.972549,0.972549), 
["CastShadow"] = false, 
["Size"] = Vector3.new(0.200000, 0.200000, 0.200000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "86e71b39-6c92-48b7-ad96-39c998099014", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["Scale"] = Vector3.new(0.000000, 0.000000, 0.000000), 
["MeshType"] = Enum.MeshType.Brick
}
}, 
["2"] = {
["GUID"] = "c49ec28c-0a66-4119-8243-f8e090310443", 
["Name"] = "6D", 
["ClassName"] = "Motor6D", 
["Properties"] = {
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["C0"] = CFrame.new(-0.250000, -1.000000, 0.500000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/df407397-2e86-4c8b-b857-55f0ecfe789d"
}, 
["Attributes"] = {
["SetPart0To"] = "Torso"
}
}, 
["3"] = {
["GUID"] = "18cff9e7-5d83-4289-9b86-969e25e92e7e", 
["Name"] = "ColorP", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanCollide"] = false, 
["CollisionGroup"] = "Players", 
["CFrame"] = CFrame.new(-0.068486, 1.950227, -11.391367, -0.000000, 0.000000, -1.000000, 0.000000, 1.000000, 0.000000, 1.000000, -0.000000, -0.000000), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(0.000000, -90.000000, 0.000000), 
["Anchored"] = false, 
["MeshId"] = "rbxassetid://7014170419", 
["Material"] = Enum.Material.SmoothPlastic, 
["EnableFluidForces"] = false, 
["Size"] = Vector3.new(1.153000, 1.422000, 1.182000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "a8ac13d7-cfdc-4edc-b8ed-7335c826aa77", 
["Name"] = "Weldd", 
["ClassName"] = "Weld", 
["Properties"] = {
["C1"] = CFrame.new(0.100098, 0.049744, -0.249878, -0.000000, 0.000000, 1.000000, -0.000000, 1.000000, -0.000000, -1.000000, -0.000000, -0.000000), 
["C0"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, -0.000000, -0.000000, 1.000000, -0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/18cff9e7-5d83-4289-9b86-969e25e92e7e", 
["Part0"] = "%PARENT/df407397-2e86-4c8b-b857-55f0ecfe789d"
}
}
}, 
["Attributes"] = {
["CopySkin"] = "Torso"
}
}
}
}, 
["8"] = {
["GUID"] = "5cf0cd4e-f8b0-4060-a66f-70f640914f18", 
["Name"] = "KM6Rod", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Anchored"] = false, 
["CanTouch"] = false, 
["Transparency"] = 1, 
["CFrame"] = CFrame.new(-179886.000000, 999801984.000000, -123954.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Massless"] = true, 
["Size"] = Vector3.new(0.250000, 0.250000, 0.250000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "95928596-c630-4c1d-8c4d-a91a06419db7", 
["Name"] = "tip", 
["ClassName"] = "Attachment", 
["Properties"] = {
["WorldPosition"] = Vector3.new(-179886.000000, 999801984.000000, -123954.000000), 
["WorldOrientation"] = Vector3.new(-0.000005, 0.000065, 0.002026), 
["CFrame"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, -0.000035, 0.000001, 0.000035, 1.000000, 0.000000, -0.000001, -0.000000, 1.000000), 
["Axis"] = Vector3.new(1.000000, 0.000035, -0.000001), 
["SecondaryAxis"] = Vector3.new(-0.000035, 1.000000, -0.000000), 
["WorldCFrame"] = CFrame.new(-179886.000000, 999801984.000000, -123954.000000, 1.000000, -0.000035, 0.000001, 0.000035, 1.000000, 0.000000, -0.000001, -0.000000, 1.000000), 
["Orientation"] = Vector3.new(-0.000005, 0.000065, 0.002026), 
["WorldSecondaryAxis"] = Vector3.new(-0.000035, 1.000000, -0.000000), 
["WorldAxis"] = Vector3.new(1.000000, 0.000035, -0.000001)
}
}, 
["2"] = {
["GUID"] = "aa24866c-9f90-4bb1-8b98-feb25ff0a0fd", 
["Name"] = "mes", 
["ClassName"] = "Model", 
["Properties"] = {
["WorldPivot"] = CFrame.new(-1.358891, 0.076638, -4.414687, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "c0caf9ab-1ea2-4f18-88d0-b81fbab93987", 
["Name"] = "tippytopmes", 
["ClassName"] = "Folder", 
["Children"] = {
["1"] = {
["GUID"] = "158313da-a77f-402c-a74a-b851adf28d51", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.433988, 1.895667, -12.630798, -0.000026, 0.000000, -1.000000, 0.060188, 0.998187, -0.000002, 0.998187, -0.060188, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(-3.451000, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.692970, 0.202074, 0.165621)
}, 
["Children"] = {
["1"] = {
["GUID"] = "bb3fd94b-a533-43a0-bf5e-5ab3a4c376c2", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "5e516ac0-a860-49dc-a394-1448362a8213", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/158313da-a77f-402c-a74a-b851adf28d51", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["2"] = {
["GUID"] = "0d4c35ce-7069-4665-9486-c3b864c5bb41", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.433994, 1.899267, -12.850277, -0.000026, -0.000004, -1.000000, -0.079318, 0.996849, -0.000002, 0.996849, 0.079318, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(4.549000, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.884626, 0.203619, 0.165621)
}, 
["Children"] = {
["1"] = {
["GUID"] = "fd41032e-13e1-4e89-aaef-df5ecd4b4b84", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "95f2ed74-2037-4ed6-bbec-e38d7d51528b", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/0d4c35ce-7069-4665-9486-c3b864c5bb41", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["3"] = {
["GUID"] = "279d8368-1565-44c0-9d5d-a94b5a518f92", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.434002, 1.966187, -13.198878, -0.000024, -0.000011, -1.000000, -0.318125, 0.948049, -0.000003, 0.948049, 0.318125, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(18.549999, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.764069, 0.208256, 0.150165)
}, 
["Children"] = {
["1"] = {
["GUID"] = "90435f26-fedc-47d5-a839-a712de3f3f3b", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "33472575-8388-4cee-ada1-455b92f77660", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/279d8368-1565-44c0-9d5d-a94b5a518f92", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["4"] = {
["GUID"] = "9b3a6ce6-1af7-48b2-8a85-0f8a67e4182e", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.433985, 1.903063, -12.508145, -0.000026, -0.000002, -1.000000, 0.060184, 0.998187, -0.000003, 0.998187, -0.060184, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(-3.450000, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.292658, 0.202074, 0.205807)
}, 
["Children"] = {
["1"] = {
["GUID"] = "1c361791-7449-402e-883f-ab11d14466de", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "1447e09f-e4f5-47af-afc1-b85cf9c63375", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/9b3a6ce6-1af7-48b2-8a85-0f8a67e4182e", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["5"] = {
["GUID"] = "0f4a2104-8c93-4a3a-8e97-865367726bd1", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.433984, 1.916972, -12.481071, -0.000026, 0.000001, -1.000000, 0.164194, 0.986428, -0.000003, 0.986428, -0.164194, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(-9.450000, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.762522, 0.203619, 0.143983)
}, 
["Children"] = {
["1"] = {
["GUID"] = "c4d85802-4224-4406-b194-711a3a4ba29b", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "6a36f5e1-75fd-4bdf-b00a-8b86a1d36337", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/0f4a2104-8c93-4a3a-8e97-865367726bd1", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["6"] = {
["GUID"] = "728d0dcb-f161-4f19-a00d-c27c27b2cda2", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.433985, 1.969551, -12.535381, -0.000026, -0.000001, -1.000000, 0.094984, 0.995479, -0.000003, 0.995479, -0.094984, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(-5.450000, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.586323, 0.232986, 0.298543)
}, 
["Children"] = {
["1"] = {
["GUID"] = "2fd0e5a4-622f-49e8-8c2a-030700315008", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "056128dc-da25-45db-a6eb-7d4603d584eb", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/728d0dcb-f161-4f19-a00d-c27c27b2cda2", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["7"] = {
["GUID"] = "fcae9faf-7a87-410c-8920-4e3cae5d3a7d", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.434001, 2.088351, -13.184201, -0.000027, 0.000003, -1.000000, -0.061895, 0.998083, 0.000005, 0.998083, 0.061895, -0.000027), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(3.549000, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.638642, 0.194396, 0.215220)
}, 
["Children"] = {
["1"] = {
["GUID"] = "1e8a18c9-a474-4543-b593-9d6a8094f159", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "7a093e64-854a-44d0-a8a1-ae79885503b5", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/fcae9faf-7a87-410c-8920-4e3cae5d3a7d", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["8"] = {
["GUID"] = "baaddfd8-9566-411f-a27c-9109fea4bb76", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.433997, 1.991754, -13.048523, -0.000027, -0.000000, -1.000000, -0.131370, 0.991333, 0.000003, 0.991333, 0.131370, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(7.549000, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.715922, 0.254674, 0.233767)
}, 
["Children"] = {
["1"] = {
["GUID"] = "6f9b5021-7a6a-40f6-b3f4-ba4996332469", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "f9e6b221-9fe8-43b2-a066-a2031481502b", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/baaddfd8-9566-411f-a27c-9109fea4bb76", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["9"] = {
["GUID"] = "e2b648e4-482b-4a92-8ef2-79db63aa2a84", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.433991, 2.018270, -12.765090, -0.000026, -0.000002, -1.000000, -0.009589, 0.999954, -0.000002, 0.999954, 0.009589, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(0.549000, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(1.059359, 0.346129, 0.339413)
}, 
["Children"] = {
["1"] = {
["GUID"] = "847e473c-9850-4a0d-8d56-ad7133084386", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "0c99e74e-1cd8-4a9f-a97f-1340e7682da4", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/e2b648e4-482b-4a92-8ef2-79db63aa2a84", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["10"] = {
["GUID"] = "041c9a01-1d48-4493-8ef3-6aed7ab80e84", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.433996, 2.019588, -12.977044, -0.000026, -0.000005, -1.000000, -0.079321, 0.996849, -0.000003, 0.996849, 0.079321, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(4.550000, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.766137, 0.308762, 0.289735)
}, 
["Children"] = {
["1"] = {
["GUID"] = "2b056580-b3b9-45f8-adb8-d5892e752b4c", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "be7736ad-8791-4f12-86db-3a76b6fd9658", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/041c9a01-1d48-4493-8ef3-6aed7ab80e84", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["11"] = {
["GUID"] = "fc23bedf-f8eb-4b5c-9e93-a5b8e80f2ddb", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.433997, 2.041828, -13.030313, -0.000026, -0.000006, -1.000000, -0.096707, 0.995313, -0.000003, 0.995313, 0.096707, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(5.550000, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.830297, 0.280950, 0.246132)
}, 
["Children"] = {
["1"] = {
["GUID"] = "2d055d1c-83c9-4f50-8039-6861041ede11", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "dd2963a3-5c45-434a-a71c-9afdf4b3d4ca", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/fc23bedf-f8eb-4b5c-9e93-a5b8e80f2ddb", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["12"] = {
["GUID"] = "e1c057b3-17f5-48df-9833-aa4070249788", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.433994, 2.018785, -12.889151, -0.000026, -0.000004, -1.000000, -0.079318, 0.996849, -0.000002, 0.996849, 0.079318, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(4.549000, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.861533, 0.321118, 0.309070)
}, 
["Children"] = {
["1"] = {
["GUID"] = "2ed15e8a-9eb8-4067-b08c-6b6ab8e77bed", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "12e9e097-d85f-4481-9fab-14d85dedae2d", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/e1c057b3-17f5-48df-9833-aa4070249788", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["13"] = {
["GUID"] = "58d475bc-5f9a-4334-80c0-621a1dc30875", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.433998, 2.008225, -13.084048, -0.000026, -0.000001, -1.000000, -0.096696, 0.995314, 0.000002, 0.995314, 0.096696, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(5.549000, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.785474, 0.253129, 0.255406)
}, 
["Children"] = {
["1"] = {
["GUID"] = "4beafc23-98fd-49b2-8b9f-74de0ddc9bbf", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "d4da2629-9110-48cf-ba50-96c5da26eee7", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/58d475bc-5f9a-4334-80c0-621a1dc30875", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["14"] = {
["GUID"] = "553d5387-c308-42f9-9010-110737350814", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.434004, 2.053773, -13.282088, -0.000025, -0.000007, -1.000000, -0.165901, 0.986143, -0.000003, 0.986143, 0.165900, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(9.550000, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.504174, 0.246946, 0.233767)
}, 
["Children"] = {
["1"] = {
["GUID"] = "ea10c14b-afbe-489d-998c-c0a5ae712a1d", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "3a8d2f8f-ec2c-4ff8-abd1-c2ed34b3b033", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/553d5387-c308-42f9-9010-110737350814", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["15"] = {
["GUID"] = "261b231e-5ba3-4eff-bc62-e9288484b0f7", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.433986, 2.020236, -12.606568, -0.000026, 0.000002, -1.000000, 0.060192, 0.998187, 0.000000, 0.998187, -0.060192, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(-3.451000, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.858350, 0.333450, 0.320182)
}, 
["Children"] = {
["1"] = {
["GUID"] = "f9836c05-6413-49ee-96a2-d6cd85e76d79", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "82eb7669-1943-443b-9aa4-d50d574858a7", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/261b231e-5ba3-4eff-bc62-e9288484b0f7", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["16"] = {
["GUID"] = "4dfb7185-bc7a-488f-8470-248db5997ac9", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.433999, 2.035133, -13.057364, -0.000026, -0.000004, -1.000000, -0.096703, 0.995313, -0.000002, 0.995313, 0.096703, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(5.549000, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.882848, 0.262402, 0.267771)
}, 
["Children"] = {
["1"] = {
["GUID"] = "1c626b8b-28ff-4d83-8f55-5d4d466a5781", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "96b6393c-8912-44ee-8c03-6c26804aaa59", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/4dfb7185-bc7a-488f-8470-248db5997ac9", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["17"] = {
["GUID"] = "827e3bab-a002-4a52-acf6-8fbcb0c8364e", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.433985, 2.024506, -12.535598, -0.000026, -0.000002, -1.000000, 0.060185, 0.998187, -0.000003, 0.998187, -0.060185, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(-3.450000, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.898536, 0.308721, 0.320182)
}, 
["Children"] = {
["1"] = {
["GUID"] = "fcda3ab8-7dc0-4d79-acee-661566091d8e", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "e7d4a72d-4949-41ec-bad3-1ba8a727b966", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/827e3bab-a002-4a52-acf6-8fbcb0c8364e", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["18"] = {
["GUID"] = "9a501fd8-a18c-4af7-8497-593347fa57a5", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.433981, 2.033901, -12.379773, -0.000026, 0.000000, -1.000000, 0.060188, 0.998187, -0.000002, 0.998187, -0.060188, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(-3.451000, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.620327, 0.293265, 0.298543)
}, 
["Children"] = {
["1"] = {
["GUID"] = "ab458866-8798-42fd-9093-7438b99519d8", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "028cdecf-eb99-4697-b5af-992b1853c31d", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/9a501fd8-a18c-4af7-8497-593347fa57a5", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["19"] = {
["GUID"] = "e7276e60-2155-4dc7-b2f8-eb8675bd51b1", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.434008, 2.113513, -13.399959, -0.000018, -0.000019, -1.000000, -0.676220, 0.736700, -0.000002, 0.736700, 0.676220, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(42.549000, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.122926, 0.226110, 0.203663)
}, 
["Children"] = {
["1"] = {
["GUID"] = "01591f06-4f66-4c1d-9a49-7e06321ac0be", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "7dace8da-06fc-491f-a868-df8f3807cdf5", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/e7276e60-2155-4dc7-b2f8-eb8675bd51b1", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["20"] = {
["GUID"] = "c90592b0-082d-4c23-9add-5c4865ad18d5", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.434008, 2.111374, -13.417909, -0.000015, -0.000021, -1.000000, -0.738271, 0.674504, -0.000003, 0.674504, 0.738271, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(47.584000, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.129981, 0.236588, 0.198442)
}, 
["Children"] = {
["1"] = {
["GUID"] = "8eec01ad-503c-424c-8a75-568a235b3be7", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "4643049b-64f9-4e43-9605-a9616147cb29", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/c90592b0-082d-4c23-9add-5c4865ad18d5", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["21"] = {
["GUID"] = "14b5cbc1-34fe-4e27-91aa-f5448b0871bb", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.434009, 2.103710, -13.433988, -0.000013, -0.000023, -1.000000, -0.844788, 0.535101, -0.000002, 0.535101, 0.844788, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(57.648998, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.137894, 0.206632, 0.194953)
}, 
["Children"] = {
["1"] = {
["GUID"] = "db16a2fc-8d3c-437d-af53-d50b8b49c29e", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "c32ae9b1-2589-4c3d-8e57-24d9272187bc", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/14b5cbc1-34fe-4e27-91aa-f5448b0871bb", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["22"] = {
["GUID"] = "6a24f6c2-49bb-45a5-a63c-84bbb269c44d", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.434009, 2.112499, -13.440545, -0.000015, -0.000022, -1.000000, -0.794601, 0.607132, -0.000002, 0.607132, 0.794601, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(52.618000, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.110449, 0.204659, 0.184480)
}, 
["Children"] = {
["1"] = {
["GUID"] = "65af7f0e-0bcc-444d-b7b5-a0e5f8b08cf5", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "f89748b0-6cf2-4ebc-a529-347120bf9818", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/6a24f6c2-49bb-45a5-a63c-84bbb269c44d", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["23"] = {
["GUID"] = "087a6fee-c5eb-4f3c-87db-540f72004908", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.434008, 2.114626, -13.395160, -0.000016, -0.000020, -1.000000, -0.738264, 0.674511, -0.000002, 0.674511, 0.738265, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(47.584000, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.099548, 0.256845, 0.217439)
}, 
["Children"] = {
["1"] = {
["GUID"] = "0c9f85f8-5079-4d9f-beb7-efbc709ac481", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "98941aaf-df88-480f-8782-2efa441a361e", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/087a6fee-c5eb-4f3c-87db-540f72004908", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["24"] = {
["GUID"] = "11a39f8b-d733-4123-9ccb-5c3ae1159f0d", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.434009, 2.102391, -13.450795, -0.000008, -0.000025, -1.000000, -0.925230, 0.379408, -0.000002, 0.379408, 0.925230, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(67.703003, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.123859, 0.173876, 0.175210)
}, 
["Children"] = {
["1"] = {
["GUID"] = "148d6c83-10c5-47ab-9d1b-ec7d4ca4c31a", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "ea22019b-7488-4a3d-a065-cc6b11e6589d", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/11a39f8b-d733-4123-9ccb-5c3ae1159f0d", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["25"] = {
["GUID"] = "af369524-5c60-4402-8908-99e02883bdfc", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.434009, 2.094764, -13.454709, -0.000000, -0.000026, -1.000000, -0.991998, 0.126254, -0.000003, 0.126254, 0.991998, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(82.747002, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.118232, 0.177393, 0.152404)
}, 
["Children"] = {
["1"] = {
["GUID"] = "6906e7c8-c594-4fdc-8d35-24369246aeeb", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "12778417-4d3d-478c-bcf2-42f7d03ac309", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/af369524-5c60-4402-8908-99e02883bdfc", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["26"] = {
["GUID"] = "76790edd-2166-4dfa-95f8-72939c11ec9c", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.434010, 2.094351, -13.463274, -0.000002, -0.000026, -1.000000, -0.991996, 0.126269, -0.000002, 0.126269, 0.991996, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(82.746002, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.101286, 0.194488, 0.125128)
}, 
["Children"] = {
["1"] = {
["GUID"] = "e7532675-a1ac-4d81-a84b-7d8504b39e64", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "b8764755-fd83-40f0-92eb-544f2272ffe0", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/76790edd-2166-4dfa-95f8-72939c11ec9c", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["27"] = {
["GUID"] = "eaac455b-8b9e-4c89-b891-f6f24f4b8b88", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.434010, 2.091328, -13.472263, 0.000002, -0.000026, -1.000000, -0.999229, 0.039265, -0.000003, 0.039265, 0.999229, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(87.750000, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.080011, 0.203378, 0.108056)
}, 
["Children"] = {
["1"] = {
["GUID"] = "66c6a3b3-7b49-4924-b8df-dc69f85953d6", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "621fb842-c6b7-40df-9b94-34162b60c007", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/eaac455b-8b9e-4c89-b891-f6f24f4b8b88", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["28"] = {
["GUID"] = "3a579974-b905-484f-879d-a37fbd81cce0", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.434011, 2.071705, -13.501149, 0.000017, -0.000020, -1.000000, -0.842286, -0.539032, -0.000003, -0.539032, 0.842286, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(122.617996, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.094347, 0.123393, 0.116837)
}, 
["Children"] = {
["1"] = {
["GUID"] = "6969e375-347a-4f6e-b8b4-f6e4b89fb75d", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "f27cfc07-8404-4b6c-a77d-a469343c108e", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/3a579974-b905-484f-879d-a37fbd81cce0", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["29"] = {
["GUID"] = "623165ef-f282-4a81-82db-7031f2d60b0d", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.434010, 2.078941, -13.487390, 0.000017, -0.000020, -1.000000, -0.842286, -0.539032, -0.000003, -0.539031, 0.842286, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(122.617996, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.116275, 0.122246, 0.134986)
}, 
["Children"] = {
["1"] = {
["GUID"] = "1664dd63-e231-42a9-a11a-98d7f6a33a91", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "98df3166-ebad-4d40-b47a-4bd4c95de4fa", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/623165ef-f282-4a81-82db-7031f2d60b0d", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["30"] = {
["GUID"] = "0522851d-5a1a-4b2c-8f94-cd0795979741", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.434011, 2.065912, -13.518644, 0.000017, -0.000020, -1.000000, -0.842286, -0.539032, -0.000003, -0.539032, 0.842286, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(122.617996, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.059254, 0.133397, 0.081879)
}, 
["Children"] = {
["1"] = {
["GUID"] = "f7a47675-9e3a-4717-a671-e6ecd463d1fb", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "d6d455b7-ef2e-4fa9-8685-d4ed26d5decc", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/0522851d-5a1a-4b2c-8f94-cd0795979741", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["31"] = {
["GUID"] = "5e7556bf-5eea-45e9-9903-37901ae55b19", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.434011, 2.062817, -13.516642, 0.000017, -0.000020, -1.000000, -0.842286, -0.539032, -0.000003, -0.539032, 0.842286, -0.000026), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(122.617996, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.062326, 0.126712, 0.099214)
}, 
["Children"] = {
["1"] = {
["GUID"] = "a5dbbb38-319e-4daf-879e-e62a08597b8e", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "ae7a2e9f-2bda-466e-bd9f-687459b79dcc", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/5e7556bf-5eea-45e9-9903-37901ae55b19", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}
}
}, 
["2"] = {
["GUID"] = "9775acf1-bcc0-4211-90f1-83cf03e4a80f", 
["Name"] = "balmes", 
["ClassName"] = "Folder", 
["Children"] = {
["1"] = {
["GUID"] = "16a4d7f8-41cd-4ece-82bc-d47f0a4f888a", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.433993, 2.027222, -12.499700, -0.000027, 0.000010, -1.000000, 0.060169, 0.998188, 0.000009, 0.998190, -0.060175, -0.000027), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(-3.449000, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.238707, 0.080547, 0.148054)
}, 
["Children"] = {
["1"] = {
["GUID"] = "56e069d3-929e-4bc9-910a-a21327dd1cdb", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "33bb92c5-33a9-4865-8254-cc9c2ff3dc91", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/16a4d7f8-41cd-4ece-82bc-d47f0a4f888a", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["2"] = {
["GUID"] = "1680bfff-629f-416f-962f-3d577f954c0a", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.299761, 2.009017, -12.500430, 0.002583, -0.175157, -0.984537, 0.060413, 0.982769, -0.174684, 0.998172, -0.059027, 0.013120), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(85.705002, -79.911003, 89.154999), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.305790, 0.350967, 0.259930)
}, 
["Children"] = {
["1"] = {
["GUID"] = "4f167629-5b0c-4240-824a-2c1e6554e889", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "8b6f1318-0197-42e3-a459-039940a978b8", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/1680bfff-629f-416f-962f-3d577f954c0a", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["3"] = {
["GUID"] = "92708804-fc7d-4bde-bb07-ba302e8f07f3", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.302424, 2.075298, -12.505218, -0.003917, 0.261004, -0.965330, 0.060698, 0.963619, 0.260295, 0.998150, -0.057574, -0.019617), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(-94.309998, -74.869003, -90.860001), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.325351, 0.379869, 0.256246)
}, 
["Children"] = {
["1"] = {
["GUID"] = "dcf3a14c-a07b-49fc-84c7-0a0267e0fe1a", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "9674fe0f-3783-4420-9677-3d43605aca5b", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/92708804-fc7d-4bde-bb07-ba302e8f07f3", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["4"] = {
["GUID"] = "aeaa7294-f85c-420f-b738-09ce0ef8ed5e", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.320506, 2.153240, -12.511105, -0.009688, 0.646143, -0.763155, 0.063721, 0.762039, 0.644388, 0.997923, -0.042387, -0.048556), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(-94.308998, -49.743000, -90.859001), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.257107, 0.270348, 0.206475)
}, 
["Children"] = {
["1"] = {
["GUID"] = "bc01b093-3b3b-4961-937a-3de61fa30361", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "6d400774-572a-4836-982b-75591fb3eb3e", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/aeaa7294-f85c-420f-b738-09ce0ef8ed5e", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["5"] = {
["GUID"] = "fc52d2dd-d6cf-4d79-9858-d64e11eabf25", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.433993, 2.027222, -12.499700, -0.000027, 0.000010, -1.000000, 0.060169, 0.998188, 0.000009, 0.998190, -0.060175, -0.000027), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(-3.449000, -90.000000, 0.000000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.238707, 0.080547, 0.148054)
}, 
["Children"] = {
["1"] = {
["GUID"] = "68ad6400-5921-4d8f-8987-9fb6c7caa41c", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "8ec3a3db-b593-4666-a7fa-505ac453f46a", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/fc52d2dd-d6cf-4d79-9858-d64e11eabf25", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["6"] = {
["GUID"] = "c1ab5b74-496b-4a74-9be9-36b7b50e1cae", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.568223, 2.009014, -12.500423, -0.002637, 0.175177, -0.984533, 0.060413, 0.982766, 0.174701, 0.998172, -0.059018, -0.013174), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(-94.313004, -79.910004, -90.862000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.305790, 0.350967, 0.259930)
}, 
["Children"] = {
["1"] = {
["GUID"] = "b2c1138a-1ccf-419d-98ca-306f32c89c17", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "0e3db02c-7b51-4351-9518-4c496fa630da", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/c1ab5b74-496b-4a74-9be9-36b7b50e1cae", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["7"] = {
["GUID"] = "221a32b1-1e47-4548-aeaa-0dc70004d261", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.565562, 2.075295, -12.505210, 0.003863, -0.260985, -0.965335, 0.060698, 0.963624, -0.260279, 0.998151, -0.057589, 0.019564), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(85.700996, -74.870003, 89.152000), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.325351, 0.379869, 0.256246)
}, 
["Children"] = {
["1"] = {
["GUID"] = "bfabd9df-a4d0-4c84-95ad-8f2ff5b6f0ef", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "0f139b05-9029-4b3d-8e0d-ce9a652c2fa3", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/221a32b1-1e47-4548-aeaa-0dc70004d261", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["8"] = {
["GUID"] = "b4917816-0fde-489a-a978-c5da38fc65b9", 
["Name"] = "Part", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.546889, 2.152747, -12.511061, 0.009634, -0.646127, -0.763169, 0.063721, 0.762050, -0.644375, 0.997923, -0.042422, 0.048514), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(85.694000, -49.743999, 89.146004), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.257107, 0.270348, 0.204933)
}, 
["Children"] = {
["1"] = {
["GUID"] = "c4c4245d-10d9-4bb7-a4d1-472b5834a3a8", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.Sphere
}
}, 
["2"] = {
["GUID"] = "9cbe81f8-9189-409f-82c7-142b54ed7a24", 
["Name"] = "WeldConstraint", 
["ClassName"] = "WeldConstraint", 
["Properties"] = {
["Part0"] = "%PARENT/b4917816-0fde-489a-a978-c5da38fc65b9", 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}
}
}, 
["3"] = {
["GUID"] = "b097fe93-f7b0-4a6b-b332-af998fc5b644", 
["Name"] = "veinyah", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.432547, 2.089637, -12.808848, -1.000000, 0.000000, -0.000000, -0.000000, 1.000000, -0.000000, 0.000000, 0.000000, -1.000000), 
["CanTouch"] = false, 
["Size"] = Vector3.new(0.352030, 0.221720, 1.274670), 
["Rotation"] = Vector3.new(180.000000, 0.000000, 180.000000), 
["MeshId"] = "rbxassetid://83471135530983", 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["PivotOffset"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, -0.000000, -0.000000, 1.000000, -0.000000, 0.000000, 0.000000, 1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "7811b58f-2131-4b40-9654-47b978fdfcc4", 
["Name"] = "KM6Rod", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/b097fe93-f7b0-4a6b-b332-af998fc5b644", 
["C0"] = CFrame.new(0.001155, -0.122103, -0.660789, -1.000000, -0.000010, 0.000000, -0.000010, 1.000000, 0.000000, -0.000000, 0.000000, -1.000000), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}
}, 
["4"] = {
["GUID"] = "01fed6b9-bcfa-445e-9732-1c1bfccc0f66", 
["Name"] = "innerah", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["CFrame"] = CFrame.new(0.433642, 2.024707, -12.118037, -1.000000, 0.000000, -0.000000, -0.000000, 1.000000, -0.000000, 0.000000, 0.000000, -1.000000), 
["CanTouch"] = false, 
["Size"] = Vector3.new(0.250300, 0.270894, 0.551300), 
["Rotation"] = Vector3.new(180.000000, 0.000000, 180.000000), 
["MeshId"] = "rbxassetid://123003510762986", 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["PivotOffset"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, -0.000000, -0.000000, 1.000000, -0.000000, 0.000000, 0.000000, 1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "80e37bb8-014d-4ea3-a408-b937ad313069", 
["Name"] = "KM6Rod", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/01fed6b9-bcfa-445e-9732-1c1bfccc0f66", 
["C0"] = CFrame.new(0.002249, -0.057173, 0.030023, -1.000000, -0.000010, 0.000000, -0.000010, 1.000000, 0.000000, -0.000000, 0.000000, -1.000000), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}, 
["Attributes"] = {
["CopySkin"] = "Torso"
}
}, 
["5"] = {
["GUID"] = "7bfc0571-6ea8-431e-9b62-5897766a9bad", 
["Name"] = "innertwoah", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["CFrame"] = CFrame.new(0.431471, 2.041282, -12.116298, -1.000000, 0.000000, -0.000000, -0.000000, 1.000000, -0.000000, 0.000000, 0.000000, -1.000000), 
["CanTouch"] = false, 
["Size"] = Vector3.new(0.385000, 0.362971, 0.474420), 
["Rotation"] = Vector3.new(180.000000, 0.000000, 180.000000), 
["MeshId"] = "rbxassetid://82608189727680", 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["PivotOffset"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, -0.000000, -0.000000, 1.000000, -0.000000, 0.000000, 0.000000, 1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "fc76d03c-a06a-4768-9795-31198ffc44fe", 
["Name"] = "KM6Rod", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/7bfc0571-6ea8-431e-9b62-5897766a9bad", 
["C0"] = CFrame.new(0.000079, -0.073748, 0.031762, -1.000000, -0.000010, 0.000000, -0.000010, 1.000000, 0.000000, -0.000000, 0.000000, -1.000000), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}, 
["Attributes"] = {
["CopySkin"] = "Torso"
}
}, 
["6"] = {
["GUID"] = "95d5d6f5-2367-47b0-bf0d-5d2d2dee436a", 
["Name"] = "backah", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["CFrame"] = CFrame.new(0.431466, 2.064756, -12.095302, -1.000000, 0.000000, -0.000000, -0.000000, 1.000000, -0.000000, 0.000000, 0.000000, -1.000000), 
["CanTouch"] = false, 
["Size"] = Vector3.new(0.398450, 0.449047, 0.714530), 
["Rotation"] = Vector3.new(180.000000, 0.000000, 180.000000), 
["MeshId"] = "rbxassetid://92393932656515", 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["PivotOffset"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, -0.000000, -0.000000, 1.000000, -0.000000, 0.000000, 0.000000, 1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "ad916aca-83ea-4fda-8db9-3cd9f73a2966", 
["Name"] = "KM6Rod", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/95d5d6f5-2367-47b0-bf0d-5d2d2dee436a", 
["C0"] = CFrame.new(0.000074, -0.097221, 0.052758, -1.000000, -0.000010, 0.000000, -0.000010, 1.000000, 0.000000, -0.000000, 0.000000, -1.000000), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}
}, 
["Attributes"] = {
["CopySkin"] = "Torso"
}
}, 
["7"] = {
["GUID"] = "3337e959-0a0c-4685-a2fa-05d5b0c44116", 
["Name"] = "tippy", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Anchored"] = false, 
["CanTouch"] = false, 
["Transparency"] = 1, 
["CFrame"] = CFrame.new(0.433993, 2.096123, -13.584332, 1.000000, 0.000000, -0.000000, 0.000000, 1.000000, 0.000000, -0.000000, 0.000000, 1.000001), 
["Massless"] = true, 
["Size"] = Vector3.new(0.100000, 0.100000, 0.100000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "d41fd815-e20b-432b-982d-cd9777724f56", 
["Name"] = "trueTip", 
["ClassName"] = "Attachment", 
["Properties"] = {
["WorldPosition"] = Vector3.new(0.433993, 2.096123, -13.584332), 
["WorldOrientation"] = Vector3.new(-0.000004, 0.000065, 0.002026), 
["CFrame"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, -0.000035, 0.000001, 0.000035, 1.000000, 0.000000, -0.000001, -0.000000, 1.000000), 
["Axis"] = Vector3.new(1.000000, 0.000035, -0.000001), 
["SecondaryAxis"] = Vector3.new(-0.000035, 1.000000, -0.000000), 
["WorldCFrame"] = CFrame.new(0.433993, 2.096123, -13.584332, 1.000000, -0.000035, 0.000001, 0.000035, 1.000000, 0.000000, -0.000001, -0.000000, 1.000001), 
["Orientation"] = Vector3.new(-0.000005, 0.000065, 0.002026), 
["WorldSecondaryAxis"] = Vector3.new(-0.000035, 1.000000, -0.000000), 
["WorldAxis"] = Vector3.new(1.000000, 0.000035, -0.000001)
}
}, 
["2"] = {
["GUID"] = "0e50deed-ac4b-4058-a93b-d5f74171c753", 
["Name"] = "KM6Rod", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/3337e959-0a0c-4685-a2fa-05d5b0c44116", 
["C0"] = CFrame.new(-0.002601, -0.128588, 1.436272, 1.000000, 0.000010, -0.000000, -0.000010, 1.000000, 0.000000, 0.000000, -0.000000, 1.000001), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}
}, 
["3"] = {
["GUID"] = "9fcd3876-c5a9-4e0a-a499-1ad9b9334d6a", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshType"] = Enum.MeshType.FileMesh
}
}
}
}
}
}, 
["3"] = {
["GUID"] = "795dd4c0-1f92-4de1-af79-d3ec7b67e299", 
["Name"] = "rod", 
["ClassName"] = "Motor6D", 
["Properties"] = {
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["C0"] = CFrame.new(0.000000, -1.032436, -0.356791, 1.000000, 0.000010, -0.000000, -0.000010, 1.000000, 0.000000, 0.000000, -0.000000, 1.000000), 
["Part1"] = "%PARENT/5cf0cd4e-f8b0-4060-a66f-70f640914f18"
}, 
["Attributes"] = {
["SetPart0To"] = "Torso"
}
}
}
}, 
["9"] = {
["GUID"] = "3cc25085-7803-4dd5-90f0-98e423932807", 
["Name"] = "M6Orbs", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Anchored"] = false, 
["CanTouch"] = false, 
["Transparency"] = 1, 
["CFrame"] = CFrame.new(-36211.000000, 1000154176.000000, -116823.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Massless"] = true, 
["Size"] = Vector3.new(0.250000, 0.250000, 0.250000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "07ac54b8-b919-4469-b32d-79c401422d1e", 
["Name"] = "orbs", 
["ClassName"] = "Motor6D", 
["Properties"] = {
["C1"] = CFrame.new(0.000000, 0.250000, 0.200000, 1.000000, 0.000000, 0.000000, 0.000000, 0.999999, 0.000000, 0.000000, 0.000000, 0.999999), 
["C0"] = CFrame.new(0.000000, -1.000000, -0.425000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/3cc25085-7803-4dd5-90f0-98e423932807"
}, 
["Attributes"] = {
["SetPart0To"] = "Torso"
}
}, 
["2"] = {
["GUID"] = "8e7a32ce-2769-495c-a4fb-31cc4330c7ea", 
["Name"] = "mes", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(0.388235,0.372549,0.384314), 
["CFrame"] = CFrame.new(0.429191, 1.837942, -12.202893, 1.000000, 0.000000, 0.000000, -0.000000, 0.999999, 0.000000, -0.000000, -0.000000, 0.999999), 
["CanTouch"] = false, 
["MeshId"] = "rbxassetid://88223412821003", 
["Size"] = Vector3.new(0.734000, 0.898170, 0.400300), 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["PivotOffset"] = CFrame.new(-0.000100, -1.661361, 0.536870, 1.000000, 0.000000, -0.000000, -0.000000, 1.000000, 0.000000, 0.000000, -0.000000, 1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "b0c562c0-529b-4709-8757-e7c0899f2ee0", 
["Name"] = "M6Orbs", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/8e7a32ce-2769-495c-a4fb-31cc4330c7ea", 
["C0"] = CFrame.new(0.002201, -0.087971, -0.213376, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/3cc25085-7803-4dd5-90f0-98e423932807"
}
}
}, 
["Attributes"] = {
["CopySkin"] = "Torso"
}
}
}
}, 
["10"] = {
["GUID"] = "29f9ae95-9b9d-4ff5-8e25-051010c69f46", 
["Name"] = "M6Rod", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Anchored"] = false, 
["CanTouch"] = false, 
["Transparency"] = 1, 
["CFrame"] = CFrame.new(92634.000000, 1000013120.000000, -121943.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Massless"] = true, 
["Size"] = Vector3.new(0.250000, 0.250000, 0.250000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "073cace4-b073-4a92-8250-206c23419fbc", 
["Name"] = "tip", 
["ClassName"] = "Attachment", 
["Properties"] = {
["WorldPosition"] = Vector3.new(92634.000000, 1000013120.000000, -121944.273438), 
["WorldOrientation"] = Vector3.new(0.000002, -0.000000, -0.000001), 
["CFrame"] = CFrame.new(0.000000, 0.050000, -1.275000, 1.000000, 0.000000, -0.000000, -0.000000, 1.000000, -0.000000, 0.000000, 0.000000, 1.000000), 
["Axis"] = Vector3.new(1.000000, -0.000000, 0.000000), 
["SecondaryAxis"] = Vector3.new(0.000000, 1.000000, 0.000000), 
["WorldAxis"] = Vector3.new(1.000000, -0.000000, 0.000000), 
["Orientation"] = Vector3.new(0.000002, -0.000000, -0.000001), 
["WorldSecondaryAxis"] = Vector3.new(0.000000, 1.000000, 0.000000), 
["WorldCFrame"] = CFrame.new(92634.000000, 1000013120.000000, -121944.273438, 1.000000, 0.000000, -0.000000, -0.000000, 1.000000, -0.000000, 0.000000, 0.000000, 1.000000), 
["Position"] = Vector3.new(0.000000, 0.050000, -1.275000)
}
}, 
["2"] = {
["GUID"] = "20405e3b-a615-4170-b637-606e1a9c50b7", 
["Name"] = "rod", 
["ClassName"] = "Motor6D", 
["Properties"] = {
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["C0"] = CFrame.new(0.000000, -1.000000, -0.500000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/29f9ae95-9b9d-4ff5-8e25-051010c69f46"
}, 
["Attributes"] = {
["SetPart0To"] = "Torso"
}
}, 
["3"] = {
["GUID"] = "754546da-9b82-4e47-a29f-f2ee45e48a31", 
["Name"] = "mes", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["CFrame"] = CFrame.new(0.439357, 2.048837, -12.664042, -1.000000, 0.000030, -0.000000, 0.000030, 1.000000, -0.000000, 0.000000, -0.000000, -1.000000), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(180.000000, 0.000000, -179.998001), 
["Anchored"] = false, 
["MeshId"] = "rbxassetid://80392371902902", 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.439001, 0.428560, 1.521500)
}, 
["Children"] = {
["1"] = {
["GUID"] = "b6d4ec6d-f389-4423-ba2b-f1cabbf213c9", 
["Name"] = "t", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.419475, 2.078553, -13.434039, -1.000000, -0.000000, -0.000000, -0.000000, 1.000000, -0.000027, 0.000000, -0.000027, -1.000000), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(179.998001, 0.000000, 180.000000), 
["Anchored"] = false, 
["MeshId"] = "rbxassetid://99198431284034", 
["Material"] = Enum.Material.Glass, 
["Massless"] = true, 
["Size"] = Vector3.new(0.348100, 0.289010, 0.374900)
}, 
["Children"] = {
["1"] = {
["GUID"] = "2950c728-b6de-4e05-ba4d-acb31d3726a8", 
["Name"] = "Decal", 
["ClassName"] = "Decal", 
["Properties"] = {
["Transparency"] = 0.699999988079071, 
["Face"] = Enum.NormalId.Back, 
["TextureContent"] = null, 
["Texture"] = "http://www.roblox.com/asset/?id=14291172105"
}
}, 
["2"] = {
["GUID"] = "a1b816f4-14f5-4671-89c4-8438e5f4bfca", 
["Name"] = "mes", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/b6d4ec6d-f389-4423-ba2b-f1cabbf213c9", 
["C0"] = CFrame.new(-0.019882, -0.029736, -0.769997, 1.000000, -0.000030, 0.000000, 0.000030, 1.000000, 0.000027, -0.000000, -0.000027, 1.000000), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/754546da-9b82-4e47-a29f-f2ee45e48a31"
}
}
}
}
}, 
["Attributes"] = {
["CopySkin"] = "Torso"
}
}, 
["4"] = {
["GUID"] = "d38dc26b-b39f-4a04-85da-e748a34a2070", 
["Name"] = "mesWeld", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/29f9ae95-9b9d-4ff5-8e25-051010c69f46", 
["C0"] = CFrame.new(0.00800000038, 0.0489999987, -0.238000005, -1, 2.98199975e-05, -1.50995803e-07, 2.98199975e-05, 1, -4.38267307e-08, 1.50994495e-07, -4.3831232e-08, -1), 
["C1"] = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), 
["Part1"] = "%PARENT/754546da-9b82-4e47-a29f-f2ee45e48a31"
}
}
}
}
}
}, 
["3"] = {
["GUID"] = "c5a28c5f-39e0-4105-974c-f819a61c45f4", 
["Name"] = "twox", 
["ClassName"] = "Folder", 
["Children"] = {
["1"] = {
["GUID"] = "90dd5576-a22f-473a-9cb2-f9512a66ada0", 
["Name"] = "br", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["CFrame"] = CFrame.new(76066.000000, 999995712.000000, 76315.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["CanTouch"] = false, 
["Anchored"] = false, 
["Material"] = Enum.Material.Sand, 
["Massless"] = true, 
["Size"] = Vector3.new(1.000000, 1.000000, 1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "21453964-094f-4a49-a350-78f8f07be31c", 
["Name"] = "m", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["Scale"] = Vector3.new(1.000000, 1.000000, 0.750000), 
["MeshId"] = "rbxassetid://104287652495563", 
["MeshType"] = Enum.MeshType.FileMesh
}
}, 
["2"] = {
["GUID"] = "8e5afaef-43cd-4b90-8ac3-57baee056cc5", 
["Name"] = "pants", 
["ClassName"] = "Decal", 
["Properties"] = {
["ZIndex"] = 0, 
["TextureContent"] = null, 
["Texture"] = "rbxassetid://0"
}, 
["Attributes"] = {
["CopyPants"] = true
}
}, 
["3"] = {
["GUID"] = "6443bef5-abdf-45e0-a657-9ed7c72430fc", 
["Name"] = "br", 
["ClassName"] = "Motor6D", 
["Properties"] = {
["Part0"] = "%PARENT/90dd5576-a22f-473a-9cb2-f9512a66ada0", 
["C0"] = CFrame.new(-0.500000, 1.350000, -0.500000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000)
}, 
["Attributes"] = {
["SetPart1To"] = "Torso"
}
}
}, 
["Attributes"] = {
["CopySkin"] = "Right Leg"
}
}, 
["2"] = {
["GUID"] = "befa2537-3971-4e06-b768-23bb558518b0", 
["Name"] = "cb", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["CFrame"] = CFrame.new(125001.000000, 1000124288.000000, 174614.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["CanTouch"] = false, 
["Transparency"] = 1, 
["Anchored"] = false, 
["Material"] = Enum.Material.Sand, 
["Massless"] = true, 
["Size"] = Vector3.new(3.750000, 0.950000, 1.875000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "2f3efd3a-76b1-4cc2-a01c-8e0d60681b24", 
["Name"] = "shirt", 
["ClassName"] = "Decal", 
["Properties"] = {
["TextureContent"] = null, 
["Texture"] = "rbxassetid://0"
}, 
["Attributes"] = {
["CopyShirt"] = true
}
}, 
["2"] = {
["GUID"] = "f90b7751-e9b6-4d66-9912-9b3e144b89fd", 
["Name"] = "pants", 
["ClassName"] = "Decal", 
["Properties"] = {
["ZIndex"] = 0, 
["TextureContent"] = null, 
["Texture"] = "rbxassetid://0"
}, 
["Attributes"] = {
["CopyPants"] = true
}
}, 
["3"] = {
["GUID"] = "719d171a-351e-4908-8b64-f2435741a770", 
["Name"] = "cb", 
["ClassName"] = "Motor6D", 
["Properties"] = {
["Part0"] = "%PARENT/befa2537-3971-4e06-b768-23bb558518b0", 
["C0"] = CFrame.new(0.675000, -0.400000, 0.000000, -0.000000, 0.000000, 1.000000, 0.000000, 1.000000, 0.000000, -1.000000, 0.000000, -0.000000), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000)
}, 
["Attributes"] = {
["SetPart1To"] = "Torso"
}
}, 
["4"] = {
["GUID"] = "a41f108c-f0f0-49c4-aae4-45a0afb0a72f", 
["Name"] = "m", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["Scale"] = Vector3.new(1.050000, 1.050000, 0.955000), 
["MeshId"] = "rbxassetid://115162818598246", 
["MeshType"] = Enum.MeshType.FileMesh
}, 
["Attributes"] = {
["DefaultSize"] = Vector3.new(1.050000, 1.050000, 0.955000)
}
}, 
["5"] = {
["GUID"] = "aa52dbfc-42ab-4e4a-b2c8-6db9ef101051", 
["Name"] = "br", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(0.388235,0.372549,0.384314), 
["CFrame"] = CFrame.new(16.945801, 1109.357056, 16.676060, 0.284013, 0.120240, 0.951251, 0.171010, 0.969846, -0.173648, -0.943447, 0.211992, 0.254887), 
["CanTouch"] = false, 
["Anchored"] = false, 
["Rotation"] = Vector3.new(34.265999, 72.036003, -22.945999), 
["MeshId"] = "rbxassetid://7220038121", 
["Massless"] = true, 
["Material"] = Enum.Material.SmoothPlastic, 
["EnableFluidForces"] = false, 
["Size"] = Vector3.new(1.100000, 1.000000, 0.950000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "02bc7093-272e-4fad-9bac-99eba591fee2", 
["Name"] = "b", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/aa52dbfc-42ab-4e4a-b2c8-6db9ef101051", 
["C0"] = CFrame.new(0.074362, 0.026893, 0.346747, 0.943447, 0.171010, 0.284013, -0.211992, 0.969846, 0.120240, -0.254887, -0.173648, 0.951251), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/befa2537-3971-4e06-b768-23bb558518b0"
}
}
}, 
["Attributes"] = {
["DefaultSize"] = Vector3.new(1.100000, 1.000000, 0.950000), 
["CopySkin"] = "Torso"
}
}, 
["6"] = {
["GUID"] = "12743582-b8c0-41f1-96da-48d8831eaa84", 
["Name"] = "bl", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(0.388235,0.372549,0.384314), 
["CFrame"] = CFrame.new(17.654249, 1109.357056, 16.676060, -0.284013, -0.120240, 0.951251, 0.171010, 0.969846, 0.173648, -0.943447, 0.211992, -0.254887), 
["CanTouch"] = false, 
["Anchored"] = false, 
["Rotation"] = Vector3.new(-145.733994, 72.036003, 157.054001), 
["MeshId"] = "rbxassetid://7220038121", 
["Massless"] = true, 
["Material"] = Enum.Material.SmoothPlastic, 
["EnableFluidForces"] = false, 
["Size"] = Vector3.new(1.100000, 1.000000, 0.950000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "f90a2f0a-4af5-4a33-9431-d7c270f16673", 
["Name"] = "b", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/12743582-b8c0-41f1-96da-48d8831eaa84", 
["C0"] = CFrame.new(0.074377, 0.026899, -0.346799, 0.943447, 0.171010, -0.284013, -0.211992, 0.969846, -0.120240, 0.254887, 0.173648, 0.951251), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/befa2537-3971-4e06-b768-23bb558518b0"
}
}
}, 
["Attributes"] = {
["DefaultSize"] = Vector3.new(1.100000, 1.000000, 0.950000), 
["CopySkin"] = "Torso"
}
}
}
}, 
["3"] = {
["GUID"] = "5e7aa35a-a5ee-4939-8d56-e3aeefd29d67", 
["Name"] = "ll", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["CFrame"] = CFrame.new(-103696.000000, 999913280.000000, 61015.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["CanTouch"] = false, 
["Anchored"] = false, 
["Material"] = Enum.Material.Sand, 
["Massless"] = true, 
["Size"] = Vector3.new(1.000000, 2.000000, 1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "d519e003-ac3d-44eb-9ed2-23242b59f0c4", 
["Name"] = "pants", 
["ClassName"] = "Decal", 
["Properties"] = {
["ZIndex"] = 0, 
["TextureContent"] = null, 
["Texture"] = "rbxassetid://0"
}, 
["Attributes"] = {
["CopyPants"] = true
}
}, 
["2"] = {
["GUID"] = "4e1ca5ce-dc33-4f1d-8d00-ff0bb75f4941", 
["Name"] = "m", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["Scale"] = Vector3.new(1.175000, 1.050000, 1.000000), 
["MeshId"] = "rbxassetid://89515083774246", 
["MeshType"] = Enum.MeshType.FileMesh
}
}, 
["3"] = {
["GUID"] = "acee8332-45ad-46f0-9b30-67a37daaca81", 
["Name"] = "weld", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/5e7aa35a-a5ee-4939-8d56-e3aeefd29d67", 
["C0"] = CFrame.new(0.050000, -0.100000, 0.040000, -0.000000, 0.000000, -1.000000, 0.000000, 1.000000, 0.000000, 1.000000, 0.000000, -0.000000), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000)
}, 
["Attributes"] = {
["SetPart1To"] = "Left Leg"
}
}
}, 
["Attributes"] = {
["FakeInvis"] = "Left Leg", 
["CopySkin"] = "Left Leg"
}
}, 
["4"] = {
["GUID"] = "5a465e62-e96a-4a2d-a427-d7df7742b09f", 
["Name"] = "rl", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["CFrame"] = CFrame.new(88223.000000, 1000012928.000000, 130087.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["CanTouch"] = false, 
["Anchored"] = false, 
["Material"] = Enum.Material.Sand, 
["Massless"] = true, 
["Size"] = Vector3.new(1.000000, 2.000000, 1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "03cfb0c0-a68e-45c1-bc15-0c8b9eff2c2e", 
["Name"] = "m", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["Scale"] = Vector3.new(1.175000, 1.050000, 1.000000), 
["MeshId"] = "rbxassetid://70866290823378", 
["MeshType"] = Enum.MeshType.FileMesh
}
}, 
["2"] = {
["GUID"] = "a54c4cc9-2400-4ec1-8ea7-b4ee23c15329", 
["Name"] = "pants", 
["ClassName"] = "Decal", 
["Properties"] = {
["ZIndex"] = 0, 
["TextureContent"] = null, 
["Texture"] = "rbxassetid://0"
}, 
["Attributes"] = {
["CopyPants"] = true
}
}, 
["3"] = {
["GUID"] = "cbb07a65-5b13-4194-b250-2045357c71ce", 
["Name"] = "weld", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/5a465e62-e96a-4a2d-a427-d7df7742b09f", 
["C0"] = CFrame.new(0.050000, -0.100000, -0.040000, -0.000000, 0.000000, -1.000000, 0.000000, 1.000000, 0.000000, 1.000000, 0.000000, -0.000000), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000)
}, 
["Attributes"] = {
["SetPart1To"] = "Right Leg"
}
}
}, 
["Attributes"] = {
["FakeInvis"] = "Right Leg", 
["CopySkin"] = "Right Leg"
}
}, 
["5"] = {
["GUID"] = "1da1e8bb-c891-4cae-bcda-3a854b2e7a45", 
["Name"] = "t", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(0.388235,0.372549,0.384314), 
["CFrame"] = CFrame.new(-184677.000000, 999926720.000000, 118937.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["CanTouch"] = false, 
["Anchored"] = false, 
["Material"] = Enum.Material.Sand, 
["Massless"] = true, 
["Size"] = Vector3.new(2.000000, 2.000000, 1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "c0cc9f8a-9f33-40ae-b90c-e673109f3aa2", 
["Name"] = "m", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshId"] = "rbxassetid://133912617822051", 
["MeshType"] = Enum.MeshType.FileMesh
}
}, 
["2"] = {
["GUID"] = "8eb1c5c8-cb7f-4d61-9e0f-d340d54aa5cc", 
["Name"] = "shirt", 
["ClassName"] = "Decal", 
["Properties"] = {
["TextureContent"] = null, 
["Texture"] = "rbxassetid://0"
}, 
["Attributes"] = {
["CopyShirt"] = true
}
}, 
["3"] = {
["GUID"] = "111e81cf-8f9f-48a9-b0da-cffb9990ace5", 
["Name"] = "pants", 
["ClassName"] = "Decal", 
["Properties"] = {
["ZIndex"] = 0, 
["TextureContent"] = null, 
["Texture"] = "rbxassetid://0"
}, 
["Attributes"] = {
["CopyPants"] = true
}
}, 
["4"] = {
["GUID"] = "8d4428af-e30c-423c-8b3a-1c5136a595e8", 
["Name"] = "weld", 
["ClassName"] = "Weld", 
["Properties"] = {
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, -1.000000, 0.000000, -0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, -1.000000), 
["C0"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part0"] = "%PARENT/1da1e8bb-c891-4cae-bcda-3a854b2e7a45"
}, 
["Attributes"] = {
["SetPart1To"] = "Torso"
}
}
}, 
["Attributes"] = {
["FakeInvis"] = "Torso", 
["CopySkin"] = "Torso"
}
}, 
["6"] = {
["GUID"] = "e52a2dcb-b5d8-4cd7-b147-152e994e334a", 
["Name"] = "bl", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["CFrame"] = CFrame.new(197836.000000, 1000145088.000000, -196317.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["CanTouch"] = false, 
["Anchored"] = false, 
["Material"] = Enum.Material.Sand, 
["Massless"] = true, 
["Size"] = Vector3.new(1.000000, 1.000000, 1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "75352854-127d-439d-9eaa-c6e80755cb5d", 
["Name"] = "m", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["Scale"] = Vector3.new(1.000000, 1.000000, 0.750000), 
["MeshId"] = "rbxassetid://105478822913962", 
["MeshType"] = Enum.MeshType.FileMesh
}
}, 
["2"] = {
["GUID"] = "a3924119-8e02-4d4a-9826-64b026deba91", 
["Name"] = "pants", 
["ClassName"] = "Decal", 
["Properties"] = {
["ZIndex"] = 0, 
["TextureContent"] = null, 
["Texture"] = "rbxassetid://0"
}, 
["Attributes"] = {
["CopyPants"] = true
}
}, 
["3"] = {
["GUID"] = "950835a9-bb85-41e5-953a-c5aa24aaf32e", 
["Name"] = "bl", 
["ClassName"] = "Motor6D", 
["Properties"] = {
["Part0"] = "%PARENT/e52a2dcb-b5d8-4cd7-b147-152e994e334a", 
["C0"] = CFrame.new(0.500000, 1.350000, -0.500000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000)
}, 
["Attributes"] = {
["SetPart1To"] = "Torso"
}
}
}, 
["Attributes"] = {
["CopySkin"] = "Left Leg"
}
}
}
}, 
["4"] = {
["GUID"] = "35943f6f-6f98-4f8e-9246-be530e6e3652", 
["Name"] = "twoxR", 
["ClassName"] = "Folder", 
["Children"] = {
["1"] = {
["GUID"] = "9ced6689-33e0-4d8a-a0dc-d4c263e0a610", 
["Name"] = "M6DUpperR", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(0.388235,0.372549,0.384314), 
["CFrame"] = CFrame.new(-13450.000000, 1000181632.000000, -48536.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["CanTouch"] = false, 
["Massless"] = true, 
["Transparency"] = 1, 
["Anchored"] = false, 
["EnableFluidForces"] = false, 
["CastShadow"] = false, 
["Size"] = Vector3.new(0.191847, 0.191847, 0.191847)
}, 
["Children"] = {
["1"] = {
["GUID"] = "53353339-afca-4b0a-afa9-bb513dda4962", 
["Name"] = "m", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["Scale"] = Vector3.new(0.000000, 0.000000, 0.000000), 
["MeshType"] = Enum.MeshType.Brick
}
}, 
["2"] = {
["GUID"] = "41f56033-6db4-4015-81f6-72af6297b33c", 
["Name"] = "upperR", 
["ClassName"] = "Motor6D", 
["Properties"] = {
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["C0"] = CFrame.new(0.240000, 0.948000, -0.555000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, -0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/9ced6689-33e0-4d8a-a0dc-d4c263e0a610"
}, 
["Attributes"] = {
["SetPart0To"] = "Torso"
}
}, 
["3"] = {
["GUID"] = "00e2af25-22c0-4a58-8ee4-165f6e2f195c", 
["Name"] = "br", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanCollide"] = false, 
["Color"] = Color3.new(0.388235,0.372549,0.384314), 
["CFrame"] = CFrame.new(0.821395, 3.357971, -12.481270, -1.000001, 0.000000, 0.000000, 0.000000, 1.000000, -0.000000, -0.000000, -0.000000, -1.000001), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(180.000000, 0.000000, 180.000000), 
["Anchored"] = false, 
["MeshId"] = "rbxassetid://104070662507287", 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.919000, 1.198000, 0.946000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "d6b1f8e4-9b0f-499e-a463-7b2c3db78731", 
["Name"] = "wd", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/9ced6689-33e0-4d8a-a0dc-d4c263e0a610", 
["C0"] = CFrame.new(0.150000, -0.590000, -0.135000, -1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, -0.000000, 0.000000, -1.000000), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/00e2af25-22c0-4a58-8ee4-165f6e2f195c"
}
}, 
["2"] = {
["GUID"] = "71b2db1e-2fe1-4055-8ac9-86e03731aeaa", 
["Name"] = "adp", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/00e2af25-22c0-4a58-8ee4-165f6e2f195c", 
["C0"] = CFrame.new(-0.000094, -0.000250, 0.210845, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, -0.000000, 0.000000, 1.000000), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/589515a8-3003-41a9-916f-215898a4ab2c"
}
}, 
["3"] = {
["GUID"] = "589515a8-3003-41a9-916f-215898a4ab2c", 
["Name"] = "adPart", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["CFrame"] = CFrame.new(0.821489, 3.357721, -12.692115, -1.000001, 0.000000, -0.000000, 0.000000, 1.000000, -0.000000, 0.000000, -0.000000, -1.000001), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(180.000000, 0.000000, 180.000000), 
["Transparency"] = 1, 
["Anchored"] = false, 
["Massless"] = true, 
["Size"] = Vector3.new(4.000000, 1.000000, 2.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "495e92f0-bc43-4bc4-891b-4b7517451dd7", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshId"] = "rbxassetid://135600820512851", 
["MeshType"] = Enum.MeshType.FileMesh
}
}, 
["2"] = {
["GUID"] = "0541fed5-a23d-4059-b4d3-f617601e2076", 
["Name"] = "ad", 
["ClassName"] = "Decal", 
["Properties"] = {
["TextureContent"] = null, 
["Face"] = Enum.NormalId.Back, 
["Color3"] = Color3.new(0.854902,0.525490,0.478431), 
["Texture"] = "http://www.roblox.com/asset/?id=17139165511"
}, 
["Attributes"] = {
["CopySkin_NP"] = true, 
["CopySkin"] = "Torso"
}
}
}
}
}, 
["Attributes"] = {
["CopySkin"] = "Torso"
}
}, 
["4"] = {
["GUID"] = "396bf5d0-f71c-4b92-9d35-987fae452035", 
["Name"] = "np", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanCollide"] = false, 
["Color"] = Color3.new(0.854902,0.525490,0.478431), 
["CFrame"] = CFrame.new(0.946540, 3.299669, -12.934912, -1.000001, 0.000000, 0.000000, 0.000000, 1.000000, -0.000000, -0.000000, -0.000000, -1.000001), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(180.000000, 0.000000, 180.000000), 
["Anchored"] = false, 
["MeshId"] = "rbxassetid://17123403927", 
["Massless"] = true, 
["Size"] = Vector3.new(0.157793, 0.158626, 0.077521)
}, 
["Children"] = {
["1"] = {
["GUID"] = "b172ae1b-35d1-4694-9c88-7638780b206a", 
["Name"] = "we", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/396bf5d0-f71c-4b92-9d35-987fae452035", 
["C0"] = CFrame.new(0.125145, 0.058302, -0.453641, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/00e2af25-22c0-4a58-8ee4-165f6e2f195c"
}
}
}, 
["Attributes"] = {
["CopySkin_NP"] = true, 
["CopySkin"] = "Torso"
}
}
}
}, 
["2"] = {
["GUID"] = "73f1f294-ca44-4f3e-bc98-f0b29a8c78df", 
["Name"] = "M6DUpperL", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(0.388235,0.372549,0.384314), 
["CFrame"] = CFrame.new(29380.000000, 999946752.000000, 121509.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["CanTouch"] = false, 
["Massless"] = true, 
["Transparency"] = 1, 
["Anchored"] = false, 
["EnableFluidForces"] = false, 
["CastShadow"] = false, 
["Size"] = Vector3.new(0.191847, 0.191847, 0.191847)
}, 
["Children"] = {
["1"] = {
["GUID"] = "6a21a17c-761f-450e-b377-cd6cb63736c2", 
["Name"] = "m", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["Scale"] = Vector3.new(0.000000, 0.000000, 0.000000), 
["MeshType"] = Enum.MeshType.Brick
}
}, 
["2"] = {
["GUID"] = "e7feacb3-9207-4bce-ac23-28d00ff3826f", 
["Name"] = "upperL", 
["ClassName"] = "Motor6D", 
["Properties"] = {
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["C0"] = CFrame.new(-0.240000, 0.948000, -0.555000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, -0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/73f1f294-ca44-4f3e-bc98-f0b29a8c78df"
}, 
["Attributes"] = {
["SetPart0To"] = "Torso"
}
}, 
["3"] = {
["GUID"] = "bae125ea-8cb5-48b5-901e-304b30bb39a9", 
["Name"] = "np", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanCollide"] = false, 
["Color"] = Color3.new(0.854902,0.525490,0.478431), 
["CFrame"] = CFrame.new(-0.079766, 3.299927, -12.951653, -1.000001, 0.000000, -0.000000, 0.000000, 1.000000, -0.000000, 0.000000, -0.000000, -1.000001), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(180.000000, 0.000000, 180.000000), 
["Anchored"] = false, 
["MeshId"] = "rbxassetid://17123404019", 
["Massless"] = true, 
["Size"] = Vector3.new(0.155692, 0.158596, 0.084925)
}, 
["Children"] = {
["1"] = {
["GUID"] = "db8d290e-7b87-4111-b936-5dc360ab63d4", 
["Name"] = "we", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/bae125ea-8cb5-48b5-901e-304b30bb39a9", 
["C0"] = CFrame.new(-0.118642, 0.055238, -0.456703, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/48d93227-a491-4e19-98d3-53d2d1d94fca"
}
}
}, 
["Attributes"] = {
["CopySkin_NP"] = true, 
["CopySkin"] = "Torso"
}
}, 
["4"] = {
["GUID"] = "48d93227-a491-4e19-98d3-53d2d1d94fca", 
["Name"] = "bl", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanCollide"] = false, 
["Color"] = Color3.new(0.388235,0.372549,0.384314), 
["CFrame"] = CFrame.new(0.038876, 3.355165, -12.494949, -1.000001, 0.000000, -0.000000, 0.000000, 1.000000, -0.000000, 0.000000, -0.000000, -1.000001), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(180.000000, 0.000000, 180.000000), 
["Anchored"] = false, 
["MeshId"] = "rbxassetid://123445729623746", 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(0.918000, 1.198000, 0.946000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "f650db47-1e8c-4a0a-8dfb-d7be6b060491", 
["Name"] = "wd", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/73f1f294-ca44-4f3e-bc98-f0b29a8c78df", 
["C0"] = CFrame.new(-0.152518, -0.592806, -0.148680, -1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, -0.000000, 0.000000, -1.000000), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/48d93227-a491-4e19-98d3-53d2d1d94fca"
}
}, 
["2"] = {
["GUID"] = "010c1d4b-cbff-4386-8f62-7a7639b34fbd", 
["Name"] = "adp", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/48d93227-a491-4e19-98d3-53d2d1d94fca", 
["C0"] = CFrame.new(-0.000000, -0.000000, 0.211000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/39811793-b3ae-4f1a-9035-17e875f55999"
}
}, 
["3"] = {
["GUID"] = "39811793-b3ae-4f1a-9035-17e875f55999", 
["Name"] = "adPart", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["CFrame"] = CFrame.new(0.038876, 3.355165, -12.705950, -1.000001, 0.000000, -0.000000, 0.000000, 1.000000, -0.000000, 0.000000, -0.000000, -1.000001), 
["CanTouch"] = false, 
["Rotation"] = Vector3.new(180.000000, 0.000000, 180.000000), 
["Transparency"] = 1, 
["Anchored"] = false, 
["Massless"] = true, 
["Size"] = Vector3.new(4.000000, 1.000000, 2.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "f11f1b2e-0852-40ee-b0d7-7629d668d302", 
["Name"] = "Mesh", 
["ClassName"] = "SpecialMesh", 
["Properties"] = {
["MeshId"] = "rbxassetid://79244112357609", 
["MeshType"] = Enum.MeshType.FileMesh
}
}, 
["2"] = {
["GUID"] = "e50c223f-ae7e-4aed-9081-93e4054ea9c0", 
["Name"] = "ad", 
["ClassName"] = "Decal", 
["Properties"] = {
["TextureContent"] = null, 
["Face"] = Enum.NormalId.Back, 
["Color3"] = Color3.new(0.854902,0.525490,0.478431), 
["Texture"] = "rbxassetid://96034413636764"
}, 
["Attributes"] = {
["CopySkin_NP"] = true, 
["CopySkin"] = "Torso"
}
}
}
}
}, 
["Attributes"] = {
["CopySkin"] = "Torso"
}
}
}
}, 
["3"] = {
["GUID"] = "968472ca-475a-409e-9fe5-3cc4a70ef028", 
["Name"] = "M6DLowerR", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(0.388235,0.372549,0.384314), 
["CFrame"] = CFrame.new(-18259.000000, 999983616.000000, -62600.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["CanTouch"] = false, 
["Massless"] = true, 
["Transparency"] = 1, 
["Anchored"] = false, 
["EnableFluidForces"] = false, 
["CastShadow"] = false, 
["Size"] = Vector3.new(0.191847, 0.191847, 0.191847)
}, 
["Children"] = {
["1"] = {
["GUID"] = "57bc3243-41c5-4880-9d57-c0e2a45782be", 
["Name"] = "lowerR", 
["ClassName"] = "Motor6D", 
["Properties"] = {
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["C0"] = CFrame.new(0.491966, -0.926946, 0.444100, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/968472ca-475a-409e-9fe5-3cc4a70ef028"
}, 
["Attributes"] = {
["SetPart0To"] = "Torso"
}
}, 
["2"] = {
["GUID"] = "67c13252-3dc8-4874-9124-c60fbdaa930a", 
["Name"] = "ar", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanCollide"] = false, 
["Color"] = Color3.new(0.388235,0.372549,0.384314), 
["CFrame"] = CFrame.new(0.923395, 2.110852, -11.357800, 1.000001, 0.000000, 0.000000, -0.000000, 0.939693, 0.342020, -0.000000, -0.342021, 0.939694), 
["CanTouch"] = false, 
["Anchored"] = false, 
["Rotation"] = Vector3.new(-20.000000, 0.000000, 0.000000), 
["MeshId"] = "rbxassetid://11591155243", 
["Massless"] = true, 
["Material"] = Enum.Material.SmoothPlastic, 
["EnableFluidForces"] = false, 
["Size"] = Vector3.new(1.270000, 1.350000, 1.203000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "ec1e69bf-3e57-447a-a917-6c177caafeac", 
["Name"] = "ar", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/968472ca-475a-409e-9fe5-3cc4a70ef028", 
["C0"] = CFrame.new(0.000034, 0.037827, -0.010632, 1.000000, 0.000000, 0.000000, 0.000000, 0.939693, 0.342020, 0.000000, -0.342020, 0.939693), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/67c13252-3dc8-4874-9124-c60fbdaa930a"
}
}
}, 
["Attributes"] = {
["CopySkin"] = "Torso"
}
}
}
}, 
["4"] = {
["GUID"] = "ca5cfec7-82e3-4f22-a3b0-b7fab3104fd7", 
["Name"] = "M6DLowerL", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(0.388235,0.372549,0.384314), 
["CFrame"] = CFrame.new(-104395.000000, 999915008.000000, -101586.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["CanTouch"] = false, 
["Massless"] = true, 
["Transparency"] = 1, 
["Anchored"] = false, 
["EnableFluidForces"] = false, 
["CastShadow"] = false, 
["Size"] = Vector3.new(0.191847, 0.191847, 0.191847)
}, 
["Children"] = {
["1"] = {
["GUID"] = "747768d7-641d-4f3a-a96b-5c18969b0444", 
["Name"] = "lowerL", 
["ClassName"] = "Motor6D", 
["Properties"] = {
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["C0"] = CFrame.new(-0.487170, -0.926856, 0.441582, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/ca5cfec7-82e3-4f22-a3b0-b7fab3104fd7"
}, 
["Attributes"] = {
["SetPart0To"] = "Torso"
}
}, 
["2"] = {
["GUID"] = "e0efcf80-9c1b-43a1-af8a-3909f89f3ee6", 
["Name"] = "al", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanCollide"] = false, 
["Color"] = Color3.new(0.388235,0.372549,0.384314), 
["CFrame"] = CFrame.new(-0.055606, 2.109438, -11.359215, 1.000001, 0.000000, 0.000000, -0.000000, 0.939693, 0.342020, -0.000000, -0.342021, 0.939694), 
["CanTouch"] = false, 
["Anchored"] = false, 
["Rotation"] = Vector3.new(-20.000000, 0.000000, 0.000000), 
["MeshId"] = "rbxassetid://11591144025", 
["Massless"] = true, 
["Material"] = Enum.Material.SmoothPlastic, 
["EnableFluidForces"] = false, 
["Size"] = Vector3.new(1.270000, 1.350000, 1.203000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "6293d159-409c-43bc-94fd-97139aaa167b", 
["Name"] = "al", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/ca5cfec7-82e3-4f22-a3b0-b7fab3104fd7", 
["C0"] = CFrame.new(0.000171, 0.036323, -0.009528, 1.000000, 0.000000, 0.000000, 0.000000, 0.939693, 0.342020, 0.000000, -0.342020, 0.939693), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/e0efcf80-9c1b-43a1-af8a-3909f89f3ee6"
}
}
}, 
["Attributes"] = {
["CopySkin"] = "Torso"
}
}
}
}, 
["5"] = {
["GUID"] = "694527a8-7c5b-4fbb-8f4d-e4ce7001a2b3", 
["Name"] = "MeshTorso", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanCollide"] = false, 
["Color"] = Color3.new(0.388235,0.372549,0.384314), 
["CFrame"] = CFrame.new(-1683.000000, 1000096832.000000, -184876.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["CanTouch"] = false, 
["MeshId"] = "rbxassetid://114875654896374", 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["Size"] = Vector3.new(2.050000, 2.050000, 1.050000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "b74aa50c-9e3f-423f-ace4-26d3572082d7", 
["Name"] = "Weld", 
["ClassName"] = "Weld", 
["Properties"] = {
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["C0"] = CFrame.new(-0.000351, -0.000000, 0.000198, -1.000000, 0.000000, -0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, -1.000000), 
["Part1"] = "%PARENT/694527a8-7c5b-4fbb-8f4d-e4ce7001a2b3"
}, 
["Attributes"] = {
["SetPart0To"] = "Torso"
}
}
}, 
["Attributes"] = {
--["RBX_AutoSetup_AssetConfiguration"] = "Body", 
["FakeInvis"] = "Torso", 
["gooPart"] = true, 
["CopySkin"] = "Torso"
}
}, 
["6"] = {
["GUID"] = "d444e54f-e201-453e-8334-850380ada2a7", 
["Name"] = "MeshRightLeg", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["CollisionGroup"] = "Players", 
["CFrame"] = CFrame.new(-44291.000000, 999939648.000000, -47770.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["CanTouch"] = false, 
["Massless"] = true, 
["Anchored"] = false, 
["MeshId"] = "rbxassetid://6870651384", 
["Material"] = Enum.Material.SmoothPlastic, 
["EnableFluidForces"] = false, 
["Size"] = Vector3.new(1.164907, 2.179829, 1.195095)
}, 
["Children"] = {
["1"] = {
["GUID"] = "f21b6d33-ad66-41cb-9acf-a1340379164c", 
["Name"] = "Weld", 
["ClassName"] = "Weld", 
["Properties"] = {
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["C0"] = CFrame.new(0.025000, 0.075000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 1.000000, -0.000000, -1.000000, 0.000000, 0.000000), 
["Part1"] = "%PARENT/d444e54f-e201-453e-8334-850380ada2a7"
}, 
["Attributes"] = {
["SetPart0To"] = "Right Leg"
}
}
}, 
["Attributes"] = {
--["RBX_AutoSetup_AssetConfiguration"] = "Body", 
["FakeInvis"] = "Right Leg", 
["CopySkin"] = "Right Leg"
}
}, 
["7"] = {
["GUID"] = "41ed40b6-822e-4e6d-a498-0551549b7d03", 
["Name"] = "MeshRightArm", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["CollisionGroup"] = "Players", 
["CFrame"] = CFrame.new(29746.000000, 1000027264.000000, 44177.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["CanTouch"] = false, 
["Massless"] = true, 
["Anchored"] = false, 
["MeshId"] = "rbxassetid://4906912683", 
["Material"] = Enum.Material.SmoothPlastic, 
["EnableFluidForces"] = false, 
["Size"] = Vector3.new(1.000000, 2.000000, 1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "bf96f1e7-6670-4946-9724-911dd98f30a8", 
["Name"] = "Weld", 
["ClassName"] = "Weld", 
["Properties"] = {
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["C0"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000001, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000001), 
["Part1"] = "%PARENT/41ed40b6-822e-4e6d-a498-0551549b7d03"
}, 
["Attributes"] = {
["SetPart0To"] = "Right Arm"
}
}
}, 
["Attributes"] = {
--["RBX_AutoSetup_AssetConfiguration"] = "Body", 
["FakeInvis"] = "Right Arm", 
["CopySkin"] = "Right Arm"
}
}, 
["8"] = {
["GUID"] = "55048741-22a9-40df-ba13-4d1a037b4ee3", 
["Name"] = "MeshLeftLeg", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["CollisionGroup"] = "Players", 
["CFrame"] = CFrame.new(47099.000000, 1000153280.000000, -64137.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["CanTouch"] = false, 
["Massless"] = true, 
["Anchored"] = false, 
["MeshId"] = "rbxassetid://6870651596", 
["Material"] = Enum.Material.SmoothPlastic, 
["EnableFluidForces"] = false, 
["Size"] = Vector3.new(1.164908, 2.179829, 1.195095)
}, 
["Children"] = {
["1"] = {
["GUID"] = "74e1cd9a-4725-4de9-a5a1-7101bf4b3ce5", 
["Name"] = "Weld", 
["ClassName"] = "Weld", 
["Properties"] = {
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["C0"] = CFrame.new(-0.025000, 0.075000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 1.000000, -0.000000, -1.000000, 0.000000, 0.000000), 
["Part1"] = "%PARENT/55048741-22a9-40df-ba13-4d1a037b4ee3"
}, 
["Attributes"] = {
["SetPart0To"] = "Left Leg"
}
}
}, 
["Attributes"] = {
--["RBX_AutoSetup_AssetConfiguration"] = "Body", 
["FakeInvis"] = "Left Leg", 
["CopySkin"] = "Left Leg"
}
}, 
["9"] = {
["GUID"] = "9c4d4566-1ef9-4985-9e1d-ea911e666c60", 
["Name"] = "MeshLeftArm", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["CollisionGroup"] = "Players", 
["CFrame"] = CFrame.new(110290.000000, 999828864.000000, 140858.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["CanTouch"] = false, 
["Massless"] = true, 
["Anchored"] = false, 
["MeshId"] = "rbxassetid://108429602333822", 
["Material"] = Enum.Material.SmoothPlastic, 
["EnableFluidForces"] = false, 
["Size"] = Vector3.new(1.000003, 2.000000, 1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "22636cf9-3443-4ce7-b579-05c98815bf8f", 
["Name"] = "Weld", 
["ClassName"] = "Weld", 
["Properties"] = {
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["C0"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000001, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000001), 
["Part1"] = "%PARENT/9c4d4566-1ef9-4985-9e1d-ea911e666c60"
}, 
["Attributes"] = {
["SetPart0To"] = "Left Arm"
}
}
}, 
["Attributes"] = {
--["RBX_AutoSetup_AssetConfiguration"] = "Body", 
["FakeInvis"] = "Left Arm", 
["CopySkin"] = "Left Arm"
}
}, 
["10"] = {
["GUID"] = "27163608-500a-4c33-9a6f-3a554d1f02b6", 
["Name"] = "M6DVinny", 
["ClassName"] = "Part", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Anchored"] = false, 
["CanTouch"] = false, 
["Transparency"] = 1, 
["CFrame"] = CFrame.new(-51562.000000, 999941440.000000, -22806.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Massless"] = true, 
["Size"] = Vector3.new(0.200000, 0.200000, 0.200000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "a9c912e7-203e-4e37-94db-a2ed64f1a1f7", 
["Name"] = "closed", 
["ClassName"] = "Model", 
["Properties"] = {
["WorldPivot"] = CFrame.new(-2.041289, 7.377569, 21.710367, 1.000000, -0.000000, -0.000000, 0.000000, 0.573577, -0.819155, -0.000000, 0.819153, 0.573578)
}, 
["Children"] = {
["1"] = {
["GUID"] = "46e97032-089f-4fc8-9669-504019a7cd59", 
["Name"] = "welds", 
["ClassName"] = "Folder", 
["Children"] = {
["1"] = {
["GUID"] = "a09ef568-936a-4d09-8677-e1fa15a8ab41", 
["Name"] = "Base", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/27163608-500a-4c33-9a6f-3a554d1f02b6", 
["C0"] = CFrame.new(-0.001038, -0.038645, -0.034090, -1.000000, 0.000000, 0.000000, 0.000000, 1.000001, -0.000000, -0.000000, -0.000000, -1.000001), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/73581f8c-ef7c-40c4-88e9-8a6f551e3263"
}
}, 
["2"] = {
["GUID"] = "a7e84a0c-7037-46a5-adb6-3b555b41c35c", 
["Name"] = "Color1", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/27163608-500a-4c33-9a6f-3a554d1f02b6", 
["C0"] = CFrame.new(-0.001038, -0.269774, -0.157494, -1.000000, 0.000000, 0.000000, 0.000000, 1.000003, -0.000000, -0.000000, -0.000000, -1.000003), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/64965756-13b4-4cb9-b427-fd5723523729"
}
}, 
["3"] = {
["GUID"] = "180f81dc-0616-4256-9573-75f000d1294f", 
["Name"] = "Color2", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/27163608-500a-4c33-9a6f-3a554d1f02b6", 
["C0"] = CFrame.new(-0.001038, -0.283289, -0.152241, -1.000000, 0.000000, 0.000000, 0.000000, 1.000003, -0.000000, -0.000000, -0.000000, -1.000003), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/99695524-3aab-45fd-b89b-4e59fd658fb4"
}
}
}
}, 
["2"] = {
["GUID"] = "73581f8c-ef7c-40c4-88e9-8a6f551e3263", 
["Name"] = "Base", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["CFrame"] = CFrame.new(0.430357, 2.086326, -11.825359, -1.000001, 0.000000, -0.000000, 0.000000, 1.000002, -0.000000, 0.000000, -0.000000, -1.000003), 
["CanTouch"] = false, 
["Size"] = Vector3.new(0.824104, 0.851360, 0.824160), 
["Rotation"] = Vector3.new(180.000000, 0.000000, 180.000000), 
["MeshId"] = "rbxassetid://70534452234138", 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["PivotOffset"] = CFrame.new(70.355453, -3.913840, -7.228230, 1.000000, 0.000000, -0.000000, -0.000000, 1.000000, -0.000000, 0.000000, 0.000000, 1.000000)
}, 
["Attributes"] = {
["CopySkin"] = "Torso"
}
}, 
["3"] = {
["GUID"] = "64965756-13b4-4cb9-b427-fd5723523729", 
["Name"] = "Color1", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.430357, 1.855197, -11.948763, -1.000001, 0.000000, -0.000000, 0.000000, 1.000003, -0.000000, 0.000000, -0.000000, -1.000005), 
["CanTouch"] = false, 
["Size"] = Vector3.new(0.069298, 0.340400, 0.553140), 
["Rotation"] = Vector3.new(180.000000, 0.000000, 180.000000), 
["MeshId"] = "rbxassetid://104448068760068", 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["PivotOffset"] = CFrame.new(70.355453, -3.682710, -7.351630, 1.000000, 0.000000, -0.000000, -0.000000, 1.000000, -0.000000, 0.000000, 0.000000, 1.000000)
}, 
["Attributes"] = {
["CopySkin_NP"] = true, 
["CopySkin"] = "Torso"
}
}, 
["4"] = {
["GUID"] = "99695524-3aab-45fd-b89b-4e59fd658fb4", 
["Name"] = "Color2", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.430357, 1.841681, -11.943510, -1.000001, 0.000000, -0.000000, 0.000000, 1.000003, -0.000000, 0.000000, -0.000000, -1.000005), 
["CanTouch"] = false, 
["Size"] = Vector3.new(0.071899, 0.321910, 0.570080), 
["Rotation"] = Vector3.new(180.000000, 0.000000, 180.000000), 
["MeshId"] = "rbxassetid://96358814278564", 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["PivotOffset"] = CFrame.new(70.355453, -3.669195, -7.346380, 1.000000, 0.000000, -0.000000, -0.000000, 1.000000, -0.000000, 0.000000, 0.000000, 1.000000)
}, 
["Attributes"] = {
["CopySkin_NP"] = true, 
["CopySkin"] = "Torso"
}
}
}
}, 
["2"] = {
["GUID"] = "28d0c74f-9c64-4adb-951e-d6621669d561", 
["Name"] = "open", 
["ClassName"] = "Model", 
["Properties"] = {
["WorldPivot"] = CFrame.new(0.488000, -0.069000, -0.460000, 1.000000, 0.000000, 0.000000, 0.000000, 0.573576, -0.819152, 0.000000, 0.819152, 0.573576)
}, 
["Children"] = {
["1"] = {
["GUID"] = "963730dc-220b-41e1-acf2-44174c18dc01", 
["Name"] = "welds", 
["ClassName"] = "Folder", 
["Children"] = {
["1"] = {
["GUID"] = "5958abdf-e760-432d-905f-3b178275e590", 
["Name"] = "Color51", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/27163608-500a-4c33-9a6f-3a554d1f02b6", 
["C0"] = CFrame.new(-0.000277, -0.122312, -0.019562, 1.000000, -0.000000, -0.000000, -0.000000, 0.573576, -0.819152, 0.000000, 0.819152, 0.573576), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/6bbf43f8-2b9b-425a-884e-c34b65206905"
}
}, 
["2"] = {
["GUID"] = "3803525f-61bb-4273-b24f-a14b9714ac2b", 
["Name"] = "Color13", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/27163608-500a-4c33-9a6f-3a554d1f02b6", 
["C0"] = CFrame.new(-0.001228, -0.279967, -0.039168, 1.000000, -0.000000, -0.000000, -0.000000, 0.573576, -0.819152, 0.000000, 0.819152, 0.573576), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/80a13abe-4374-49b0-9530-483b730bb4bd"
}
}, 
["3"] = {
["GUID"] = "d48ab3b9-3ea0-43b1-b8a4-05585d60ddc9", 
["Name"] = "Color12", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/27163608-500a-4c33-9a6f-3a554d1f02b6", 
["C0"] = CFrame.new(-0.000228, -0.196888, -0.388373, 1.000000, -0.000000, -0.000000, -0.000000, 0.573576, -0.819152, 0.000000, 0.819152, 0.573576), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/8eed16eb-bc81-4093-bf13-0a689f736727"
}
}, 
["4"] = {
["GUID"] = "5c4f57a9-639e-4be5-a9d3-55503fe279e2", 
["Name"] = "Color11", 
["ClassName"] = "Weld", 
["Properties"] = {
["Part0"] = "%PARENT/27163608-500a-4c33-9a6f-3a554d1f02b6", 
["C0"] = CFrame.new(-0.001279, -0.342955, -0.122234, 1.000000, -0.000000, -0.000000, -0.000000, 0.573576, -0.819152, 0.000000, 0.819152, 0.573576), 
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["Part1"] = "%PARENT/efab072b-1c2d-431f-89b8-814c60b2c7f6"
}
}
}
}, 
["2"] = {
["GUID"] = "efab072b-1c2d-431f-89b8-814c60b2c7f6", 
["Name"] = "Color11", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["MeshId"] = "rbxassetid://97033910476816", 
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.430115, 1.782016, -11.913503, 1.000001, 0.000000, -0.000000, -0.000000, 0.573576, -0.819153, -0.000000, 0.819154, 0.573577), 
["CanTouch"] = false, 
["Size"] = Vector3.new(0.521100, 0.370410, 0.573200), 
["Rotation"] = Vector3.new(55.000000, 0.000000, 0.000000), 
["Transparency"] = 1, 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["PivotOffset"] = CFrame.new(-13.802549, -1.799145, -15.085100, 1.000000, 0.000000, -0.000000, -0.000000, 1.000000, -0.000000, 0.000000, 0.000000, 1.000000)
}, 
["Attributes"] = {
["CopySkin_NP"] = true, 
["CopySkin"] = "Torso"
}
}, 
["3"] = {
["GUID"] = "8eed16eb-bc81-4093-bf13-0a689f736727", 
["Name"] = "Color12", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["MeshId"] = "rbxassetid://93287272061387", 
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.431166, 1.928083, -12.179644, 1.000001, 0.000000, -0.000000, -0.000000, 0.573576, -0.819153, -0.000000, 0.819154, 0.573577), 
["CanTouch"] = false, 
["Size"] = Vector3.new(0.015400, 0.015930, 0.029201), 
["Rotation"] = Vector3.new(55.000000, 0.000000, 0.000000), 
["Transparency"] = 1, 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["PivotOffset"] = CFrame.new(-13.803600, -1.664915, -14.812799, 1.000000, 0.000000, -0.000000, -0.000000, 1.000000, -0.000000, 0.000000, 0.000000, 1.000000)
}, 
["Attributes"] = {
["CopySkin_NP"] = true, 
["CopySkin"] = "Torso"
}
}, 
["4"] = {
["GUID"] = "80a13abe-4374-49b0-9530-483b730bb4bd", 
["Name"] = "Color13", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["MeshId"] = "rbxassetid://88687924677081", 
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(1.000000,0.580392,0.580392), 
["CFrame"] = CFrame.new(0.430166, 1.845004, -11.830437, 1.000001, 0.000000, -0.000000, -0.000000, 0.573576, -0.819153, -0.000000, 0.819154, 0.573577), 
["CanTouch"] = false, 
["Size"] = Vector3.new(0.497601, 0.577830, 0.571899), 
["Rotation"] = Vector3.new(55.000000, 0.000000, 0.000000), 
["Transparency"] = 1, 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["PivotOffset"] = CFrame.new(-13.802600, -1.903315, -15.081150, 1.000000, 0.000000, -0.000000, -0.000000, 1.000000, -0.000000, 0.000000, 0.000000, 1.000000)
}, 
["Attributes"] = {
["CopySkin_NP"] = true, 
["CopySkin"] = "Torso"
}
}, 
["5"] = {
["GUID"] = "6bbf43f8-2b9b-425a-884e-c34b65206905", 
["Name"] = "Color51", 
["ClassName"] = "MeshPart", 
["Properties"] = {
["MeshId"] = "rbxassetid://91037591491219", 
["CanQuery"] = false, 
["CanCollide"] = false, 
["Color"] = Color3.new(0.388235,0.372549,0.384314), 
["CFrame"] = CFrame.new(0.431117, 2.002659, -11.810831, 1.000001, 0.000000, -0.000000, -0.000000, 0.573576, -0.819153, -0.000000, 0.819154, 0.573577), 
["CanTouch"] = false, 
["Size"] = Vector3.new(0.846900, 0.830550, 0.806100), 
["Rotation"] = Vector3.new(55.000000, 0.000000, 0.000000), 
["Transparency"] = 1, 
["Anchored"] = false, 
["Material"] = Enum.Material.SmoothPlastic, 
["Massless"] = true, 
["PivotOffset"] = CFrame.new(-13.803551, -2.009805, -14.963249, 1.000000, 0.000000, -0.000000, -0.000000, 1.000000, -0.000000, 0.000000, 0.000000, 1.000000)
}, 
["Attributes"] = {
["CopySkin"] = "Torso"
}
}
}
}, 
["3"] = {
["GUID"] = "84b6c39a-3af8-4022-addd-6405fc6fb7e4", 
["Name"] = "vinny", 
["ClassName"] = "Motor6D", 
["Properties"] = {
["C1"] = CFrame.new(0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000000), 
["C0"] = CFrame.new(0.000000, -0.875000, -0.000000, 1.000000, 0.000000, 0.000000, 0.000000, 1.000001, -0.000000, 0.000000, 0.000000, 1.000001), 
["Part1"] = "%PARENT/27163608-500a-4c33-9a6f-3a554d1f02b6"
}, 
["Attributes"] = {
["SetPart0To"] = "Torso"
}
}
}
}
}
}
}, 
["Attributes"] = {
["RequiresUnloader"] = true
}
}, 
["2"] = {
["GUID"] = "92ec665e-1b44-4162-9898-c47a38719e18", 
["Name"] = "EvilUI", 
["ClassName"] = "ScreenGui", 
["Parent"] = "%IPARENT:ReplicatedStorage/PlantsStorage/Evil/", 
["Children"] = {
["1"] = {
["GUID"] = "fcd8d469-cc89-40ba-9f25-f64f3d3d1ded", 
["Name"] = "main", 
["ClassName"] = "Frame", 
["Properties"] = {
["AnchorPoint"] = Vector2.new(0.500000, 0.500000), 
["Transparency"] = 1, 
["BackgroundTransparency"] = 1, 
["Position"] = UDim2.new(0.500000, 0.000000, 0.500000, 0.000000), 
["BorderColor3"] = Color3.new(0.000000,0.000000,0.000000), 
["Size"] = UDim2.new(0.000000, 450.000000, 0.000000, 300.000000), 
["BorderSizePixel"] = 0, 
["BackgroundColor3"] = Color3.new(1.000000,1.000000,1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "97652905-6f21-4cfe-beee-c86806fd41c3", 
["Name"] = "background", 
["ClassName"] = "Frame", 
["Properties"] = {
["Transparency"] = 0.15000000596046449, 
["BackgroundTransparency"] = 0.15000000596046449, 
["ClipsDescendants"] = true, 
["BorderColor3"] = Color3.new(1.000000,1.000000,1.000000), 
["ZIndex"] = -1, 
["Size"] = UDim2.new(1.000000, 0.000000, 1.000000, 0.000000), 
["BackgroundColor3"] = Color3.new(0.058824,0.058824,0.058824)
}, 
["Children"] = {
["1"] = {
["GUID"] = "75fcac11-8ccd-43d4-b82a-924a9fad76b6", 
["Name"] = "icon", 
["ClassName"] = "ImageLabel", 
["Properties"] = {
["ImageColor3"] = Color3.new(0.235294,0.235294,0.235294), 
["ImageTransparency"] = 0.5, 
["BorderColor3"] = Color3.new(0.000000,0.000000,0.000000), 
["Transparency"] = 1, 
["Image"] = "rbxassetid://136577229560528", 
["BackgroundTransparency"] = 1, 
["Position"] = UDim2.new(0.000000, -60.000000, 0.000000, -70.000000), 
["Size"] = UDim2.new(0.000000, 200.000000, 0.000000, 200.000000), 
["ResampleMode"] = Enum.ResamplerMode.Pixelated, 
["BorderSizePixel"] = 0, 
["BackgroundColor3"] = Color3.new(1.000000,1.000000,1.000000)
}
}, 
["2"] = {
["GUID"] = "4821048a-3d35-47bf-b429-75ff07e5a46f", 
["Name"] = "header", 
["ClassName"] = "TextLabel", 
["Properties"] = {
["TextWrapped"] = true, 
["TextTransparency"] = 0, 
["TextStrokeTransparency"] = 0.5, 
["AnchorPoint"] = Vector2.new(0.500000, 0.000000), 
["ZIndex"] = 4, 
["TextSize"] = 20, 
["Size"] = UDim2.new(1.000000, 0.000000, 0.000000, 40.000000), 
["TextColor3"] = Color3.new(1.000000,1.000000,1.000000), 
["BorderColor3"] = Color3.new(0.105882,0.164706,0.207843), 
["Text"] = "GENDER", 
["Font"] = Enum.Font.GothamBlack, 
["BackgroundTransparency"] = 1, 
["Position"] = UDim2.new(0.500000, 0.000000, 0.000000, 10.000000), 
["FontFace"] = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy, Enum.FontStyle.Normal), 
["Transparency"] = 1, 
["TextScaled"] = true, 
["BackgroundColor3"] = Color3.new(1.000000,1.000000,1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "b9a152a0-ba8e-49d6-8635-62d56365c982", 
["Name"] = "stroke", 
["ClassName"] = "UIStroke", 
["Properties"] = {
["Color"] = Color3.new(0.058824,0.058824,0.058824), 
["Transparency"] = 0.20000000298023225, 
["Thickness"] = 2
}
}
}
}
}
}, 
["2"] = {
["GUID"] = "38fef9d8-cd24-4c8b-9a00-598440ec640f", 
["Name"] = "gender", 
["ClassName"] = "Frame", 
["Properties"] = {
["Visible"] = false, 
["Transparency"] = 1, 
["BackgroundTransparency"] = 1, 
["BorderColor3"] = Color3.new(0.000000,0.000000,0.000000), 
["Size"] = UDim2.new(1.000000, 0.000000, 1.000000, 0.000000), 
["BorderSizePixel"] = 0, 
["BackgroundColor3"] = Color3.new(1.000000,1.000000,1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "ea5fa606-4084-446c-9f15-932972521f72", 
["Name"] = "genderIcon", 
["ClassName"] = "ImageButton", 
["Properties"] = {
["ImageColor3"] = Color3.new(0.313726,0.549020,0.666667), 
["BorderColor3"] = Color3.new(0.000000,0.000000,0.000000), 
["Size"] = UDim2.new(0.000000, 70.000000, 0.000000, 70.000000), 
["AnchorPoint"] = Vector2.new(0.500000, 0.500000), 
["Image"] = "rbxassetid://88110934768850", 
["BackgroundTransparency"] = 1, 
["Position"] = UDim2.new(1.000000, -45.000000, 1.000000, -105.000000), 
["Transparency"] = 1, 
["ZIndex"] = 2, 
["BorderSizePixel"] = 0, 
["BackgroundColor3"] = Color3.new(1.000000,1.000000,1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "5cd547f5-56ba-49c5-84c9-9a4d71d011c7", 
["Name"] = "shad", 
["ClassName"] = "ImageLabel", 
["Properties"] = {
["ImageColor3"] = Color3.new(0.019608,0.019608,0.019608), 
["BorderColor3"] = Color3.new(0.000000,0.000000,0.000000), 
["AnchorPoint"] = Vector2.new(0.500000, 0.500000), 
["Image"] = "rbxassetid://88110934768850", 
["BackgroundTransparency"] = 1, 
["Position"] = UDim2.new(0.500000, 0.000000, 0.500000, 3.000000), 
["Transparency"] = 1, 
["Size"] = UDim2.new(1.000000, 0.000000, 1.000000, 0.000000), 
["BorderSizePixel"] = 0, 
["BackgroundColor3"] = Color3.new(1.000000,1.000000,1.000000)
}
}
}
}, 
["2"] = {
["GUID"] = "42bdaeff-7ea0-4931-8ea8-3e5d4d58450d", 
["Name"] = "toggles", 
["ClassName"] = "Frame", 
["Properties"] = {
["AnchorPoint"] = Vector2.new(0.000000, 0.500000), 
["Transparency"] = 1, 
["BackgroundTransparency"] = 1, 
["Position"] = UDim2.new(0.000000, 35.000000, 1.000000, -85.000000), 
["BorderColor3"] = Color3.new(0.000000,0.000000,0.000000), 
["Size"] = UDim2.new(0.000000, 35.000000, 0.000000, 35.000000), 
["BorderSizePixel"] = 0, 
["BackgroundColor3"] = Color3.new(0.470588,0.470588,0.470588)
}, 
["Children"] = {
["1"] = {
["GUID"] = "78ade97b-2933-4f84-894e-b36edddbff6c", 
["Name"] = "ulist", 
["ClassName"] = "UIListLayout", 
["Properties"] = {
["VerticalAlignment"] = Enum.VerticalAlignment.Bottom, 
["Padding"] = UDim.new(0.000000, 8.000000), 
["SortOrder"] = Enum.SortOrder.LayoutOrder
}
}
}
}, 
["3"] = {
["GUID"] = "bdc0aa6b-93cb-45d1-84ac-197c8ad1a409", 
["Name"] = "genderApply", 
["ClassName"] = "TextButton", 
["Properties"] = {
["FontFace"] = Font.new("rbxasset://fonts/families/SourceSansPro.json", Enum.FontWeight.Regular, Enum.FontStyle.Normal), 
["TextColor3"] = Color3.new(0.000000,0.000000,0.000000), 
["BorderColor3"] = Color3.new(0.000000,0.000000,0.000000), 
["Text"] = "", 
["TextTransparency"] = 0, 
["Transparency"] = 1, 
["AnchorPoint"] = Vector2.new(0.500000, 0.500000), 
["Font"] = Enum.Font.SourceSans, 
["BackgroundTransparency"] = 1, 
["Position"] = UDim2.new(0.500000, 0.000000, 1.000000, -25.000000), 
["TextSize"] = 14, 
["Size"] = UDim2.new(1.000000, -40.000000, 0.000000, 30.000000), 
["BorderSizePixel"] = 0, 
["BackgroundColor3"] = Color3.new(0.156863,0.549020,0.313726)
}, 
["Children"] = {
["1"] = {
["GUID"] = "3b458429-e6ad-4d21-a7a7-8a0dc8ced3b3", 
["Name"] = "background", 
["ClassName"] = "Frame", 
["Properties"] = {
["Transparency"] = 0.25, 
["BackgroundTransparency"] = 0.25, 
["BorderColor3"] = Color3.new(1.000000,1.000000,1.000000), 
["Size"] = UDim2.new(1.000000, 0.000000, 1.000000, 0.000000), 
["BackgroundColor3"] = Color3.new(0.117647,0.352941,0.117647)
}
}, 
["2"] = {
["GUID"] = "11c0f1e8-05ab-492c-9d7a-2c46b235a26f", 
["Name"] = "header", 
["ClassName"] = "TextLabel", 
["Properties"] = {
["TextWrapped"] = true, 
["TextTransparency"] = 0, 
["TextStrokeTransparency"] = 0.5, 
["AnchorPoint"] = Vector2.new(0.500000, 0.500000), 
["ZIndex"] = 4, 
["TextSize"] = 20, 
["Size"] = UDim2.new(1.000000, 0.000000, 1.000000, 0.000000), 
["TextColor3"] = Color3.new(1.000000,1.000000,1.000000), 
["BorderColor3"] = Color3.new(0.105882,0.164706,0.207843), 
["Text"] = "APPLY", 
["Font"] = Enum.Font.GothamBlack, 
["BackgroundTransparency"] = 1, 
["Position"] = UDim2.new(0.500000, 0.000000, 0.500000, 0.000000), 
["FontFace"] = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy, Enum.FontStyle.Normal), 
["Transparency"] = 1, 
["TextScaled"] = true, 
["BackgroundColor3"] = Color3.new(1.000000,1.000000,1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "eb134490-b6dc-4404-88b1-04245f57dfba", 
["Name"] = "stroke", 
["ClassName"] = "UIStroke", 
["Properties"] = {
["Transparency"] = 0.25
}
}
}
}
}
}, 
["4"] = {
["GUID"] = "fb88cb94-9baf-49d2-b7de-838435dfed1b", 
["Name"] = "ViewportFrame", 
["ClassName"] = "ViewportFrame", 
["Properties"] = {
["Transparency"] = 1, 
["BackgroundTransparency"] = 1, 
["Position"] = UDim2.new(0.200000, 0.000000, 0.166667, 0.000000), 
["BorderColor3"] = Color3.new(0.000000,0.000000,0.000000), 
["Size"] = UDim2.new(0.000000, 269.000000, 0.000000, 163.000000), 
["BorderSizePixel"] = 0, 
["BackgroundColor3"] = Color3.new(1.000000,1.000000,1.000000)
}
}, 
["5"] = {
["GUID"] = "f2bf7eb3-0917-4569-8ed0-0a2e24643fcd", 
["Name"] = "bottomSizeSlider", 
["ClassName"] = "Frame", 
["Properties"] = {
["AnchorPoint"] = Vector2.new(0.500000, 0.500000), 
["Transparency"] = 1, 
["BackgroundTransparency"] = 1, 
["Position"] = UDim2.new(0.500000, 0.000000, 1.000000, -100.000000), 
["BorderColor3"] = Color3.new(0.000000,0.000000,0.000000), 
["Size"] = UDim2.new(1.000000, -300.000000, 0.000000, 10.000000), 
["BorderSizePixel"] = 0, 
["BackgroundColor3"] = Color3.new(0.470588,0.470588,0.470588)
}, 
["Children"] = {
["1"] = {
["GUID"] = "2b8312b3-9ec8-46c0-ae80-51f1ef6d7323", 
["Name"] = "header", 
["ClassName"] = "TextLabel", 
["Properties"] = {
["TextWrapped"] = true, 
["TextTransparency"] = 0, 
["TextStrokeTransparency"] = 0.5, 
["AnchorPoint"] = Vector2.new(0.500000, 0.500000), 
["ZIndex"] = 4, 
["TextSize"] = 20, 
["Size"] = UDim2.new(1.000000, 0.000000, 0.000000, 20.000000), 
["TextColor3"] = Color3.new(1.000000,1.000000,1.000000), 
["BorderColor3"] = Color3.new(0.105882,0.164706,0.207843), 
["Text"] = "BOTTOM SIZE (0.9)", 
["Font"] = Enum.Font.GothamBlack, 
["BackgroundTransparency"] = 1, 
["Position"] = UDim2.new(0.500000, 0.000000, 0.500000, -22.000000), 
["FontFace"] = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy, Enum.FontStyle.Normal), 
["Transparency"] = 1, 
["TextScaled"] = true, 
["BackgroundColor3"] = Color3.new(1.000000,1.000000,1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "74ee1473-a816-4794-8142-81d318059bfd", 
["Name"] = "stroke", 
["ClassName"] = "UIStroke", 
["Properties"] = {
["Transparency"] = 0.25
}
}
}
}, 
["2"] = {
["GUID"] = "22b38629-46ae-4354-bd56-07e2113d2506", 
["Name"] = "button", 
["ClassName"] = "TextButton", 
["Properties"] = {
["FontFace"] = Font.new("rbxasset://fonts/families/SourceSansPro.json", Enum.FontWeight.Regular, Enum.FontStyle.Normal), 
["TextColor3"] = Color3.new(0.000000,0.000000,0.000000), 
["BorderColor3"] = Color3.new(1.000000,1.000000,1.000000), 
["Text"] = "", 
["AnchorPoint"] = Vector2.new(0.500000, 0.500000), 
["Font"] = Enum.Font.SourceSans, 
["TextTransparency"] = 0, 
["Position"] = UDim2.new(0.750000, 0.000000, 0.500000, 0.000000), 
["Size"] = UDim2.new(0.000000, 10.000000, 0.000000, 15.000000), 
["ZIndex"] = 5, 
["TextSize"] = 14, 
["BackgroundColor3"] = Color3.new(0.235294,0.235294,0.235294)
}
}, 
["3"] = {
["GUID"] = "70927a6d-dd4f-45d4-982b-1314c51b2628", 
["Name"] = "background", 
["ClassName"] = "Frame", 
["Properties"] = {
["Transparency"] = 0.15000000596046449, 
["BackgroundTransparency"] = 0.15000000596046449, 
["BorderColor3"] = Color3.new(1.000000,1.000000,1.000000), 
["Size"] = UDim2.new(1.000000, 0.000000, 1.000000, 0.000000), 
["BackgroundColor3"] = Color3.new(0.058824,0.058824,0.058824)
}
}
}
}, 
["6"] = {
["GUID"] = "86b40d0e-cedf-43b1-a8de-0991c3b28b45", 
["Name"] = "ohioSizeSlider", 
["ClassName"] = "Frame", 
["Properties"] = {
["Visible"] = false, 
["BorderColor3"] = Color3.new(0.000000,0.000000,0.000000), 
["AnchorPoint"] = Vector2.new(0.500000, 0.500000), 
["Transparency"] = 1, 
["BackgroundTransparency"] = 1, 
["Position"] = UDim2.new(0.500000, 0.000000, 1.000000, -220.000000), 
["Size"] = UDim2.new(1.000000, -300.000000, 0.000000, 10.000000), 
["BorderSizePixel"] = 0, 
["BackgroundColor3"] = Color3.new(0.470588,0.470588,0.470588)
}, 
["Children"] = {
["1"] = {
["GUID"] = "c67e8fb3-d08d-4eb9-b5de-de03423c1b9c", 
["Name"] = "header", 
["ClassName"] = "TextLabel", 
["Properties"] = {
["TextWrapped"] = true, 
["TextTransparency"] = 0, 
["TextStrokeTransparency"] = 0.5, 
["AnchorPoint"] = Vector2.new(0.500000, 0.500000), 
["ZIndex"] = 4, 
["TextSize"] = 20, 
["Size"] = UDim2.new(1.000000, 0.000000, 0.000000, 20.000000), 
["TextColor3"] = Color3.new(1.000000,1.000000,1.000000), 
["BorderColor3"] = Color3.new(0.105882,0.164706,0.207843), 
["Text"] = "FUTA SIZE (0.9)", 
["Font"] = Enum.Font.GothamBlack, 
["BackgroundTransparency"] = 1, 
["Position"] = UDim2.new(0.500000, 0.000000, 0.500000, -22.000000), 
["FontFace"] = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy, Enum.FontStyle.Normal), 
["Transparency"] = 1, 
["TextScaled"] = true, 
["BackgroundColor3"] = Color3.new(1.000000,1.000000,1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "afe3ec6f-645b-424c-bca9-fdc12f65e78f", 
["Name"] = "stroke", 
["ClassName"] = "UIStroke", 
["Properties"] = {
["Transparency"] = 0.25
}
}
}
}, 
["2"] = {
["GUID"] = "3508b349-ad96-4aa4-a5fe-1abf6914cea0", 
["Name"] = "background", 
["ClassName"] = "Frame", 
["Properties"] = {
["Transparency"] = 0.15000000596046449, 
["BackgroundTransparency"] = 0.15000000596046449, 
["BorderColor3"] = Color3.new(1.000000,1.000000,1.000000), 
["Size"] = UDim2.new(1.000000, 0.000000, 1.000000, 0.000000), 
["BackgroundColor3"] = Color3.new(0.058824,0.058824,0.058824)
}
}, 
["3"] = {
["GUID"] = "e1f7efd5-4c50-4a06-8183-d97abe496321", 
["Name"] = "button", 
["ClassName"] = "TextButton", 
["Properties"] = {
["FontFace"] = Font.new("rbxasset://fonts/families/SourceSansPro.json", Enum.FontWeight.Regular, Enum.FontStyle.Normal), 
["TextColor3"] = Color3.new(0.000000,0.000000,0.000000), 
["BorderColor3"] = Color3.new(1.000000,1.000000,1.000000), 
["Text"] = "", 
["AnchorPoint"] = Vector2.new(0.500000, 0.500000), 
["Font"] = Enum.Font.SourceSans, 
["TextTransparency"] = 0, 
["Position"] = UDim2.new(0.750000, 0.000000, 0.500000, 0.000000), 
["Size"] = UDim2.new(0.000000, 10.000000, 0.000000, 15.000000), 
["ZIndex"] = 5, 
["TextSize"] = 14, 
["BackgroundColor3"] = Color3.new(0.235294,0.235294,0.235294)
}
}
}
}, 
["7"] = {
["GUID"] = "ca5562c8-1ed0-4d4b-91a8-96b7455911e9", 
["Name"] = "showClothless", 
["ClassName"] = "Frame", 
["Properties"] = {
["AnchorPoint"] = Vector2.new(1.000000, 0.000000), 
["Transparency"] = 0.15000000596046449, 
["BackgroundTransparency"] = 0.15000000596046449, 
["Position"] = UDim2.new(1.000000, -10.000000, 0.000000, 10.000000), 
["BorderColor3"] = Color3.new(0.588235,0.196078,0.196078), 
["Size"] = UDim2.new(0.000000, 100.000000, 0.000000, 25.000000), 
["BackgroundColor3"] = Color3.new(0.294118,0.098039,0.098039)
}, 
["Children"] = {
["1"] = {
["GUID"] = "45804f71-c2cd-4ee1-baf4-a2caba1b6289", 
["Name"] = "button", 
["ClassName"] = "TextButton", 
["Properties"] = {
["FontFace"] = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Bold, Enum.FontStyle.Normal), 
["TextColor3"] = Color3.new(1.000000,1.000000,1.000000), 
["BorderColor3"] = Color3.new(0.000000,0.000000,0.000000), 
["Text"] = "", 
["TextTransparency"] = 0, 
["Transparency"] = 1, 
["TextWrapped"] = true, 
["Font"] = Enum.Font.GothamBold, 
["BackgroundTransparency"] = 1, 
["TextSize"] = 14, 
["TextScaled"] = true, 
["Size"] = UDim2.new(1.000000, 0.000000, 1.000000, 0.000000), 
["BorderSizePixel"] = 0, 
["BackgroundColor3"] = Color3.new(1.000000,1.000000,1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "a5d733ca-2416-4577-ab43-1e27b7547a2a", 
["Name"] = "stroke", 
["ClassName"] = "UIStroke", 
["Properties"] = {
["Color"] = Color3.new(0.058824,0.058824,0.058824), 
["Transparency"] = 0.20000000298023225, 
["Thickness"] = 1.5
}
}
}
}
}, 
["Attributes"] = {
["MouseTip"] = ""
}
}, 
["8"] = {
["GUID"] = "f9067f6c-02be-4686-ab23-9a75e23b3bd5", 
["Name"] = "packageSizeSlider", 
["ClassName"] = "Frame", 
["Properties"] = {
["AnchorPoint"] = Vector2.new(0.500000, 0.500000), 
["Transparency"] = 1, 
["BackgroundTransparency"] = 1, 
["Position"] = UDim2.new(0.500000, 0.000000, 1.000000, -55.000000), 
["BorderColor3"] = Color3.new(0.000000,0.000000,0.000000), 
["Size"] = UDim2.new(1.000000, -60.000000, 0.000000, 10.000000), 
["BorderSizePixel"] = 0, 
["BackgroundColor3"] = Color3.new(0.470588,0.470588,0.470588)
}, 
["Children"] = {
["1"] = {
["GUID"] = "d0ad4f5d-5654-479d-bb2c-57b279b2388d", 
["Name"] = "button", 
["ClassName"] = "TextButton", 
["Properties"] = {
["FontFace"] = Font.new("rbxasset://fonts/families/SourceSansPro.json", Enum.FontWeight.Regular, Enum.FontStyle.Normal), 
["TextColor3"] = Color3.new(0.000000,0.000000,0.000000), 
["BorderColor3"] = Color3.new(1.000000,1.000000,1.000000), 
["Text"] = "", 
["AnchorPoint"] = Vector2.new(0.500000, 0.500000), 
["Font"] = Enum.Font.SourceSans, 
["TextTransparency"] = 0, 
["Position"] = UDim2.new(0.750000, 0.000000, 0.500000, 0.000000), 
["Size"] = UDim2.new(0.000000, 10.000000, 0.000000, 15.000000), 
["ZIndex"] = 5, 
["TextSize"] = 14, 
["BackgroundColor3"] = Color3.new(0.235294,0.235294,0.235294)
}
}, 
["2"] = {
["GUID"] = "9782fd43-0b01-4e68-9a12-fb7d768c9605", 
["Name"] = "header", 
["ClassName"] = "TextLabel", 
["Properties"] = {
["TextWrapped"] = true, 
["TextTransparency"] = 0, 
["TextStrokeTransparency"] = 0.5, 
["AnchorPoint"] = Vector2.new(0.500000, 0.500000), 
["ZIndex"] = 4, 
["TextSize"] = 20, 
["Size"] = UDim2.new(1.000000, 0.000000, 0.000000, 20.000000), 
["TextColor3"] = Color3.new(1.000000,1.000000,1.000000), 
["BorderColor3"] = Color3.new(0.105882,0.164706,0.207843), 
["Text"] = "PACKAGE SIZE (0.9)", 
["Font"] = Enum.Font.GothamBlack, 
["BackgroundTransparency"] = 1, 
["Position"] = UDim2.new(0.500000, 0.000000, 0.500000, -22.000000), 
["FontFace"] = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy, Enum.FontStyle.Normal), 
["Transparency"] = 1, 
["TextScaled"] = true, 
["BackgroundColor3"] = Color3.new(1.000000,1.000000,1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "ce686c88-e31d-4aa7-b7e2-836c67d50f91", 
["Name"] = "stroke", 
["ClassName"] = "UIStroke", 
["Properties"] = {
["Transparency"] = 0.25
}
}
}
}, 
["3"] = {
["GUID"] = "73449a45-7b5b-49e1-9406-ef1d6bdd088f", 
["Name"] = "background", 
["ClassName"] = "Frame", 
["Properties"] = {
["Transparency"] = 0.15000000596046449, 
["BackgroundTransparency"] = 0.15000000596046449, 
["BorderColor3"] = Color3.new(1.000000,1.000000,1.000000), 
["Size"] = UDim2.new(1.000000, 0.000000, 1.000000, 0.000000), 
["BackgroundColor3"] = Color3.new(0.058824,0.058824,0.058824)
}
}
}
}
}
}, 
["3"] = {
["GUID"] = "0e793677-1b0e-4570-9aac-167757044e4a", 
["Name"] = "ega", 
["ClassName"] = "Frame", 
["Properties"] = {
["Visible"] = false, 
["Transparency"] = 1, 
["BackgroundTransparency"] = 1, 
["ClipsDescendants"] = true, 
["BorderColor3"] = Color3.new(1.000000,1.000000,1.000000), 
["ZIndex"] = -1, 
["Size"] = UDim2.new(1.000000, 0.000000, 1.000000, 0.000000), 
["BackgroundColor3"] = Color3.new(0.058824,0.058824,0.058824)
}, 
["Children"] = {
["1"] = {
["GUID"] = "13fc2d0e-2077-444a-9b93-01d0630c65dd", 
["Name"] = "Add", 
["ClassName"] = "TextButton", 
["Properties"] = {
["TextWrapped"] = true, 
["FontFace"] = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy, Enum.FontStyle.Normal), 
["Transparency"] = 1, 
["TextColor3"] = Color3.new(0.000000,1.000000,0.000000), 
["TextTransparency"] = 0, 
["Text"] = "+", 
["TextSize"] = 20, 
["TextStrokeTransparency"] = 0.5, 
["AnchorPoint"] = Vector2.new(0.500000, 0.500000), 
["Font"] = Enum.Font.GothamBlack, 
["BackgroundTransparency"] = 1, 
["Position"] = UDim2.new(0.750000, 0.000000, 0.500000, 0.000000), 
["TextScaled"] = true, 
["Size"] = UDim2.new(0.250000, 0.000000, 0.000000, 80.000000), 
["BorderSizePixel"] = 0, 
["BackgroundColor3"] = Color3.new(1.000000,1.000000,1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "36ed645e-4823-4841-a1b0-ab93d13bbf79", 
["Name"] = "stroke", 
["ClassName"] = "UIStroke", 
["Properties"] = {
["Color"] = Color3.new(0.058824,0.058824,0.058824), 
["Transparency"] = 0.20000000298023225, 
["Thickness"] = 2
}
}
}
}, 
["2"] = {
["GUID"] = "77d36a01-20a0-4dda-8c1a-0167a6210968", 
["Name"] = "notice", 
["ClassName"] = "TextLabel", 
["Properties"] = {
["TextWrapped"] = true, 
["TextTransparency"] = 0, 
["TextStrokeTransparency"] = 0.5, 
["AnchorPoint"] = Vector2.new(0.500000, 0.000000), 
["ZIndex"] = 4, 
["TextSize"] = 20, 
["Size"] = UDim2.new(1.000000, 0.000000, 0.000000, 40.000000), 
["TextColor3"] = Color3.new(1.000000,0.725490,0.549020), 
["BorderColor3"] = Color3.new(0.105882,0.164706,0.207843), 
["Text"] = "NOTE: CAN ONLY BE SET ONCE PER PLAYER SESSION", 
["Font"] = Enum.Font.GothamBold, 
["BackgroundTransparency"] = 1, 
["Position"] = UDim2.new(0.500000, 0.000000, 0.800000, 0.000000), 
["FontFace"] = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Bold, Enum.FontStyle.Normal), 
["Transparency"] = 1, 
["TextScaled"] = true, 
["BackgroundColor3"] = Color3.new(1.000000,1.000000,1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "0e089312-43a4-4757-aad3-b9797a9e1c06", 
["Name"] = "stroke", 
["ClassName"] = "UIStroke", 
["Properties"] = {
["Color"] = Color3.new(0.058824,0.058824,0.058824), 
["Transparency"] = 0.20000000298023225, 
["Thickness"] = 2
}
}
}
}, 
["3"] = {
["GUID"] = "f0e31850-70ee-44fe-844b-485e7af4a526", 
["Name"] = "Subtract", 
["ClassName"] = "TextButton", 
["Properties"] = {
["TextWrapped"] = true, 
["FontFace"] = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy, Enum.FontStyle.Normal), 
["Transparency"] = 1, 
["TextColor3"] = Color3.new(1.000000,0.000000,0.000000), 
["TextTransparency"] = 0, 
["Text"] = "-", 
["TextSize"] = 20, 
["TextStrokeTransparency"] = 0.5, 
["AnchorPoint"] = Vector2.new(0.500000, 0.500000), 
["Font"] = Enum.Font.GothamBlack, 
["BackgroundTransparency"] = 1, 
["Position"] = UDim2.new(0.250000, 0.000000, 0.500000, 0.000000), 
["TextScaled"] = true, 
["Size"] = UDim2.new(0.250000, 0.000000, 0.000000, 80.000000), 
["BorderSizePixel"] = 0, 
["BackgroundColor3"] = Color3.new(1.000000,1.000000,1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "47e1f338-e8a7-4ad9-837e-4ac19e6c792d", 
["Name"] = "stroke", 
["ClassName"] = "UIStroke", 
["Properties"] = {
["Color"] = Color3.new(0.058824,0.058824,0.058824), 
["Transparency"] = 0.20000000298023225, 
["Thickness"] = 2
}
}
}
}, 
["4"] = {
["GUID"] = "65cafc60-531e-41cb-a8a5-2e8e4e53024c", 
["Name"] = "ageApply", 
["ClassName"] = "TextButton", 
["Properties"] = {
["FontFace"] = Font.new("rbxasset://fonts/families/SourceSansPro.json", Enum.FontWeight.Regular, Enum.FontStyle.Normal), 
["TextColor3"] = Color3.new(0.000000,0.000000,0.000000), 
["BorderColor3"] = Color3.new(0.000000,0.000000,0.000000), 
["Text"] = "", 
["TextTransparency"] = 0, 
["Transparency"] = 1, 
["AnchorPoint"] = Vector2.new(0.500000, 0.500000), 
["Font"] = Enum.Font.SourceSans, 
["BackgroundTransparency"] = 1, 
["Position"] = UDim2.new(0.500000, 0.000000, 0.795000, -25.000000), 
["TextSize"] = 14, 
["Size"] = UDim2.new(0.500000, -40.000000, 0.000000, 30.000000), 
["BorderSizePixel"] = 0, 
["BackgroundColor3"] = Color3.new(0.156863,0.549020,0.313726)
}, 
["Children"] = {
["1"] = {
["GUID"] = "72473b3a-3f2d-418a-9c89-59c1365fb240", 
["Name"] = "header", 
["ClassName"] = "TextLabel", 
["Properties"] = {
["TextWrapped"] = true, 
["TextTransparency"] = 0, 
["TextStrokeTransparency"] = 0.5, 
["AnchorPoint"] = Vector2.new(0.500000, 0.500000), 
["ZIndex"] = 4, 
["TextSize"] = 20, 
["Size"] = UDim2.new(1.000000, 0.000000, 1.000000, 0.000000), 
["TextColor3"] = Color3.new(1.000000,1.000000,1.000000), 
["BorderColor3"] = Color3.new(0.105882,0.164706,0.207843), 
["Text"] = "APPLY", 
["Font"] = Enum.Font.GothamBlack, 
["BackgroundTransparency"] = 1, 
["Position"] = UDim2.new(0.500000, 0.000000, 0.500000, 0.000000), 
["FontFace"] = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy, Enum.FontStyle.Normal), 
["Transparency"] = 1, 
["TextScaled"] = true, 
["BackgroundColor3"] = Color3.new(1.000000,1.000000,1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "f50be176-194f-446f-8fa0-bdf46fec7d80", 
["Name"] = "stroke", 
["ClassName"] = "UIStroke", 
["Properties"] = {
["Transparency"] = 0.25
}
}
}
}, 
["2"] = {
["GUID"] = "6666b9da-a79b-4e95-b51b-c6e7fa398508", 
["Name"] = "background", 
["ClassName"] = "Frame", 
["Properties"] = {
["Transparency"] = 0.25, 
["BackgroundTransparency"] = 0.25, 
["BorderColor3"] = Color3.new(0.000000,0.000000,0.000000), 
["Size"] = UDim2.new(1.000000, 0.000000, 1.000000, 0.000000), 
["BorderSizePixel"] = 2, 
["BackgroundColor3"] = Color3.new(0.117647,0.352941,0.117647)
}
}
}
}, 
["5"] = {
["GUID"] = "41647d8d-2690-4ede-9bb5-303a71b9eb08", 
["Name"] = "number", 
["ClassName"] = "TextBox", 
["Properties"] = {
["Transparency"] = 1, 
["FontFace"] = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy, Enum.FontStyle.Normal), 
["TextWrapped"] = true, 
["TextColor3"] = Color3.new(1.000000,1.000000,1.000000), 
["BorderColor3"] = Color3.new(0.000000,0.000000,0.000000), 
["Text"] = "18", 
["TextSize"] = 14, 
["TextScaled"] = true, 
["AnchorPoint"] = Vector2.new(0.500000, 0.500000), 
["Font"] = Enum.Font.GothamBlack, 
["BackgroundTransparency"] = 1, 
["Position"] = UDim2.new(0.500000, 0.000000, 0.500000, 0.000000), 
["Size"] = UDim2.new(0.250000, 0.000000, 0.000000, 80.000000), 
["ClearTextOnFocus"] = false, 
["BorderSizePixel"] = 0, 
["BackgroundColor3"] = Color3.new(1.000000,1.000000,1.000000)
}, 
["Children"] = {
["1"] = {
["GUID"] = "a8469181-c60d-43c9-80fa-3200aa48789a", 
["Name"] = "stroke", 
["ClassName"] = "UIStroke", 
["Properties"] = {
["Color"] = Color3.new(0.058824,0.058824,0.058824), 
["Transparency"] = 0.20000000298023225, 
["Thickness"] = 2
}
}
}
}
}
}
}
}
}, 
["Attributes"] = {
["RequiresUnloader"] = true
}
}
}