-- ================================================================
-- | Configuration                                                |
-- ================================================================

local config = {}

-----------------
config.MaxWalkSpeed = 25;
config.MaxJumpPower = 80;
-----------------------------------------------

config.MinJoinTime = 20;

config.DebugEnabled = true;

-- If true, then the heat NumberValues will reflect the values
-- contained in the script.
config.DiagnosticsEnabled = false


-- Whitelists Adonis flight system
config.AllowAdonisFlight = true;

-- How long punished players have to wait before they regain
-- physics control.
config.PunishmentDuration = 0.5

-- How long they will be punished when confirmed exploits
config.PunishmentDuration2 = 3

-- Roughly how far the script looks for valid nearby objects.
-- Making this larger doesn't affect how the anticheat determines
-- whether a player is standing on something, however.
config.CheckRadius = 5

-- Objects with any dimension thinner than this will be ignored
-- by no-clip checks, which leaves some room for events like doors
-- that close right behind players.
config.NoclipThicknessTolerance = 0.5


-- I recommend you leave this true when you have moving physics
-- objects, because players could appear to be noclipping even
-- if they're not exploiting. For example, from hopping around
-- while inside a moving boat.
config.AllowNoclippingThroughPhysicsObjects = true

config.NoClipEnabled = true

-- How many times the walk speed the player is allowed to run
-- before heating up. This also amounts to the distance a player
-- can instantly teleport before this instantly overheats,
-- multiplied by the TimeSpan.
config.SpeedToleranceRatio = 0.5

-- How long a player can float around before the anticheat overheats.
config.MaxFlyingDuration = 2.5

-- How fast a player must fall down to avoid triggering the
-- anti-flight system. I recommend keeping this above 50
-- to curtail gliding exploits.
config.FlightHeatCooldownRequiredFallSpeed = 200

-- The amount of RotVelocity.Magnitude the anticheat will stay cool
-- with. Exploit scripts usually create ludicrous velocities, so they
-- often trigger even generous limits.
config.RotVelocityTolerance = 360 * 7

-- The timespan that the anticheat will account for. Lower values
-- means potential cheats will be stopped sooner, but also means
-- lower tolerance for network jitter.
config.TimeSpan = 1;

return config
