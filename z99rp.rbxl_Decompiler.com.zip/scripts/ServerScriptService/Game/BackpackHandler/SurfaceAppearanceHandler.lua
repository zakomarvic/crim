local ServerStorage =			game:GetService("ServerStorage")
local ReplicatedStorage =		game:GetService("ReplicatedStorage")
local Players =					game:GetService("Players")
local PhysicsService = 			game:GetService("PhysicsService")

return function()
	local mf = Instance.new("Folder")
	mf.Name = "PBRTextures"
	mf.Parent = ReplicatedStorage.Storage

	for i,v in pairs(ServerStorage.Tools:GetChildren()) do
		local tsa = nil
		if v:IsA("Tool") and not v:GetAttribute("ForcePBR") then
			for i,z in pairs(v:GetDescendants()) do
				if z:IsA("SurfaceAppearance") and not z.Parent:GetAttribute("IgnorePBR2") then
					if not z.Parent:GetAttribute("IgnorePBR") then
						if z.Parent:IsA("BasePart") then
							z.Parent:SetAttribute("SATP",true)
						end

						if not tsa then
							tsa = z 

							--local f = mf:FindFirstChild(v.Name) or Instance.new("Folder")
							--f.Name = v.Name
							--f.Parent = mf

							z.Name = v.Name
							z.Parent = mf
						else
							z:Destroy()
						end
					else
						local n = tostring(math.random(10000,99999))
						z.Name = n
						if z.Parent:IsA("BasePart") then
							z.Parent:SetAttribute("SATP2",n)
						end
						z.Parent = mf
					end
				end
			end
		end
	end

	for i,v in pairs(ServerStorage.Storage.DisplayItems:GetDescendants()) do
		if v:IsA("SurfaceAppearance") and not v:GetAttribute("ForcePBR") then
			if not v.Parent:GetAttribute("IgnorePBR2") and v.Parent:IsA("BasePart") then
				v.Parent:SetAttribute("SATP",true)
			end
			
			v:Destroy()
		end
	end
	
	_G.SurfaceAppearanceHandlerDone = true
end