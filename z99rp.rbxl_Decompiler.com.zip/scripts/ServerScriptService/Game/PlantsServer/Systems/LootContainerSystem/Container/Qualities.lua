return {
	{weight = 60, quality = 0},
	{weight = 30, quality = 1},
	{weight = 20, quality = 2},
	{weight = 10, quality = 3},
}