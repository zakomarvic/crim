


local ReplicatedStorage = game:GetService("ReplicatedStorage")

local CharacterHandler = {}
CharacterHandler.__index = CharacterHandler

function CharacterHandler:ToggleTrusses(m)
	if self.plr.TeamColor ~= self.teams.Infected.TeamColor then
		m = false
	end

	if m == CharacterHandler.TrussesEnabled then
		return
	end

	CharacterHandler.TrussesEnabled = m

	if CharacterHandler.TrussesFolder ~= nil then
		if m then
			CharacterHandler.TrussesFolder.Parent = workspace.Debris
		else
			CharacterHandler.TrussesFolder.Parent = ReplicatedStorage
		end
	end
end

function CharacterHandler:ToggleMarkers(m)
	if self.plr.TeamColor ~= self.teams.Infected.TeamColor then
		m = false
	end
	
	if m == CharacterHandler.MarkersEnabled then
		return
	end

	CharacterHandler.MarkersEnabled = m


	if CharacterHandler.MarkersFolder ~= nil then
		if m then
			CharacterHandler.MarkersFolder.Parent = workspace.Debris
		else
			CharacterHandler.MarkersFolder.Parent = ReplicatedStorage
		end
	end
end

function CharacterHandler:ToggleBlockers(m)
	if self.plr.TeamColor ~= self.teams.Survivors.TeamColor then
		m = false
	end

	if m == CharacterHandler.BlockersEnabled then
		return
	end

	CharacterHandler.BlockersEnabled = m

	if CharacterHandler.BlockersFolder ~= nil then
		if m then
			CharacterHandler.BlockersFolder.Parent = workspace.Filter.Parts
		else
			CharacterHandler.BlockersFolder.Parent = ReplicatedStorage
		end
	end
end

function CharacterHandler:ToggleSewerBlockers(m)
	if self.plr.TeamColor ~= self.teams.Survivors.TeamColor then
		m = false
	end

	if m == CharacterHandler.SewerBlockersEnabled then
		return
	end

	CharacterHandler.SewerBlockersEnabled = m

	if CharacterHandler.SewerBlockersFolder ~= nil then
		if m then
			CharacterHandler.SewerBlockersFolder.Parent = workspace.Filter.Parts
		else
			CharacterHandler.SewerBlockersFolder.Parent = ReplicatedStorage
		end
	end
end

function CharacterHandler.new(self)
	local function Update()
		CharacterHandler.ToggleTrusses(self,self.I.trussesEnabledV.Value)
		CharacterHandler.ToggleBlockers(self,true)
		CharacterHandler.ToggleMarkers(self,self.I.markersEnabledV.Value)
		CharacterHandler.ToggleSewerBlockers(self,self.I.sewersDisabledV.Value)
	end
	
	local function NewChar(char)
		self.char = char
		self.hum = char:WaitForChild("Humanoid")
		self.root = char:WaitForChild("HumanoidRootPart")
		
		if string.lower(self.I.titleV.Value) == "survive" or string.lower(self.I.titleV.Value) == "infect" then
			if self.plr.Team == self.teams.Infected then
				self.I.titleV.Value = "INFECT"
			else
				self.I.titleV.Value = "SURVIVE"
			end
		end
		
		Update()
	end

	CharacterHandler.TrussesFolder = workspace.Debris:WaitForChild("InfectedTrusses",30)
	CharacterHandler.BlockersFolder = script:WaitForChild("PlayerBlockers")
	CharacterHandler.MarkersFolder = script:WaitForChild("InfectedMarkers")
	CharacterHandler.SewerBlockersFolder = script:WaitForChild("SewerBlockers")
	
	self.plr.CharacterAdded:Connect(NewChar)
	if self.plr.Character then
		NewChar(self.plr.Character)
	end

	self.I.trussesEnabledV.Changed:Connect(Update)
	self.I.markersEnabledV.Changed:Connect(Update)
	self.I.sewersDisabledV.Changed:Connect(Update)
	
	Update()
end

function CharacterHandler:Update(dt)
	
end

return CharacterHandler