local TS = game:GetService("TweenService")
local Teams = game:GetService("Teams")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local BCHandler = {}

local uiSoundsF = ReplicatedStorage:WaitForChild("Storage"):WaitForChild("UISounds")

function BCHandler.new(self)
	local canBuyV = self.I.values.CanBuyCash
	
	local frame = self.ui.mF.BuyCashFrame
	local openBuyButton = self.ui.tF.BuyCashButton
	
	local guiOpen = false
	
	local coreGui
	pcall(function()
		coreGui = self.plr.PlayerGui.CoreGUI
	end)
	
	local function CanBuyCheck()
		return not self.isVipServer and (self.plr.Character ~= nil and canBuyV.Value and ReplicatedStorage.Values.BuyZonesEnabled.Value and self.I.modeV.Value == "intermission") and _G.PlayerData.Cash < canBuyV.Amount.Value
	end
	
	local function PlaySound(s)
		if uiSoundsF and coreGui.Parent and uiSoundsF:FindFirstChild(s) then
			uiSoundsF[s]:Play()
		end
	end
	
	local function ToggleGUI(m)
		if not m then
			m = not guiOpen
		end
		
		if m == guiOpen then
			return
		end
		
		if m then
			frame.Price.Text = tostring(canBuyV.Price.Value) .. " R$"
			frame.Amount.Text = "+$" .. tostring(canBuyV.Amount.Value)
			
			PlaySound("open")
			frame.Visible = true
			openBuyButton.Visible = false
		else
			PlaySound("close")
			frame.Visible = false
			openBuyButton.Visible = CanBuyCheck()
		end
		
		guiOpen = m
	end
	
	local function Update()
		if not CanBuyCheck() and guiOpen then
			ToggleGUI(false)
		end
		openBuyButton.Visible = not guiOpen and CanBuyCheck()
	end
	
	local function BuyFunc()
		if not CanBuyCheck() then
			return
		end
		
		local result =  _G.PromptProductPurchase(canBuyV.ID.Value)

		if result then
			uiSoundsF.purchase:Play()
			ToggleGUI(false)
		end
		
		Update()
	end
	
	canBuyV.Changed:Connect(Update)
	self.I.modeV.Changed:Connect(Update)
	self.plr.CharacterAdded:Connect(function()
		Update()
	end)
	Update()
	
	openBuyButton.MouseButton1Down:Connect(function()
		ToggleGUI()
	end)
	
	frame.CloseButton.MouseButton1Down:Connect(function()
		ToggleGUI(false)
	end)
	
	frame.BuyButton.MouseButton1Down:Connect(function()
		BuyFunc()
	end)
	
	for i,v in pairs(frame:GetDescendants()) do
		if v:IsA("TextButton") then
			v.MouseEnter:Connect(function()
				PlaySound("hover")
			end)
			v.MouseButton1Down:Connect(function()
				PlaySound("click")
			end)
		end
	end
	openBuyButton.MouseEnter:Connect(function()
		PlaySound("hover")
	end)
	openBuyButton.MouseButton1Down:Connect(function()
		PlaySound("click")
	end)
end

return BCHandler