return function(config,tool)
	config.Damage *= 1.08	
	config.Knockback *= 10
	
	config.Customs = {
		["ForceKnockback"] = true;
		KnockbackNMulti = 50;
	}
	
	return config
end