


local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Teams = game:GetService("Teams")

local MainHandler = {}
MainHandler.__index = MainHandler

local GUIHandler = require(script.GUIHandler)
local CharacterHandler = require(script.CharacterHandler)


function MainHandler.new(gui)
	local self = {}
	
	self.gui = gui
	self.plr = Players.LocalPlayer
	self.mouse = self.plr:GetMouse()
	self.cam = workspace.CurrentCamera
	
	self.I = {}
	self.I.folder = ReplicatedStorage:WaitForChild("InfectionMode",10000)

	self.I.values = self.I.folder.Values
	self.I.events = self.I.folder.Events
	self.I.modeV = self.I.values.Mode
	self.I.timerV = self.I.values.Timer
	self.I.descV = self.I.values.DescText
	self.I.titleV = self.I.values.TitleText
	self.I.amV = self.I.values.AMValue
	self.I.descEnabledV = self.I.values.DescEnabled
	self.I.titleEnabledV = self.I.values.TitleEnabled
	self.I.hTrackingEnabledV = self.I.values.HumanTrackingEnabled	
	self.I.trussesEnabledV = self.I.values.TrussesEnabled
	self.I.markersEnabledV = self.I.values.MarkersEnabled
	self.I.sewersDisabledV = self.I.values.SewersDisabled
	
	self.isVipServer = ReplicatedStorage.Values.IsVipServer.Value
	
	self.teams = {}
	self.teams.Survivors = Teams:WaitForChild("Survivors",1000)
	self.teams.Infected = Teams:WaitForChild("Infected",1000)
	
	self.uiSounds = self.gui.UISounds
	
	GUIHandler.new(self)
	CharacterHandler.new(self)
	
	gui.Enabled = true
	
	return setmetatable(self,MainHandler)
end

return MainHandler