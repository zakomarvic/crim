local TS = game:GetService("TweenService")
local Teams = game:GetService("Teams")

local TrackingHandler = {}
TrackingHandler.TrackInstances = {}

local function createBillboard()
	local b = Instance.new("BillboardGui")
	b.Size = UDim2.new(1,25,1,25)
	b.StudsOffset = Vector3.new(0,4.2,0)
	b.AlwaysOnTop = true
	b.MaxDistance = 1500
	b.Name = "SURVIVOR_GUI"

	local i = Instance.new("ImageLabel")
	i.Name = "ImageLabel"
	i.BackgroundTransparency = 1
	i.Size = UDim2.new(1,0,1,0)
	i.Image = "http://www.roblox.com/asset/?id=6302514520"
	i.ImageColor3 = Color3.fromRGB(255, 255, 0)
	i.ScaleType = Enum.ScaleType.Fit
	i.AnchorPoint = Vector2.new(0.5,0.5)
	i.Position = UDim2.new(0.5,0,0.5,0)
	i.Parent = b

	return b
end

function TrackingHandler:Mode(m)
	if m == TrackingHandler.M then
		return
	end
	
	TrackingHandler.M = m
	
	--print("toggled tracking",m)
	
	if m then
		for i,v in pairs(Teams.Survivors:GetPlayers()) do
			local char = v.Character
			
			local hum = char and char:FindFirstChild("Humanoid")
			local root = char and char:FindFirstChild("HumanoidRootPart")
			
			if root and hum and hum.Health > 0 then
				local bb = createBillboard()
				bb.PlayerToHideFrom = nil
				bb.Parent = root
				bb.Adornee = root
				table.insert(TrackingHandler.TrackInstances,bb)
				
				local function OnDeath()
					if bb and bb.Parent then
						bb.ImageLabel.Image = "http://www.roblox.com/asset/?id=74183613102292"
						bb.ImageLabel.ImageColor3 = Color3.fromRGB(255, 89, 89)
					end
				end
				
				hum.Died:Connect(function()
					OnDeath()
				end)
			end
		end
	else
		for i,v in pairs(TrackingHandler.TrackInstances) do
			if v and v.Parent then
				v:Destroy()
			end			
		end
		TrackingHandler.TrackInstances = {}
	end
end

return TrackingHandler