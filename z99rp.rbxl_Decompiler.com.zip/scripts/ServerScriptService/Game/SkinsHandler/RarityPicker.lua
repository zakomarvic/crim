return function(Rarities)
	local RNG = Random.new(); -- You could use math.random, this is just what I chose.
	local Counter = 0;
	for i, v in pairs(Rarities) do
		Counter += Rarities[i][2]
	end
	local Chosen = RNG:NextNumber(0, Counter);
	for i, v in pairs(Rarities) do
		Counter -= Rarities[i][2]
		if Chosen > Counter then
			return Rarities[i][1]
		end
	end
end