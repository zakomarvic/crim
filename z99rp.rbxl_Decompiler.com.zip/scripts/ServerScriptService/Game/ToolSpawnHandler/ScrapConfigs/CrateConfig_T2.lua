return { -- grey crates
	
	["MaxItems"] = 3;
	["ReRollRate"] = 40;
	
	["StoredAmmo_TakePerc"] = {0,50}; -- Up to this % of the stored ammo can be taken
	["Ammo_TakePerc"] = {0,0}; -- Up to this % of the ammo can be taken
	
	["AP_TakePerc"] = {5,45}; -- Up to this % of the armor AP can be taken
	
	["ItemsTable"] = {
		
		--["CursedDagger"] = {
		--	Chance = 1;
		--	Weight = 60;
		--	--IsGun = false;
		--	MaxDrops = 1;
		--};
		
		--//armor
		
		["HelmetA_1"] = {
			Chance = 8;
			Weight = 35;
			IsHelmet = true;
			MaxDrops = 1;
		};
		["VestA_1"] = {
			Chance = 8;
			Weight = 50;
			IsVest = true;
			MaxDrops = 1;
		};
		
		--------
		
		
		--// guns 
		["Sawn-Off"] = {
			Chance = 8;
			Weight = 55;
			IsGun = true;
			MaxDrops = 1;
		};	
		
		["Beretta"] = {
			Chance = 8;
			Weight = 55;
			IsGun = true;
			MaxDrops = 1;
		};	

		["G-17"] = {
			Chance = 8;
			Weight = 55;
			IsGun = true;
			MaxDrops = 1;
		};

		["TEC-9"] = {
			Chance = 8;
			Weight = 55;
			IsGun = true;
			MaxDrops = 1;
		};
		
		["M1911"] = {
			Chance = 7;
			Weight = 65;
			IsGun = true;
			MaxDrops = 1;
		};

		["Deagle"] = {
			Chance = 5;
			Weight = 65;
			IsGun = true;
			MaxDrops = 1;
		};

		["Magnum"] = {
			Chance = 5;
			Weight = 65;
			IsGun = true;
			MaxDrops = 1;
		};
		
		["FNP-45"] = {
			Chance = 4;
			Weight = 65;
			IsGun = true;
			MaxDrops = 1;
		};
		
		---

		["SKS"] = {
			Chance = 7;
			Weight = 65;
			IsGun = true;
			MaxDrops = 1;
		};
		
		---

		["Uzi"] = {
			Chance = 6;
			Weight = 65;
			IsGun = true;
			MaxDrops = 1;
		};

		
		["MAC-10"] = {
			Chance = 6;
			Weight = 65;
			IsGun = true;
			MaxDrops = 1;
		};
		
		["Ithaca-37"] = {
			Chance = 6;
			Weight = 85;
			IsGun = true;
			MaxDrops = 1;
		};
		
		["Super-Shorty"] = {
			Chance = 6;
			Weight = 85;
			IsGun = true;
			MaxDrops = 1;
		};
		
		----

		["MP7"] = {
			Chance = 5;
			Weight = 65;
			IsGun = true;
			MaxDrops = 1;
		};

		["G-18"] = {
			Chance = 5;
			Weight = 65;
			IsGun = true;
			MaxDrops = 1;
		};
		
		["Tommy"] = {
			Chance = 5;
			Weight = 85;
			IsGun = true;
			MaxDrops = 1;
		};
	
		
		["Uzi-S"] = {
			Chance = 3;
			Weight = 65;
			IsGun = true;
			MaxDrops = 1;
		};


		["MAC-10-S"] = {
			Chance = 3;
			Weight = 65;
			IsGun = true;
			MaxDrops = 1;
		};
		["Tommy-S"] = {
			Chance = 3;
			Weight = 85;
			IsGun = true;
			MaxDrops = 1;
		};
		
		
		["UMP-45"] = {
			Chance = 5;
			Weight = 85;
			IsGun = true;
			MaxDrops = 1;
		};
		
		["AKS-74U"] = {
			Chance = 3;
			Weight = 100;
			IsGun = true;
			MaxDrops = 1;
		};

		["Mare"] = {
			Chance = 2;
			Weight = 100;
			IsGun = true;
			MaxDrops = 1;
		};
		---------------------
		
		--v 83%
		--// melees
		
		["Fire-Axe"] = {
			Chance = 7;
			Weight = 45;
		};
		
		["Rambo"] = {
			Chance = 7;
			Weight = 35;
		};
		
		["Metal-Bat"] = {
			Chance = 7;
			Weight = 65;
		};
		
		["Machete"] = {
			Chance = 7;
			Weight = 45;
		};
		
		["Katana"] = {
			Chance = 7;
			Weight = 65;
		};
		
		["Sledgehammer"] = {
			Chance = 7;
			Weight = 65;
		};

		["Chainsaw"] = {
			Chance = 7;
			Weight = 65;
		};
		---------------------
		
		
		--// throwables
		
		["Molotov"] = {
			Chance = 6;
			Weight = 10;
		};
		["Smoke-Grenade"] = {
			Chance = 6;
			Weight = 10;
		};
		["Grenade"] = {
			Chance = 6;
			Weight = 25;
		};
		["C4"] = {
			Chance = 4;
			Weight = 30;
		};
		["Flashbang"] = {
			Chance = 6;
			Weight = 15;
		};
		["CS-Grenade"] = {
			Chance = 6;
			Weight = 15;
		};
		["Stun-Grenade"] = {
			Chance = 6;
			Weight = 15;
		};
		
		
		["FireworkLauncher"] = {
			Chance = 6 * 5;
			Weight = 1;
			IsGun = true;
			MaxDrops = 1;
		};
	};
}