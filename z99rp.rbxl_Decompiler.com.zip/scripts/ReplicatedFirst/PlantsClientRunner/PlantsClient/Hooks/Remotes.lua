-- CLIENT

local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
local character = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Objects"):WaitForChild("Character"))
local sessions = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Objects"):WaitForChild("Sessions"))
--
local Calls = {}
--
Calls["SessionAction"] = function(id: string, action: string, data: {any})
	local session = sessions.get(id)
	session:received(action, data)
end
--
Calls["BefriendRequest"] = function(data: {[string]: any})
	--
	local sid = data.sid
	local ses = sessions.get(sid)
	local notification = _G.NotificationsSystem.show({duration = 10, header = "Glory Request", message = data.who.." is requesting to glory you.", buttons = {{header = "Accept", id = "a"}, {header = "Decline", id = "d"}}})
	--
	notification.selected:Connect(function(bid) 
		ses:send("selected", bid) end)
	--
end
--
Calls["BefriendFinalize"] = function(data: {[string]: any})
	--
	local sid = data.sid
	local ses = sessions.get(sid)
	local notification = _G.NotificationsSystem.show({duration = 20, header = "Request Accepted", message = "Your glory request has been accepted, trigger it by clicking finalize.", buttons = {{header = "Finalize"}}})
	--
	notification.selected:Connect(function(bid) 
		ses:send("finalized") end)
	task.delay(20, function()
		if (ses.active) then ses:send("timedout") end end)
	--
end
--
Calls["UpdateCharacter"] = function(data)
	--
	local action = data.action
	local adata = data.data
	--
	local ochar = adata.character
	local ocharObj = character.getCharacterBy(ochar)
	if (ocharObj) then
		if (action == "ragdoll") then
			ocharObj:updateRagdoll(adata.state, true)
		elseif (action == "ragdollCFrames") then
			--
			local dict = {}
			for _, cf in ipairs(adata.cframes) do
				dict[cf.name] = cf.cframe
			end
			--
			ocharObj.temp.ragdollCFrames = dict
		end
	end
	--
end
--
Calls["SetTransparency"] = function(data)
	data[1].Transparency=data[2]
end
--
Calls["Tween"] = function(data)
	--
	local ins = data[1]
	local info = TweenInfo.new(data[2][1], data[2][2], data[2][3], data[2][4], data[2][5], data[2][6])
	local props = data[3]
	--
	game:GetService("TweenService"):Create(ins, info, props):Play()
end
--
Calls["PlaySound"] = function(data)
	framework.Gs.PlaySound(data[1], data[2], data[3])
end
--
Calls["LoadAnimations"] = function(animations)
	require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Scripts"):WaitForChild("AnimationsPreloader"))(animations)
end
--
Calls["OpenLootContainer"] = function(data)
	_G.LCS.openContainer(data.container, data.inventory)
end
--
Calls["CloseLootContainer"] = function(data)
	_G.LCS.closeContainer()
end
--
Calls["SetCF"] = function(data)
	--
	if data.Part and data.Part.Parent then
		data.Part.CFrame=data.CF
	end
	--
end
--
Calls["UpdateEmotesInventory"] = function(data)
	_G.EmotesSystem.emotesEquipped = data.equipped
	_G.EmotesSystem.emotesOwned = data.inventory
	_G.EmotesSystem.refresh()
end
--
Calls["UpdateReputation"] = function(data)
	local reputation = data.reputation
	_G.ReputationSystem.updateReputation(reputation)
end
--
Calls["AffectReputation"] = function(data)
	table.insert(_G.ReputationSystem.affects, data)
end
--
Calls["ChatBubble"] = function(data)
	game:GetService("TextChatService"):DisplayBubble(data[1], data[2])
end
--
Calls["VisualEffects"] = function(data)
	if (data.fx == "GivingGifts") then
		task.spawn(function() 
			--
			local vf = _G.GVF()
			local cc = _G.Create("ColorCorrectionEffect", "giftcc", game.Lighting)
			local fovins = _G.Create("NumberValue", "gift", vf.FOVs)
			local fov = (data.towards == true and -1) or 1
			--
			local inInfo = TweenInfo.new(0.25, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, 0, false, 0)
			local outInfo = TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, 0, false, 0)
			game:GetService("TweenService"):Create(fovins, inInfo, {Value = fov}):Play()
			game:GetService("TweenService"):Create(cc, inInfo, {Brightness = 0.05}):Play()
			task.wait(0.25)
			game:GetService("TweenService"):Create(fovins, inInfo, {Value = 0}):Play()
			game:GetService("TweenService"):Create(cc, inInfo, {Brightness = 0}):Play()
			task.wait(1)
			_G.SafeDestroy(cc)
			_G.SafeDestroy(fovins)
			--
		end)
	end
end
--
Calls["Effects"] = function(data)
	if (data.fx == "presents") and _G.GSettings and _G.GSettings.LiquidEffects and _G.ClientLoaded then
		local cf = data.cf
		local goo = require(game:GetService("ReplicatedStorage").PlantsStorage.Utilities.goo).new(cf, _G.Random(0.4, 0.6, 100), 5, data.vel, data.il)
		--
		if (goo and goo.assembly) then
			if (data) then
				if (data.ext.anchorIsStuck ~= nil) then
					local stuckpart = data.ext.anchorIsStuck[1]
					local offset = data.ext.anchorIsStuck[2]
					local apoint = goo.assembly.points[1]
					apoint.anchored = true
					apoint.stuckOn = stuckpart
					apoint.stuckOnOffset = offset
				end
			end
		end
		--
		goo = nil
	end
	--
	if (data.fx == "BloodScourge") then
		--
		local scourgeFX=game:GetService("ReplicatedStorage").Storage.Resonance.BloodScourge.Ring:Clone()
		scourgeFX.CFrame=data.CF
		scourgeFX.Parent=workspace.Debris
		--
		framework.Gs.PlaySound(game:GetService("ReplicatedStorage").Storage.Resonance.BloodScourge.Scourge,scourgeFX)
		--
		for i,v in pairs(scourgeFX.Attachment:GetChildren()) do
			v:Emit(1)
		end
		--
		game.Debris:AddItem(scourgeFX,3)
	end
end
--
Calls["OutGlorpie"] = function(data)
	local thing=data.thing
	local index=data.index
	if (thing:FindFirstChild("onexR") and thing.onexR:FindFirstChild("M6Rod") and thing.onexR.M6Rod:FindFirstChild("tip")) or (thing:FindFirstChild("twoxR") and thing.twoxR:FindFirstChild("M6Rod") and thing.twoxR.M6Rod:FindFirstChild("tip")) then
		--
		local M6DRod
		if thing:FindFirstChild("onexR") then
			M6DRod = thing.onexR.M6Rod
		elseif thing:FindFirstChild("twoxR") then
			M6DRod = thing.twoxR.M6Rod
		end
		--
		local cf = M6DRod.tip.WorldCFrame
		local vel = Vector3.new(0, 0, 0)
		local ext = {}
		-- Velocity

		if (data.GlorpVelocity~=nil) then
			local rx = framework.Gs.Random(data.GlorpVelocity[1][1], data.GlorpVelocity[1][2], 100)
			local ry = framework.Gs.Random(data.GlorpVelocity[2][1], data.GlorpVelocity[2][2], 100)
			local rz = framework.Gs.Random(data.GlorpVelocity[3][1], data.GlorpVelocity[3][2], 100)
			vel = Vector3.new(rx, ry, rz)
		else
			vel = Vector3.new(math.random(-1, 1), math.random(-1, 3), math.random(6, 10)) end
		vel = (cf.RightVector.Unit*vel.X) + (cf.UpVector.Unit*vel.Y) + (cf.LookVector.Unit*vel.Z)
		--
		local strngs = math.random(1,2)
		if ((index == 3 or math.random(1,10)<=4) and (M6DRod:FindFirstChild("color1") and strngs>0)) or data.GlorpAlwaysAnchored==true then
			strngs -= 1
			ext.anchorIsStuck = {M6DRod.color1, Vector3.new(0, 0, 0)}
		end
		--
		Calls["Effects"]({fx = "presents", cf = cf, vel = vel, il = {thing}, ext = ext})
		--
	end
end
--
Calls["Collar"] = function(daata)
	--
	local action=daata[1]
	local data=daata[2]
	--
	local Player=game.Players.LocalPlayer
	--
	local gHum
	--
	if Player.Character then
		gHum=Player.Character:FindFirstChildOfClass("Humanoid")
	end
	--
	if action=="Replicate" then
		--
		task.spawn(function()
			local pull = workspace.Gravity / (20.00611807 * 5) --We're on earth babyyy
			--
			local segments = 10
			local pull = workspace.Gravity / (20.00611807 * 5) --We're on earth babyyy
			local width = .1
			local attachment0 = data[1]
			local attachment1 = data[2]
			local LineSegments = {}
			local firstLineDrawn = false
			--
			local function DrawFirstLine(p1,p2,container)
				local distance = (p1-p2).magnitude
				local line = Instance.new("Part")
				line.Name = "LineSegment"
				line.BrickColor = BrickColor.new("Really black")
				line.Material = "SmoothPlastic"
				line.Transparency = 0
				line.Anchored = true
				line.CanCollide = false
				line.Shape = Enum.PartType.Cylinder
				line.TopSurface = Enum.SurfaceType.Smooth
				line.BottomSurface = Enum.SurfaceType.Smooth
				line.formFactor = Enum.FormFactor.Custom
				line.Size = Vector3.new(distance,width,width)
				line.CFrame = CFrame.new(p1,p2)*CFrame.new(0,0,-distance/2)*CFrame.Angles(0,math.rad(90),0)
				table.insert(LineSegments, line)
				line.Parent = container
			end
			--
			local function UpdateLine(p1, p2, i)
				local distance = (p1-p2).magnitude
				LineSegments[i].Size = Vector3.new(distance,width,width)
				LineSegments[i].CFrame = CFrame.new(p1,p2)*CFrame.new(0,0,-distance/2)*CFrame.Angles(0,math.rad(90),0)
			end
			--
			local function DrawCatenary(p1,p2,container)
				for i=1,segments do
					local x = ((((i-1)*2)/segments)-1)
					local x2 = (((i*2)/segments)-1)
					if firstLineDrawn then
						UpdateLine(
							p1+((p2-p1)/segments*(i-1))+Vector3.new(0,(((math.cosh(x)-1)/(math.cosh(1)-1))-1)*pull,0),
							p1+((p2-p1)/segments*i)+Vector3.new(0,(((math.cosh(x2)-1)/(math.cosh(1)-1))-1)*pull,0),
							i
						)
					else
						DrawFirstLine(
							p1+((p2-p1)/segments*(i-1))+Vector3.new(0,(((math.cosh(x)-1)/(math.cosh(1)-1))-1)*pull,0),
							p1+((p2-p1)/segments*i)+Vector3.new(0,(((math.cosh(x2)-1)/(math.cosh(1)-1))-1)*pull,0),
							container
						)
					end
				end
				firstLineDrawn = true
				--
				local p1 = attachment0.WorldPosition
				local p2 = attachment1.WorldPosition
			end
			--
			repeat
				game:GetService("RunService").Heartbeat:Wait()
				--
				DrawCatenary(attachment0.WorldPosition, attachment1.WorldPosition, workspace.Debris)
				--
			until (attachment0==nil or attachment0.Parent==nil or attachment1==nil or attachment1.Parent==nil)
			--
			for i,v in pairs(LineSegments) do
				v:Destroy()
			end
			--
		end)
	elseif action=="lock" then
		local Owner=data[1]
		if Player.Character and Player.Character:GetAttribute("Collared") and gHum and gHum.Parent then
			if Owner then
				task.spawn(function()
					--Player.Character:SetAttribute("Collared",true)
					--
					local maxRange = 15
					local area = 30
					--
					local function GetDistance()
						return (Player.Character.HumanoidRootPart.Position - Owner.HumanoidRootPart.Position).magnitude
					end
					--
					local function GetClosestAcceptedPoint()
						return Owner.HumanoidRootPart.Position + (Player.Character.HumanoidRootPart.Position - Owner.HumanoidRootPart.Position).unit * (maxRange / 4)
					end
					--
					local reachConnection
					--
					repeat
						game:GetService("RunService").Heartbeat:Wait()
						--
						pcall(function()
							if Owner.Parent and Player.Character.Parent and gHum.Parent then
								if not Player.Character.Parent:FindFirstChild("Gifting") and not Player.Character.Parent:FindFirstChild("ReceivingGifts") then
									if gHum.Sit then
										gHum.Jump=true
									end
									if GetDistance()>area then
										--
										Player.Character.HumanoidRootPart.CFrame = CFrame.new(GetClosestAcceptedPoint())
										--
										if reachConnection then
											reachConnection:Disconnect()
											reachConnection = nil
										end
									end
									--
									if GetDistance()>maxRange then
										--
										_G.Controls:Disable()
										--
										gHum:MoveTo(GetClosestAcceptedPoint())

										reachConnection = gHum.MoveToFinished:Connect(function(hasReached)
											_G.Controls:Enable()
											--
											if hasReached == false then
												Player.Character.HumanoidRootPart.CFrame = CFrame.new(GetClosestAcceptedPoint())
											end
											if reachConnection then
												reachConnection:Disconnect()
												reachConnection = nil
											end
										end)
									end
									--
								end
							end
						end)
						--
					until (Owner==nil or Owner.Parent==nil) or (Player.Character==nil or Player.Character.Parent==nil) or not Player.Character:GetAttribute("Collared")
					--
					_G.Controls:Enable()
					--
							--[[if Player.Character and Player.Character.Parent then
								Player.Character:SetAttribute("Collared",nil)
							end]]
					--
				end)
			end
		end
	end
end
--
Calls["RunModule"] = function(data)
	local module = data[1]
	require(module)(table.unpack(data[2]))
end
--
Calls["TransferModule"] = function(data)
	local module = require(data.module)
	local new = data.new
	--
	for newind, newval in pairs(new) do
		module[newind] = newval
	end
	--
end
--
Calls["HidePrompt"] = function(data)
	data.Prompt.Enabled=false
end
--
Calls["SmokeScreen"] = function(data)
	--
	data[1].Transparency = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0.9),
		NumberSequenceKeypoint.new(1, 1)
	})
	--
end
--
Calls["stopAllTracks"] = function(data)
	--
	for i,v in pairs(data[1]:GetPlayingAnimationTracks()) do
		local a = v.Animation
		if a.Name == data[2] and a.AnimationId == data[3] then
			v:Stop(0.2)
			break
		end
	end
	--
end
--
Calls["Spark"] = function(data)
	--
	local part=data.part
	--	local NewSparks = LightningSparks.new(pos,0.5,4,Color3.fromRGB(255, 200, 0),Color3.fromRGB(255, 170, 0),Vector3.new(math.random(-15,15),math.random(-15,15),math.random(-15,15)))
	local randomX=math.random(-2,2)
	local randomZ=math.random(-2,2)
	local randomY=math.random(-2,1)
	--
	local a1, a2 = Instance.new("Attachment",part),Instance.new("Attachment",part)
	--
	a1.WorldCFrame=part.CFrame+Vector3.new(randomX,randomY,randomZ)
	a2.WorldCFrame=part.CFrame+Vector3.new(-randomX,-randomY,-randomZ)
	--
	framework.services.TweenService:Create(a1,TweenInfo.new(0.05,Enum.EasingStyle.Sine,Enum.EasingDirection.Out,0,false,0),{WorldCFrame=part.CFrame+Vector3.new(randomX,randomY,randomZ)}):Play()
	framework.services.TweenService:Create(a2,TweenInfo.new(0.05,Enum.EasingStyle.Sine,Enum.EasingDirection.Out,0,false,0),{WorldCFrame=part.CFrame+Vector3.new(-randomX,-randomY,-randomZ)}):Play()
	--
	local NewBolt = _G.LightningBolt.new(a1, a2, 30)
	--
	NewBolt.PulseSpeed = 2
	NewBolt.PulseLength = 1
	NewBolt.FadeLength = 0.5
	NewBolt.MaxRadius = 2
	NewBolt.Thickness=0.2
	NewBolt.Frequency=.5
	NewBolt.Color = Color3.fromRGB(255, 250, 120)
	--
	game.Debris:AddItem(a1,3)
	game.Debris:AddItem(a2,3)
	--
end
--
Calls["Lighting"] = function(data)
	--
	local Speed=1
	--
	if data.Speed then
		Speed=data.Speed
	end
	--
	local Position=data.torso.Position
	--
	framework.Gs.PlaySound(game:GetService("ReplicatedStorage").Storage.Shifter.Strike,workspace,Speed)
	--
	local PreTransform=game:GetService("ReplicatedStorage").Storage.Shifter.PreTransform:Clone()
	PreTransform.Parent=workspace.Debris
	PreTransform.Position=Position
	--
	task.wait(0.5/Speed)
	--
	for i,v in pairs(PreTransform.Attachment:GetChildren()) do 
		if v:IsA("ParticleEmitter") then
			v.Enabled=true
		end
	end
	--
	local cc=Instance.new("ColorCorrectionEffect")
	cc.TintColor=Color3.fromRGB(255, 202, 117)
	cc.Brightness=-0.3
	cc.Saturation=-0.5
	--
	local be=Instance.new("BloomEffect")
	be.Intensity=0.6
	be.Size=50
	be.Threshold=1
	--
	cc.Parent=workspace.CurrentCamera
	be.Parent=workspace.CurrentCamera
	--
	local ccTween = framework.services.TweenService:Create(cc, TweenInfo.new(0.05, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0), {
		Brightness = 1.5,
	})
	ccTween:Play()
	--
	ccTween.Completed:wait()
	--z
	framework.services.TweenService:Create(cc, TweenInfo.new(0.55/Speed, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0), {
		Brightness = -0.3,
	}):Play()
	---
	task.wait(1.25/Speed)
	--
	for i,v in pairs(PreTransform.Attachment:GetChildren()) do 
		if v:IsA("ParticleEmitter") then
			v.Enabled=false
		end
	end
	game.Debris:AddItem(PreTransform,3)
	--
	local Transform=game:GetService("ReplicatedStorage").Storage.Shifter.Transform:Clone()
	Transform.Parent=workspace.Debris
	Transform.Position=Position
	--
	for i,v in pairs(Transform:GetDescendants()) do 
		if v:IsA("ParticleEmitter") or v:IsA("Beam") then
			v.Enabled=true
		end
	end
	--
	local ShiftSFX = framework.Gs.PlaySound(game:GetService("ReplicatedStorage").Storage.Shifter.Shift,workspace,Speed)
	--
	local config={
		Volume = 1;
		EmitterSize = 500;
		MaxDistance = 10000;	

		Shake = {
			MaxDist = 1000;
			Multi = 3;

			Offset1 = 0.5;
			Offset2 = 3.5;
		}
	}
	--
	game:GetService("ReplicatedStorage").Events2.MonitorSound2:Fire(ShiftSFX,config)
	--
	local ccTween2 = framework.services.TweenService:Create(cc, TweenInfo.new(0.4/Speed, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0), {
		Brightness = 0.7;
	})
	ccTween2:Play()
	ccTween2.Completed:wait()
	--
	task.wait(1.5/Speed)	
	--
	framework.services.TweenService:Create(cc,TweenInfo.new(2/Speed,Enum.EasingStyle.Linear,Enum.EasingDirection.Out,0,false,0),{Brightness=0,TintColor=Color3.fromRGB(255,255,255)}):Play()
	framework.services.TweenService:Create(be,TweenInfo.new(2/Speed,Enum.EasingStyle.Linear,Enum.EasingDirection.Out,0,false,0),{Size=0}):Play()
	--
	game.Debris:AddItem(be,2.1/Speed)
	game.Debris:AddItem(cc,2.1/Speed)
	--
	task.delay(1/Speed,function()
		--
		for i,v in pairs(Transform:GetDescendants()) do 
			if v:IsA("ParticleEmitter") or v:IsA("Beam") then
				v.Enabled=false
			end
		end
		--
		game.Debris:AddItem(Transform,3)
	end)
	--
end
--
Calls["SetLookAngles"] = function(data)
	game:GetService("ReplicatedStorage").PlantsStorage.Hooks.remote:Fire(data[1],data[2],data[3])
end
--
Calls["HeadBubble"] = function(data)
	require(game:GetService("ReplicatedStorage").Modules.HeadExplode).AkiraKill(data)
	_G.PlaySound(game:GetService("ReplicatedStorage").Storage.Resonance.Corruption.Wipe,data.char.Torso)
end
--
Calls["UpdateJoints"] = function(data)
	--
	for i,v in pairs(data[1]) do
		if v:IsA("Motor6D") then
			v.Enabled=data[2]
		end
	end
	--
end
--
Calls["AnchorParts"] = function(data)
	--
	for i,v in pairs(data[1]) do
		if v:IsA("BasePart") then
			v.Anchored=data[2]
		end
	end
	--
end
--
Calls["DytooMorph"] = function(data)
	local morpher = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Evil"):WaitForChild("theEvilScript"))
	morpher.dytoo(table.unpack(data))
end
--
Calls["LoadMorph"] = function(data)
	local morpher = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Evil"):WaitForChild("theEvilScript"))
	morpher.apply(table.unpack(data))
end
--
Calls["setClientAttribute"] = function(data)
	data[1]:SetAttribute(data[2],data[3])
end
--
Calls["WindUpHit"] = function(data)
	require(game:GetService("ReplicatedStorage").Modules.WindUpHit)(data)
end
--
Calls["StaySafe"] = function(data)
	game:GetService("ReplicatedStorage").Events2.ClientWarn:Fire({"STAY SAFE.",1,Color3.fromRGB(245, 110, 255),Color3.new(0,0,0),"lost"})
	local STOPGui=game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage").Assets.Storage.STOPGui:Clone()
	STOPGui.Parent=game.Players.LocalPlayer.PlayerGui
	STOPGui.buzzer:Play()
	framework.services.TweenService:Create(STOPGui.ImageLabel,TweenInfo.new(2,Enum.EasingStyle.Sine,Enum.EasingDirection.Out,0,false,1),{ImageTransparency=1}):Play()
	game.Debris:AddItem(STOPGui,4)
end
--
return Calls