local AC = {}

local RunService = game:GetService("RunService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")
local CollectionService = game:GetService("CollectionService")
local PhysicsService = game:GetService("PhysicsService")

local Config = require(script.Parent.Parent.Modules.Config)

local Character = script.TargetCharacter.Value
local Player = Players:GetPlayerFromCharacter(Character)
local RootPart = Character:FindFirstChild("HumanoidRootPart")
local RootJoint = RootPart and RootPart:FindFirstChild("RootJoint")
local Humanoid = Character:FindFirstChildWhichIsA("Humanoid")
local torso,Head

local DiagnosticsFolder = Character:FindFirstChild("MovementAnticheat")
local OnPunishment = DiagnosticsFolder and DiagnosticsFolder.OnPunishment or nil
local MapArea = workspace:FindFirstChild("Filter") and workspace.Filter:FindFirstChild("MapArea")

if not MapArea then
	warn("MovementAnticheat: No MapArea part found!")
end

local startTick = tick()

--local function _StartCheck()
--	return (RootPart.Position - Vector3.new(0,0,0)).Magnitude >= 15 or tick() - startTick >= 5
--end

--if not _StartCheck() then
--	repeat wait(0.1) until _StartCheck()
--end

local LastCFrame = RootPart and RootPart.CFrame
local LastGoodCFrame = RootPart and RootPart.CFrame
local LastGroundedAltitude = RootPart and RootPart.CFrame.Position.Y
local SpeedHeat = 0 -- If any of these hit 1, the player is punished.
local FlightHeat = 0 -- As an exception, players must fall fast enough to avoid triggering FlightHeat.
local VelocityHeat = 0
local IsBeingPunished = false

AC.IsBeingPunished = false
AC.PunishCount = 0
AC.Studs = {}

local nWOB

local running = true

local loops = 0
local lastTick = tick()

local first = false
local humanoidSeated = false

local con1,con2,con3,con4,con5,con6

local nPart = Instance.new("Part")
nPart.Name = Character.Name .. "'s ting"
nPart.Anchored = true
nPart.Size = Vector3.new(0,0,0)
nPart.Massless = true
nPart.Transparency = 1
nPart.CanCollide = false

---
local IgnoreList = {}
IgnoreList = {Character;
	workspace.Filter.Spawns;
	workspace.Filter.ToolSpawns;
	workspace.Filter.WaterCurrents;
	workspace.Filter.SpawnedPiles;
	workspace.Filter.SpawnedBread;
	workspace.Filter.CombatZones;
	workspace.Filter.SpawnedTools;
	workspace.Map.Shopz;
	workspace.Filter.MapArea;
}

for _,v in pairs(CollectionService:GetTagged("UselessObjects")) do
	table.insert(IgnoreList,v)
end
---

local function BeamChar()
	warn("lol,",Player.Name,"attempted to remove their humanoid! what an idiot, kick time")

	pcall(function()
		game.ServerStorage.Events3.qUE_exPOTLOG:Fire("ZKLFXG890ZDFGJKN43SU8IOG",Player.Name,"Server tamper: KICKED, no Humanoid found",2)
	end)

	Player:Kick("AE: RED LIGHT")
end

local function IsPartEffectivelyAnchored(object)
	assert(typeof(object) == "Instance" and object:IsA("BasePart"))

	if object.Anchored then
		return true
	end
	local parts = object:GetConnectedParts(true)
	for i, part in ipairs(parts) do
		if part.Anchored then
			return true
		end
	end
	return false
end

local function Debug(m)
	if Config.DebugEnabled then
		warn(m)
	end
end

local function CreateNWOB()
	local b = Instance.new("BoolValue")
	b.Name = "NWO"
	b.Parent = Humanoid	
end

local function FindPartBeingStoodOn(nearbyParts)
	local function raycast(p1, p2, dist)
		local direction = p2 - p1
		if direction.Magnitude > (dist or 7) then
			direction = direction.Unit * (dist or 7)
		end
		local ray = Ray.new(p1, direction)
		local part, position, normal = workspace:FindPartOnRayWithWhitelist(ray, nearbyParts, false)
		local pass = part ~= nil and (normal.Y > 0 or part:IsA("TrussPart"))
		return pass, part, position, normal
	end

	-- Do scatter raycasts
	local scatterOffsets = {
		Vector3.new(0, -6, 0),
		Vector3.new(2, -6, 0),
		Vector3.new(-2, -6, 0),
		Vector3.new(0, -6, 2),
		Vector3.new(0, -6, -2),
	}

	for i, offset in ipairs(scatterOffsets) do
		local pass, part2, position, normal = raycast(RootPart.Position + Vector3.new(0,1,0), RootPart.Position + Vector3.new(0,1,0) + offset, 13)
		if pass then
			return part2
		end
	end

	-- Do special raycasts in case we missed.
	for i, part1 in ipairs(nearbyParts) do
		-- Raycast straight to object's center.
		local pass, part2, position, normal = raycast(RootPart.Position, part1.Position)
		if pass then
			return part2
		end

		-- Raycast sideways, then downwards.
		pass, part2, position, normal =
			raycast(RootPart.Position, Vector3.new(part1.Position.X, RootPart.Position.Y, part1.Position.Z), 7) -- First attempt.
		if pass then
			return part2
		end
		pass, part2, position, normal =
			raycast(position, position + Vector3.new(0, -5, 0)) -- Second attempt.
		if pass then
			return part2
		end

		-- Raycast on each XYZ plane where two others are locked to the object's center.
		for _, d in ipairs({"X", "Y", "Z"}) do
			-- Find the closest Vector3 aligned on the "d" axis.
			local cFrame = part1.CFrame:ToObjectSpace(RootPart.CFrame)
			if cFrame[d] < part1.Size[d] / 2 and cFrame[d] > -part1.Size[d] / 2 then
				local intermediateVector = {X = 0, Y = 0, Z = 0}
				intermediateVector[d] = cFrame[d]
				local intermediateCFrame = CFrame.new(intermediateVector.X, intermediateVector.Y, intermediateVector.Z)
				local targetVector = part1.CFrame:ToWorldSpace(intermediateCFrame).Position

				-- Do a raycast.
				pass, part2, position, normal =
					raycast(RootPart.Position, targetVector)
				if pass then
					return part2
				end
			end
		end
	end

	-- Are we inside terrain water?
	local tRegion = Region3.new(RootPart.Position - Vector3.new(1, 1, 1), RootPart.Position + Vector3.new(1, 1, 1)):ExpandToGrid(4)
	local td1, td2 = workspace.Terrain:ReadVoxels(tRegion, 4)
	for x, xt in ipairs(td1) do
		for y, yt in ipairs(xt) do
			for z, cell in ipairs(yt) do
				if cell == Enum.Material.Water then
					return workspace.Terrain
				end
			end
		end
	end

	return nil
end

local function Reset()
	LastGoodCFrame = RootPart.CFrame
	LastCFrame = RootPart.CFrame
	LastGroundedAltitude = RootPart.CFrame.Position.Y
	SpeedHeat = 0
	FlightHeat = 0
	VelocityHeat = 0
end

local function ResetCharacter()
	RootPart.CFrame = LastGoodCFrame
	coroutine.wrap(function()
		for i = 1,3 do
			RootPart.CFrame = LastGoodCFrame
			if _G.RagdollCheck(Character) then
				for _,v in pairs(Character:GetChildren()) do
					if v ~=  RootPart and v:IsA("BasePart") and not (v:FindFirstChild("Broken")) then
						v.CFrame = LastGoodCFrame
						v.Velocity = Vector3.new()
					end
				end
			end
			RootPart.Velocity = Vector3.new()
			RunService.Heartbeat:Wait()
		end
	end)()
	RootPart.Velocity = Vector3.new(0, 0, 0)
	RootPart.RotVelocity = Vector3.new(0, 0, 0)
	Humanoid:ChangeState(Enum.HumanoidStateType.Running)
end

local function Punish(reason,details,bypass,insta)
	if not IsBeingPunished then
		IsBeingPunished = true
		AC.IsBeingPunished = true

		local duration = Config.PunishmentDuration
		local didKill = false

		AC.PunishCount = AC.PunishCount + 1
		delay(45,function()
			AC.PunishCount = math.max(AC.PunishCount - 1,0)
		end)

		Player:SetAttribute("_LRTF",math.floor(tick()))

		if AC.PunishCount >= 5 or insta then
			if Humanoid and Humanoid.Parent then
				Humanoid.Health = -100
			end

			didKill = true

			local bruh = " (x" .. tostring(AC.PunishCount) .. ")"
			local msg = "[Movement: log]" .. " | Reset for possible " .. reason .. bruh .. " | " .. details or ""

			pcall(function()
				game.ServerStorage.Events3.qUE_exPOTLOG:Fire("ZKLFXG890ZDFGJKN43SU8IOG",Player.Name,msg,2)
			end)

			--if didKill then
			--	pcall(function()
			--		game.ServerStorage.Events3.qUE_exPOTLOG:Fire("ZKLFXG890ZDFGJKN43SU8IOG",Player.Name,"[Movement: log] | Reset for triggering system multiple times",2)
			--	end)
			--end
		elseif AC.PunishCount > 2 and MapArea and RootPart and RootPart.Parent and (RootPart.CFrame.p - MapArea.CFrame.p).Magnitude > 3000 then
			if Humanoid and Humanoid.Parent then
				Humanoid.Health = -100
			end

			didKill = true

			warn(string.format("[MovementAnticheat] Killed %s for flinging out the map.", Player.Name))

			pcall(function()
				game.ServerStorage.Events3.qUE_exPOTLOG:Fire("ZKLFXG890ZDFGJKN43SU8IOG",Player.Name,"[Movement: log] | Reset for flinging out of map bounds (" .. tostring((RootPart.CFrame.p - MapArea.CFrame.p).Magnitude) .. " studs)",2)
			end)
		end

		--if not first then
		--	first = true
		--	return
		--end

		warn(string.format("[MovementAnticheat] Punishing %s for %s. (Count: %s)", Player.Name, reason,tostring(AC.PunishCount)))
		--		if OnPunishment then
		--			OnPunishment:FireClient(Player, reason)
		--		end

		--AC.PunishCount > 1 
		if Config.PunishmentDuration > 0 and RootPart:CanSetNetworkOwnership() == true then
			if RootPart and RootPart.Parent and not RootPart:GetAttribute("NoNetworkOwnerSet") then
				RootPart:SetNetworkOwner(nil)
			end
			if not (nWOB and nWOB.Parent) then
				nWOB = CreateNWOB()
			end
		end
		if AC.PunishCount >= 3 or didKill then
			duration = Config.PunishmentDuration2
			--if tick() - script.JoinTime.Value <= (Config.MinJoinTime * 0.75) then
			local tab = {
				Title = "Anti Exploit";
				Text = didKill and "You were reset due to constant activation of the system." or "You were rectified due to possible movement cheats";
				--Icon = "";
				Duration = 5;
			}
			ReplicatedStorage.Events.Notification:FireClient(Player,tab,"lost")	
			--end
		end

		if con4 then
			con4:Disconnect()
			con4 = nil
		end

		pcall(ResetCharacter)

		con4 = RootPart:GetPropertyChangedSignal("CFrame"):Connect(Reset)

		coroutine.wrap(function()
			--spawn(function()
			if duration > 0 then
				wait(duration)

				--warn(string.format("[MovementAnticheat] %s's punishment ended.", Player.Name))

				if con4 then
					con4:Disconnect()
					con4 = nil
				end

				if Humanoid and Humanoid.Parent and Humanoid.Health > 0 then
					pcall(Reset)

					IsBeingPunished = false
					AC.IsBeingPunished = false

					if RootPart:CanSetNetworkOwnership() == true then
						if not RootPart:GetAttribute("NoNetworkOwnerSet") then
							RootPart:SetNetworkOwner(Player)
						end
						if nWOB and nWOB.Parent then
							nWOB:Destroy()
						end
						nWOB = nil
					end
				end
			end
			--end)
		end)()
	end
end

function AC.Check(deltaTime)
	RootPart = (Character and Character:FindFirstChild("HumanoidRootPart"))
	torso = (Character and (Character:FindFirstChild("Torso") or Character:FindFirstChild("UpperTorso")))
	Head = (Character and Character:FindFirstChild("Head"))
	RootJoint = (RootPart and RootPart:FindFirstChild("RootJoint")) or Character:GetAttribute("Shifter")==true
	Humanoid = (Character and Character:FindFirstChildWhichIsA("Humanoid"))

	if not RootPart or not Humanoid or not torso or not Head or not RootJoint then
		if Humanoid and Humanoid.Parent then
			print("Wyd")
			Humanoid.Health = 0
		end

		return false,"lost char components","",true,true
	end

	local p1 = LastCFrame.Position
	local p2 = RootPart.CFrame.Position

	if p2.Y < (workspace.FallenPartsDestroyHeight - 100) and Humanoid.Health > 0 then
		if Humanoid and Humanoid.Parent then
			Humanoid.Health = 0
		end

		pcall(function()
			game.ServerStorage.Events3.qUE_exPOTLOG:Fire("ZKLFXG890ZDFGJKN43SU8IOG",Player.Name,"[Movement: log] | Possible tp bypass attempt | " .. tostring(p2.Y),2)
		end)

		return false,"below map limit","",true,true
	end

	if humanoidSeated or RootPart.Anchored 
		--or RootPart:GetNetworkOwner() ~= Player 
	then
		LastCFrame = RootPart.CFrame
		LastGoodCFrame = RootPart.CFrame
		return true,false
	end

	local legalFlying =	 Character:GetAttribute("HUCMV") or	 (Config.AllowAdonisFlight and RootPart:FindFirstChild("ADONIS_FLIGHT")) or Character:GetAttribute("FreeFly") or Character:GetAttribute("Shifter") or Character:GetAttribute("UnShifting")
	local legalTeleporting =		(_G.gTag and _G.gTag(Humanoid,"CTP")) or Character:GetAttribute("Shifter") or Character:GetAttribute("Collared") or Character:GetAttribute("UnShifting")
	local justRespawned = 		(_G.gTag and _G.gTag(Player,"RE"))
	local legalRagdolled = 		(_G.RagdollCheck and _G.RagdollCheck(Character)) or false

--[[	if not legalTeleporting and tick() - startTick < 3 and Player.RespawnLocation and (RootPart.CFrame.p - Player.RespawnLocation.CFrame.p).Magnitude > math.max(Player.RespawnLocation.Size.Magnitude * 2,100) then
		LastGoodCFrame = Player.RespawnLocation.CFrame + Vector3.new(0,1,0)
		return false,"speeding/teleporting","-"
	end]]

	if tick() - lastTick > deltaTime * 2 then 
		LastCFrame = RootPart.CFrame
		LastGoodCFrame = RootPart.CFrame

		lastTick = tick()
		return true
	else
		lastTick = tick()
	end

	local vf = _G.GVF and _G.GVF(Character.Name)

	if vf and vf.Currents:FindFirstChild("IGZNFD") then
		LastCFrame = RootPart.CFrame
		LastGoodCFrame = RootPart.CFrame
		return true,false
	end

	local legalGrabbed = vf and vf.Grabbed.Value

	local mightBeCheating = false

	local nearbyPartsRaw = workspace:FindPartsInRegion3WithIgnoreList(
		Region3.new(
			p2 - Vector3.new(Config.CheckRadius, Config.CheckRadius, Config.CheckRadius),
			p2 + Vector3.new(Config.CheckRadius, Config.CheckRadius, Config.CheckRadius)),
		IgnoreList,
		300)
	local nearbyParts = {workspace.Terrain}
	for i, part in ipairs(nearbyPartsRaw) do
		if part.CanCollide then
			table.insert(nearbyParts, part)
		end
	end
	-- Curtail no-clipping.

	--				--	local noClipList = {}
	--				--	for i, part in ipairs(nearbyParts) do -- Make a conditioned copy.
	--				--		local size = part.Size
	--				--		if part.CanCollide and (not Config.AllowNoclippingThroughPhysicsObjects or IsPartEffectivelyAnchored(part))
	--				--			and size.X > Config.NoclipThicknessTolerance and size.Y > Config.NoclipThicknessTolerance and size.Z > Config.NoclipThicknessTolerance then
	--				--			
	--				--			table.insert(noClipList, part)
	--				--		end
	--				--	end
	--				--	do
	--				--		if not legalFlying then
	--				--			local ray = Ray.new(p1, p2 - p1)
	--				--			local part, position = workspace:FindPartOnRayWithWhitelist(ray, noClipList, true)
	--				--			
	--				--			if part ~= nil then
	--				--				Punish("no-clipping")
	--				--			end
	--				--		end
	--				--	end

	--[[if Config.NoClipEnabled and (p1 - p2).Magnitude > 0.1 and not (legalFlying or legalTeleporting or legalGrabbed) then
		nPart.CFrame = RootPart.CFrame
		nPart.Parent = workspace.Debris
		if nPart:CanSetNetworkOwnership() then
			nPart:SetNetworkOwner(nil)
		end

		local function GetTouchingParts(part)
			local connection = part.Touched:Connect(function() end)
			local results = part:GetTouchingParts()
			connection:Disconnect()
			return results
		end

		local list = GetTouchingParts(nPart)

		local function get()
			for _,v in pairs(list) do
				local collide2 = true

				if v.CanCollide then
					local id = PhysicsService:GetCollisionGroupName(v.CollisionGroupId)
					collide2 = PhysicsService:CollisionGroupsAreCollidable("Character", id)
				end

				if v.CanCollide and collide2 and v.Size.Magnitude >= 5 and v.Name ~= "DoorBase" then
					return v
				end
			end
		end
		local Hit = get()
		if Hit then
			nPart.Parent = nil
			return false,"no-clipping","-"
		end

		nPart.Parent = nil
	end]]

	-- Curtail speed and teleporting.
	local horizontalMagnitude = math.sqrt((p2.X - p1.X) ^ 2 + (p2.Z - p1.Z) ^ 2)
	local fastestNearbyObjectSpeed = 0
	for i, part in ipairs(nearbyParts) do -- Account for other objects that might be making the player fast.
		fastestNearbyObjectSpeed = math.max(fastestNearbyObjectSpeed, part.Velocity.Magnitude)
	end

	local maxSpeed = Config.MaxWalkSpeed
	local flightTimeSpan = Config.TimeSpan
	local flyMulti = 1

	if legalRagdolled then
		maxSpeed = maxSpeed * 2
		--flightTimeSpan = flightTimeSpan * 2
		flyMulti = 2
	elseif _G.DownedCheck and _G.DownedCheck(Character) then
		maxSpeed = maxSpeed / 3
	end

	local jumpAdd = 0

	if vf and vf:FindFirstChild("Currents") then
		for _,v in pairs(vf.Currents:GetChildren()) do
			if string.sub(v.Name,0,3) == "SD_" then
				maxSpeed = maxSpeed - math.min(0,v.Value * 1.2)
			elseif string.sub(v.Name,0,7) == "SRV_SD_" then
				maxSpeed = maxSpeed - math.min(0,v.Value * 1.2)
			elseif string.sub(v.Name,0,3) == "SP_" then
				maxSpeed = maxSpeed * math.max(v.Value * 1.2,1)
			elseif string.sub(v.Name,0,7) == "S_SWST_" then
				maxSpeed = maxSpeed - math.min(0,v.Value * 1.2)
			elseif string.sub(v.Name,0,3) == "JR_" then
				if v.Value < 0 then
					jumpAdd += -v.Value
				end

				flyMulti = flyMulti * math.max(v.Value * 1.5,1)
			end
		end	
	end

	maxSpeed = maxSpeed * 2
	local toleratedMaxSpeed = (fastestNearbyObjectSpeed + maxSpeed) * Config.SpeedToleranceRatio

	--print(horizontalMagnitude,toleratedMaxSpeed)

	if not (legalFlying or legalTeleporting or justRespawned) and not legalGrabbed then
		SpeedHeat = math.max(0, SpeedHeat + (horizontalMagnitude / toleratedMaxSpeed - deltaTime) / flightTimeSpan)
		if SpeedHeat > 0.3 then
			mightBeCheating = true
			if SpeedHeat >= 1 then
				local dist = math.abs(math.floor(p2.Magnitude - p1.Magnitude))
				return false,"speeding/teleporting",tostring(dist) .. " studs"
			end
		end

		if SpeedHeat > 0.3 then
			Debug(Player.Name .. " | Speed | " .. tostring(SpeedHeat).. "/" .. tostring(maxSpeed) .. " | " .. math.floor(horizontalMagnitude) .. "/" .. math.floor(toleratedMaxSpeed)) 
		end
	else
		SpeedHeat = 0
	end

	if not (legalFlying or legalTeleporting or legalGrabbed) then
		if (p2.Y < -170 and p1.Y > -30) or (p1.Y - p2.Y < -50) then
			local dist = math.floor(p2.Y - p1.Y)
			return false,"speeding/teleporting-2",tostring(dist) .. " studs"
		end
	end
	-- Curtail flying.

	local isNearObjects = (FindPartBeingStoodOn(nearbyParts) ~= nil)
	if not isNearObjects and not (legalFlying or legalTeleporting or justRespawned or RootPart.Anchored) and not legalGrabbed then
		mightBeCheating = true
		FlightHeat = math.max(0, FlightHeat + ((p2.Y - p1.Y) / (Config.FlightHeatCooldownRequiredFallSpeed * flyMulti) + deltaTime) / (Config.MaxFlyingDuration * flyMulti))

		-- Figure out a maximum jump height
		local jumpHeightTolerance

		local maxPower = Config.MaxJumpPower
		if legalTeleporting then
			maxPower = maxPower * 3
		end

		if Humanoid.UseJumpPower then
			-- The '* 1.1' part is in case the humanoid has slight jumpieness from Roblox's weird physics.
			jumpHeightTolerance = (maxPower ^ 2) / (2 * workspace.Gravity) * 1.1
		else
			jumpHeightTolerance = Humanoid.JumpHeight * 1.1
		end

		if legalRagdolled then
			jumpHeightTolerance = jumpHeightTolerance * 12
		end

		if jumpAdd >= 1 then
			jumpHeightTolerance  = jumpHeightTolerance * math.max((jumpAdd * 0.1),1)
		end

		local studs = math.abs(math.floor(p2.Y - p1.Y))

		if FlightHeat / maxSpeed > 0.3 then
			Debug(Player.Name .. " | Fly | " .. tostring(FlightHeat).. "/" .. tostring(maxSpeed))
		end

		--print(FlightHeat,p2.Y, LastGroundedAltitude + jumpHeightTolerance)

		if (studs >= 1 and FlightHeat >= 1) or p2.Y > LastGroundedAltitude + jumpHeightTolerance then
			return false,"flying", studs .. " studs"
		end
	else
		FlightHeat = 0
		LastGroundedAltitude = p2.Y
	end

	-- Curtail excessive velocity cheats. (Note: Only accounts for RotVelocity. May change in the future.)
	VelocityHeat = math.max(0, VelocityHeat + (RootPart.RotVelocity.Magnitude / Config.RotVelocityTolerance - deltaTime) / flightTimeSpan)

	if not legalGrabbed then
		if VelocityHeat > 0.3 then
			Debug(Player.Name .. " | VelocityHeat | " .. tostring(VelocityHeat).. "/" .. tostring(1))
		end
		if VelocityHeat > 0.3 then
			mightBeCheating = true

			if VelocityHeat >= 1 then
				return false,"fling-exploits",tostring(math.floor(RootPart.RotVelocity.Magnitude)) .. " rotvel"
			end
		end	
	end

	if not dead and torso and (RootPart.CFrame.p - torso.CFrame.p).Magnitude > 10 and not legalRagdolled then
		return false,"torso separation",tostring(math.floor((RootPart.CFrame.p - torso.CFrame.p).Magnitude)) .. "s"
	end

	if not dead and Head and (RootPart.CFrame.p - Head.CFrame.p).Magnitude > 10 and not legalRagdolled then
		return false,"head separation",tostring(math.floor((RootPart.CFrame.p - Head.CFrame.p).Magnitude)) .. "s"
	end

	return true,mightBeCheating
end

function AC.MainLoop(deltaTime)
	if not running then script:Destroy() return end

	loops = loops + 1

	if IsBeingPunished then
		if not RootPart:GetAttribute("NoNetworkOwnerSet") and RootPart:GetNetworkOwner() == Player or RootPart:GetNetworkOwnershipAuto() then
			-- How did the player get control back?! Take it away again!
			if RootPart:CanSetNetworkOwnership() == true then
				RootPart:SetNetworkOwner(nil)
				if not (nWOB and nWOB.Parent) then
					nWOB = CreateNWOB()
				end
			end
			ResetCharacter()
			warn(string.format("[MovementAnticheat] %s somehow got physics control back during punishment. Taking it away again.", Player.Name))
		else
			LastCFrame = RootPart.CFrame
			LastGoodCFrame = RootPart.CFrame
		end
		return
			--elseif RootPart:CanSetNetworkOwnership() and RootPart:GetNetworkOwner() ~= Player then
			--	return
	end

	if tick() - lastTick > deltaTime * 2 then 
		LastCFrame = RootPart.CFrame
		LastGoodCFrame = RootPart.CFrame

		lastTick = tick()
		return
	else
		lastTick = tick()
	end


	local mightBeCheating

	if not Character:FindFirstChild("KJFF") and not Character:GetAttribute("Shifter") then
		local res1,res2,res3,res4,res5 = AC.Check(deltaTime)
		if res1 then
			mightBeCheating = res2
		else
			if Humanoid.Health > 0 then
				Punish(res2,res3,res4,res5)
			end
			mightBeCheating = true
		end
	end

	-- Record last position.
	LastCFrame = RootPart.CFrame
	if not mightBeCheating then
		LastGoodCFrame = RootPart.CFrame
	end
end

function AC:Disconnect()
	if not running then return end
	running = false

	con1:Disconnect()
	con2:Disconnect()
	con3:Disconnect()
	if con4 then
		con4:Disconnect()
	end
	con5:Disconnect()
	con6:Disconnect()

	script:Destroy()
end

if not Humanoid then
	BeamChar()
end

local function onDeath()
	dead = true

	local function setcg(p)
		if p and p.Parent then
			p.CollisionGroupId = PhysicsService:GetCollisionGroupId("NoCharCollide")
		end
	end

	setcg(RootPart)
	setcg(torso)
	setcg(Head)

	spawn(function()
		while running do
			if (RootPart and RootPart.Parent and RootPart.RotVelocity.Magnitude > 500) or (torso and torso.Parent and torso.RotVelocity.Magnitude > 500) then
				if RootPart and RootPart.Parent and RootPart:CanSetNetworkOwnership() and not RootPart:GetAttribute("NoNetworkOwnerSet") then
					RootPart:SetNetworkOwner(nil)
				end
				if torso and torso.Parent and torso:CanSetNetworkOwnership() and not torso:GetAttribute("NoNetworkOwnerSet") then
					torso:SetNetworkOwner(nil)
				end
				break
			end

			wait(0.5)
		end
	end)
end

con1 = Humanoid.Died:Connect(onDeath)

if Humanoid.Health <=0 then
	onDeath()
end

-- Prevent potential noanticheat cheats.

con2 = Character.AncestryChanged:Connect(function(_,parent)
	if not parent then
		AC:Disconnect()
	end
end)

local n = 0

con3 = Humanoid.AncestryChanged:Connect(function(_,parent)
	local ting = false
	local done = false

	if game:IsAncestorOf(Character) then
		if Character.PrimaryPart and Character:IsAncestorOf(Character.PrimaryPart) then
			if not parent or not game:IsAncestorOf(Humanoid) then
				ting = true
				-- If the humanoid was :Destroyed() from the server, this check will not fire
				-- If the humanoid was set with .Parent = nil (which is still possible) or the humanoid was :Destroyed() from the client, this will fire and the humanoid will be replaced
				-- This might interfere with server code that happens to set the humanoid's parent to nil and then somehow is effected by the humanoid actually not being there
				-- That case is unlikely, and would suggest bad code if it causes some sort of error (But, that's what the enabled switch is for anyway)

				if n > 2 then
					BeamChar()
					return
				end

				pcall(function()
					game.ServerStorage.Events3.qUE_exPOTLOG:Fire("ZKLFXG890ZDFGJKN43SU8IOG",Player.Name,"[Movement: log] | Possible attempted removal of Humanoid",2)
				end)

				local s,e = pcall(function()
					Humanoid:WaitForChild("\0", 1e-6) -- Hacky way to yield for a very very tiny amount of time
					Humanoid.Parent = Character
					done = true

					n += 1
					delay(30,function()
						n -= 1
					end)
				end)
				if not s then
					warn(e)
				end
			end
		end
	end

	if ting and not done then
		BeamChar()
	end
end)

local stillConnected = setmetatable({}, {__mode="kv"})
con5 = Character.ChildAdded:Connect(function(child)
	--if child:IsA("Humanoid") then
	--	trackHumanoid()
	--end

	if child:IsA("BackpackItem") then
		if not stillConnected[child] then
			local connection
			connection = child.AncestryChanged:Connect(function(_, parent)
				-- Yeah, AncestryChanged fires after ChildAdded... Makes sense to me!
				if parent == Character then
					return
				end

				if parent == workspace then
					-- Tool is being dropped
					--if Anticheat.ChecksEnabled.InvalidDrop then
					-- If the tool can't be dropped and it wasn't dropped from the server
					if not child.CanBeDropped then
						-- Prevent the drop
						child:WaitForChild("\0", 1e-6) -- Hacky way to yield for a very very tiny amount of time
						child.Parent = Player:FindFirstChildWhichIsA("Backpack") or Instance.new("Backpack", Player)
					end
					--end
				elseif not parent then
					--if Anticheat.ChecksEnabled.ToolDeletion then
					-- Stop the tool from being deleted
					-- Will fail if done on the server via :Destroy()
					pcall(function()
						child:WaitForChild("\0", 1e-6) -- Hacky way to yield for a very very tiny amount of time
						child.Parent = Player:FindFirstChildWhichIsA("Backpack") or Instance.new("Backpack", Player)
					end)
					--end
				else
					stillConnected[child] = nil
					connection:Disconnect()
					connection = nil
				end
			end)
			stillConnected[child] = connection
		end

		--if Anticheat.ChecksEnabled.MultiTool then
		-- Count the number of tools in the character
		local toolCount = 0
		for _, child in ipairs(Character:GetChildren()) do
			if child:IsA("BackpackItem") then
				toolCount += 1

				if toolCount > 1 then
					child:WaitForChild("\0", 1e-6) -- Hacky way to yield for a very very tiny amount of time
					-- If we already have a tool, we want to move this one back to the player's backpack
					-- This also avoids conflicts where a tool is given to the player by the server
					child.Parent = Player:FindFirstChildWhichIsA("Backpack") or Instance.new("Backpack", Player)
				end
			end
		end
		--end
	end
end)

con6 = Humanoid:GetPropertyChangedSignal("SeatPart"):Connect(function()
	if Humanoid.SeatPart ~= nil then
		humanoidSeated = true
	else
		humanoidSeated = false
	end
end)

-- Share stats with clients.
--if Config.DiagnosticsEnabled then
--	RunService.Heartbeat:Connect(function(deltaTime)
--		DiagnosticsFolder.FlightHeat.Value = FlightHeat
--		DiagnosticsFolder.SpeedHeat.Value = SpeedHeat
--		DiagnosticsFolder.VelocityHeat.Value = VelocityHeat
--	end)
--end

-- An exception for when a server script explicitly teleports the player.
-- Exploiters are not able to trigger this from their side due to the way
-- replication works.

return AC
