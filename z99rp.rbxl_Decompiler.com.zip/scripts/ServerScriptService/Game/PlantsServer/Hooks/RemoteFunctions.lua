-- Game Dependencies

local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
--
local Events3 = game:GetService("ServerStorage").Events3
local MoneyEvent = Events3.nMonee
local Modules = game:GetService("ReplicatedStorage").Modules
local GetSellPrice = require(Modules.GetSellPrice)
local Dealers = require(game:GetService("ServerStorage").PlantsStorage.Objects.Dealer)
local Players = require(game:GetService("ServerStorage").PlantsStorage.Objects.Player)
local Emotes = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Media"):WaitForChild("Emotes"))
--
local Calls = {}
--
Calls["ReceiveArrayOf"] = function(plr, data)
	return _G.ReceiveArrayOf(data[1])
end
--
Calls["PurchaseRandomEmote"] = function(plr)
	local playerObj = Players.getPlayerBy(plr)
	--
	local unowned = {}
	for emote, _ in pairs(Emotes) do
		if (playerObj.data.other.EmotesOwned[emote] == nil) then
			table.insert(unowned, emote)
		end
	end
	--
	if (#unowned > 0 and playerObj.data.money.Shards >= 20) then
		--
		playerObj.data.money.Shards -= 20
		playerObj.data.update(true)
		--
		local new_emote = unowned[math.random(1, #unowned)]
		playerObj.data.other.EmotesOwned[new_emote] = {
			obtained = os.clock()
		} playerObj:replicateEmotesInventory()
		--
		return true
	else
		return false
	end
	--
end
--
Calls["ChooseEmoteForSlot"] = function(plr, data)
	local playerObj = Players.getPlayerBy(plr)
	local slot = data.slot
	local emote = data.emote
	--
	playerObj.data.other.EmotesEquipped["Slot".. slot] = emote
	playerObj:replicateEmotesInventory()
	--
	return
end
--
Calls["ConvertBankToShards"] = function(plr, data)
	--
	local playerObj = Players.getPlayerBy(plr)
	local entered = data.entered
	local actual = (entered * 100)
	local guar_shards = math.floor(entered/5000)
	local chance_shards = math.floor(entered/1000)
	local chance = math.clamp((math.floor((entered/10000)) * 3) + 10, 3, 45)
	if (entered <= 0) then return false, "INPUT AN AMOUNT ABOVE 0" end
	if (playerObj.data.money.Bank < actual) then return false, "NOT ENOUGH BANK" end
	--
	playerObj.data.money.Bank -= actual
	local shards = guar_shards
	for i = 1, chance_shards do
		if (math.random(1, 100) <= chance) then
			shards += 1 end end
	playerObj.data.money.Shards += shards
	playerObj.data.update(true)
	--
	return true, "CONVERTED INTO ".. shards.. " SHARDS"
end
--
Calls["SellAllScrap"] = function(plr, data)
	local scrap = {}
	--
	local function gothr(thr)
		for _, tool: Tool in ipairs(thr:GetChildren()) do
			if (tool:IsA("Tool") and tool:GetAttribute("IsScrap") and tool:GetAttribute("ScrapFound")) then
				table.insert(scrap, tool) end end end
	gothr(plr.Backpack)
	gothr(plr.Character)
	--
	local money = 0
	for _, tool in ipairs(scrap) do
		money += GetSellPrice(plr, tool, _G.GetItemStats(tool)) end
	MoneyEvent:Fire("IU3898EJKLOY89TYZJDKLJGYI390WKHJSDHG9UKLJLEDGKLJERG9U",plr,"Cash",money)
	_G.SafeDestroy(scrap)
	return true, "Successfully sold all scrap!"
	--
end
--
Calls["applyGender"] = function(plr, data)
	--
	if not plr:GetAttribute("ega") then
		plr:SetAttribute("ega",data.ega) end
	--
	plr:SetAttribute("gender",data.gender)
	plr:SetAttribute("packageSize",data.size)
	plr:SetAttribute("bottomSize",data.bottomSize)
	plr:SetAttribute("packageBody",data.body)
	plr:SetAttribute("packageFlat",data.flat)
	plr:SetAttribute("packageBottom",data.bottom)
	plr:SetAttribute("packageFakeTwoX",data.fakeTwoX and data.gender=="OneX")
	--
	plr:SetAttribute("packageHood",(data.hood and data.gender=="TwoX") and true or nil)
	plr:SetAttribute("hoodSize",(data.hood and data.gender=="TwoX") and data.hood.scale or nil)
	--
	plr:SetAttribute("packageEvilStick",data.evilStick)
	--
	plr.Character:SetAttribute("gender",data.gender)
	--
	if plr:GetAttribute("ega") then
		local egaUI=game:GetService("ReplicatedStorage").PlantsStorage.Evil.egaGui:Clone()
		egaUI.Frame.egaText.Text="[ "..tostring(plr:GetAttribute("ega")).." ]"
		egaUI.Frame.egaText.TextColor3=(data.gender=="OneX" and not data.fakeTwoX) and Color3.fromRGB(0,150,255) or (data.gender=="OneX" and data.fakeTwoX) and Color3.fromRGB(0,240,255) or (data.gender=="TwoX" and not data.hood) and Color3.fromRGB(255, 125, 255) or (data.gender=="TwoX" and data.hood) and Color3.fromRGB(150, 90, 255)
		egaUI.PlayerToHideFrom=plr
		egaUI.Parent=plr.Character.Head
	end
	--
	framework.networking.toClients(nil, false, "LoadMorph", {plr.Character, (data.gender == "TwoX" and "twox") or "onex", {
		--configs
		scale = data.size, 
		includeBody = data.body,
		includeTop = not data.flat,
		includeBottom = data.bottom,
		isFakeTwoX = data.fakeTwoX and data.gender=="OneX",
		isHood = (data.hood and data.gender=="TwoX") and true or false,
		hoodScale = (data.hood and data.gender=="TwoX") and data.hood.scale or 0.9,
		evilStick = data.evilStick,
	}})
	--
	plr.Character.HumanoidRootPart.Anchored=false
	--
	return true
end
--
Calls["CanUseDealer"] = function(plr, data)
	--
	local shop = data.shop
	local dealer = Dealers.getDealerBy(shop)
	--
	if (dealer) then
		local can = dealer:canUse(plr)
		return can
	else
		return true
	end
end
--
Calls["getAnims"] = function(plr)
	if (_G.keyboarding) then
		return _G.keyboarding.getAnimationsFor(plr.character,game:GetService("ReplicatedStorage").PlantsStorage.Hooks.remoteFunction:InvokeClient(plr,"GetAttributes"))
	else
		return {}
	end
end
--
Calls["SelectAnim"] = function(plr, data)
	--
	if plr.Character then
		plr.Character:SetAttribute("SelectedAnim",data[1])
	end
	--
	return
end
--
Calls["Ohio"] = function(plr, data)
	--
	local toReturn=nil
	--
	if data.action=="get" then
		--
		if plr.Character then
			toReturn=plr.Character:GetAttribute("FType") end
		--
	end
	--
	if data.action=="set" then
		--
		if plr.Character then
			plr.Character:SetAttribute("FType",data.toSet) end
		--
	end
	
	return toReturn
end
--
local traitsMedia = require(game:GetService("ReplicatedStorage").PlantsStorage.Media.Traits)
Calls["Traits"] = function(plr, data)
	--
	local plrObj = Players.getPlayerBy(plr)
	local plrTraits = plrObj.data.other.Traits
	local mode = data.mode
	--
	if (mode == "Gain" or mode == "Lose") then
		if ((os.clock() - (plr:GetAttribute("ChangingTraitsNotificationOs") or 0)) >= 90) then
			plr:SetAttribute("ChangingTraitsNotificationOs", os.clock())
			--
			local tab = {
				Title = "Changing Traits";
				Text = "In order for your traits to take effect you have to reset.";
				Duration = 20;
				Button1 = "Close";
			}
			--
			game:GetService("ReplicatedStorage").Events.Notification:FireClient(plr, tab,"Beep2")	
		end
	end
	--
	if (mode == "Gain") then
		local trait = traitsMedia.get(data.trait)
		--
		if (trait) then
			local list = (trait.trait == "Boon" and plrTraits.Boons) or plrTraits.Flaws
			--
			if (trait.trait == "Boon" and plrTraits.Points < trait.points) then
				return {success = false, reason = "Not enough points."} end
			if (table.find(list, trait.name)) then
				return {success = false, reason = "Already gained?"} end
			--
			table.insert(list, trait.name)
			plrObj:evaluateTraitPoints()
			return {success = true, data = plrTraits}
		end
		--
		return {success = false}
	elseif (mode == "Lose") then
		local trait = traitsMedia.get(data.trait)
		--
		if (trait) then
			local list = (trait.trait == "Boon" and plrTraits.Boons) or plrTraits.Flaws
			--
			if (trait.trait == "Flaw" and plrTraits.Points < trait.points) then
				return {success = false, reason = "Not enough points to spare."} end
			if (table.find(list, trait.name) == nil) then
				return {success = false, reason = "Not found?"} end
			--
			framework.Gs.RemoveFromArray(list, trait.name)
			plrObj:evaluateTraitPoints()
			return {success = true, data = plrTraits}
		end
		--
		return {success = false}
	elseif (mode == "Get") then
		plrObj:evaluateTraitPoints()
		return plrTraits
	end
	--
end
--
Calls["CheckJStatus"] = function(plr)
	local jPrompt
	--
	local character=plr.Character
	--
	if not framework.Gs.SafeCheck(character) or not character:FindFirstChild("HumanoidRootPart") or not character:FindFirstChild("Gifting") then return end
	if not _G.CheckIfCan(character,"Any") then return end
	--
	local jPrompt=character.HumanoidRootPart:FindFirstChild("J_Prompt")
	--
	if jPrompt then 
		jPrompt:Destroy()
		jPrompt=nil
	else
		local prompt: ProximityPrompt = framework.Gs.Create("ProximityPrompt", "J_Prompt", character.HumanoidRootPart)
		local otherPlayer=game.Players:GetPlayerFromCharacter(character.Gifting.Value)
		framework.networking.toClient(plr,false,"HidePrompt",{Prompt=prompt})
		if otherPlayer then
			framework.networking.toClient(otherPlayer,false,"HidePrompt",{Prompt=prompt})
		end
		--
		prompt.ActionText = ""
		prompt.ObjectText = ""
		prompt.HoldDuration = 1.5
		prompt.RequiresLineOfSight = false
		prompt.Style = Enum.ProximityPromptStyle.Custom
		prompt.KeyboardKeyCode = Enum.KeyCode.J
		--
		jPrompt=prompt
		--
		local promptConns={}
		--
		table.insert(promptConns,prompt.Triggered:Connect(function(keyboarder)
			local keyboarderCharacter = keyboarder.Character
			local keyboarderValues = _G.GVF(keyboarder.Name)
			if (not keyboarderValues.GiftingStatus.Value and _G.CheckIfCan(keyboarderCharacter)) and (_G.SafeCheck(prompt) and prompt.Enabled) then
				--
				local extra = {}
				local selected = keyboarderCharacter:GetAttribute("SelectedAnim")
				local module = _G.keyboarding.getBefriendModule(selected)
				if (module) then
					if (module:GetAttribute("RequiresWall")) then
						extra.WallCFrame = _G.getBefriendingWall(keyboarderCharacter.HumanoidRootPart.CFrame).cframe end
				end
				--
				_G.keyboarding.threehug(character, keyboarder.Character, character.Gifting.Value, selected, extra)
			end
		end))
		--
		table.insert(promptConns,_G.GVF(character.Name).GiftingStatus:GetPropertyChangedSignal("Value"):Connect(function()
			if not _G.GVF(character.Name).GiftingStatus.Value then
				prompt:Destroy()
			end
		end))
		--
		table.insert(promptConns,prompt.AncestryChanged:Connect(function()
			if not _G.SafeCheck(prompt) then
				for i,v in pairs(promptConns) do
					v:Disconnect()
				end
			end
		end))
		--
	end
	--
	return jPrompt
end
--
return Calls