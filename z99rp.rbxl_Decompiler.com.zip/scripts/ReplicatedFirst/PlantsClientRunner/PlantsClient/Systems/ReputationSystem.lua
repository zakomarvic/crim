-- CLIENT

local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
--
return function()
	local plantsGui = _G.PlantsGui
	local reputationGui = plantsGui.Reputation
	--
	local system = {
		shownOs = os.clock(),
		shown = false,
		show = 0,
		value = 0,
		affects = {},
		showAffectOs = os.clock(),
	}
	--
	function system.showReputation()
		if (not system.shown) then
			system.shown = true
			system.shownOs = os.clock()
			game:GetService("TweenService"):Create(reputationGui, TweenInfo.new(0.75, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {Position = UDim2.new(0.5, 0, 0, 102)}):Play()
		end
	end
	--
	function system.hideReputation()
		if (system.shown) then
			system.shown = false
			game:GetService("TweenService"):Create(reputationGui, TweenInfo.new(0.75, Enum.EasingStyle.Sine, Enum.EasingDirection.In, 0, false, 0), {Position = UDim2.new(0.5, 0, 0, -75)}):Play()
		end
	end
	--
	function system.updateReputation(new)
		system.value = math.clamp(new, -100, 100)
		--
		local factor = 0.5 + ((system.value/100)*0.5)
		local info = TweenInfo.new(0.4, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0)
		game:GetService("TweenService"):Create(reputationGui.state, info, {Position = UDim2.new(factor, 0, 0.5, 0)}):Play()
		--
		local color = Color3.fromRGB(175, 175, 175)
		if (factor <= 0.125) then
			color = Color3.fromRGB(150, 50, 50)
		elseif (factor <= 0.375) then
			color = Color3.fromRGB(125, 75, 75)
		elseif (factor >= 0.875) then
			color = Color3.fromRGB(50, 150, 50)
		elseif (factor >= 0.625) then
			color = Color3.fromRGB(75, 125, 75) end
		reputationGui.state.icon.ImageColor3 = _G.colorAdd(color, 50, 50, 50)
		reputationGui.state.icon.iconshad.ImageColor3 = _G.colorAdd(color, -50, -50, -50)
		reputationGui.state.header.TextColor3 = _G.colorAdd(color, 50, 50, 50)
		reputationGui.state.header.Text = "(".. system.value..")"
		--
	end
	--
	function system.cycle(delta)
		-- Showing & Hiding
		
		if (system.show > 0 or #system.affects>0 and not system.shown) then
			system.showReputation()
		elseif (system.show <= 0 and #system.affects<=0 and system.shown) then
			system.hideReputation()
		end
		-- Affects
		
		if (system.shown and (os.clock() - system.shownOs) >= 1 and #system.affects>0 and (os.clock() - system.showAffectOs) >= 0.5) then
			local affect = system.affects[1]
			framework.Gs.RemoveFromArray(system.affects, affect)
			system.showAffectOs = os.clock()
			--
			local color = (affect.amount > 0 and Color3.fromRGB(100, 200, 100)) or Color3.fromRGB(200, 100, 100)
			local ui = reputationGui.templates.affect:Clone()
			ui.Parent = reputationGui.affects
			ui.header.TextColor3 = color
			ui.header.stroke.Color = _G.colorAdd(color, -75, -75, -75)
			ui.header.Text = "(".. affect.amount..") ".. affect.reason or "UNDEFINED"
			ui.Size = UDim2.new(1, 0, 0, 0)
			ui.Visible = true
			--
			local frameinfo = TweenInfo.new(0.25, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0)
			local textinfo = TweenInfo.new(0.2, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0)
			ui.header.TextTransparency = 1
			ui.header.stroke.Transparency = 1
			framework.services.TweenService:Create(ui, frameinfo, {Size = UDim2.new(1, 0, 0, 18)}):Play()
			framework.services.TweenService:Create(ui.header, textinfo, {TextTransparency = 0}):Play()
			framework.services.TweenService:Create(ui.header.stroke, textinfo, {Transparency = 0.1}):Play()
			--
			system.show+=1
			task.delay(3, function() 
				system.show-=1
				local frameinfo = TweenInfo.new(0.3, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0.3)
				local textinfo = TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0)
				framework.services.TweenService:Create(ui, frameinfo, {Size = UDim2.new(1, 0, 0, 0)}):Play()
				framework.services.TweenService:Create(ui.header, textinfo, {TextTransparency = 1}):Play()
				framework.services.TweenService:Create(ui.header.stroke, textinfo, {Transparency = 1}):Play()
				task.delay(1, function() ui:Destroy() end)
			end)
			--
			system.updateReputation(system.value + affect.amount)
			if (affect.amount > 0) then
				framework.Gs.PlaySound(script.gain, game.Players.LocalPlayer.PlayerGui, framework.Gs.Random(0.9, 1.1, 100))
			else
				framework.Gs.PlaySound(script.lose, game.Players.LocalPlayer.PlayerGui, framework.Gs.Random(0.9, 1.1, 100))
			end
			--
		end
		--
	end
	--
	framework.services.RunService.Heartbeat:Connect(function(delta) 
		system.cycle(delta) end)
	framework.services.UserInputService.InputBegan:Connect(function(input, ge) 
		if (not ge) then
			if (input.KeyCode == Enum.KeyCode.P) then
				system.show += 1
				task.delay(3, function() 
					system.show -= 1 end)
			end
			--- ohioooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo
			if (input.KeyCode == Enum.KeyCode.M) then
				--
				if game.Players.LocalPlayer.Character and game.Players.LocalPlayer.Character:FindFirstChild("bellRemote") then 
					game.Players.LocalPlayer.Character.bellRemote:FireServer() end
				--
			end
		end
	end)
	--
	reputationGui.Position = UDim2.new(0.5, 0, 0, -60)
	_G.ReputationSystem = system
	system.hideReputation()
end
--