repeat task.wait() until (_G.ClientLoaded == true or game.Players.LocalPlayer.Character ~= nil) and (game:IsLoaded())
task.wait(0.5)
require(script:WaitForChild("PlantsClient"))()