local factions = {}
--
factions.OhioOfSecrecy = {
	group = 77878060,
	abbreviation = "LOS",
	--
	attire = {
		--
		bartender = {
			rank = 1,
			name = "Bartender",
			display = "rbxassetid://101661171990486",
			shirt = "rbxassetid://18777036764",
			pants = "rbxassetid://18777088377",
		},
		--
		security = {
			rank = 2,
			name = "Security",
			display = "rbxassetid://87960750253498",
			shirt = "rbxassetid://18673970949",
			pants = "rbxassetid://18674018865",
		},
		--
		dancer = {
			rank = 1,
			name = "Bartender",
			display = "rbxassetid://73564179626965",
			shirt = "rbxassetid://18686244651",
			pants = "rbxassetid://18686230197",
		},
	},
	--
	highestrank = 9, -- Used for studio testing purposes.
	highestrole = "The Ordained", -- ^
	ranks = {
		["Follower"] = -1,
		["Club Employee"] = 2,
		["Acolyte"] = 2,
		["Researcher"] = 4,
		["Bulwark"] = 5,
		["Seeker"] = 6,
		["Executive"] = 7,
		["Cardinal"] = 8,
		["The Ordained"] = 9,
	},
	--
}
--
factions.OhioNationalGuard = {
	group = 498133475,
	abbreviation = "ONG",
	--
	attire = {
		--
		enlistedLS = {
			rank = 1,
			name = "Long Sleeve",
			display = "rbxassetid://97007285286307",
			shirt = "rbxassetid://78036170952054",
			pants = "rbxassetid://91236924767983",
		},
		--
		enlistedSL = {
			rank = 1,
			name = "Short Sleeve",
			display = "rbxassetid://105765473019348",
			shirt = "rbxassetid://90900588390918",
			pants = "rbxassetid://91236924767983",
		},
	},
	--
	highestrank = 5, -- Used for studio testing purposes.
	highestrole = "President", -- ^
	ranks = {
		["Enlistee"] = -1,
		["Branch Member"] = 1,
		["Branch NCO"] = 2,
		["Branch Officer"] = 3,
		["General"] = 4,
		["President"] = 5,
	},
	--
}
--
factions.CriminalUnderground = {
	group = 593159557,
	abbreviation = "CU",
	--
	attire = {
		--
		--
	},
	--
	highestrank = 2, -- Used for studio testing purposes.
	highestrole = "Guild Leader", -- ^
	ranks = {
		["Unknown"] = -1,
		["Newbies"] = 1,
		["Guild Leader"] = 2,
	},
	--
}
--
factions.WalrifasAutos = {
	group = 709791788,
	abbreviation = "WA",
	--
	attire = {
		--
		associate = {
			rank = 1,
			name = "Associate",
			display = "rbxassetid://18889249846",
			shirt = "rbxassetid://97473178556078",
			pants = "rbxassetid://107939757052700",
		},
		--
		boss = {
			rank = 2,
			name = "Boss",
			display = "rbxassetid://18889249846",
			shirt = "rbxassetid://135923109906564",
			pants = "rbxassetid://133908536082111",
		},
		--
		godfather = {
			rank = 3,
			name = "Godfather",
			display = "rbxassetid://18889249846",
			shirt = "rbxassetid://74215015977480",
			pants = "rbxassetid://114700390237202",
		},
		--
	},
	--
	highestrank = 3, -- Used for studio testing purposes.
	highestrole = "Godfather", -- ^
	ranks = {
		["Unknown"] = -1,
		["Associates"] = 1,
		["Boss"] = 2,
		["Godfather"] = 3,
	},
	--
}
--
return factions