local LogService = game:GetService("LogService")

local LogShared = {}

function LogShared:GetHistory()
	local logHistory = LogService:GetLogHistory()
	for i,v in logHistory do 
		local timeStamp = DateTime.fromUnixTimestamp(v.timestamp):ToLocalTime()
		v.timestamp = string.format("%s:%s:%s",timeStamp.Hour,timeStamp.Minute,timeStamp.Second)
	end
	return logHistory
end
function LogShared:AddEvent(maid,callback)
	maid:Add(LogService.MessageOut:Connect(function(message,messageType)
		local timeStamp = DateTime.now():ToLocalTime()
		timeStamp = string.format("%s:%s:%s",timeStamp.Hour,timeStamp.Minute,timeStamp.Second)
		local entry = {
			message = message,
			messageType = messageType,
			timestamp = timeStamp
		}
		callback(entry)
	end))
end

return LogShared
