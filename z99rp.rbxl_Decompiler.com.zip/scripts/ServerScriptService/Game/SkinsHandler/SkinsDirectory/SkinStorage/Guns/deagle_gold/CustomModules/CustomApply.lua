local APPLY_COLOR = Color3.fromRGB(145, 127, 175)

return function(model)
	--if model.ClassName == "Tool" then
		for i,v in pairs(model:GetDescendants()) do
			if v:IsA("Sound") then
				script.ChorusSoundEffect:Clone().Parent = v
			elseif v:IsA("ParticleEmitter") then
				v.Color = ColorSequence.new{
					ColorSequenceKeypoint.new(0, Color3.fromRGB(255,170,0)),
					ColorSequenceKeypoint.new(1, Color3.fromRGB(255,170,0))
				}
				v.Brightness = 15
				v.LightEmission = 1
			elseif v:IsA("BasePart") then
				if v.Name == "BulletPart" then
					v.TextureID = ""
					v.Color = Color3.fromRGB(255,170,0)
					v.Material = Enum.Material.Neon
				elseif v:IsA("MeshPart") then
					if v:GetAttribute("SATP") then
						local sA = script.Value.Value and script.Value.Value:FindFirstChild("SurfaceAppearance")
						if sA then
							sA:Clone().Parent = v
						end
					end
				end
			elseif v:IsA("Attachment") and v.Name == "Muzzle" then
				script.FFireSoundTWO:Clone().Parent = v
			end
		end
	--end
	
	return true
end