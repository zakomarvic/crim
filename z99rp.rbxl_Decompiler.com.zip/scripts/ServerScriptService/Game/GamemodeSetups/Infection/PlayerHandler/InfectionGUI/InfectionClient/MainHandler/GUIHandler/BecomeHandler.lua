local TS = game:GetService("TweenService")
local Teams = game:GetService("Teams")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local BCHandler = {}

local uiSoundsF = ReplicatedStorage:WaitForChild("Storage"):WaitForChild("UISounds")

function BCHandler.new(self)
	local becomeInfectedF = self.ui.mF.BecomeInfectedFrame
	
	local coreGui
	pcall(function()
		coreGui = self.plr.PlayerGui.CoreGUI
	end)
	
	local function CanBuyCheck()
		return not self.isVipServer 
			and self.plr.Character ~= nil 
			and self.plr.Character:FindFirstChild("Humanoid") 
			and self.plr.Character.Humanoid.Health > 0 
			and self.I.modeV.Value == "game" 
			and self.I.timerV.Value > 0
			and self.I.amV.Value ~= 6
			and self.plr.TeamColor == self.teams.Infected.TeamColor
			and not self.plr:GetAttribute("IsPaidInfected")
	end
	
	local function PlaySound(s)
		if uiSoundsF and uiSoundsF.Parent and uiSoundsF:FindFirstChild(s) then
			uiSoundsF[s]:Play()
		end
	end
	
	local frames = {}
	
	local function Update()
		becomeInfectedF.Visible = CanBuyCheck()
		
		--print("Update1",CanBuyCheck())
		
		for i,v in pairs(frames) do
			v.Update()
		end
	end

	local function SetUp()
		local clickBusy = false
		
		for i,v in pairs(self.I.folder.BecomeValues:GetChildren()) do
			local t = {}
			t.f = script.BecomeFrame:Clone() 
			
			t.ClickFunc = function()
				if clickBusy then return end
				
				PlaySound("click")
				
				clickBusy = true

				if self.plr:GetAttribute("ShopProductClaim_" .. v.Name) then
					local result = ReplicatedStorage.Events.AttemptClaimShopProduct:InvokeServer(v.Name)

					if result then
						uiSoundsF.purchase:Play()
						Update()
					else
						uiSoundsF.error:Play()
					end
				else
					local result = _G.PromptProductPurchase(v.ProductID.Value)

					if result then
						uiSoundsF.purchase:Play()
						Update()
					end
				end
				
				clickBusy = false
			end
			
			t.Update = function()
				local has = self.plr:GetAttribute("ShopProductClaim_" .. v.Name)
				
				local titleText = ((has and "CLAIM") or "BECOME") .. " " .. string.upper(v.Title.Value)
				
				t.f.Title.Text = titleText
				t.f.Title.TextColor3 = has and Color3.fromRGB(255, 170, 0) or Color3.new(1,1,1)
				
				--print("updae2",self.I.amV.Value,v.AMValue.Value)
				
				t.f.Visible = self.I.amV.Value ~= 12 and self.I.amV.Value >= v.AMValue.Value 
			end
			
			t.f.TextButton.MouseButton1Down:Connect(function()
				t.ClickFunc()
			end)

			t.f.TextButton.MouseEnter:Connect(function()
				PlaySound("hover")
			end)
			
			t.f.LayoutOrder = v.LayoutOrder.Value
			
			t.Update()
			
			t.f.Parent = becomeInfectedF
			
			frames[v.Name] = t
		end
		self.I.modeV.Changed:Connect(Update)
		self.I.timerV.Changed:Connect(Update)
		self.plr.CharacterAdded:Connect(function()
			Update()
		end)
		self.plr.AttributeChanged:Connect(Update)
		self.I.amV.Changed:Connect(Update)
		Update()
	end
	
	spawn(function()
		if not self.plr:GetAttribute("InfectionLoaded") then
			self.plr:GetAttributeChangedSignal("InfectionLoaded"):Wait()
		end
		SetUp()
	end)
	
end

return BCHandler