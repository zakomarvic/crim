local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local TS = game:GetService("TweenService")

local M = {}
M.__index = M

function M:Grant(player,typ)
	--print("trying jugg...")
	
	local function CanBuyCheck()
		return not self.isVipServer 
			and (self.gMode == "game" 
				and self.I.valuesFolder.Timer.Value > 0
				and self.I.valuesFolder.AMValue.Value ~= 6
				and player.TeamColor == self.teams.Infected.TeamColor
				and not player:GetAttribute("IsPaidInfected")
				and (self.Config.TokenContent[typ] and self.Config.TokenContent[typ].IsBecome)
				and self.I.valuesFolder.AMValue.Value ~= 12 and self.I.valuesFolder.AMValue.Value >= self.Config.TokenContent[typ].MinAM
			)
	end
	
	--print("grantbecomeshophandler",player,typ,CanBuyCheck())
	
	local result
	local _s,_e = pcall(function()
		if CanBuyCheck() then
			--print("got1")
			local tokenC = self.Config.TokenContent[typ]
			
			player:SetAttribute("IsPaidInfected",true)
			player:SetAttribute("ForceInfectedType",tokenC.Name)
			
			player.Character = nil
			M.PlayerHandler.LoadCharacter(self,player)
			
			local char = player.Character or player.CharacterAdded:Wait()
			local hum = char:WaitForChild("Humanoid")
			
			local ff = Instance.new("ForceField")
			game.Debris:AddItem(ff,2)
			ff.Parent = char
			
			player:SetAttribute("ForceInfectedType",nil)
			player:SetAttribute("TokenInUse_" .. typ,true)

			self.activePlayers[player].DataChanged = true
			
			local con1,con2,con3,con4,con5
			
			local function DoRefundCheck(ignoreCombat,ignore2)
				if  	(
						(ignore2 or self.I.values.mode.Value == "game")
					)
						and player:GetAttribute("TokenInUse_" .. typ)
				then
					if not ignoreCombat and not ReplicatedStorage.Values.ShuttingDown.Value 
						and _G.InCombatCheck(player,true)
					then
						return
					else
						player:SetAttribute("TokenInUse_" .. typ,nil)
						M.PurchaseHandler.GrantToken(self,player,typ)
						
						if player and player.Parent then
							local tab = {
								Title = "Token Refunded";
								Text = "'" .. tokenC.Title .. "' token refunded.";
								Duration = 60;
								Button1 = "Close";
							}
							ReplicatedStorage.Events.Notification:FireClient(player,tab,"BEEP")	
						end
					end
				end
			end
			
			local function Disconnect(doCheck,ignoreCombat,ignore2)
				if con1 then
					con1:Disconnect()
					con1 = nil
				end
				if con2 then
					con2:Disconnect()
					con2 = nil
				end
				if con3 then
					con3:Disconnect()
					con3 = nil
				end
				if con4 then
					con4:Disconnect()
					con4 = nil
				end
				if con5 then
					con5:Disconnect()
					con5 = nil
				end
				
				if doCheck then
					DoRefundCheck(ignoreCombat,ignore2)
				end
				
				delay(1,function()
					player:SetAttribute("IsPaidInfected",nil)
				end)
			end
			
			con1 = player:GetAttributeChangedSignal("InfectionLeaving"):Connect(function()
				Disconnect(true)
			end)
			
			con2 = char.AncestryChanged:Connect(function(_,parent)
				if not parent then
					con2:Disconnect()
					
					task.wait(0.1)
				
					Disconnect(true,true)
				end
			end)
			
			con3 = ReplicatedStorage.Values.ShuttingDown.Changed:Connect(function()
				Disconnect(true,true)
			end)
			
			con4 = hum.Died:Connect(function()
				task.wait(0.1)
				player:SetAttribute("TokenInUse_" .. typ,nil)
				
				Disconnect()
			end)
			
			local t = time()
			
			con5 = self.I.valuesFolder.Timer.Changed:Connect(function()
				if self.I.valuesFolder.Timer.Value <= 0 then
					if con5 then
						con5:Disconnect()
						con5 = nil
					end
					if time() - t < 30 then
						Disconnect(true,true,true)
					end
				end
			end)		
			
			local tab = {
				Title = "Became " .. tokenC.Name;
				Text = "Token successfully used";
				Duration = 5;
			}
			ReplicatedStorage.Events.Notification:FireClient(player,tab,"purchase")	

			result = true
		end
	end)
	
	if not _s then
		warn("UTS Spawn Error Error:",_e)
		return false
	end
	
	return result
end

function M.new(self)
	if M.IsSetUp then return end
	M.IsSetUp = true
	
	M.CurrentSelf = self
	
	M.PlayerHandler = require(script.Parent.Parent.Parent.PlayerHandler)
	M.PurchaseHandler = require(script.Parent.Parent.Parent.PurchaseHandler)
	
	for i,v in pairs(self.Config.TokenContent) do
		if v.IsBecome and v.Enabled then
			self["Infected_" .. i] = true
			
			local f = script.Template:Clone()
			f.Name = i
			
			f.AMValue.Value = v.MinAM
			f.Title.Value = v.Name
			f.LayoutOrder.Value = v.OrderNum
			
			f.ProductID.Value = v.ProductID
			
			f.Parent = self.I.folder.BecomeValues
			
			self.ProductIds[v.ProductID] = v.ProductName or i
			
			M.PurchaseHandler.TokenHandlerMs[i] = M
		end
	end
	
	if self.Config.TokenContent.RayGun and self.Config.TokenContent.RayGun.Enabled then
		--print("Yeah enabled")
		
		self.UTS_15_Enabled = true
		
		local j_is = ReplicatedStorage.Storage.ItemStats.Guns["RayGun"]
		j_is.IsDevProduct.ID.Value = self.Config.TokenContent.RayGun.ProductID
		j_is.ForSale.Value = true
		j_is.MaxStock.Value = 1
		j_is.MinStock.Value = 1
		
		self.ProductIds[self.Config.TokenContent.RayGun.ProductID] = "ray_gun"
	end
end

return M