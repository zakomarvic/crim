
local config = {
	Test_Skip = true;
	Test_Skip_Load = true;
	Test_Skip_Load2 = true;
	Full_Skip = false;
	Skip_Studio = true;

	MoveScale = 200;
	
	CamSettings = {
		FOV = 30;
		MoveScale = 200;
		PlaybackMulti = 0.05;

		MoveVec = 0.15;
		FovVec = 0.2;

		--EndCFrame = CFrame.new(-27.9244843, 5.58447456, 4.28179026, -1, -2.64078853e-16, 3.01845082e-15, 0, 0.996194839, 0.0871552899, -3.02998064e-15, 0.0871552899, -0.99619478) * CFrame.Angles(math.rad(0),0,0);
	};

	GUI_delay = 6.7;

	ReverbType = Enum.ReverbType.Arena;

	colorSettings = {
		colorc1 = {
			p1 = {
				properties = {
					Brightness = 5;
					Contrast = 1;
					Saturation = 5;
					TintColor = Color3.fromRGB(172, 219, 255);
				};
			};
			p2 = {
				enabled = true;
				delayT = 0;
				tInfo = TweenInfo.new(1,Enum.EasingStyle.Quint,Enum.EasingDirection.Out);

				properties = {
					Brightness = 0.125;
					Contrast = 0;
					Saturation = -0.4;
					TintColor = Color3.fromRGB(216, 247, 255);
				};
			}
		};

		colorc2 = {
			p1 = {
				properties = {
					Enabled = true;
					FarIntensity = 0.756;
					FocusDistance = 0.05;
					InFocusRadius = 2.565;
					NearIntensity = 0.75;	
				};
			};

			p2 = {
				enabled = true;
				delayT = 2;
				tInfo = TweenInfo.new(3,Enum.EasingStyle.Quint,Enum.EasingDirection.Out);
				properties = {
					Enabled = true;
					FarIntensity = 1;
					FocusDistance = 0.05;
					InFocusRadius = 6.0253;
					NearIntensity = 1;	
				};
			}
		};

		colorc3 = {
			p1 = {
				properties = {
					Brightness = 0;
					Contrast = 0;
					Saturation = 0;
					TintColor = Color3.new(1,1,1);
				};
			};
			p2 = {
				enabled = true;
				delayT = 4.1;
				tInfo = TweenInfo.new(1.2,Enum.EasingStyle.Quint,Enum.EasingDirection.In,0,true,0.45);

				properties = {
					Brightness = -1.5;
					Contrast = 0.2;
					Saturation = 0;
				};
			}
		};

		--colorc4 = {
		--	p1 = {
		--		properties = {
		--			Brightness = 0;
		--			Contrast = 0;
		--			Saturation = 0;
		--			TintColor = Color3.new(1,1,1);
		--		};
		--	};
		--	p2 = {
		--		enabled = true;
		--		delayT = 7.85;
		--		tInfo = TweenInfo.new(0.6,Enum.EasingStyle.Sine,Enum.EasingDirection.In,0,true);

		--		properties = {
		--			Brightness = 2;
		--			Contrast = 0;
		--			Saturation = 0;
		--		};
		--	}
		--};
	};

	GrainSettings = {
		Size = 50;
		Speed = 50;
		Visibility = 4;
	};

	Lighting = {
		Ambient = Color3.fromRGB(0, 0, 0);
		OutdoorAmbient = Color3.fromRGB(0, 0, 0);
		Brightness = 0;
		ClockTime = 0;
		ColorShift_Top = Color3.fromRGB(0, 0, 0);
		ColorShift_Bottom = Color3.fromRGB(0,0,0);
		EnvironmentDiffuseScale = 0;
		EnvironmentSpecularScale = 1;
		ExposureCompensation = 1.25;
	};


	Note1 = "It's about that time.";
	Note2 = "ohio";

	NoteTransparency = 0.85;

	DescText = "ON SKIBIDI";
	DescColor = Color3.fromRGB(255, 235, 160);
	DescTransparency = 0.25;
	DescTextSize = 12;
}
-------------------------------------------------

--getfenv(0).script = nil

local ReplicatedStorage =	game:GetService("ReplicatedStorage")
local RunService = 			game:GetService("RunService")
local StarterGui = 			game:GetService("StarterGui")
local Players = 			game:GetService("Players")
local TS =					game:GetService("TweenService")
local UIS = 				game:GetService("UserInputService")
local SoundService =		game:GetService("SoundService")
local ContentProvider = 	game:GetService("ContentProvider")
local ReplicatedFirst =		game:GetService("ReplicatedFirst")

local GamepadService = game:GetService("GamepadService")

ReplicatedFirst:RemoveDefaultLoadingScreen()

local plr =		Players.LocalPlayer
local mouse =	plr:GetMouse()
local cam =		workspace.CurrentCamera

local GUI =			script.Parent

GUI.Parent = plr:WaitForChild("PlayerGui",1000)
GUI.Enabled = true

pcall(reee)

local events = ReplicatedStorage:WaitForChild("Events",1000)
local events2 = ReplicatedStorage:WaitForChild("Events2")
local modules = ReplicatedStorage:WaitForChild("Modules")
local values = ReplicatedStorage:WaitForChild("Values")
local storage = ReplicatedStorage:WaitForChild("Storage")

local filter = workspace:WaitForChild("Filter",1000)

local soundGroup1 = SoundService:WaitForChild("Master"):WaitForChild("Main",1000)
local soundGroup2 = SoundService:WaitForChild("Master"):WaitForChild("Radios",1000)

local load_event = events:WaitForChild("BRBRBRRBLOOOL")
local SVM = require(modules:WaitForChild("SmoothValue"))
local SERVER_ID_VAL = values:WaitForChild("ServerId").Value

local uiSounds = ReplicatedStorage:WaitForChild("Storage"):WaitForChild("UISounds")

local IS_STUDIO = RunService:IsStudio()
local menuHandlerM = nil
local frames = {}
local tempInstances = {}
local cons = {}
local lastTick = 0
local equalizer1,equalizer2
local pLoudnessV,atmosI,defaultLightingI
local smoothVal_move
local smoothVal_fov
local hasPlayed = false
local open = false
local colorC1,colorC2,colorC3,colorC4
local invokeResult = nil

local scene = storage:WaitForChild("MenuScene")
local camPart

--local cf1 = filter.MenuScene:WaitForChild("MenuCamPart1",100).CFrame
--local cf2 = filter.MenuScene:WaitForChild("MenuCamPart2",100).CFrame
--local cfV = Instance.new("CFrameValue",script)

local i = TweenInfo.new(0.5,Enum.EasingStyle.Quint,Enum.EasingDirection.Out)


local DO_FULL_SKIP = config.Full_Skip
local SKIP_LOAD = config.Test_Skip_Load
local SKIP_LOAD2 = config.Test_Skip_Load2
local DO_SKIP = config.Test_Skip

if not IS_STUDIO then
	SKIP_LOAD = false
	SKIP_LOAD2 = false
	DO_FULL_SKIP = false
	DO_SKIP = false
end
--if game.GameId == 2881451226 then
--	DO_FULL_SKIP = true
--	--SKIP_LOAD = true
--	--SKIP_LOAD2 = true
--	--DO_FULL_SKIP = true
--	--DO_SKIP = true
--end

local function CryptString(Str, Key)
	return Str:gsub('.', function(c)
		return string.char(c:byte()+Key)
	end)
end

local cc = 0

local function CryptTable(Table, Key)
	local Crypted_Table = {}

	for i,v in next, Table do
		Crypted_Table[CryptString(tostring(i), Key)] = v
	end

	return Crypted_Table
end

local function StrictTable(Virtual_Table)
	local Protected = newproxy(true)
	local Mt = getmetatable(Protected)

	Mt.__index = Virtual_Table
	Mt.__namecall = Virtual_Table
	Mt.__newindex = function()
		error("Attempt to modify a protected table.")
	end

	Mt.__metatable = "This table is protected."

	return Protected
end

local function protectTable(Table)
	local SecretKey = math.floor(math.random()*100)
	local CryptedTable = CryptTable(Table, SecretKey)
	local NewTable = {}

	for i,v in next, CryptedTable do
		local NewIndex = CryptString(tostring(i), -SecretKey)
		NewTable[tonumber(NewIndex) or NewIndex] = v
	end

	return StrictTable(NewTable)
end


local function Lerp(a, b, c)
    return a + ((b - a) * c)
end

local function WaitForLoad()
	GUI.Loaded:GetPropertyChangedSignal("Value"):Wait()
end

local function invoke()
	local t = SERVER_ID_VAL
	load_event:InvokeServer(string.reverse(string.sub(t,22,string.len(t))),"HelloThere")
end

function reee()
	plr.CameraMode = Enum.CameraMode.Classic
	cam.CameraType = Enum.CameraType.Scriptable
	cam.FieldOfView = 80

	SoundService.AmbientReverb = config.ReverbType

	coroutine.wrap(function()
		local timeout = 5
		local t = tick()
		while not pcall(
			game.StarterGui.SetCore, game.StarterGui, "TopbarEnabled", false
			) and tick()-t<timeout do
			wait()
		end
		StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.Chat,false)
		StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.Backpack,false)
		StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.Health,false)
		pcall(function()
			StarterGui:SetCore("ResetButtonCallback", false)	
		end)
	end)()
end

local function MenuCam()
	plr.CameraMode = Enum.CameraMode.Classic
	cam.CameraType = Enum.CameraType.Scriptable
	
	local function DoCam()
		local Center = Vector2.new(cam.ViewportSize.X/2, cam.ViewportSize.Y/2)
		local MoveVector = Vector3.new((mouse.X-Center.X)/config.CamSettings.MoveScale, -(mouse.Y-Center.Y)/config.CamSettings.MoveScale, 0)

		if hasPlayed then
			MoveVector = Vector3.new(0,0,0)
		end

		smoothVal_move:Update(Vector3.new(MoveVector.Y,-MoveVector.X,MoveVector.Z))

		local cf =  camPart.CFrame * CFrame.Angles(math.rad(smoothVal_move.Value.X), math.rad(smoothVal_move.Value.Y), math.rad(smoothVal_move.Value.Z))

		local pbl = GUI.music.PlaybackLoudness

		local fov = pbl * config.CamSettings.PlaybackMulti

		smoothVal_fov:Update(Vector3.new(fov,0,0))

		local fov_val = smoothVal_fov.Value.X
		fov_val = fov_val * pLoudnessV.Value

		cam.FieldOfView = config.CamSettings.FOV + fov_val

		cf = cf * CFrame.Angles(0, 
			0, math.rad(math.random(-fov_val, 
				pbl) * 0.0025)) + Vector3.new(
			math.rad(math.random(-fov_val * 0.001, fov_val * 0.001) * 0.025), 
			math.rad(math.random(-fov_val * 0.001, fov_val * 0.001) * 0.025), 
			math.rad(math.random(-fov_val * 0.001, fov_val * 0.001) * 0.025)
		)	

		game.Lighting.ClockTime = config.Lighting.ClockTime

		cam.CFrame = cf
	end
	
	local function DoGrain()
		local baseSize	= 300*(config.GrainSettings.Size*0.02)
		local speed		= 1/(40*(config.GrainSettings.Speed*0.02))
		
		if tick()-lastTick < speed then return end
		
		lastTick = tick()
		frames.GrainImage.TileSize = UDim2.new(math.random(baseSize*0.89,baseSize*1.11)/1000,0,math.random(baseSize*0.89,baseSize*1.11)/1000,0)
	end
	
	DoCam()
	DoGrain()
end

local function ToggleGUI(m,s,nz)
	s = s or 1
	if m then
		
		frames.titleImage:TweenPosition(UDim2.new(0.5,0,0.1,0),Enum.EasingDirection.Out,Enum.EasingStyle.Back,s,true)
		frames.titleImage.ImageTransparency = 1
		frames.titleImage.Version.TextTransparency = 1
		frames.titleImage.Image="rbxassetid://11818627057"
		TS:Create(frames.titleImage,TweenInfo.new(s,Enum.EasingStyle.Linear,Enum.EasingDirection.Out),{ImageTransparency = 0}):Play()
		TS:Create(frames.titleImage.Version,TweenInfo.new(s,Enum.EasingStyle.Linear,Enum.EasingDirection.Out),{TextTransparency = 0}):Play()
		TS:Create(frames.titleImage.Desc,TweenInfo.new(s,Enum.EasingStyle.Linear,Enum.EasingDirection.Out),{TextTransparency = config.DescTransparency or 0}):Play()
		
		if not nz then
			local t = {frames.buttonsFrame.PlayFrame;
				frames.buttonsFrame.TutorialFrame;
				frames.buttonsFrame.SettingsFrame;
				frames.buttonsFrame.ControlsFrame;
				frames.buttonsFrame.MenuFrame;
				frames.buttonsFrame.StoreFrame;
				frames.buttonsFrame.InventoryFrame
			}
			for i,v in pairs(t) do
				local s2 = s 
				local chosenPos = 1
				
				local i2 = i
				
				if v == frames.buttonsFrame.StoreFrame or v == frames.buttonsFrame.InventoryFrame then
					chosenPos = 0
					i2 = 6
					s2 /= 1.35
				end
				
				task.delay((i2 - 1) * (s * 0.1),function()
					v:TweenPosition(UDim2.new(chosenPos,0,v.Position.Y.Scale,0),Enum.EasingDirection.Out,Enum.EasingStyle.Quint,s2,true)
				end)
			end
		end
	else
		TS:Create(frames.titleImage,TweenInfo.new(s,Enum.EasingStyle.Linear,Enum.EasingDirection.Out),{ImageTransparency = 1}):Play()
		TS:Create(frames.titleImage.Version,TweenInfo.new(s,Enum.EasingStyle.Linear,Enum.EasingDirection.Out),{TextTransparency = 1}):Play()		
		TS:Create(frames.titleImage.Desc,TweenInfo.new(s,Enum.EasingStyle.Linear,Enum.EasingDirection.Out),{TextTransparency = 1}):Play()	
		
		frames.titleImage:TweenPosition(UDim2.new(0.5,0,-0.25,0),Enum.EasingDirection.In,Enum.EasingStyle.Back,s,true)
		local t = {
			frames.buttonsFrame.StoreFrame;
			frames.buttonsFrame.InventoryFrame;
			frames.buttonsFrame.PlayFrame;	
			frames.buttonsFrame.TutorialFrame;
			frames.buttonsFrame.SettingsFrame;
			frames.buttonsFrame.ControlsFrame;
			frames.buttonsFrame.MenuFrame;
		
		}
		for i,v in pairs(t) do
			local s2 = s
			local chosenPos = 0

			local i2 = i

			if v == frames.buttonsFrame.StoreFrame or v == frames.buttonsFrame.InventoryFrame then
				chosenPos = -0.5
				i2 = 1
				--s2 /= 1.35
			else
				i2 -= 1
			end

			task.delay((i2 - 1) * (s * 0.1),function()
				v:TweenPosition(UDim2.new(chosenPos,0,v.Position.Y.Scale,0),Enum.EasingDirection.Out,Enum.EasingStyle.Quint,s2,true)
			end)
		end
	end
	open = m
end

local function mouseHover(b,m,ct)
	if m then
		GUI.hover:Play()
		TS:Create(b,i,{BackgroundTransparency = ct or 0.75}):Play()
		--TS:Create(b.TextLabel,i,{Position = UDim2.new(p,0,0,0)}):Play()
	else
		TS:Create(b,i,{BackgroundTransparency = ct or 1}):Play()
		--TS:Create(b.TextLabel,i,{Position = UDim2.new(0,0,0,0)}):Play()
	end
end

local function SetLighting()
	for _,v in pairs(game.Lighting:WaitForChild("DefaultLightingConfig"):GetChildren()) do
		game.Lighting[v.Name] = v.Value
	end
end

local function PlayFunc(fast)
	if hasPlayed then return end
	
	hasPlayed = true

	for _,v in pairs(cons) do
		v:Disconnect()
	end
	cons = nil
	
	local function setDefaultLighting()
		for _,v in pairs(defaultLightingI:GetChildren()) do
			game.Lighting[v.Name] = v.Value
		end
		
		local f1 = ReplicatedStorage.Storage:WaitForChild("LightingObjects")
		for _,v in pairs(f1.Instances:GetChildren()) do
			if not v:IsA("ColorCorrectionEffect") then
				if v:IsA("BlurEffect") or v:IsA("BloomEffect") or v:IsA("DepthOfFieldEffect") or v:IsA("SunRaysEffect") then
					v:SetAttribute("PostFX",true)
				end
			end
			v.Parent = game.Lighting
		end
		f1.DefaultLightingConfig:Clone().Parent = game.Lighting
		f1:Destroy()
		
		ReplicatedStorage.Events2.SettingsChanged:Fire("PostFX")
	end
	
	if fast then
		ReplicatedStorage:WaitForChild("GameLoaded",1000)
		repeat task.wait(0.1) until _G.ClientLoaded ~= nil and 	 _G.GSettings and ReplicatedStorage:FindFirstChild("GameLoaded") and plr:FindFirstChild("DataLoaded") and not ReplicatedStorage.Values.ShuttingDown.Value
		
		if atmosI then
			atmosI.Parent = game.Lighting
		end
		
		for _,v in pairs(tempInstances) do
			v:Destroy()
		end
		
		invoke()
		equalizer1:Destroy()
		equalizer2:Destroy()
		colorC1:Destroy()
		colorC2:Destroy()
		colorC3:Destroy()
		colorC4:Destroy()
		
		RunService:UnbindFromRenderStep("MenuCam")
		game.Debris:AddItem(GUI,0)
		plr.CameraMode = Enum.CameraMode.Classic
		cam.CameraType = Enum.CameraType.Custom
		StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.Chat,true)
		StarterGui:SetCore("TopbarEnabled", true)
		cam.FieldOfView = 70
		setDefaultLighting()
		game.Debris:AddItem(scene,0)
		SetLighting()
		
		GamepadService:DisableGamepadCursor()
		
		return
	end
	
	GUI.boom:Play()
	
	mouseHover(frames.settingsButton.Parent.Frame,false)
	mouseHover(frames.menuButton.Parent.Frame,false)
	--mouseHover(creditsB,false)
	
	mouseHover(frames.playButton.Parent.Frame,true,0.325)
	task.delay(0.5,function()
		mouseHover(frames.playButton.Parent.Frame,false)
		ToggleGUI(false,1.5)
	end)
	
	TS:Create(GUI.BlackFrame,TweenInfo.new(2.5,Enum.EasingStyle.Quint,Enum.EasingDirection.In),{BackgroundTransparency = 0}):Play()
	
	if pLoudnessV and pLoudnessV.Parent then
		TS:Create(pLoudnessV,TweenInfo.new(2.5,Enum.EasingStyle.Linear,Enum.EasingDirection.Out),{Value = 0}):Play()
	end
	TS:Create(GUI.music,TweenInfo.new(2.5,Enum.EasingStyle.Linear,Enum.EasingDirection.Out),{Volume = 0}):Play()
	
	task.wait(2.5)
	RunService:UnbindFromRenderStep("MenuCam")
	
	coroutine.wrap(function()
		frames.mainFrame.Visible = false
		frames.GrainImage.Visible = false
		frames.Overlay.Visible = false
		GUI.CinBar1.Visible = false
		GUI.CinBar2.Visible = false
	end)()
	
	for _,v in pairs(tempInstances) do
		v:Destroy()
	end
	
	--task.wait(2.5)

	if atmosI then
		atmosI.Parent = game.Lighting
	end
	
	invoke()
	
	GamepadService:DisableGamepadCursor()
	
	task.wait(1)
	
	local i2 = TweenInfo.new(2.5,Enum.EasingStyle.Quint,Enum.EasingDirection.Out)
	TS:Create(equalizer1,i2,{HighGain = 0;LowGain = 0;MidGain = 0}):Play()
	TS:Create(equalizer2 ,i2,{HighGain = 0;LowGain = 0;MidGain = 0}):Play()
	
	plr.CameraMode = Enum.CameraMode.Classic
	cam.CameraType = Enum.CameraType.Custom
	StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.Chat,true)
	StarterGui:SetCore("TopbarEnabled", true)
	
	SoundService.AmbientReverb = Enum.ReverbType.NoReverb
		
	game.Debris:AddItem(equalizer1,3)
	game.Debris:AddItem(equalizer2,3)
	game.Debris:AddItem(colorC1,0)
	game.Debris:AddItem(colorC2,0)
	game.Debris:AddItem(scene,0)
	
	setDefaultLighting()
	cam.FieldOfView = 70
	SetLighting()
	
	task.wait(0.1)
	
	TS:Create(GUI.BlackFrame,i2,{BackgroundTransparency = 1}):Play()
	game.Debris:AddItem(GUI,10)
end

local function Load()
	local preloadDone = false

	
	if DO_FULL_SKIP or SKIP_LOAD then
		preloadDone = true
		task.wait(1)
	else
		local LoadFunc = function()
			local t = tick()
			
			local ToLoad = ReplicatedStorage:WaitForChild("ToLoad",1000)
			
			--task.wait(3)
			
			local loadTable = ToLoad:GetChildren()
			
			table.sort(loadTable, function(a, b)
		--		local aS = a:WaitForChild("Scope",1).Value
		--		local bS = b:WaitForChild("Scope",1).Value
				return a.ClassName < b.ClassName
			end)
	
			--ContentProvider:PreloadAsync(loadTable)
			
			local tab = {scene
				;GUI;game.Lighting;scene
			}
			
			if not SKIP_LOAD2 then
				table.insert(tab,ReplicatedStorage)
			end
			
			local tab2 = {}
			
			for _,v in pairs(tab) do
				for _,z in pairs(v:GetDescendants()) do
					if z:IsA("Animation") or z:IsA("ParticleEmitter") or z:IsA("Decal") or z:IsA("Texture") or z:IsA("ImageLabel") or z:IsA("ImageButton") or z:IsA("MeshPart") or z:IsA("SpecialMesh") or z:IsA("Sound") then
						table.insert(tab2,z)
					end
				end
			end
			
			local amtLoaded = 0
			
			ContentProvider:PreloadAsync(tab2, function()
				amtLoaded = amtLoaded + 1

				local amtDone = amtLoaded/#tab2
			end)
			
			--warn("Assets load time: " .. math.floor(tick() - t) .. "s")
			
			preloadDone = true
			
			game.Debris:AddItem(ReplicatedStorage.ToLoad,3)
		end

		local Loader = coroutine.create(LoadFunc)
		coroutine.resume(Loader)
	end

	local loadLabel = frames.loadFrame.LoadLabel
	local noteLabel1 = frames.loadFrame.NoteLabel1
	local noteLabel2 = frames.loadFrame.NoteLabel2
	
	frames.titleImage.Desc.Text = config.DescText
	frames.titleImage.Desc.TextColor3 = config.DescColor
	frames.titleImage.Desc.TextTransparency = config.DescTransparency or 0
	frames.titleImage.Desc.TextSize = config.DescTextSize or 20
	
	noteLabel1.Text = config.Note1
	noteLabel2.Text = config.Note2
	
	local tw = TS:Create(loadLabel,TweenInfo.new(0.5,Enum.EasingStyle.Linear,Enum.EasingDirection.InOut,10000,true),{TextTransparency = 0.5})
	tw:Play()

	
	TS:Create(noteLabel1,TweenInfo.new(2,Enum.EasingStyle.Quad,Enum.EasingDirection.Out,0,false,2),{TextTransparency = config.NoteTransparency}):Play()
	TS:Create(noteLabel2,TweenInfo.new(2,Enum.EasingStyle.Quad,Enum.EasingDirection.Out,0,false,4),{TextTransparency = config.NoteTransparency}):Play()

	
	local t = tick()
	--if not game:IsLoaded() then
	--    game.Loaded:Wait()
	--end
	
	--if ReplicatedStorage:WaitForChild("Values").ShuttingDown.Value then
	--	GUI.Enabled = false
	--end

	local l1 = false
	local l2 = false
	local l3 = false
	local l4 = false

	local dot = ""
	
	ReplicatedStorage:WaitForChild("Values",300)
	defaultLightingI = ReplicatedStorage:WaitForChild("DefaultLighting",300)
	
	spawn(function()
		for i = 1,30 do
			invokeResult = load_event:InvokeServer("GetData")
			if invokeResult and typeof(invokeResult) == "table" then
				break
			end
			task.wait(2)
		end
	end)
	
	if not (DO_FULL_SKIP or SKIP_LOAD) then
		repeat task.wait(0.2)
			local T = "LOADING"
			
			if ReplicatedStorage.Values.ShuttingDown.Value then
				T = "TELEPORTING"
			elseif game:IsLoaded() then
				if l1 then
					T = "LOADING SERVER"
				end
				l1 = true
				if ReplicatedStorage:FindFirstChild("GameLoaded") then
					if l2 then
						T = "LOADING ASSETS"
					end
					l2 = true
					if preloadDone then
						if l3 then
							T = "LOADING FRAMEWORK"
						end
						l3 = true
						if _G.ClientLoaded then
							if l4 then
								T = "LOADING DATA"
							end
							l4 = true
						end
					end
				end
			end
			
			loadLabel.Text = T .. dot

			if string.len(dot) >= 3 then
				dot = ""
			end
			
			dot = dot .. "."
		
		until 
		((_G.ClientLoaded and _G.GSettings and ReplicatedStorage:FindFirstChild("GameLoaded") and (preloadDone)) or tick() - t >= 60)
		and not ReplicatedStorage.Values.ShuttingDown.Value
		and plr:FindFirstChild("DataLoaded")
		and invokeResult
		and game:IsLoaded()
	end

	loadLabel.Text = "LOADED"
	
	warn("LOAD TIME: " .. math.floor(tick() - t) .. "s")
	
	tw:Cancel()
	TS:Create(loadLabel,TweenInfo.new(1.75,Enum.EasingStyle.Quad,Enum.EasingDirection.In,0,false,0.25),{TextTransparency = 1}):Play()
	TS:Create(noteLabel1,TweenInfo.new(1.75,Enum.EasingStyle.Quad,Enum.EasingDirection.In),{TextTransparency = 1}):Play()
	TS:Create(noteLabel2,TweenInfo.new(1.75,Enum.EasingStyle.Quad,Enum.EasingDirection.In),{TextTransparency = 1}):Play()

	task.wait(2.5)
	
	--task.delay(0,function()
	--	TS:Create(frames.loadFrame,TweenInfo.new(2,Enum.EasingStyle.Linear,Enum.EasingDirection.In),{BackgroundTransparency = 1}):Play()
	--	task.delay(2,function()	
	--		frames.loadFrame.Visible = false
	--	end)
	--end)
	
	if not plr.Parent or not game.Players:FindFirstChild(plr.Name) then
		GUI:Destroy()
		wait(100)
	end
	
	pcall(function()
		if _G.InputType == 2 then
			GamepadService:EnableGamepadCursor(GUI.Frame)
		end
	end)
	
	GUI.Loaded.Value = true	
end

local function DoWarning(reason)
	reason = reason or "[Unspecified]"
	frames.WarningFrame.Frame.WarningLabel.Text = "Moderation note: " .. "<b>" .. reason .. "</b>"
	frames.WarningFrame.Visible = true
	frames.loadFrame.Visible = false
	
	GUI.error:Play()
	
	local ev = Instance.new("BindableEvent",script)
	local con1,con2,con3,con4,con5
	
	wait(5)
	
	local function disc()
		if con1 then
			con1:Disconnect()
			con1 = nil
		end
		if con2 then
			con2:Disconnect()
			con2 = nil
		end
		if con3 then
			con3:Disconnect()
			con3 = nil
		end
		if con4 then
			con4:Disconnect()
			con4 = nil
		end
		
		UIS.MouseIconEnabled = false
		
		ev:Fire()
	end
	
	local function showButton()
		if con1 then
			con1:Disconnect()
			con1 = nil
		end
		
		local tb = frames.WarningFrame.Frame.TextButton
		tb.Visible = true
		
		con2 = tb.MouseButton1Click:Connect(function()
			GUI.click:Play()
			tb.Selectable = false
			tb.Selected = true
			tb.Active = false
			TS:Create(tb,TweenInfo.new(0.25,Enum.EasingStyle.Linear,Enum.EasingDirection.Out,0,true),{BackgroundColor3 = Color3.fromRGB(162, 255, 133)}):Play()
			disc()
		end)
		
		con3 = tb.MouseEnter:Connect(function()
			mouseHover(tb,true,0.325,0)
		end)
		con4 = tb.MouseLeave:Connect(function()
			mouseHover(tb,false,0.5)
		end)
	end
	
	UIS.MouseIconEnabled = true
	
	con1 = mouse.Move:Connect(showButton)
	
	ev.Event:Wait()
	
	frames.WarningFrame.BlackFrame.Visible = true
	frames.WarningFrame.BlackFrame.BackgroundTransparency = 1
	TS:Create(frames.WarningFrame.BlackFrame,TweenInfo.new(2,Enum.EasingStyle.Linear,Enum.EasingDirection.In),{BackgroundTransparency = 0}):Play()

	task.spawn(function()
		load_event:InvokeServer("Abide")
	end)
	
	task.delay(2,function()
		if frames and frames.WarningFrame and frames.WarningFrame.Parent then
			frames.WarningFrame.Visible = false
			frames.loadFrame.Visible = true
		end
	end)
	
	wait(1)
end

local function SetUp()
	cam.CameraSubject = nil
	cam.CameraType = Enum.CameraType.Scriptable
	cam.CFrame = CFrame.new(0,10000000,0)
	
	camPart = scene:WaitForChild("Camera",30):WaitForChild("CameraPart",30)
	
	config = protectTable(config)
	
	menuHandlerM = require(script:WaitForChild("MenuHandler"))
	menuHandlerM.SetUp(scene,config)
	
	smoothVal_move = SVM.new(Vector3.new(),config.CamSettings.MoveVec)
	smoothVal_fov = SVM.new(Vector3.new(),config.CamSettings.FovVec)
	
	frames.mainFrame = GUI:WaitForChild("Frame")
	frames.titleImage = frames.mainFrame.TitleImage
	
	frames.buttonsFrame = frames.mainFrame.ButtonsFrame
	frames.settingsFrame = frames.buttonsFrame.SettingsFrame
	frames.menuFrame = frames.buttonsFrame.MenuFrame
	
	frames.playFrame = frames.buttonsFrame.PlayFrame
	frames.controlsFrame = GUI.ControlsFrame
	frames.loadFrame = GUI.LoadFrame
	frames.WarningFrame = GUI.WarningFrame
	
	frames.controlsButton = frames.buttonsFrame.ControlsFrame.TextButton
	frames.settingsButton = frames.buttonsFrame.SettingsFrame.TextButton
	frames.menuButton = frames.buttonsFrame.MenuFrame.TextButton
	frames.playButton = frames.buttonsFrame.PlayFrame.TextButton
	frames.tutorialButton = frames.buttonsFrame.TutorialFrame.TextButton
	frames.storeButton = frames.buttonsFrame.StoreFrame.TextButton
	frames.invButton = frames.buttonsFrame.InventoryFrame.TextButton
	
	frames.GrainImage = GUI.GrainImage
	frames.Overlay = GUI.Overlay
	
	--local frames.buttonsFrame = 		Frame:WaitForChild("ButtonsFrame")
	--local frames.controlsButton =	frames.buttonsFrame:WaitForChild("ControlsFrame"):WaitForChild("TextButton")
	--local frames.settingsButton =	frames.buttonsFrame:WaitForChild("SettingsFrame"):WaitForChild("TextButton")
	--local frames.playButton =		frames.buttonsFrame:WaitForChild("PlayFrame"):WaitForChild("TextButton")
	
	colorC1,colorC2,colorC3,colorC4 = Instance.new("ColorCorrectionEffect"),Instance.new("DepthOfFieldEffect"),Instance.new("ColorCorrectionEffect"),Instance.new("ColorCorrectionEffect")
	
	task.spawn(Load)
	pcall(reee)
	
	GUI.Enabled = false
	--Frame.Position = UDim2.new(-0.3,0,0,0)
	
--	coroutine.resume(coroutine.create(function()
--		ContentProvider:PreloadAsync({GUI})
--	end))
	
	GUI.Parent = plr:WaitForChild("PlayerGui")
	GUI.Enabled = true
	
	ToggleGUI(false,0)
	
	local function SSetup()
		equalizer1 = Instance.new("EqualizerSoundEffect")
		equalizer1.LowGain = -1000
		equalizer1.HighGain = -1000
		equalizer1.MidGain = -1000
		equalizer1.Priority = 1000

		atmosI = game.Lighting:FindFirstChild("Atmosphere")
		if atmosI then
			atmosI.Parent = nil
		end
		for _,v in pairs(script.LightingObjects:GetChildren()) do
			if not v:IsA("ColorCorrectionEffect") then
				if v:IsA("BlurEffect") or v:IsA("BloomEffect") or v:IsA("DepthOfFieldEffect") or v:IsA("SunRaysEffect") then
					v:SetAttribute("PostFX",true)
				end
			end
			v.Parent = game.Lighting
			table.insert(tempInstances,v)
		end

		equalizer2 = equalizer1:Clone()
		equalizer1.Parent = soundGroup1
		equalizer2.Parent = soundGroup2

		UIS.MouseIconEnabled = false

		ReplicatedStorage:WaitForChild("Storage").GUIs.CoreGUI.Parent = plr.PlayerGui

		local lc = config.Lighting
		for i,v in pairs(lc) do
			game.Lighting[i] = v
		end
	end
	
	SSetup()
	WaitForLoad()
	
	if invokeResult and invokeResult.Warning ~= nil then
		warn("Warning received")
		DoWarning(invokeResult.Warning)
		warn("-")
	end
	task.wait(2)
	
	TS:Create(frames.loadFrame,TweenInfo.new(1,Enum.EasingStyle.Linear,Enum.EasingDirection.In),{BackgroundTransparency = 1}):Play()
	
	if ReplicatedStorage.Values.SkipMenuIntro.Value then
		PlayFunc()
		return
	end
	
	if not (DO_SKIP or DO_FULL_SKIP) then
		scene.Parent = filter
		frames.titleImage.Version.Text = ReplicatedStorage.Values.VersionType.Value .. " " .. ReplicatedStorage.Values.VersionNumber.Value

		colorC1.Parent = cam
		colorC2.Parent = cam
		colorC3.Parent = cam
		colorC4.Parent = cam
		
		frames.GrainImage.Visible = true
		frames.GrainImage.ImageTransparency = 0.6
		frames.Overlay.Visible = true
		
		
		--wait(2)
		------START
		
		TS:Create(frames.GrainImage,TweenInfo.new(2,Enum.EasingStyle.Quint,Enum.EasingDirection.Out),{ImageTransparency =  1.05- (config.GrainSettings.Visibility*0.01) }):Play()

		menuHandlerM.Start()
		
		if config.colorSettings.colorc1.p2.enabled then
			task.delay(config.colorSettings.colorc1.p2.delayT,function()
				TS:Create(colorC1,config.colorSettings.colorc1.p2.tInfo,config.colorSettings.colorc1.p2.properties):Play()
			end)
		end
		if config.colorSettings.colorc2.p2.enabled then
			task.delay(config.colorSettings.colorc2.p2.delayT,function()
				TS:Create(colorC2,config.colorSettings.colorc2.p2.tInfo,config.colorSettings.colorc2.p2.properties):Play()
			end)
		end
		if config.colorSettings.colorc3.p2.enabled then
			task.delay(config.colorSettings.colorc3.p2.delayT,function()
				
				task.delay(0.87,function()
					if config.CamSettings.EndCFrame then
						scene.Camera.Root.CFrame = config.CamSettings.EndCFrame
					end
					
					task.delay(0.5,function()
						--scene.Laugh:Play()
					end)
				end)

				TS:Create(colorC3,config.colorSettings.colorc3.p2.tInfo,config.colorSettings.colorc3.p2.properties):Play()
			end)
		end
		
		if config.colorSettings.colorc4 and config.colorSettings.colorc4.p2 and config.colorSettings.colorc4.p2.enabled then
			task.delay(config.colorSettings.colorc4.p2.delayT,function()
				TS:Create(colorC4,config.colorSettings.colorc4.p2.tInfo,config.colorSettings.colorc4.p2.properties):Play()
			end)
		end

		UIS.MouseIconEnabled = true
		
		GUI.music:Play()
		GUI.music.TimePosition = 10.5 -- 11.5
		
		local defaultVolume = GUI.music.Volume
		
		if _G.GSettings and _G.GSettings.GameMusic == false then
			GUI.music.Volume = 0
		end
		
		--task.delay(6,function()
		--	filter.MenuScene.LightPart.A.Light.Enabled = true
		--	filter.MenuScene.LightPart.A.Light.Shadows = true
		--	filter.MenuScene.LightPart.B.Light.Enabled = true
		--	filter.MenuScene.LightPart.B.Light.Shadows = true
		--	filter.MenuScene.LightPart.C.Light.Enabled = true
		--	filter.MenuScene.LightPart.C.Light.Shadows = true		
			
		--	TS:Create(filter.MenuScene.LightPart,TweenInfo.new(4,Enum.EasingStyle.Quart,Enum.EasingDirection.InOut),{Transparency = 0}):Play()
		--	TS:Create(filter.MenuScene.LightPart.A.Light,TweenInfo.new(4,Enum.EasingStyle.Quart,Enum.EasingDirection.InOut),{Brightness = 0.25}):Play()
		--	TS:Create(filter.MenuScene.LightPart.B.Light,TweenInfo.new(4,Enum.EasingStyle.Quart,Enum.EasingDirection.InOut),{Brightness = 10}):Play()		
		--	TS:Create(filter.MenuScene.LightPart.C.Light,TweenInfo.new(4,Enum.EasingStyle.Quart,Enum.EasingDirection.InOut),{Brightness = 0.25}):Play()
		--end)
		
	

		if _G.CheckIfMobile and _G.CheckIfMobile() then
			frames.buttonsFrame.UIScale.Scale = 1.3
			frames.buttonsFrame.Position = UDim2.new(frames.buttonsFrame.Position.X.Scale,frames.buttonsFrame.Position.X.Offset,0.65,0)
		end
		
		task.delay(config.GUI_delay,function()
			if _G.DeviceType ~= 3 and _G.PlayerData then
				if _G.PlayerData.Prime and string.lower(ReplicatedStorage.Values.GameMode.Value) == "casual" then
					local gui = ReplicatedStorage.Storage.GUIs.CasualWarningGUI:Clone()
					
					gui.Parent = plr.PlayerGui
					
					local guiButton = gui:WaitForChild("Frame").ReturnButton.TextButton
					
					ToggleGUI(true,nil,true)
					cons.CasualWarn = guiButton.MouseButton1Click:Connect(function()
						uiSounds.click:Play()
						gui:Destroy()
						
						ToggleGUI(true)
					end)
					
					cons.CasualWarn2 = guiButton.MouseEnter:Connect(function()
						uiSounds.hover:Play()
					end)
				elseif not _G.PlayerData.Prime then
					local gui = ReplicatedStorage.Storage.GUIs.PrimeBuyGUI:Clone()

					gui.Parent = plr.PlayerGui

					local guiButton = gui:WaitForChild("Frame").ReturnButton.TextButton

					ToggleGUI(true,nil,true)
					cons.PrimeBuyClose = gui.Frame.CloseButton.MouseButton1Click:Connect(function()
						uiSounds.click:Play()
						gui:Destroy()
						ToggleGUI(true)
					end)
					
					cons.PrimeBuyBuy = guiButton.MouseButton1Click:Connect(function()
						uiSounds.click:Play()
						local result = _G.PromptGamepass("Prime")
						if result then
							uiSounds.purchase:Play()
							
							gui:Destroy()
							ToggleGUI(true)
						end
					end)
					cons.PrimeBuyBuy2= guiButton.MouseEnter:Connect(function()
						uiSounds.hover:Play()
					end)
				else
					ToggleGUI(true)
				end
			else
				ToggleGUI(true)
			end
		end)
		
		pLoudnessV = Instance.new("NumberValue",script)
		pLoudnessV.Value = 1
		
		--cam.CFrame = cf1
		--cfV.Value = cam.CFrame
		
		RunService:BindToRenderStep("MenuCam",1,MenuCam)
		
		local tgToggle
		local ind = 1
		
		local function tutorialhandler()
			local tG = GUI:WaitForChild("TutorialFrame")
			local tgFs = tG.MainFrame.Frames

			local currentF
			
			local maxind = 8
			
			local function up()
				ind +=1
				ind = math.min(ind,8)
				
				tgToggle()
			end
			
			local function down()
				ind -= 1
				ind = math.max(ind,1)
				
				tgToggle()
			end
			
			tgToggle = function()
				if currentF then
					currentF.Visible = false
				end
				
				currentF = tgFs:FindFirstChild(ind)
				
				currentF.Visible = true
				
				if ind <= 1 then
					tG.MainFrame.LeftButton.Visible = false
					tG.MainFrame.RightButton.Visible = true
				elseif ind >= maxind then
					tG.MainFrame.LeftButton.Visible = true
					tG.MainFrame.RightButton.Visible = false
				else
					tG.MainFrame.LeftButton.Visible = true
					tG.MainFrame.RightButton.Visible = true
				end
			end
			
			tG.MainFrame.LeftButton.MouseButton1Click:Connect(function()
				if ind - 1 > 0 then
					GUI.click:Play()
				end
				down()
			end)
			
			tG.MainFrame.RightButton.MouseButton1Click:Connect(function()
				if ind + 1 <= maxind then
					GUI.click:Play()
				end
				
				up()
			end)
			
			tgToggle()
		end
		
		tutorialhandler()
		
		cons.PB1 = frames.playButton.MouseEnter:Connect(function()
			mouseHover(frames.playButton.Parent.Frame,true,0.325)
		end)
		cons.PB2 = frames.playButton.MouseLeave:Connect(function()
			mouseHover(frames.playButton.Parent.Frame,false)
		end)
		cons.PB3 = frames.playButton.MouseButton1Click:Connect(function()
			GUI.click:Play()
			TS:Create(frames.playButton.Parent.Frame,TweenInfo.new(0.25,Enum.EasingStyle.Linear,Enum.EasingDirection.Out,0,true),{BackgroundColor3 = Color3.fromRGB(162, 255, 133)}):Play()
			PlayFunc()
		end)

		cons.SB1 = frames.settingsButton.MouseEnter:Connect(function()
			mouseHover(frames.settingsButton.Parent.Frame,true,0.25)
		end)
		cons.SB2 = frames.settingsButton.MouseLeave:Connect(function()
			mouseHover(frames.settingsButton.Parent.Frame,false)
		end)
		cons.SB3 = frames.settingsButton.MouseButton1Click:Connect(function()
			if not open then return end
			GUI.click:Play()
			events2.ToggleSettingsUI:Fire(true)
			ToggleGUI(false,0)
		end)
		cons.SB4 = events2.SettingsClosed.Event:Connect(function()
			ToggleGUI(true)
		end)
		
		cons.MC = events2.SettingsChanged.Event:Connect(function(a1,a2)
			if a1 == "GameMusic" then
				GUI.music.Volume = (a2 and defaultVolume) or 0
			end
		end)
		
		cons.CTR1 = frames.controlsButton.MouseEnter:Connect(function()
			mouseHover(frames.controlsButton.Parent.Frame,true,0.26)
		end)
		cons.CTR2 = frames.controlsButton.MouseLeave:Connect(function()
			mouseHover(frames.controlsButton.Parent.Frame,false)
		end)
		cons.CTR3 = frames.controlsButton.MouseButton1Click:Connect(function()
			if not open then return end
			GUI.click:Play()
			GUI.ControlsFrame.Visible = true
			ToggleGUI(false,0)
		end)
		cons.CTR4 = GUI.ControlsFrame.CloseButton.MouseButton1Click:Connect(function()
			GUI.click:Play()
			GUI.ControlsFrame.Visible = false
			ToggleGUI(true)
		end)
		
		cons.M1 = frames.menuButton.MouseEnter:Connect(function()
			mouseHover(frames.menuButton.Parent.Frame,true,0.26)
		end)
		cons.M2 = frames.menuButton.MouseLeave:Connect(function()
			mouseHover(frames.menuButton.Parent.Frame,false)
		end)
		cons.M3 = frames.menuButton.MouseButton1Click:Connect(function()
			if not open then return end
			GUI.click:Play()
			events2.ToggleReturnMenu:Fire()
		end)
		
		cons.T1 = frames.tutorialButton.MouseEnter:Connect(function()
			mouseHover(frames.tutorialButton.Parent.Frame,true,0.26)
		end)
		cons.T2 = frames.tutorialButton.MouseLeave:Connect(function()
			mouseHover(frames.tutorialButton.Parent.Frame,false)
		end)
		cons.T3 = frames.tutorialButton.MouseButton1Click:Connect(function()
			--if open then return end
			GUI.click:Play()
			uiSounds.open:Play()
			GUI.TutorialFrame.Visible = true
			ToggleGUI(false,0)
		end)
		cons.T4 = GUI.TutorialFrame.Header.CloseButton.MouseButton1Click:Connect(function()
			--if not open then return end
			GUI.click:Play()
			uiSounds.close:Play()
			GUI.TutorialFrame.Visible = false
			ind = 1
			tgToggle()
			ToggleGUI(true)
		end)
		cons.T5 = GUI.TutorialFrame.Header.CloseButton.MouseEnter:Connect(function()
			GUI.hover:Play()
		end)
		
		cons.ST1 = frames.storeButton.MouseEnter:Connect(function()
			mouseHover(frames.storeButton.Parent.Frame,true,0.26)
		end)
		cons.ST2 = frames.storeButton.MouseLeave:Connect(function()
			mouseHover(frames.storeButton.Parent.Frame,false)
		end)
		cons.ST3 = frames.storeButton.MouseButton1Click:Connect(function()
			--if open then return end
			GUI.click:Play()
			uiSounds.open:Play()
			--GUI.TutorialFrame.Visible = true
			events2.ToggleStoreUI:Fire(true)
			ToggleGUI(false,0)
		end)
		cons.ST4 = events2.StoreUIClosed.Event:Connect(function()
			ToggleGUI(true)
		end)
		
		cons.IV1 = frames.invButton.MouseEnter:Connect(function()
			mouseHover(frames.invButton.Parent.Frame,true,0.26)
		end)
		cons.IV2 = frames.invButton.MouseLeave:Connect(function()
			mouseHover(frames.invButton.Parent.Frame,false)
		end)
		cons.IV3 = frames.invButton.MouseButton1Click:Connect(function()
			--if open then return end
			GUI.click:Play()
			uiSounds.open:Play()
			--GUI.TutorialFrame.Visible = true
			events2.ToggleSkinsUI:Fire(true)
			ToggleGUI(false,0)
		end)
		cons.IV4 = events2.SkinsUIClosed.Event:Connect(function()
			ToggleGUI(true)
		end)
		
		
		for i,v in pairs(config.colorSettings.colorc1.p1.properties) do
			colorC1[i] = v
		end
		
		for i,v in pairs(config.colorSettings.colorc2.p1.properties) do
			colorC2[i] = v
		end
		
		for i,v in pairs(config.colorSettings.colorc3.p1.properties) do
			colorC3[i] = v
		end
		
		if config.colorSettings.c4 then
			for i,v in pairs(config.colorSettings.colorc4.p1.properties) do
				colorC4[i] = v
			end
		end
	else
		PlayFunc(true)
	end
	
	--TS:Create(cfV,TweenInfo.new(15,Enum.EasingStyle.Quint,Enum.EasingDirection.InOut),{Value = cf2}):Play()
	--TS:Create(colorC2,TweenInfo.new(10,Enum.EasingStyle.Quint,Enum.EasingDirection.In),{InFocusRadius = 4.5}):Play()
end

local _s,_e = pcall(SetUp)
if game.GameId == 1857700501 and not _s then
	warn(_e)
end