-- // Services
local HttpService = game:GetService("HttpService")

-- // Var
local BoardsAPI = {}
local Response

local Settings = script.Parent:WaitForChild("Settings")
local TrelloAPIKey = Settings:WaitForChild("TrelloKey").Value
local TrelloToken = Settings:WaitForChild("TrelloToken").Value


function BoardsAPI.GetBoardInfo(BoardId: string)
	if not BoardId then
		warn("[SERVER] BoardsAPI • [GetBoardInfo] : BoardId is missing.")
		return false
	end
	
	local Succ, Err = pcall(function()
		Response = HttpService:GetAsync("https://api.trello.com/1/boards/" .. BoardId .. "?key=" .. TrelloAPIKey .. "&token=" .. TrelloToken)
	end)
	
	if not Succ then
		warn("[SERVER] BoardsAPI • [GetBoardInfo] : ", Err)
		return false
	else
		Response = HttpService:JSONDecode(Response)
		return Response
	end
end

function BoardsAPI.GetCardsOnBoard(BoardId: string)
	if not BoardId then
		warn("[SERVER] BoardsAPI • [GetCardsOnBoard] : BoardId is missing.")
		return false
	end

	local Succ, Err = pcall(function()
		Response = HttpService:GetAsync("https://api.trello.com/1/boards/" .. BoardId .. "/cards" .. "?key=" .. TrelloAPIKey .. "&token=" .. TrelloToken)
	end)

	if not Succ then
		warn("[SERVER] BoardsAPI • [GetCardsOnBoard] : ", Err)
		return false
	else
		Response = HttpService:JSONDecode(Response)
		return Response
	end
end


function BoardsAPI.GetLabelsOnBoard(BoardId: string)
	if not BoardId then
		warn("[SERVER] BoardsAPI • [GetLabelsOnBoard] : BoardId is missing.")
		return false
	end

	local Succ, Err = pcall(function()
		Response = HttpService:GetAsync("https://api.trello.com/1/boards/" .. BoardId .. "/labels" .. "?key=" .. TrelloAPIKey .. "&token=" .. TrelloToken)
	end)

	if not Succ then
		warn("[SERVER] BoardsAPI • [GetLabelsOnBoard] : ", Err)
		return false
	else
		Response = HttpService:JSONDecode(Response)
		return Response
	end
end


function BoardsAPI.GetCardOnBoard(BoardId: string, CardName: string)
	if not BoardId then
		warn("[SERVER] BoardsAPI • [GetCardOnBoard] : BoardId is missing.")
		return false
	end
	
	local CardID
	local Cards = BoardsAPI.GetCardsOnBoard(BoardId)
	
	if not Cards then
		warn("[SERVER] BoardsAPI • [GetListID] : Something went wrong try to check if BoardID is correct.")
		return false
	end

	
	for _,Data in pairs(Cards) do
		if CardName == Data.name then
			CardID = Data.id
			
			local Succ, Err = pcall(function()
				Response = HttpService:GetAsync("https://api.trello.com/1/boards/" .. BoardId .. "/cards/" .. CardID .. "?key=" .. TrelloAPIKey .. "&token=" .. TrelloToken)
			end)

			if not Succ then
				warn("[SERVER] BoardsAPI • [GetCardOnBoard] : ", Err)
				return false
			else
				Response = HttpService:JSONDecode(Response)
				return Response
			end
		else
			warn("[SERVER] BoardsAPI • [GetCardOnBoard] : Card Not Found.")
			return false
		end	
	end	
end


function BoardsAPI.GetBoardID(Name: string)
	if not Name then
		warn("[SERVER] BoardsAPI • [GetBoardID] : Name is missing.")
		return false
	end
	
	local Succ, Err = pcall(function()
		Response = HttpService:GetAsync("https://api.trello.com/1/members/me/boards" .. "?key=" .. TrelloAPIKey .. "&token=" .. TrelloToken)
	end)

	for _,Data in pairs(HttpService:JSONDecode(Response)) do
		if Name == Data.name then
			return Data.id
		end
	end
	warn("[SERVER] BoardsAPI • [GetBoardID] : Name not found.")
	return false
end


function BoardsAPI.GetListsOnBoard(BoardId: string)
	if not BoardId then
		warn("[SERVER] BoardsAPI • [GetBoardID] : BoardId is missing.")
		return false
	end

	local Succ, Err = pcall(function()
		Response = HttpService:GetAsync("https://api.trello.com/1/boards/" .. BoardId .. "/lists?key=" .. TrelloAPIKey .. "&token=" .. TrelloToken)
	end)
	
	if not Succ then
		warn("[SERVER] BoardsAPI • [GetListsOnBoard] : ", Err)
		return false
	else
		Response = HttpService:JSONDecode(Response)
		return Response
	end
end

function BoardsAPI.GetListID(BoardId, Name)
	if not BoardId or not Name then
		warn("[SERVER] BoardsAPI • [GetListID] : Required Argoment is missing (BoardId, Name).")
		return false
	end
	
	local Lists = BoardsAPI.GetListsOnBoard(BoardId)
	
	if not Lists then
		warn("[SERVER] BoardsAPI • [GetListID] : Something went wrong try to check if BoardID is correct.")
		return false
	end
	
	for _,DataList in pairs(Lists) do
		if Name == DataList.name then
			return DataList.id
		end
	end
	
	warn("[SERVER] BoardsAPI • [GetListID] : List not found.")
	return false
end




function BoardsAPI.CreateListOnBoard(BoardId: string, Name: string)
	if not BoardId then
		return warn("[SERVER] BoardsAPI • [CreateListOnBoard] : BoardId is missing.")
	end
	
	if not Name then
		return warn("[SERVER] BoardsAPI • [CreateListOnBoard] : Name is missing.")
	end
	
	local Succ, Err = pcall(function()
		Response = HttpService:PostAsync("https://api.trello.com/1/boards/" .. BoardId .. "/lists" .. "?key=" .. TrelloAPIKey .. "&token=" .. TrelloToken, HttpService:JSONEncode({name = Name, id = BoardId}))
	end)
	
	if not Succ then
		warn("[SERVER] BoardsAPI • [CreateListOnBoard] : ", Err)
		return false
	else
		return true
	end
end


function BoardsAPI.CreateBoard(Name: string)
	if not Name then
		return warn("[SERVER] CreateBoard • [CreateListOnBoard] : Name is missing.")
	end

	local Succ, Err = pcall(function()
		Response = HttpService:PostAsync("https://api.trello.com/1/boards/" .. "?key=" .. TrelloAPIKey .. "&token=" .. TrelloToken, HttpService:JSONEncode({name = Name}))
	end)

	if not Succ then
		warn("[SERVER] BoardsAPI • [CreateBoard] : ", Err)
		return false
	else
		return true
	end
end




return BoardsAPI
