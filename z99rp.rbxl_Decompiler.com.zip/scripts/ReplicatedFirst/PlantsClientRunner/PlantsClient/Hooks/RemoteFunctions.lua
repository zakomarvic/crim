-- Client

local sessions = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Objects"):WaitForChild("Sessions"))
--
local Calls = {}
--
Calls["Ping"] = function()
	return
end
--
Calls["CreateSession"] = function(id: string)
	sessions.new(id)
	return
end
--
Calls["GetFromClient"] = function(data)
	return data[1]:FindFirstChild(data[2])
end
--
Calls["GetAttributes"] = function()
	--
	local attributes={}
	--
	if game.Players.LocalPlayer.Character then
		attributes=game.Players.LocalPlayer.Character:GetAttributes()
	end
	--
	return attributes
end
--
Calls["UnloadData"] = function(data)
	local parent = data.parent
	local unload = data.unload
	--
	for _, ins in pairs(unload) do
		task.spawn(function()
			require(script:WaitForChild("Unpack"))(parent, ins)
		end)
	end
	--
	return
end
--
return Calls