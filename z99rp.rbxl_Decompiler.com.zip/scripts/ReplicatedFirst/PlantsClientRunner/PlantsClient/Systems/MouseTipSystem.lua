-- CLIENT

local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
local mouse = game.Players.LocalPlayer:GetMouse()
--
return function()
	--
	local plantsGui = _G.PlantsGui
	local hoverGui: Frame = plantsGui.MouseTip
	local _hover = {
		isHovering = false,
		isHidden = false,
		hoverObject = nil,
		connections = {},
		position = Vector2.zero,
		hoverOs = os.clock(),
		hiddenOs = os.clock(),
		indent = 0,
	}
	--
	hoverGui.Size = UDim2.new(0, 0, 0, 0)
	hoverGui.background.BackgroundTransparency = 1
	hoverGui.label.TextTransparency = 1
	hoverGui.label.stroke.Transparency = 1
	--
	function _hover.getBounds(text, width, size)
		size = (size == nil and 16) or size
		--
		local boundParams = Instance.new("GetTextBoundsParams")
		boundParams.Text = text
		boundParams.Size = 16
		boundParams.Width = width
		boundParams.Font = Font.new("rbxasset://fonts/families/Montserrat.json", Enum.FontWeight.Bold, Enum.FontStyle.Normal)
		return game:GetService("TextService"):GetTextBoundsAsync(boundParams)
	end
	--
	function _hover.cycle(delta)
		--
		if (not _hover.isHidden or (os.clock() - _hover.hiddenOs) <= 0.4) then
			--
			if (_hover.isHovering) then
				_hover.hoverOs = os.clock() end
			--
			local blend = 1 - math.pow(1 - 0.18, delta * 60)
			_hover.position = _hover.position:Lerp(Vector2.new(mouse.X, mouse.Y), blend)
			hoverGui.Position = UDim2.new(0, _hover.position.X, 0, _hover.position.Y+_hover.indent)
		end
		--
		if (not _hover.isHovering) then
			if (not _hover.isHidden and (os.clock() - _hover.hoverOs) >= 0.15) then
				_hover.isHidden = true
				_hover.hiddenOs = os.clock()
				--
				local ts = framework.services.TweenService
				local hoverinfo = TweenInfo.new(0.4, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0)
				ts:Create(hoverGui, hoverinfo, {Size = UDim2.new(0, 0, 0, hoverGui.Size.Y.Offset)}):Play()
				ts:Create(hoverGui.background, hoverinfo, {BackgroundTransparency = 1}):Play()
				ts:Create(hoverGui.label, hoverinfo, {TextTransparency = 1}):Play()
				ts:Create(hoverGui.label.stroke, hoverinfo, {Transparency = 1}):Play()
				--
			end
		end
		--
	end
	--
	function _hover.start(object)
		--
		_hover.indent = game:GetService("GuiService"):GetGuiInset().Y
		_hover.hoverObject = object
		if (not _hover.isHovering or object ~= _hover.hoverObject) then
			_hover.isHidden = false
			_hover.isHovering = true
			hoverGui.Visible = true
			--
			if (os.clock() - _hover.hoverOs) >= 0.4 then
				hoverGui.Size = UDim2.new(0, 0, 0, 22)
				_hover.position = Vector2.new(mouse.X, mouse.Y)
				hoverGui.Position = UDim2.new(0, _hover.position.X, 0, _hover.position.Y+_hover.indent)
			end
			--
			local txt = object:GetAttribute("MouseTip")
			local ts = framework.services.TweenService
			local bounds = _hover.getBounds(txt, object:GetAttribute("MouseTipWidth") or 200)
			local hoverinfo = TweenInfo.new(0.4, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0)
			hoverGui.label.Text = txt
			local size = UDim2.new(0, math.ceil(bounds.X)+10, 0, bounds.Y + 6)
			--
			local effects = object:FindFirstChild("effects")
			if (effects) then
				
			end
			--
			ts:Create(hoverGui, hoverinfo, {Size = size}):Play()
			ts:Create(hoverGui.background, hoverinfo, {BackgroundTransparency = 0.15}):Play()
			ts:Create(hoverGui.label, hoverinfo, {TextTransparency = 0}):Play()
			ts:Create(hoverGui.label.stroke, hoverinfo, {Transparency = 0.25}):Play()
			--
		end
		--
		
		--
	end
	--
	function _hover.stop(object)
		if (_hover.isHovering and _hover.hoverObject == object) then
			_hover.isHovering = false
			_hover.hoverObject = nil
		end
	end
	--
	function _hover.connect(ui: Frame)
		--
		local con = {}
		--
		table.insert(con, ui.MouseEnter:Connect(function() 
			_hover.start(ui)
		end))
		--
		table.insert(con, ui.MouseLeave:Connect(function() 
			_hover.stop(ui)
		end))
		--
		table.insert(con, ui.AncestryChanged:Connect(function() 
			if (not ui:IsDescendantOf(game)) then
				for _, rcon in ipairs(con) do
					rcon:Disconnect()
					framework.Gs.RemoveFromArray(_hover.connections, con)
				end
			end
		end))
		--
		table.insert(_hover.connections, con)
	end
	--
	for _, ui in ipairs(game:GetService("CollectionService"):GetTagged("MouseHoverTip")) do
		_hover.connect(ui) end
	game:GetService("CollectionService"):GetInstanceAddedSignal("MouseHoverTip"):Connect(_hover.connect)
	--
	framework.services.RunService.RenderStepped:Connect(_hover.cycle)
end
--