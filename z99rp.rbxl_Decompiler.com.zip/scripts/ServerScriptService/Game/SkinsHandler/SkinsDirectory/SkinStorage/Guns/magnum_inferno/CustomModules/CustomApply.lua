 


local APPLY_COLOR = Color3.fromRGB(145, 127, 175)

local function multNumberSequence(sequence,Scale)
	local numberKeypoints2 = {}
	for i = 1, #sequence.Keypoints do
		local currKeypoint = sequence.Keypoints[i]
		table.insert(numberKeypoints2, NumberSequenceKeypoint.new(currKeypoint.Time,currKeypoint.Value*Scale))
	end
	return NumberSequence.new(numberKeypoints2)
end

local pbrF = game:GetService("ReplicatedStorage").Storage:WaitForChild("PBRTextures")

return function(model)
	--if model.ClassName == "Tool" then
	for i,v in pairs(model:GetDescendants()) do
		if v:IsA("Sound") then
			if v.Name == "FireSound1" or v.Name == "FireSound2" or v.Name == "FireSound3" then
				v.Pitch *= 0.85
			elseif v.Parent.Name == "ReloadA" then
				v.Pitch *= 0.875
			end
			--script.ChorusSoundEffect:Clone().Parent = v
		elseif v:IsA("ParticleEmitter") then
			if v.Name =="Muzzle Flash 1" or v.Name == "Muzzle Flash 2" or v.Name == "FlashEmitter" then
				--v.Color = ColorSequence.new{
				--	ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 64, 0)),
				--	ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 64, 0))
				--}
			end

			--v.Brightness = 15
			--v.LightEmission = 1

			local seq = v.Size
			v.Size=multNumberSequence(seq, 2)
		elseif v:IsA("BasePart") then
			if v.Name == "BulletsFakePart" or v.Name == "BulletsRealPart" then
				v:SetAttribute("SATP2",nil)
				v:SetAttribute("SATP",nil)
				v.TextureID = ""
				v.Color = Color3.fromRGB(147, 85, 52)
				v.Material = Enum.Material.Neon
			elseif v:IsA("MeshPart") then
				--v:SetAttribute("SATP2",nil)
				--v:SetAttribute("SATP",nil)
				--v.TextureID = ""
				--v.BrickColor = BrickColor.new("Black")
				--v.Material = Enum.Material.Metal
			end
		elseif v:IsA("Attachment") and v.Name == "Muzzle" then
			script.FFireSoundTWO:Clone().Parent = v
		end

		if v.Name == "HammerPart" or v.Name == "DrumPartPart" then

			local sA = v:FindFirstChildOfClass("SurfaceAppearance")
			if sA then
				sA:Destroy()
			end

			local sA2 = script.SurfaceAppearance:Clone()
			sA2.Name = ""
			sA2.Parent = v

			--print("Yeah2")

			v:SetAttribute("SATP",nil)
		elseif v.Name == "SpeedLoaderPart" then
			v:SetAttribute("SATP",nil)
			--v:SetAttribute("PBR_SetMetal",true)
			v.TextureID = ""
			v.Material = Enum.Material.Metal
			v.Color = Color3.fromRGB(54, 54, 54)
		elseif v:GetAttribute("SATP") then
			local sA = script.Value.Value and script.Value.Value:FindFirstChild("SurfaceAppearance")
			if sA then
				sA:Clone().Parent = v
			end
		end
	end
	--end

	for i,v in pairs(model:GetDescendants()) do
		if v:IsA("BasePart") then
			if v.Name == "L1" or v.Name == "L2" or v.Name == "L3" or v.Name == "L4" then
				v.Color = Color3.fromRGB(167, 106, 1)
			end
		end
	end


	return true
end