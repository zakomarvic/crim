
return function(model)
	if model.ClassName == "Tool" then
		
		model:SetAttribute("voidedge", true)
		
		model.WeaponHandle:FindFirstChild("KatanaMesh"):Destroy()
		
		for _, v in pairs(script:GetChildren()) do
			if v:IsA("MeshPart") then
				local mesh = v:Clone()
				mesh.Parent = model.WeaponHandle
				mesh.Weld.Part0 = mesh
				mesh.Weld.Part1 = model.WeaponHandle
			end
		end
		
		model.WeaponHandle:FindFirstChild("Trail"):Destroy()
		
		local trail = script:WaitForChild("Trail"):Clone()
		trail.Attachment0 = model.WeaponHandle.T0
		trail.Attachment1 = model.WeaponHandle.T1
		trail.Parent = model.WeaponHandle
		
		local idle = script:WaitForChild("voidedge_idle"):Clone()
		idle.Parent = model.WeaponHandle
	end
	return true
end