local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local TS = game:GetService("TweenService")

local M = {}
M.__index = M

function M:Grant(player)
	local char = player.Character
	local hum = char and char:FindFirstChild("Humanoid")
	
	local stock = ReplicatedStorage.Values.GlobalStocks.CurrentStocks["Juggernaut"]
	
	--print("trying jugg...")
	
	local result
	local _s,_e = pcall(function()
		if char and hum and hum.Health > 0 and stock.Value > 0 and self.buyZonesV.Value and player.Team == self.teams.Survivors then
			stock.Value = 0
			--print("got1")
			
			for i,v in pairs(player.Backpack:GetChildren()) do
				if ReplicatedStorage.Storage.ItemStats.Guns:FindFirstChild(v.Name) then
					game.Debris:AddItem(v,0)
				end
			end
			
			local jugConfig = self.Config.TokenContent.Juggernaut
			
			self.purchasedTokenContent["Juggernaut"] = player
			
			player:SetAttribute("CashCap",30000)

			local minigun = ServerStorage.Tools.Minigun:Clone()
			local armor = ServerStorage.Tools.RCU_Armour2:Clone()
			local uts = ServerStorage.Tools["UTS-S"]:Clone()

			minigun:SetAttribute("CantDrop",true)
			minigun:SetAttribute("CantSell",true)
			minigun:SetAttribute("DisableBulletTypeChange",true)
			
			uts:SetAttribute("CantDrop",true)
			uts:SetAttribute("CantSell",true)
			uts:SetAttribute("DisableBulletTypeChange",true)
			
			char:SetAttribute("Shop_HasGun",true)
			char:SetAttribute("No_FDP_Change",true)
			char:SetAttribute("HasJuggernaut",true)
			char:SetAttribute("JuggernautInUse",true)
			
			uts.Parent = player.Backpack
			minigun.Parent = player.Backpack
			armor.Parent = player.Character
			
			local otherTools = {
				"BlackBayonet";
				"PrecisionStrike";
				"MS-Grenade";
				"RCU_Bandage";
				"RCU_Bandage";
				"RCU_Bandage";
			}
			
			for i,v in pairs(otherTools) do
				local t = ServerStorage.Tools:FindFirstChild(v)
				if t then
					t = t:Clone()
					t:SetAttribute("CantDrop",true)
					t:SetAttribute("CantSell",true)
					
					t.Parent = player.Backpack
				end
			end
			
			local HP = self.Config.TokenContent.Juggernaut.HP
			
			hum.MaxHealth = HP + 15
			hum.Health = HP

			player:SetAttribute("CustomKillCash",jugConfig.CustomKillCash)
			
			local b = Instance.new("BoolValue")
			b.Name = "hasGasMask"
			b.Parent = char
			
			local vf = _G.GVF(char.Name)
			if vf then
				for _,v in pairs(vf.HealthValues:GetChildren()) do
					v.MaxValue = jugConfig.LimbHP
					v.Value = v.MaxValue
				end
				
				vf.FallDamageProof.Value = jugConfig.FallDamageProof
				
				local b = Instance.new("BoolValue")
				b.Name = "RBTMVB_S"
				b.Parent = vf.Currents
			end
			
			player:SetAttribute("JuggernautInUse",true)
			char:SetAttribute("NoRandomInfectChoose",true)
			char:SetAttribute("BridgeSetRespawn",true)
			--print("got3")

			--print("got4")

			local t = {
				TextColor3 = Color3.fromRGB(255, 224, 111);
				TextStrokeColor3 = Color3.new(0,0,0);
				TextTransparency = 0;
				TextStrokeTransparency = 0;
				Text = "JUGGERNAUT ACTIVE - DEFEND AT ALL COSTS"
			}

			--print("got5")

			self.I.eventsFolder.DescMessage:FireAllClients(t,10,true)
			
			local tab = {
				Title = "Juggernaut Purchased";
				Text = "Single use - Exiting server or dying will result in loss.";
				Duration = 60;
				Button1 = "Close";
			}
			ReplicatedStorage.Events.Notification:FireClient(player,tab,"purchase")	

			--print("JUGG SUCCESSFUL!",player)

			self.activePlayers[player].DataChanged = true
			
			local con1,con2,con3,con4
			
			local function DoRefundCheck(ignoreCombat)
				if  	(
						self.I.values.mode.Value == "commencing"
							or self.I.values.mode.Value == "game"
							or self.I.values.mode.Value == "prepare"
							or self.I.values.mode.Value == "intermission"
					)
						and player:GetAttribute("JuggernautInUse")
				then
					if not ignoreCombat and not ReplicatedStorage.Values.ShuttingDown.Value 
						and _G.InCombatCheck(player,true)
					then
						return
					else
						player:SetAttribute("JuggernautInUse",nil)
						M.PurchaseHandler.GrantToken(self,player,"Juggernaut")
						
						if player and player.Parent then
							local tab = {
								Title = "Token Refunded";
								Text = "'Juggernaut' token refunded.";
								Duration = 60;
								Button1 = "Close";
							}
							ReplicatedStorage.Events.Notification:FireClient(player,tab,"BEEP")	
						end	
					end
				end
			end
			
			local function Disconnect(doCheck,ignoreCombat)
				if con1 then
					con1:Disconnect()
					con1 = nil
				end
				if con2 then
					con2:Disconnect()
					con2 = nil
				end
				if con3 then
					con3:Disconnect()
					con3 = nil
				end
				
				if doCheck then
					DoRefundCheck(ignoreCombat)
				end
			end
			
			con1 = player:GetAttributeChangedSignal("InfectionLeaving"):Connect(function()
				Disconnect(true)
			end)
			
			con2 = char.AncestryChanged:Connect(function(_,parent)
				if not parent then
					con2:Disconnect()
					
					task.wait(0.5)
					
					if not ReplicatedStorage.Values.ShuttingDown.Value then
						player:SetAttribute("JuggernautInUse",nil)
					end
					Disconnect()
				end
			end)
			
			con3 = ReplicatedStorage.Values.ShuttingDown.Changed:Connect(function()
				Disconnect(true,true)
			end)
			
			hum.Died:Connect(function()
				if not ReplicatedStorage.Values.ShuttingDown.Value then
					player:SetAttribute("JuggernautInUse",nil)
				end	
			end)
			
			hum:SetAttribute("NoMeleeKnock",true)			

			result = true
		end
	end)
	
	if not _s then
		warn("SpawnJuggernautSuit Error:",_e)
		return false
	end
	
	return result
end

function M.new(self)
	if M.IsSetUp then return end
	M.IsSetUp = true
	
	M.CurrentSelf = self
	
	M.PlayerHandler = require(script.Parent.Parent.Parent.PlayerHandler)
	M.PurchaseHandler = require(script.Parent.Parent.Parent.PurchaseHandler)
	
	local jugConfig = self.Config.TokenContent.Juggernaut
	
	if jugConfig and jugConfig.Enabled then
		--print("Yeah enabled")
		
		self.JuggernautEnabled = true
		
		local j_is = ReplicatedStorage.Storage.ItemStats.Armour.Juggernaut
		j_is.IsDevProduct.ID.Value = jugConfig.ProductID
		j_is.ForSale.Value = true
		j_is.MaxStock.Value = 1
		j_is.MinStock.Value = 1
		
		self.ProductIds[jugConfig.ProductID] = "juggernaut"
	end
end

return M