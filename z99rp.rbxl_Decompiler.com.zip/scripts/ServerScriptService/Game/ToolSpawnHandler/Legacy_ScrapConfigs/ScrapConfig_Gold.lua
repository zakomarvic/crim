return { -- gold scraps
	["Coal"] = {
		Rarity = 1;
		Chance = 23; -- %
	};
	
	["AKS-74U"] = {
		Rarity = 4;
		Chance = 10; -- %
	};
	["M4A1-1"] = {
		Rarity = 4;
		Chance = 10; -- %
	};
	
	["FN-FAL"] = {
		Rarity = 4;
		Chance = 10; -- %
	};

	["Mare"] = {
		Rarity = 4;
		Chance = 10; -- %
	};

	["M320-1"] = {
		Rarity = 4;
		Chance = 10; -- %
	};

	
	["RPG-7"] = {
		Rarity = 4;
		Chance = 9; -- %
	};
	
	["AKM"] = {
		Rarity = 4;
		Chance = 9; -- %
	};
	
	["T7-1"] = {
		Rarity = 4;
		Chance = 9; -- %
		SlotUsage = 0;
		IsHelmet = true;
	};	
	
	--["SlayerSword"] = {
	--	Rarity = 4;
	--	Chance = 11; -- %
	--};

}