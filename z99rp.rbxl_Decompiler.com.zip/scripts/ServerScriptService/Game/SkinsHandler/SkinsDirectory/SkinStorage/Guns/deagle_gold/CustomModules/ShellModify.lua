return function(shell)
	shell.Color = Color3.fromRGB(255,170,0)
	shell.TextureID = ""
	shell.Material = Enum.Material.Neon

	local sa = shell:FindFirstChildOfClass("SurfaceAppearance")
	if sa then
		sa:Destroy()
	end
	
	return true
end