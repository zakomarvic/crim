return {
	LeaderboardEnabled = false;

	DeathCashDropMulti = 0.286; --0.286
	FinishSpeedMulti = 2;
	AssistsDisabled = true;

	LegacyDowningSystem = true;

	MinBountyToKill = 500;

	Explosive_MinDmgToKillMulti = 1.9;

	AllowAllAccessories = true;

	XpAllowance = true;

	LootCashMulti = 0.85;
	MaxScrapsMulti = 0.7;
	MaxCratesMulti = 1;

	RemoveCombatZones = true;

	SpawnWithGamepassWeps = true;

	NoNormalXp = true; -- no xp from anything except allowance

	DefaultMap = "07-EXTENDED";
};