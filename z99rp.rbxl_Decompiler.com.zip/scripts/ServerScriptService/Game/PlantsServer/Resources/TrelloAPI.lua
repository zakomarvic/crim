--[[
   ___                                  _   _       ____                          _                     
  / _ \   _   _    __ _    ___   _ __  (_) | |_    / ___|    ___   _ __  __   __ (_)   ___    ___   ___ 
 | | | | | | | |  / _` |  / _ \ | '__| | | | __|   \___ \   / _ \ | '__| \ \ / / | |  / __|  / _ \ / __|
 | |_| | | |_| | | (_| | |  __/ | |    | | | |_     ___) | |  __/ | |     \ V /  | | | (__  |  __/ \__ \
  \__\_\  \__,_|  \__,_|  \___| |_|    |_|  \__|   |____/   \___| |_|      \_/   |_|  \___|  \___| |___/
  
  Need Help With Documention or Script? Join Our Comunity: https://discord.gg/3m5m6TaC6g or contact us on our Dev Forum post  
  
  TrelloApiModule: Writted By InceptionStrange(@Sonostrano20) & JustFury (@FuryX547)
  Dev Forum Post: https://devforum.roblox.com/t/1641593
  Documentation: https://inceptionstrange.gitbook.io/trelloapi/
  
  
--]]

-- // Var
local TrelloAPI = {
	BoardsAPI = require(script:WaitForChild("BoardsAPI")),
	CardsAPI = require(script:WaitForChild("CardsAPI")),
	CommentsAPI = require(script:WaitForChild("CommentsAPI"))
}


-- // Security
if not script:IsDescendantOf(game.ServerScriptService) then
	warn("[SERVER] It is highly recommended to put the script inside ServerScriptService, Exploiters could steal your Token and ApiKey if this module is visible on Client.")
end


return TrelloAPI
