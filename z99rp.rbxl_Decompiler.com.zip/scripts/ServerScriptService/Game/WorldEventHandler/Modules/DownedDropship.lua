local DownedDropshipHandler = {}
DownedDropshipHandler.__index = DownedDropshipHandler

--// Services \\--

local Workspace = game:GetService("Workspace")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

--// Folders \\--

local Sounds = script.Parent.Parent:WaitForChild("Sounds")

local WorldEvents = workspace:WaitForChild("WorldEvents")
local Spawns = WorldEvents.Spawns
local VFX = WorldEvents.VFX

--// Variables \\--

local DropshipInst = script:WaitForChild("Dropship")
local RingInst = script:WaitForChild("RingModel")

local DownedDropshipSound = Sounds.DownedDropship
local InCombatMusic = Sounds.InCombat

local WE = ReplicatedStorage.Events:WaitForChild("WE")

--// Module \\--

function DownedDropshipHandler:init(targetPartStr: string, t: number)
	local getSpawn = Spawns:FindFirstChild(targetPartStr)
	if (not getSpawn) then
		warn("Spawn point not found:", targetPartStr)
		return
	end

	self:play_tease_sequence()
	WE:FireAllClients("Shake", "Bump")

	local newDropship = self:create_dropship(getSpawn)
	self:perform_crash_sequence(newDropship, getSpawn, t)

	WE:FireAllClients("Shake", "Bump")
	task.wait(1.5)
	WE:FireAllClients("Shake", "Explosion")

	local newRing = self:create_new_ring(getSpawn)
	self:start_leaderboard()
	self:init_koh(newRing, t)

	self:start_idle_fire(newDropship)
	self:start_smoke_vfx(newDropship)
	self:start_combat_sfx(newDropship)

	task.delay(t, function()
		self:stop_koh()
		self:clear_leaderboard()

		newRing:Destroy()
		newDropship:Destroy()
	end)
end

--// Functions \\--

function DownedDropshipHandler:play_tease_sequence()
	WE:FireAllClients("Notify", "Incoming Transmission", "Desperate cries emit from afar")
	WE:FireAllClients("RadioToggle")

	task.wait(2)
end

function DownedDropshipHandler:create_dropship(getSpawn: BasePart)
	local newDropship = DropshipInst:Clone()
	local newPos = getSpawn.CFrame * CFrame.new(0, 1200, 9000)

	newDropship:SetPrimaryPartCFrame(newPos)
	newDropship.Parent = WorldEvents

	return newDropship
end

function DownedDropshipHandler:perform_crash_sequence(newDropship: Model, getSpawn: BasePart, t: number)
	local crashSound = self:start_crashing_sfx(newDropship)
	local startPos = newDropship:GetPivot()

	local startTick = tick()
	while (tick() - startTick <= 14) do
		RunService.Heartbeat:Wait()
		local progress = math.clamp((tick() - startTick) / 14, 0, 1)

		self:update_dropship_position(newDropship, startPos, getSpawn.CFrame, progress)
		self:update_visual_effects(newDropship, progress)
	end

	self:finalize_crash(newDropship)
end

function DownedDropshipHandler:update_dropship_position(dropship: Model, startPos: CFrame, endPos: CFrame, progress: number)
	local newPos = startPos:Lerp(endPos, progress)
	dropship:PivotTo(newPos * CFrame.Angles(math.rad(-5 * progress), 0, math.rad(15 * progress)))
end

function DownedDropshipHandler:update_visual_effects(dropship: Model, progress: number)
	dropship.PrimaryPart.Attachment.ParticleEmitter:Emit(1)
	-- Add more visual effects here based on progress
end

function DownedDropshipHandler:start_idle_fire(dropship: Model)
	dropship.PrimaryPart.Attachment.ParticleEmitter2.Enabled = true
end

function DownedDropshipHandler:finalize_crash(dropship: Model)
	dropship.Ship.CaptureUI.BillboardGui.Enabled = true
	dropship.Ship.Debris.Transparency = 0
end

function DownedDropshipHandler:init_koh(ring: BasePart, t: number)
	WE:FireAllClients("InitKOH", t)

	local cooldowns = {}

	local onRingEnter = WE.OnServerEvent:Connect(function(player: Player, str: string)
		if (str ~= "DownedDropship") then
			return
		end

		if (cooldowns[player]) then
			return
		end

		cooldowns[player] = true

		local character = player.Character
		if (not character) then
			return
		end
		
		local humanoid = character:FindFirstChildOfClass("Humanoid")
		if (not humanoid) then
			return
		end
		
		local ringDistance = player:DistanceFromCharacter(ring.Position) <= ring:GetAttribute("Radius")
		if (ringDistance) then
			if (humanoid.Health <= 0) then
				return
			end
			
			if (_G.DownedCheck(character, 1)) then
				return
			end
			
			if (player:FindFirstChild("leaderstats"):FindFirstChild("Score")) then
				player:FindFirstChild("leaderstats"):FindFirstChild("Score").Value += 2
			end
		end

		task.delay(0.5, function()
			cooldowns[player] = nil
		end)
	end)

	self.stopKOH = function()
		if (onRingEnter) then
			onRingEnter:Disconnect()
		end
	end
end

function DownedDropshipHandler:start_leaderboard()
	local create_leaderboard_for_player = function(player: Player)
		local leaderstats = player:FindFirstChild("leaderstats")
		if (not leaderstats) then
			leaderstats = Instance.new("Folder")
			leaderstats.Name = "leaderstats"
			leaderstats.Parent = player
		end

		if (not leaderstats:FindFirstChild("Score")) then
			local scoreValue = Instance.new("IntValue")
			scoreValue.Name = "Score"
			scoreValue.Parent = leaderstats
		end
	end

	for _, player in ipairs(Players:GetPlayers()) do
		create_leaderboard_for_player(player)
	end

	local playerJoin = Players.PlayerAdded:Connect(create_leaderboard_for_player)

	self.clear_leaderboard = function()
		if (playerJoin) then
			playerJoin:Disconnect()
		end

		for _, player in ipairs(Players:GetPlayers()) do
			local leaderstats = player:FindFirstChild("leaderstats")
			if (leaderstats and leaderstats:FindFirstChild("Score")) then
				leaderstats:FindFirstChild("Score"):Destroy()
			end
		end
	end
end

function DownedDropshipHandler:create_new_ring(part: BasePart)
	local newRing = RingInst:Clone()
	newRing.Parent = VFX
	newRing.CFrame = part.CFrame * CFrame.new(0, 5, 0)

	return newRing
end

function DownedDropshipHandler:start_smoke_vfx(dropship: Model)
	dropship.Ship.Smoke.Beam1.Enabled = true
	dropship.Ship.Smoke.Beam2.Enabled = true
end

function DownedDropshipHandler:start_combat_sfx(dropship: Model)
	local newSound = InCombatMusic:Clone()
	newSound.Volume = 1
	newSound.RollOffMode = Enum.RollOffMode.Linear
	newSound.RollOffMaxDistance = 100
	newSound.Parent = dropship

	newSound:Play()
end

function DownedDropshipHandler:start_crashing_sfx(dropship: Model)
	local newSound = DownedDropshipSound:Clone()
	newSound.Volume = 2
	newSound.RollOffMode = Enum.RollOffMode.Linear
	newSound.RollOffMaxDistance = 200
	newSound.Parent = dropship

	newSound:Play()
	return newSound
end

--// End \\--

return DownedDropshipHandler