wait(2)
script.Parent.crate_top:Destroy()
for i,v in pairs(script.Parent:GetDescendants()) do
	if v:IsA("LinearVelocity") then
		v.Enabled = true
		game.Debris:AddItem(v,0.1)
	elseif v:IsA("BasePart") then
		v.Anchored = false
	elseif v:IsA("Weld") or v:IsA("ManualWeld") then
		v:Destroy()
	end
end