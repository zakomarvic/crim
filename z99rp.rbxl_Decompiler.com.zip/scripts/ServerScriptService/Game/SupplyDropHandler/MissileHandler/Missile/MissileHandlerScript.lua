local RunService = game:GetService("RunService")

local function Vel(speed,lv)
	return lv*Vector3.new(speed,speed,speed)
end

local function move(target, engine,speed)
	local origincframe = engine.BodyGyro.CFrame
	local dir

	if target ~= nil then
		dir = (target.Position - engine.Position).unit
	else
		dir = engine.CFrame.lookVector 
	end

	local spawnPos = engine.Position
	local pos = spawnPos + dir

	local temp = speed
	if(target ~= nil) then
		local targetvel = target.Velocity
		local dist = (target.Position - engine.Position).magnitude
		local spd = temp - dist
		local test = target.Position+(targetvel/Vector3.new(temp,temp,temp)*(dist))  -- +Vector3.new(0,-1,0)
		engine.BodyGyro.MaxTorque = Vector3.new(17900,17900, 17900)
		engine.BodyGyro.CFrame = CFrame.new(pos,  test+dir)
	else
		engine.BodyGyro.MaxTorque = Vector3.new(17900,17900, 17900)
		engine.BodyGyro.CFrame = CFrame.new(pos, pos+dir)
	end
end

local model = script.Parent
local mainPart = model.PrimaryPart
local meshPart = model.MeshPart

local bodyVel = mainPart.BodyVelocity

local targetVal = model.TargetVal
local speedVal = model.SpeedVal


local exploded = false

local function onExplode(plane)
	if exploded then return end
	
	exploded = true
	
	mainPart.Anchored = true
	
	local _s,_e = pcall(function()
		local exp = game.ServerStorage.Projectiles.MissileExplosion:Clone()
		--game.Debris:AddItem(exp,60)
		exp.CFrame = mainPart.CFrame
		exp.Parent = workspace.Debris
		exp.Main.Disabled = false
	end)
	
	if not _s then
		warn(_e)
	end
	
	for i,v in pairs(model:GetDescendants()) do
		if v:IsA("BasePart") then
			v.Anchored = true
			v.Transparency = 1
			v.CanCollide = false
		elseif v:IsA("ParticleEmitter") then
			v.Enabled = false
		elseif v:IsA("Sound") or v:IsA("LightEmitter") or v.Name == "SmokeParticle" then
			v:Destroy()
		end
	end
	
	if plane and plane.Parent then
		
		pcall(function()
			plane.Explode:Fire(true)
		end)
		--plane:Destroy()
	end
end

local function onHit(h)
	if h:IsDescendantOf(model) then
		return
	end
	if not h.Parent then
		return
	end
	
	if h.Parent.Name ~= "SupplyPlane" and h.Parent.Parent.Name ~= "SupplyPlane" then
		return
	end
	
	onExplode((h.Parent.Name == "SupplyPlane" and h.Parent) or h.Parent.Parent)
end

delay(2,function()
	mainPart.Thrust:Play()
end)

local t = {}
for i,v in pairs(model:GetDescendants()) do
	if (v:IsA("ParticleEmitter") or v:IsA("PointLight")) and v.Enabled then
		table.insert(t,v)
	end
end

game:GetService("ReplicatedStorage").Events.ForceClientParticles:FireAllClients(t)


local con
con = RunService.Heartbeat:Connect(function()
	local targ = targetVal.Value
	
	local pp = targ.Parent and targ.PrimaryPart
	
	if targ.Active.Value then
		move(pp,mainPart,speedVal.Value)
	else
		move(nil,mainPart,speedVal.Value)
	end
	
	bodyVel.Velocity = Vel(speedVal.Value,mainPart.CFrame.lookVector)
end)


local con2
con2 = meshPart.Touched:Connect(onHit)