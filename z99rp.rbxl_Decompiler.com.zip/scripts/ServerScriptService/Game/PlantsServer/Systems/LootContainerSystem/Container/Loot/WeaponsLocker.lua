return {
	-- Pistols & Handguns
	
	{name = "Beretta", weight = 24, power = 20, isGun = true},
	{name = "G-17", weight = 20, power = 25, isGun = true},
	{name = "M1911", weight = 16, power = 30, isGun = true},
	{name = "Deagle", weight = 12, power = 35, isGun = true},
	-- Rifles
	
	{name = "AKS-74U", weight = 7, power = 40, isGun = true},
	{name = "M4A1-1", weight = 7, power = 40, isGun = true},
	-- Shotguns
	
	{name = "Sawn-Off", weight = 15, power = 30, isGun = true},
	{name = "Super-Shorty", weight = 12, power = 40, isGun = true},
	{name = "Ithaca-37", weight = 11, power = 40, isGun = true},
	--
}