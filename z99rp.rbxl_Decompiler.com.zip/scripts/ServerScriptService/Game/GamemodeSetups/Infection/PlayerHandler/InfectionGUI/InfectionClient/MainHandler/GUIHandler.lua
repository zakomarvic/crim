


local TS = game:GetService("TweenService")

local GuiHandler = {}
GuiHandler.__index = GuiHandler

function GuiHandler:UpdateUI()
	if self.I.titleEnabledV.Value then
		if string.lower(self.I.titleV.Value) == "survive" or string.lower(self.I.titleV.Value) == "infect" then
			if self.plr.Team == self.teams.Infected then
				self.I.titleV.Value = "INFECT"
			else
				self.I.titleV.Value = "SURVIVE"
			end
		end
		
		if self.I.descEnabledV.Value then
			self.ui.timer.Visible = true
			if self.uistates.timer ~= self.I.descV.Value then
				self.uistates.timer = self.I.descV.Value
				
				self.ui.timer.Text = self.I.descV.Value
				if self.I.descV.BlinkRed.Value then
					if self.uicons.timer then
						self.uicons.timer:Cancel()
					end
					
					self.uiSounds.timerclick:Play()
					
					self.ui.timer.TextColor3 = Color3.new(0.945, 0.43, 0.434)
					self.uicons.timer = TS:Create(self.ui.timer,TweenInfo.new(0.5,Enum.EasingStyle.Linear,Enum.EasingDirection.Out),{TextColor3 = Color3.new(1,1,1)})
					self.uicons.timer:Play()
				end
			end
		else
			self.ui.timer.Visible = false
		end

		if self.uistates.title ~= self.I.titleV.Value then
			self.uistates.title = self.I.titleV.Value
			if self.uicons.title then
				self.uicons.title:Cancel()
			end

			self.ui.title.Text = self.I.titleV.Value
			self.ui.title.TextColor3 = Color3.new(0.945, 0.43, 0.434)
			self.uicons.title = TS:Create(self.ui.title,TweenInfo.new(1,Enum.EasingStyle.Linear,Enum.EasingDirection.Out),{TextColor3 = Color3.new(1,1,1)})
			self.uicons.title:Play()
		end

		self.ui.tF.Visible = true
	else
		self.ui.tF.Visible = false
	end
end

function GuiHandler.new(self)
	self.ui = {}
	self.ui.mF = self.gui.MainFrame
	self.ui.tF = self.ui.mF.TitleFrame
	
	self.ui.timer = self.ui.tF.Timer
	self.ui.title = self.ui.tF.Title
	
	self.uistates = {}
	self.uicons = {}
	
	local function UIUpdater()
		local function UpdateUI()
			GuiHandler.UpdateUI(self)
		end
		self.I.descV.Changed:Connect(UpdateUI)
		self.I.titleV.Changed:Connect(UpdateUI)
		self.I.descEnabledV.Changed:Connect(UpdateUI)
		self.I.titleEnabledV.Changed:Connect(UpdateUI)
		
		UpdateUI()
	end
	UIUpdater()
	
	self.MorseCodeHandler = require(script.MorsecodeHandler)
	self.TrackingHandler = require(script.TrackingHandler)
	self.EndHandler = require(script.EndHandler)
	
	self.I.events.ScreenText.OnClientEvent:Connect(function(...)
		self.MorseCodeHandler.Do(self,...)
	end)
	
	self.I.events.PlaySound.OnClientEvent:Connect(function(soundName)
		if self.uiSounds:FindFirstChild(soundName) then
			self.uiSounds[soundName]:Play()
		end
	end)
	
	self.I.events.EndSequence.OnClientEvent:Connect(function(...)
		self.EndHandler.new(self,...)
	end)
	
	local function UpdateTracking()
		--print("upd",1)
		if self.plr.Team == self.teams.Infected then
			--print("upd",2)
			self.TrackingHandler.Mode(self,self.I.hTrackingEnabledV.Value)
		else
			self.TrackingHandler.Mode(self,false)
		end
	end
	
	self.plr.CharacterAdded:Connect(UpdateTracking)
	self.I.hTrackingEnabledV.Changed:Connect(UpdateTracking)
	UpdateTracking()
	
	self.I.events.DescMessage.OnClientEvent:Connect(function(t,removeTime,doSound)
		removeTime = removeTime or 5
		
		for i,v in pairs(self.ui.tF:GetChildren()) do
			if v:GetAttribute("CurrentDescMessage") then
				v:Destroy()
			end
		end
		
		local d = script.Desc2:Clone()
		d:SetAttribute("CurrentDescMessage",true)
		
		if doSound then
			if self.uiSounds:FindFirstChild("boom") then
				self.uiSounds["boom"]:Play()
			end
		end
		
		for i,v in pairs(t) do
			d[i] = v
		end
		
		d.Parent = self.ui.tF
		
		delay(removeTime,function()
			if d and d.Parent then
				game.Debris:AddItem(d,1)
				TS:Create(d,TweenInfo.new(1,Enum.EasingStyle.Linear,Enum.EasingDirection.InOut),{TextTransparency = 1;TextStrokeTransparency = 1}):Play()
			end
		end)
	end)
	
	self.BuyCashHandler = require(script.BuyCashHandler)
	self.BuyCashHandler.new(self)
	
	self.TokenShopHandler = require(script.TokenShopHandler)
	self.TokenShopHandler.new(self)

	self.BecomeHandler = require(script.BecomeHandler)
	self.BecomeHandler.new(self)
end

function GuiHandler:Update(dt)
	
end

return GuiHandler