-- SERVER

local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework")) 

return function()
	local theworkspace = game:GetService("Workspace")
	local themap = theworkspace:WaitForChild("Map")
	--
	local function setupWardrobe(wardrobe: Model)
		wardrobe:SetAttribute("inUse", 0) 
		local wardrobeFaction = wardrobe:GetAttribute("Faction")
		local wardrobeFactionData = _G.FactionsData[wardrobeFaction]
		local remote: RemoteEvent = _G.Create("RemoteEvent", "wardrobeRemote", wardrobe)
		local interactors = {}
		--
		remote.OnServerEvent:Connect(function(player, action, data) 
			if (action == "close") then
				interactors[player] = false
			elseif (action == "wear") then
				if (interactors[player] == true) then
					local attire = data[1]
					local attiredata = wardrobeFactionData.attire[attire]
					local factionrank = _G.Factions.GetPlayerRankIn(player, wardrobeFaction)
					local attirerank = attiredata.rank or 0
					local character = player.Character 
					local humanoid = character.Humanoid
					--
					if (factionrank >= attirerank) then
						_G.PlaySound(script.wear, character.HumanoidRootPart, _G.Random(0.95, 1.05, 100))
						if (humanoid:GetAttribute("wornAttire") ~= nil) then
							-- Shirt

							local shirt: Shirt = character:FindFirstChild("Shirt")
							if (shirt:GetAttribute("HadShirtBefore") ~= false) then
								shirt.ShirtTemplate = shirt:GetAttribute("PlayerTemplate")
							else
								shirt:Destroy() end
							-- Pants

							local pants: Pants = character:FindFirstChild("Pants")
							if (pants:GetAttribute("HadPantsBefore") ~= false) then
								pants.PantsTemplate = pants:GetAttribute("PlayerTemplate")
							else
								pants:Destroy() end
							--
							humanoid:SetAttribute("wornAttire", nil)
						else
							-- Shirt

							local shirt: Shirt = character:FindFirstChild("Shirt")
							if (shirt == nil) then
								shirt = _G.Create("Shirt", "Shirt", character) 
								shirt:SetAttribute("HadShirtBefore", false)
								shirt.ShirtTemplate = attiredata.shirt
							else
								shirt:SetAttribute("PlayerTemplate", shirt.ShirtTemplate)
								shirt.ShirtTemplate = attiredata.shirt end
							-- Pants

							local pants: Pants = character:FindFirstChild("Pants")
							if (pants == nil) then
								pants = _G.Create("Pants", "Pants", character) 
								pants:SetAttribute("HadPantsBefore", false)
								pants.PantsTemplate = attiredata.pants
							else
								pants:SetAttribute("PlayerTemplate", pants.pantsTemplate)
								pants.PantsTemplate = attiredata.pants end
							--
							humanoid:SetAttribute("wornAttire", attiredata.name)
						end
						--
						if _G.GVF(player.Name) and not _G.GVF(player.Name).GiftingStatus.Value then
							framework.networking.toClients(nil,false,"DytooMorph",{player,character,false}) end
						--
					else
						warn("User is not allowed this attire.")
					end
					--
				end
			end
		end)
		--
		local function useWardrobe(player, character)
			task.spawn(function() 
				--
				interactors[player] = true
				local factionrank = _G.Factions.GetPlayerRankIn(player, wardrobeFaction)
				local humanoid = character.Humanoid
				_G.IncrementAttribute(wardrobe, "inUse", 1)
				local sp = _G.AffectChar(character, "SP", .5, "WARDROBE", 0)
				local enteros = os.clock()
				local endthis = false
				remote:FireClient(player, "open", {wardrobe, wardrobeFactionData.attire, factionrank})
				--
				repeat
					local delta = task.wait()
					--
					if ((os.clock() - enteros) >= 0.5 and humanoid.MoveDirection.Magnitude >= 0.05) then
						endthis = true end
					--
				until (endthis == true or interactors[player] ~= true or _G.SafeCheck({player, character}) == false)
				--
				_G.SafeDestroy({sp})
				_G.IncrementAttribute(wardrobe, "inUse", -1)
				remote:FireClient(player, "close")
				interactors[player] = false
				--
			end)
		end
		--
		wardrobe.Prompt.ProximityPrompt.Triggered:Connect(function(player) 
			local character = player.Character
			--
			if (character == nil or character.Parent == nil or character:FindFirstChild("Humanoid") == nil or character.Humanoid.Health <= 0) then
				return end
			--
			if (not _G.CheckIfCan(character, "Right Arm")) then
				game:GetService("ReplicatedStorage").Events.ClientWarn:FireClient(player,{"You can't access this wardrobe as of currently.",1,Color3.fromRGB(255, 121, 121),Color3.new(0,0,0),"lost"}) 
				return end
			--
			useWardrobe(player, character)
			--
		end)
		--
	end
	--
	for _, m in ipairs(themap.Wardrobes:GetChildren()) do
		setupWardrobe(m) end
	themap.Wardrobes.ChildAdded:Connect(function(m) setupWardrobe(m) end)
	--
end