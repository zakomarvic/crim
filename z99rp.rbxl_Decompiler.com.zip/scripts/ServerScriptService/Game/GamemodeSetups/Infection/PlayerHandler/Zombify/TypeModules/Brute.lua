local M = {}

local ServerStorage = game:GetService("ServerStorage")

function M.DoAppearance(char)
	local oldShirt = char:FindFirstChildOfClass("Shirt")
	local oldPants = char:FindFirstChildOfClass("Pants")
	if oldShirt then
		oldShirt:Destroy()
	end
	if oldPants then
		oldPants:Destroy()
	end
	
	for i,v in pairs(char.Humanoid:GetAccessories()) do
		v:Destroy()
	end

	script.Shirt:Clone().Parent = char
	script.Pants:Clone().Parent = char
	
	local bC = char:FindFirstChildOfClass("BodyColors")
	local color = BrickColor.new("Dark stone grey")
	
	bC.HeadColor = color
	bC.LeftArmColor = color
	bC.RightArmColor = color
	bC.LeftLegColor = color
	bC.RightLegColor = color
	bC.TorsoColor = color
	
	local h = script.BruteRig:Clone()
	h.Parent = char
	h.Script.Disabled = false
	
	local face = char.Head:FindFirstChild("face")
	if face then
		face:Destroy()
	end
	local newFace = script.NewZombieFace:Clone()
	newFace.Name = "Head"
	newFace.Parent = char.Head
	
	for i,v in pairs(char:GetChildren()) do
		if v:IsA("BasePart") and (v.Name == "Head" or v.Name == "Torso" or v.Name == "Left Arm" or v.Name == "Right Arm" or v.Name == "Left Leg" or v.Name == "Right Leg") then
			v:SetAttribute("CSIZCHNGE",true)
			
			if v.Name ~= "Torso" and v.Name ~= "Head" then
				script.ConcreteTexture:Clone().Parent = v
			end
			
		elseif v:IsA("CharacterMesh") then
			v:Destroy()
		end
	end
	
	for i,v in pairs(script.CharacterMeshes:GetChildren()) do
		v:Clone().Parent = char
	end
	
	char.Humanoid:AddAccessory(script.InfectedEyes:Clone())
	
	local armSize = Vector3.new(1.505, 3.76, 1.505)
	
	char["Left Arm"].Size = armSize
	char["Right Arm"].Size = armSize
	char.Torso.Size = Vector3.new(2, 2, 1.4)
	char.Torso.Transparency = 0.99
	
	delay(2,function()
		char["Left Arm"].RagdollAttachment.Position = Vector3.new(0, 2, 0)	
		char["Right Arm"].RagdollAttachment.Position = Vector3.new(0, 2, 0)
		char["Left Leg"].RagdollAttachment.Position = Vector3.new(0, 2, 0)	
		char["Right Leg"].RagdollAttachment.Position = Vector3.new(0, 2, 0)
		char["Torso"].Torso_Head.Position = Vector3.new(-0.282, 1.214, -1.105)		
	end)
	
	char.HumanoidRootPart.Size = Vector3.new(2,2,0.7)
	
	local s = ServerStorage.Tools["__RESIZERT"]:Clone()
	s.Perc.Value = 1.4
	s.Parent = char
	
	wait()
	
	local s = ServerStorage.Tools["__RESIZERT_HEAD"]:Clone()
	s.Perc.Value = 0.714
	s.Parent = char
	
	char.Humanoid:SetAttribute("NeckOffset",CFrame.new(0, -1, -0.5))

	delay(1,function()
		if char and char.Parent and char:FindFirstChild("Torso") then
			local ls_C0 = CFrame.new(-1.19999981, 0.599999905, 0, 0.0207941849, 1.11758709e-08, -0.999783754, 0.0363317318, 0.999339521, 0.000755662099, 0.999123454, -0.0363395885, 0.0207804441)
			
			local rs_C1 = CFrame.new(-0.606155694, 1.908209801, 7.3380968e-10, -3.57627869e-07, 0, 1, 0, 1, 0, -1, 0, -3.57627869e-07)
			
			char.Humanoid:SetAttribute("OriginRS_C1",rs_C1)
			
			char.Torso["Left Shoulder"].C0 = ls_C0
			char.Torso["Left Shoulder"].C1 = CFrame.new(0.899999976, 2, 0, 0, 0, -1, 0, 1, 0, 1, 0, 0)

			char.Torso["Right Shoulder"].C1 = rs_C1
		end
	end)
end

function M.new(char)
	local plr = game.Players:GetPlayerFromCharacter(char)
	local hum = char.Humanoid
	
	local HP = 1000
	local SPEED_ADD = 4
	local JUMPADD = -10
	local ACCEL = 0.4

	local function DoMain()
		if not hum:GetAttribute("DontChangeHP") then
			hum.MaxHealth = HP + 15
			hum.Health = hum.MaxHealth
		end

		local vF = _G.GVF(char.Name)
		
		--local vest = game.ServerStorage.Tools.VestB_1:Clone()
		--vest.Parent = char
		--local helmet = game.ServerStorage.Tools.HelmetB_2:Clone()
		--helmet.Parent = char

		task.wait(0.1)

		if vF then
			if not hum:GetAttribute("DontChangeHP") then
				for _,v in pairs(vF.HealthValues:GetChildren()) do
					local h = HP
					if v.Name == "Head" then
						--h /= 2
					end
					v.MaxValue = h
					v.Value = v.MaxValue
				end
			end	
			
			vF.MovementSoundModifier.Value = 2.7
			vF.AccelerationModifier.Value = ACCEL
			vF.FallDamageProof.Value = 0.25
			vF.BleedProof.Value *= 2
			
			vF.NoRagdoll.Value = true
			vF.ExplosiveKnockbackProof.Value = 0.1
			vF.ExplosiveJBreakProof.Value = 0.1
			vF.ExplosiveProof.Value = 2
			
			vF.NoFlameGasStun.Value = true
			
			local b = Instance.new("BoolValue")
			b.Name = "RBTMVB_S"
			b.Parent = vF.Currents
			
			--local ACCEL_MULTI = 2
			--local ACCEL_MAX = 15

			--local b1 = Instance.new("NumberValue")
			--b1.Name = "ACCLTRR"
			--b1.Value = ACCEL_MULTI

			--local b2 = Instance.new("NumberValue")
			--b2.Name = "M"
			--b2.Value =ACCEL_MAX
			--b2.Parent = b1
			
			--b1.Parent = vF.Currents
			
			--local r = Instance.new("BoolValue")
			--r.Name = "IGZNFD"
			--r.Parent = vF.Currents
			
			vF.Currents.ChildAdded:Connect(function(x)
				if string.find(string.lower(x.Name),"flinch") then
					game.Debris:AddItem(x,0.1)
				end
			end)
			
			_G.AffectChar(char,"JR",math.huge,"WKVL2",-JUMPADD)
			_G.AffectChar(char,"SD",math.huge,"WKVL2",-SPEED_ADD)
			
			_G.AffectChar(char,"AS",math.huge)
			_G.AffectChar(char,"AC",math.huge)
			
			local zx = vF.Currents:FindFirstChild("CLMB_SD")
			if zx then
				zx:Destroy()
			end
		end

		local zf = game.ServerStorage.Tools["__ZombieFists4"]:Clone()
		zf.Parent = plr.Backpack
		
		delay(1,function()
			if not hum:GetAttribute("NoAutoEquip") and _G.CheckIfCan(char) then
				hum:EquipTool(zf)
			end
			spawn(function()
				while hum and hum.Parent and hum.Health > 0 do
					if zf.Parent and zf.Parent ~= char and not hum:GetAttribute("NoAutoEquip") and _G.CheckIfCan(char) then
						hum:EquipTool(zf)
					elseif not _G.CheckIfCan(char) then
						hum:UnequipTools()
					end
					task.wait(0.35)
				end
			end)
		end)

		hum:SetAttribute("ForceWalkStage",1)
		hum:SetAttribute("NoGasStun",true)
		hum:SetAttribute("NoOnFireAnim",true)
		hum:SetAttribute("NRG_FD",true) -- no activate fall damage ragdoll
		--hum:SetAttribute("ZSPRN_M",1) -- sprint thing
		hum:SetAttribute("NACTIVFD",true)
		hum:SetAttribute("NoFlinchSD",true)
		hum:SetAttribute("NoExplosiveStun",true)
		hum:SetAttribute("IsHighInfected",true)
		
		local animateS = char:WaitForChild("Animate",3)
		if animateS then
			for i,v in pairs({"idle1","idle2","idle3"}) do
				for i,v in pairs(animateS[v]:GetChildren()) do
					v.AnimationId = "rbxassetid://127585051698508"
				end
			end
			for i,v in pairs({"walk1","walk2","walk3"}) do
				for i,v in pairs(animateS[v]:GetChildren()) do
					v.AnimationId = "rbxassetid://106157847668733"
				end
			end
			for i,v in pairs({"run1","run2","run3"}) do
				for i,v in pairs(animateS[v]:GetChildren()) do
					v.AnimationId = "rbxassetid://83810348098685"
				end
			end
		end
		
		for i,v in pairs(hum:GetPlayingAnimationTracks()) do
			if v:GetAttribute("IsShakeAnim") then
				--v:AdjustSpeed(0.5)
				--v:AdjustWeight(0.1)
			end
		end
		
		delay(0,function()
			if hum.Parent then
				local t = tick()
				repeat
					hum:TakeDamage(2)
					task.wait(1)
				until not hum.Parent or hum.Health <= 0

				if hum and hum.Parent then
					hum:TakeDamage(10000)
					hum.Health = 0
				end
			end
		end)
		
		local zSounds = script.Parent.Parent.ZombieSounds:Clone()
		script.Sounds:Clone().Parent = zSounds
		zSounds.Parent = char
		zSounds.Disabled = false
		zSounds.Enabled = true
		
		local ss = script.SpawnScream:Clone()
		game.Debris:AddItem(ss,15)
		ss.Name = "Sound"
		ss.Parent = workspace.Audio
		ss:Play()
		
		delay(1,function()
			if hum and hum.Parent and hum.Health > 0 then
				local sl = script.SPantLoop:Clone()
				sl.Parent = char.Head
				sl:Play()

				hum.Died:Connect(function()
					if sl and sl.Parent then
						sl:Stop()
					end
				end)
			end
		end)
	end

	if plr then
		DoMain()
	end
	
	--if not M.NormalM then
	--	M.NormalM = require(script.Parent.Normal)
	--end
	--M.NormalM.DoAppearance(char)
	
	M.DoAppearance(char)
end

return M