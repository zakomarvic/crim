return {
	["Shiv"] = {
		Rarity = 3;
		Chance = 25; -- %
		SlotUsage = 1;
		HExplode = true;
	};
	
	--["PumpkinHelmet"] = {
	--	Rarity = 2;
	--	Chance = 20; -- %
	--	SlotUsage = 1;
	--	IsHelmet = true;
	--};	
	
	["CursedDagger"] = {
		Rarity = 1;
		Chance = 15; -- %
		SlotUsage = 1.5;
	};
	
	["TheCure"] = {
		Rarity = 2;
		Chance = 9; -- %
		SlotUsage = 1;
	};
	
	["Rambo"] = {
		Rarity = 1;
		Chance = 5; -- %
		SlotUsage = 3;
	};
	
	["Rage-potion"] = {
		Rarity = 2;
		Chance = 5; -- %
		SlotUsage = 1;
	};	

	["Fire-Axe"] = {
		Rarity = 2;
		Chance = 5; -- %
		SlotUsage = 4;
	};	

	["C4"] = {
		Rarity = 3;
		Chance = 5; -- %
		SlotUsage = 1.5;
	};	

	["Chainsaw"] = {
		Rarity = 3;
		Chance = 5; -- %
		SlotUsage = 6;
	};

	["Sawn-Off"] = {
		Rarity = 2;
		Chance = 5; -- %
		SlotUsage = 3.5;
	};
	
	["HallowsLauncherMK2"] = {
		Rarity = 3;
		Chance = 1; -- %
		SlotUsage = 7;
	};
}