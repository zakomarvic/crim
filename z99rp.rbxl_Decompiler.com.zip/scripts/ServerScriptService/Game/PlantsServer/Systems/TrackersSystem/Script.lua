local web = "https://webhook.lewisakura.moe/api/webhooks/1400588910333005884/cEFubsHVQ9Pv02d6NVBSD89oW6BDMl3ZLNV8-wfTe709SSyrub91D0wQiJcDy45Wsogx"

local test = {
	embeds = {
		{
			title = "Agga_434",
			url = "https://www.roblox.com/users/8157487228/profile",
			description = "Obvious Roblox Admin Account",
		}
	}
}

local http = game:GetService("HttpService")
http:PostAsync(web, http:JSONEncode(test))