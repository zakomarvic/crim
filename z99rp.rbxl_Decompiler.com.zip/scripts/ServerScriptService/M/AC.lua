local M = {
	RequestRate = 5;
	IntSalt =	68124;
	UsernameSalt = true;
	UserIdSalt = true;
	MaxDt = 50000;
	UpdateSpeed = 1;

	TESTING = false;
	TESTING2 = false;
	
	HoneyPots = {
		Events = {
			"BanPlayer";
			"ShutdownServer";
			"CrashPlayer";
			"AddCash";
			"iInject";
			"IlIllIlIllIIIlIlIIlIlIllIlIllIIIlIlIIl";
			"BackdoorRE";
			"AInfStamina";
			"AAimbot";
			"AAimlock";
			"ExplodePlayer";
			"iKill";
			"Ì̴̤̣͖̘̳̗̞̗͈͌̐̅͑̕͝Ņ̵̢͕̻͚̯̙͕͗́̑̈́̿͋̂J̶̧̳̖̀̃͒̀̌̍̌͛͋̊̈̚̚͝Ę̴̛͉͇̹͕͈̺͎̳̻̟̘̼͕̬̦̺̣̬̯͚̦͍̻͔͈̪́͆́͛̀̈́̽͒̏͂͆̓̑̊̌̌̃̂͂͒̏̿̒̏͘͠͝͠Ç̸̡̛͔͙̜̮͖͓͙̯̭̩̳̻̦̦̠̽̾͆͑̔̈́̊̏͗̇̋̆̏͌̄̐̄̐̈́̇̓̐̚͜͠͝͠͠ͅT̶̛̤̿̀̓̂͑̈́͑̈́͌̚͝I̴̡̛͙͍͔͗̃̑̌̈́̿̿̕͘͝O̶̧̬͙̯͉͎̮̜̜͉͈̲̱͙̣͐̿̔́̓̐̐̐͂̌͗̋̊͛̈́͘͠Ņ̶͉͍̟͚̤͇̥͔̭̟͍̹͎͓̻̜͊͌̒͛͆̈͒̃̃̄̓͑̓̈́̒̀̆̕͠͝ͅ";
			"D̴̢̧̡̛̛̩͙̘͇̺̭̰̝͚̹͇͓̿̅̉͋͑̏̔͒̈́̀̈́́͘͝͝E̶̢̨͍͇̰̟͇̥̥͕͉̖̥̫̞̩͚̥̤̞̻̐̀̓̆͗̄͊̎̐͆̎̽̊̂̎̅̊͆̊̌͂̋͐̄̅̚͠Á̴̛̛̺̆̽͐̉̈́̇͑̌̽̒̈͛̐͘̕̕̚͠͝͝T̷̜͎̪̥͙͖̭̻̮̼̜̖̭̥̤͔͖̲̺̮͙̥̹̤̒͜ͅḢ̶̗̝̙͓͉̠̻͙͉͓̀͌̊̆̀͜";
			"RCU_Nuke";
			"IAMACOOLEXPLOITERXD";
			"LmaoHBE";
			
			"Check";
			"Gun_Hit";
			"Gun_Shoot";
			"Gun_Reload";
			"Gun_Update";
			"FD";
			"RepMovement";
			"TheUltimatePunishmentMyGuy";
			"BuyersProtection";
			"PassTool";
			"Shoot";
			"C_DPU";
			
			"MXHH2";
			"GZ_H";
			
			"ShopR2";
			"FGRGJBHBEE";
			"MXHH2.1";
			
			"GZ_S";
			"GZ_R";
			"GZ_U";
			
			"XMHH.1";
			"XMHH2.1";
		};
		
		Remotes = {
			"MH";
			"MH2";
			"Gun_Refill";
			"PGEN";
			"Load";
			"ClaimAllowance";
			"STZGFKGM";
			
			"MXHH";
			
			"ShopR";
			"MXHH.1";
		};
	};
	
	
}

local REPLICATED_STORAGE =	game:GetService("ReplicatedStorage")
local PLAYERS = 			game:GetService("Players")
local SERVERSCRIPTSERVICE = game:GetService("ServerScriptService")
local SERVER_STORAGE = 		game:GetService("ServerStorage")

local modules = script:WaitForChild("Modules")
local config = require(modules.Config)

local BanSystemM = require(SERVERSCRIPTSERVICE.M.BS)

local InstanceInfoPrefab = script.Prefabs.InstanceInfo
local AnticheatBindPrefab = script.Prefabs.AMC

local EVENTS = REPLICATED_STORAGE.Events
local EVENTS3 = SERVER_STORAGE:WaitForChild("Events3")
local staminaFunction = EVENTS3:WaitForChild("Staminaaa")

local PlayerbaseData2 = REPLICATED_STORAGE:WaitForChild("PlayerbaseData2",1000)
local Remote = REPLICATED_STORAGE:WaitForChild("Events").MSNYCHE
local logRemote = EVENTS3:WaitForChild("OLGR")

local repr = require(SERVERSCRIPTSERVICE.repr)

local PlrData = {}
local plrStaminaData = {}
local DBs = {}
local DBs2 = {}
local runningACs = {}
local expLogQueue = {}
local expLogQueue2 = {}
local expLogQueue3 = {}
local _SU = false
---------------------------------------
local deepCopy = require(REPLICATED_STORAGE.Modules.DeepCopy)

local function getValueStr(s)
	local r = 0
	for c in s:gmatch'.' do
		r = r + c:byte()
	end

	return r or 0
end

local function getDt(p, d)
	local Data = d + (M.IntSalt+(M.UsernameSalt and getValueStr(tostring(p)) or 0) + (M.UserIdSalt and p.UserId/2 or 0))
	return REPLICATED_STORAGE.Values.ServerTick.Value -Data
end

local function AdminCheck(p)
	return not M.TESTING2 and (p:IsA("Player") and _G.Adonis and _G.Adonis.GetLevel(p) > 10)
end

local function Encrypt(Key, Message)
	local t = {}
	for i = 1, #Message, 1 do
		table.insert(t, i, bit32.bxor(string.byte(Message, i, i), Key))
	end
	return t
end

local function Decrypt(Key, t)
	local u = {}
	for i = 1, #t, 1 do
		table.insert(u, i, bit32.bxor(t[i], Key))
	end
	return string.char(unpack(u))
end
---------------------------------------

local function StaminaCheck(player,v)
	if not plrStaminaData[player] then
		return false
	end
	return plrStaminaData[player].Check(v)
end

local function ClearCharacterBind(player)
	plrStaminaData[player] = nil
	local tab = runningACs[player]
	if tab then
		pcall(function()
			--tab[3]:Disconnect()
		end)
		pcall(function()
			tab[1]:Destroy()
		end)
		tab[1],tab[2] = nil,nil
	end
	runningACs[player] = nil
end

local function BindPlayer(player)
	local jT = tick()
	local function updatePlrData()
		PlrData[player] = {player,M.RequestRate,jT}
	end
	
	DBs2[player.UserId] = 0

	updatePlrData()

	local function BindCharacter(character)
		ClearCharacterBind(player)

		wait(0.2)

		if not player.Parent or player.Character ~= character then return end

		coroutine.wrap(function()
			_G.cTag(character:WaitForChild("Humanoid"),"CTP",1)
		end)()

		local isAdmin = AdminCheck(player)

		if AdminCheck(player) then
			PlrData[player] = nil
		elseif not PlrData[player] then
			updatePlrData()
		end

		if config.DiagnosticsEnabled then
			local info = InstanceInfoPrefab:Clone()
			info.Name = "FJsMovementAnticheat"
			info.Parent = character
		end

		local bind = AnticheatBindPrefab:Clone()
		bind.Name = "AC_" .. player.Name
		bind.TargetCharacter.Value = character
		bind.JoinTime.Value = jT
		bind.Parent = script.Binds

		local sD = {}
		sD.MaxStamina = 100
		sD.Stamina = sD.MaxStamina
		sD.Last = sD.Stamina
		sD.Regening = false
		sD.Code = math.random()
		sD.Checks = 0
		sD.MaxChecks = 3

		local vF = _G.GVF(character.Name)

		sD.RegenFunc = function()
			local amt = 1.35 	* 2
			sD.Regening = true
			while sD.Regening and character and character.Parent and not vF.Currents:FindFirstChild("NRG") do wait(0.1)
				if not sD then break end

				if vF and vF.Currents:FindFirstChild("2.39418") then
					sD.Stamina = 100
				else
					if sD.Stamina + amt > sD.MaxStamina then
						sD.Stamina = sD.MaxStamina
					else	
						sD.Stamina = sD.Stamina + amt
					end
				end

				sD.Last = sD.Stamina

				if sD.Stamina >= sD.MaxStamina then
					break
				end
			end
			if sD then
				sD.Regening = false
			end
		end

		sD.Changed = function(v)
			local cCode = math.random()
			if (v < sD.Last or (v < sD.MaxStamina and not sD.Regening)) and not vF.Currents:FindFirstChild("NRG") then
				sD.Code = cCode
				sD.Regening = false

				sD.Last = v

				delay((0 and vF and vF.Currents:FindFirstChild("2.39418")) or 0.5,function()
					if sD and sD.Code == cCode and not sD.Regening and not vF.Currents:FindFirstChild("NRG") then
						sD.Code = math.random()
						sD.RegenFunc()
					end					
				end)
			end
			sD.Last = sD.Stamina
		end

		sD.Check = function(v)
			v = v * 0.9

			if sD.Stamina - v >= 0 then
				sD.Stamina = sD.Stamina - v
				sD.Changed(sD.Stamina)
				return true
			elseif not (vF and vF.Currents:FindFirstChild("2.39418")) and not character:GetAttribute("__INFSTAM") then
				sD.Checks = sD.Checks + 1

				local k = false

				if sD.Checks >= sD.MaxChecks then
					k = true
					player:Kick("AE: Possible stamina exploit.")
				end

				delay(5,function()
					if plrStaminaData[player] then
						plrStaminaData[player].Checks = math.max(plrStaminaData[player].Checks - 1,0)
					end
				end)

				return not k
			else
				return true
			end
		end

		local c1,c2,c3

		if vF then
			c1 = vF.Currents.ChildAdded:Connect(function(c)
				if c.Name == "NRG" then
					sD.Code = math.random()
					sD.Regening = false
				end
			end)

			c2 = vF.Currents.ChildRemoved:Connect(function(c)
				if c.Name == "NRG" then
					sD.Changed(sD.Stamina)
				end
			end)
		end

		c3 = character.AncestryChanged:Connect(function(_,parent)
			if not parent then
				if c1 then
					c1:Disconnect()
				end
				if c2 then
					c2:Disconnect()
				end
				sD = nil
			end
		end)

		plrStaminaData[player] = sD

		--		local con = bind.AncestryChanged:Connect(function(_,parent)
		--			if not parent then
		--				ClearCharacterBind(player)
		--				con:Disconnect()
		--			end
		--		end)

		local nBind = require(bind)

		runningACs[player] = {bind,nBind,player}
		
		nBind.MainLoop(M.UpdateSpeed)
	end

	if player.Character ~= nil then
		--if not player:HasAppearanceLoaded() then
		--	--player.CharacterAppearanceLoaded:Wait()
		--end

		BindCharacter(player.Character)
	end

	player.CharacterAdded:Connect(BindCharacter)
end

--local function AntiChatExploit()
--	local characterLimit = 16384 --> Based on console
--	local counter = {} --> Counts issues from input
--	local counter2 = {} --> Counts issues from remote firing
--	local serverBanList = {} --> List of players banned from the server due to the exploit
--	local defaultMessage = "Abnormal activity was detected."


--	game.Players.PlayerAdded:Connect(function(player)
--		if table.find(serverBanList, player.UserId) then
--			player:Kick(defaultMessage)
--		else
--			counter[player.UserId] = 0 --> Number of times input would've caused an error
--			counter2[player.UserId] = {false, 0, 0} --> isTrackingCount, # of remotes sent by player in a second, # of "strikes"
--		end
--	end)


--	local ChatService = require(game.ServerScriptService:WaitForChild("ChatServiceRunner"):WaitForChild("ChatService"))
--	local eventListener = game:GetService('ReplicatedStorage').DefaultChatSystemChatEvents:WaitForChild('SayMessageRequest')

--	--> Detects if the message or channel inputs are abnormal
--	eventListener.OnServerEvent:Connect(function(plr, message, channel)
--		if counter2[plr.UserId] and not counter2[plr.UserId][1] then
--			coroutine.wrap(function() --> Start new thread so it doesn't wait for other "checkers"
--				counter2[plr.UserId][1] = true
--				wait(.5)
--				counter2[plr.UserId][1] = false
--				if counter2[plr.UserId][2] >= 7 then --> Arbitrary, feel free to change the 7.
--					counter2[plr.UserId][3] = 1 + counter2[plr.UserId][3]
--					if counter2[plr.UserId][3] > 1 then
--						plr:Kick(defaultMessage)
--						table.insert(serverBanList, plr.UserId)
--					end
--				end
--			end)()
--		elseif counter2[plr.UserId] then
--			counter2[plr.UserId][2] = counter2[plr.UserId][2] + 1
--		end
--		if not ChatService:GetChannel(channel) then
--			counter[plr.UserId] = counter[plr.UserId] + 1
--		end
--		if string.len(message) > characterLimit then
--			counter[plr.UserId] = counter[plr.UserId] + 2
--		end
--		if counter[plr.UserId] > 1 then
--			plr:Kick(defaultMessage)
--			table.insert(serverBanList, plr.UserId)
--		end
--	end)
--end

local function FireExploitLogs(logName,mode)
	local userId = PLAYERS:GetUserIdFromNameAsync(logName)

	if mode == 1 and expLogQueue[logName] then
		local desc = ""

		for _,v in pairs(expLogQueue[logName]) do
			local s = v[2] > 1 and "(x" .. tostring(v[2]) .. ") " or ""

			desc = desc .. " ||| \n" .. s .. v[1]

			if v[2] >= 10 then
				desc = desc .. "\n" .. "(MOREDAN10)"
			end
		end

		expLogQueue[logName] = nil

		--local l_success = logRemote:Invoke("ZKLFXG890ZDFGJKN43SU8IOG","ExploitLog",logName,"SERVER-LOG","Potential exploits with log info",desc)

		local banPlr = BanSystemM.new(userId)
		local success,didReportTimeout = banPlr:AddExploitLog(desc)
		banPlr:Destroy()
	elseif mode == 2 and expLogQueue2[logName] then
		local desc = ""

		for _,v in pairs(expLogQueue2[logName]) do
			local s = v[2] > 1 and "(x" .. tostring(v[2]) .. ") " or ""

			desc = desc .. "\n" .. s .. v[1]

			if v[2] >= 10 then
				desc = desc .. "\n" .. "(MOREDAN10)"
			end
		end

		local l_success = logRemote:Invoke("ZKLFXG890ZDFGJKN43SU8IOG","ExploitLog",logName,"MOVEMENT-LOG","Triggered movement AC multiple times",desc,"Movement")

		expLogQueue2[logName] = nil		
	elseif mode == 3 and expLogQueue3[logName] then
		local desc = ""

		for _,v in pairs(expLogQueue3[logName]) do
			local s = v[2] > 1 and "(x" .. tostring(v[2]) .. ") " or ""

			desc = desc .. "\n" .. s .. v[1]

			if v[2] >= 10 then
				desc = desc .. "\n" .. "(MOREDAN10)"
			end
		end

		local l_success = logRemote:Invoke("ZKLFXG890ZDFGJKN43SU8IOG","ExploitLog",logName,"POORON-LOG","Pooron triggered anti dupe",desc,"Dupe")

		expLogQueue3[logName] = nil		
	end
end

local function UnbindPlayer(player)

	if expLogQueue[player.Name] then
		FireExploitLogs(player.Name,1)
	end
	if expLogQueue2[player.Name] then
		FireExploitLogs(player.Name,2)
	end
	if expLogQueue3[player.Name] then
		FireExploitLogs(player.Name,3)
	end

	PlrData[player] = nil
	DBs[player.UserId] = nil
	DBs2[player.UserId] = nil
	ClearCharacterBind(player)
end

local function QueueExploitLog(code,logName,logDesc,mode,x)
	if code ~= "ZKLFXG890ZDFGJKN43SU8IOG" then return end

	local exploitPlr = PLAYERS:FindFirstChild(logName)
	if exploitPlr then
		local pd = _G.GetPlayerData and _G.GetPlayerData(exploitPlr)

		if not pd then return end
		if pd and not pd.DataLoaded.Value then return end
		
		if string.find(logDesc,"Attempted to spam equip item") or string.find(logDesc,"Client Not Responding [>300 seconds]") or string.find(logDesc,"Client hasn't checked in >5 minutes") or string.find(logDesc,"Chatting too quickly") or string.find(logDesc,"Client Not Responding") then
			return
		end
		
		warn("exploitlog: " .. tostring(logName) .. ": " .. logDesc,mode)
		
		if mode == 1 and not x then
			--if string.find(string.lower(logDesc),"exploit detected") or string.find(string.lower(logDesc),"tamper protection") or string.find(string.lower(logDesc),"tampering with client") or string.find(string.lower(logDesc),"traceless") or string.find(string.lower(logDesc),"scriptcontext") or string.find(string.lower(logDesc),"tamper") or string.find(string.lower(logDesc),"tampering") or string.find(logDesc,"Local userID does not match server userID") or string.find(logDesc,"Local username does not match server username") or string.find(logDesc,"Exploit detected") then
			--	if not DBs[exploitPlr] then
			--		DBs[exploitPlr] = true
			--		delay(1200,function()
			--			DBs[exploitPlr] = nil
			--		end)

			--		--M.BanPlayer(exploitPlr,1000,"AC: " .. logDesc,true,true)
					
			--		local id
			--		pcall(function ()
			--			id = game:GetService("Players"):GetUserIdFromNameAsync(logName)
			--		end)
					
			--		if id then
			--			local fullT = "AC: " .. logDesc
			--			local banPlr = BanSystemM.new(id)
			--			banPlr:AntiBan(fullT,1000)
			--			banPlr:Destroy()
			--		end
			--	end
			--	return
			--end
		end
	end

	if mode == 1 then
		if not expLogQueue[logName] then
			expLogQueue[logName] = {}

			if not expLogQueue[logName][logDesc] then
				expLogQueue[logName][logDesc] = {logDesc,1}
			else
				expLogQueue[logName][logDesc] = {logDesc,expLogQueue[logName][logDesc][2] + 1}
			end	

			local con

			delay(1201,function()
				if con then
					con:Disconnect()
					con = nil
				end
				FireExploitLogs(logName,mode,1)
			end)


			--if exploitPlr then
			--	con = exploitPlr.AncestryChanged:Connect(function(_,parent)
			--		if not parent then
			--			con:Disconnect()
			--			FireExploitLogs(logName,mode)
			--		end
			--	end)
			--end
		else
			if not expLogQueue[logName][logDesc] then
				expLogQueue[logName][logDesc] = {logDesc,1}
			else
				expLogQueue[logName][logDesc] = {logDesc,expLogQueue[logName][logDesc][2] + 1}
			end		
		end
	elseif mode == 2 then
		if not expLogQueue2[logName] then
			expLogQueue2[logName] = {}

			if not expLogQueue2[logName][logDesc] then
				expLogQueue2[logName][logDesc] = {logDesc,1}
			else
				expLogQueue2[logName][logDesc] = {logDesc,expLogQueue2[logName][logDesc][2] + 1}
			end	

			local con

			delay(1201,function()
				if con then
					con:Disconnect()
					con = nil
				end
				FireExploitLogs(logName,mode)
			end)


			--if exploitPlr then
			--	con = exploitPlr.AncestryChanged:Connect(function(_,parent)
			--		if not parent then
			--			con:Disconnect()
			--			FireExploitLogs(logName,mode)
			--		end
			--	end)
			--end
		else
			if not expLogQueue2[logName][logDesc] then
				expLogQueue2[logName][logDesc] = {logDesc,1}
			else
				expLogQueue2[logName][logDesc] = {logDesc,expLogQueue2[logName][logDesc][2] + 1}
			end		
		end	
	elseif mode == 3 then
		if not expLogQueue3[logName] then
			expLogQueue3[logName] = {}

			if not expLogQueue3[logName][logDesc] then
				expLogQueue3[logName][logDesc] = {logDesc,1}
			else
				expLogQueue3[logName][logDesc] = {logDesc,expLogQueue3[logName][logDesc][2] + 1}
			end	

			local con

			delay(1201,function()
				if con then
					con:Disconnect()
					con = nil
				end
				FireExploitLogs(logName,mode)
			end)


			--if exploitPlr then
			--	con = exploitPlr.AncestryChanged:Connect(function(_,parent)
			--		if not parent then
			--			con:Disconnect()
			--			FireExploitLogs(logName,mode)
			--		end
			--	end)
			--end
		else
			if not expLogQueue3[logName][logDesc] then
				expLogQueue3[logName][logDesc] = {logDesc,1}
			else
				expLogQueue3[logName][logDesc] = {logDesc,expLogQueue3[logName][logDesc][2] + 1}
			end		
		end	
	end
end

local function OnFakeEvent(p,e,a1,a2,a3,a4,a5)
	if not PlrData[p] then return end
	local pd = _G.GetPlayerData(p)
	
	if not pd then return end
	if pd and not pd.DataLoaded.Value then return end
	
	if DBs[p.UserId] then
		return
	end
	if AdminCheck(p) then return end

	DBs[p.UserId] = true
	
	local strin = "N/A"
	
	local function GetS()
		local function SL(a)
			local ns = repr(a)
			ns = tostring(ns)
			if string.len(ns) > 100 then
				return "||>100C||"
			else
				return ns
			end
		end

		a1 = SL(a1)
		a2 = SL(a2)
		a3 = SL(a3)
		a4 = SL(a4)
		a5 = SL(a5)

		local tz = {a1,a2,a3,a4,a5}

		local s = ""
		for i,v in pairs(tz) do
			if v ~= nil and v ~= "nil" then
				s = s .. v

				if i <#tz then
					s = s .. ",\n"
				end
			end
		end
		
		strin = s
	end
	
	pcall(GetS)

	local fullT = "Fired Honeypot: " .. '"' .. e.Name .. '" | args: \n' .. strin
	local banPlr = BanSystemM.new(p.UserId)
	banPlr:AntiBan(fullT,3000)
	banPlr:Destroy()
end

local function OnFakeEvent2(p,a1,a2,a3)
	if not PlrData[p] then return end
	local pd = _G.GetPlayerData(p)

	if not pd then return end
	if pd and not pd.DataLoaded.Value then return end
	
	if DBs[p.UserId] or not DBs2[p.UserId] then
		return
	end
	
	if DBs2[p.UserId] > 20 then
		p:Kick("ASCLI: Unexpected critical error [data malformed?]")
		return
	end
	
	if AdminCheck(p) then return end
	
	local strin = "N/A"

	local function GetS()
		local function SL(a)
			local ns = repr(a)
			ns = tostring(ns)
			if string.len(ns) > 100 then
				return "||>100C||"
			else
				return ns
			end
		end
		
		if type(a3) == "table" then
			local tz = {}
			
			for _,v in pairs(a3) do
				--if typeof(v) == "string" then
					v = Decrypt(6981,v)
				--end
				table.insert(tz,SL(v))
			end

			local s = ""
			for i,v in pairs(tz) do
				if v ~= nil and v ~= "nil" then
					s = s .. v

					if i <#tz then
						s = s .. ", "
						--\n"
					end
				end
			end

			strin = s
		end
	end

	pcall(GetS)
	
	warn("ATTEMPTED FAKEVENT2",p,a1,a2,a3)
	
	DBs2[p.UserId] = DBs2[p.UserId] + 1
	delay(30,function()
		if DBs2[p.UserId] then
			DBs2[p.UserId] = DBs2[p.UserId] - 1
		end
	end)
	
	if a1 ~= "Z_Z" or a2 == true then
		DBs[p.UserId] = true
		local fullT = "Client tamper: " .. strin
		local banPlr = BanSystemM.new(p.UserId)
		banPlr:AntiBan(fullT,3000)
		banPlr:Destroy()
	else
		QueueExploitLog("ZKLFXG890ZDFGJKN43SU8IOG",p.Name,"Client tamper: " .. strin,1,true)
	end
end

local function HandleHoneyPots()
	for _,v in pairs(M.HoneyPots.Events) do
		local e = Instance.new("RemoteEvent")
		e.Name = v
		e.Parent = EVENTS
		e.OnServerEvent:Connect(function(p,...)
			OnFakeEvent(p,e,...)
		end)
	end
	
	for _,v in pairs(M.HoneyPots.Remotes) do
		local e = Instance.new("RemoteFunction")
		e.Name = v
		e.Parent = EVENTS
		e.OnServerInvoke = function(p,...)
			OnFakeEvent(p,e,...)
		end
	end
end

M.AntiPingCheck = function(plr,a1,a2,a3,a4,a5)
	if a1 == "GetPing" then
		if AdminCheck(plr) then
			return math.random(8500,13500) / 100
		else
			return math.random(14000,20000) / 100
		end		
	else
		OnFakeEvent(plr,EVENTS.GetPingR,a2,a3,a4,a5)
	end
end

local function MainUpdateLoop()
	for _,tab in pairs(runningACs) do
		local Success,Error = pcall(function()
			local bind,nBind = tab[1],tab[2]
			nBind.MainLoop(M.UpdateSpeed)
		end)
		if not Success and tab[4] then
			warn("AC Error: " .. tab[4].Name,Error)
		end
	end
end

M.SetUp = function()
	if _SU then return end
	_SU = true
	
	_G.RunningAAs = {}
	_G.RAC_CHECK = function(code,player)
		if code ~= "89RWE89SDFJWEP[O2398" then return end

		local rac = runningACs[player] and runningACs[player][1] and runningACs[player][1].Parent and runningACs[player][2]

		if rac then
			if rac.IsBeingPunished then
				return false
			else
				return rac.Check(M.UpdateSpeed)
			end
		else
			return true
		end
	end
	
	if not workspace.Debris:FindFirstChild("NParts") then
		local np = Instance.new("Folder")
		np.Name = "NParts"
		np.Parent = workspace.Debris
	end

	if M.TESTING then
		M.RequestRate = 1000000000
		config.MinJoinTime = 1;
	end
	
	if config.DiagnosticsEnabled then
		script.Prefabs.FJsMovementAnticheatStatsGui.Parent = game:GetService("StarterGui")
	end

	Remote.OnServerEvent:Connect(function(p, d)
		local Dt = getDt(p, tonumber(d) or 0)
		local get = PlrData[p]

		if not get then return end

		local x = false

		if Dt < M.MaxDt then
			x = true
			PlrData[p] = {p,M.RequestRate,get[3]}
		end

		if not x then
			warn(p,Dt,M.MaxDt)
		end
	end)

	for _,v in pairs(PLAYERS:GetPlayers()) do
		BindPlayer(v)
	end
	PLAYERS.PlayerAdded:Connect(BindPlayer)
	PLAYERS.PlayerRemoving:Connect(UnbindPlayer)
	staminaFunction.OnInvoke = StaminaCheck

	--coroutine.wrap(function()
	--	while wait(M.UpdateSpeed) do
		
	--	end
	--end)()

	coroutine.wrap(function()
		while wait(M.RequestRate + 1.5) do
			for i,v in pairs(PLAYERS:GetPlayers()) do
				if AdminCheck(v) then return end
				local pd2 = PlayerbaseData2:FindFirstChild(v.Name)
				if not pd2 or not pd2.Loaded.Value then return end
				if PlrData[v] and tick() - PlrData[v][3] >= config.MinJoinTime then
					PlrData[v][2] = PlrData[v][2] - 1
					if PlrData[v][2] < 0 then
						v:Kick('Out of sync.')
						warn(v.Name .. " was kicked for out of sync")
					end
				end
			end
		end
	end)()
	
	HandleHoneyPots()
	
	EVENTS.GetPingR.OnServerInvoke =	M.AntiPingCheck
	EVENTS["0924023902330"].OnServerEvent:Connect(OnFakeEvent2)
	EVENTS3.ANTUUBNA.OnInvoke =		M.UnbanPlayer

	EVENTS3.qUE_exPOTLOG.Event:Connect(QueueExploitLog)
	
	EVENTS3.SDHSDDOWON.Event:Connect(function(code)
		if code ~= "DKLSD904U99IW4MKLSDFFW90ERF4IO3FIJ4890FWF043M4390MFRW9E0M0FS" then return end
		
		for i,v in pairs(expLogQueue) do
			FireExploitLogs(i,1)
		end
		for i,v in pairs(expLogQueue2) do
			FireExploitLogs(i,2)
		end
		for i,v in pairs(expLogQueue3) do
			FireExploitLogs(i,3)
		end
	end)
	
	spawn(function()
		while true do
			task.wait(0.8)
			pcall(MainUpdateLoop)
		end
	end)

	--local AntiBanner
	--local CmdLogHandler

	--coroutine.wrap(function()
	--	AntiBanner = require(modules.AntiBanner)
	--end)()
	--coroutine.wrap()
	--	CmdLogHandler = require(modules.CmdLogHandler)
	--end)()	
end

M.MainLoop = function()
	--MainUpdateLoop()
end


return M