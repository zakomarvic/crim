repeat task.wait() until (_G.ClientLoaded == true or game.Players.LocalPlayer.Character ~= nil) and (game:IsLoaded())
task.wait(0.5)
-- Cmdr

local Cmdr = require(game:GetService("ReplicatedStorage"):WaitForChild("CmdrClient"))
Cmdr:SetActivationKeys({ Enum.KeyCode.F2 })
print("Cmdr Client Ran!")
-- End