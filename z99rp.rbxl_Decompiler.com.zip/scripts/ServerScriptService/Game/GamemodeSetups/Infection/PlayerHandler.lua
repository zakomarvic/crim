local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local TS = game:GetService("TweenService")
local MemoryStoreService = game:GetService("MemoryStoreService")
local DatastoreService = game:GetService("DataStoreService")

local M = {}
M.__index = M

local PlayerbaseData = ServerStorage:WaitForChild("PlayerbaseData")
local PlayerbaseData2 = ReplicatedStorage:WaitForChild("PlayerbaseData2")

local CreateViewportCharacterM = require(ServerStorage.Modules.Other.CreateViewportCharacter)

local DEFAULT_ROUND_DATA = {
	Kills = 0;
	Assists = 0;
	Profit = 0;
}

local DEFAULT_TEMP_DATA = {
	Cash = 0;
}

local WINS_KEY = "WinKey_1";
local ROUNDS_PLAYED_KEY = "RoundsPlayedKey.1"
local TOTAL_KILLS_KEY = "KillsKey.1"

local DEFAULT_MAINSAVE_DATA = {
	LastPlayed = 0;
	
	--RoundsPlayed = 0;
	--TotalKills = 0;
	--TotalAssists = 0;
	--TotalProfit = 0;
	--TotalSpendings = 0;
	
	OtherStats = {
		RoundsPlayed = 0;
		TotalKills = 0;
		TotalAssists = 0;
		TotalProfit = 0;
		TotalCashSpent = 0;
		RobuxSpent = 0;
	};
	
	Wins = 0;
	Tokens = {
		Juggernaut = 0;
		RayGun = 0;
		UTS_15 = 0;
		PrecisionStrike = 0;
		BecomeHunter = 0;
		BecomeBrute = 0;
		BecomeSpitter = 0;
	}; -- juggernaut tokens
	
	GiftedTokens = {};
}

local function Lerp(a, b, c)
	return a + ((b - a) * c)
end

local deepCopy = require(ReplicatedStorage.Modules.DeepCopy)

function M:LoadCharacter(v,...)
	ServerStorage.Events3.LoadCharacter:Invoke(v,...)
end

function M:DoEndScreen(winResult,endMusic,delayT)
	local endData = {
		desc = "Survived until 6 AM";
		descColor3 = Color3.new(1,1,1);
		
		winner = "Survivors";

		leaderstats = {
		};
	};
	
	if winResult == "Survivors" then
		endData.desc = "Survived The Night"
		endData.descColor3 = Color3.fromRGB(192, 255, 213)
	else
		endData.desc = "Survived Until " .. self.I.values.desc.Value
		endData.descColor3 = Color3.fromRGB(255, 190, 191)
	end
	
	workspace.Audio.UndergroundAmbience.Volume = 0

	for v,data in pairs(self.activePlayers) do
		local _s,_e = pcall(function()
			if data.roundData then
				local d = data.roundData
				
				if winResult == "Survivors" and self.aliveHumans[v] then
					d.wasWinner = true
					d.Profit += self.Config.WinCash_Humans
				elseif winResult == "Infected" and table.find(self.originalInfected,v) then
					d.originalInfected = true
					d.Profit += self.Config.WinCash_OriginalInfected
				end
				
				local spends = ServerStorage.Events3.GetShopSpends:Invoke(v)
				
				if spends then
					spends = math.floor(spends)
					d.Profit -= spends
				end
				
				d.Profit = math.min(math.floor(d.Profit),M.GetCashCap(self,v))
				
				endData.leaderstats[v.Name] = d

				data.SaveData.OtherStats.TotalProfit += d.Profit
				data.SaveData.OtherStats.TotalCashSpent += spends
				data.SaveData.OtherStats.TotalKills += math.floor(data.roundData.Kills)
				data.SaveData.OtherStats.TotalAssists += math.floor(data.roundData.Assists)
				data.SaveData.OtherStats.RoundsPlayed +=1
				
				data.DataChanged = true
				
				self.activePlayers[v] = data
			end

			if v.Character then
				local ff = Instance.new("ForceField")
				ff.Visible = false
				ff.Parent = v.Character

				local hum = v.Character:FindFirstChild("Humanoid")
				if hum then
					hum:SetAttribute("NoAutoEquip",true)
					
					hum:UnequipTools()
				end

				_G.AffectChar(v.Character,"B",25)
				_G.AffectChar(v.Character,"AC",25)
				_G.AffectChar(v.Character,"AS",25)
			end
		end)
		
		if not _s then
			warn("S EndSequence Error:",_e)
		end
	end	
	
	--print("server do end screen")
	
	self.I.eventsFolder.EndSequence:FireAllClients(endData,endMusic,delayT)
end

function M:ResetAllRoundData()
	--print("reset all round data")
	for v,data in pairs(self.activePlayers) do
		if v and v.Parent and typeof(data) == "table" then
			data.roundData = deepCopy(DEFAULT_ROUND_DATA)
			self.activePlayers[v] = data
		end
	end
end

function M:UpdateActivePlayer(plr)
	local data = self.activePlayers[plr]
	if not data then return end
	
	--if data.SaveData.JugTokens > 0 then
	--	plr:SetAttribute("ShopProductClaim_Juggernaut",true)
	--else
	--	plr:SetAttribute("ShopProductClaim_Juggernaut",nil)
	--end
	
	for i,v in pairs(data.SaveData.Tokens) do
		local n = "ShopProductClaim_" .. i
		plr:SetAttribute(n,v > 0 and true or nil)
	end
end

function M:ClearHumanCons()
	for i,v in pairs(self.monitorSurvivorCons) do
		pcall(function()
			v:Disconnect()
		end)
	end
	
	for v,_ in pairs(self.activePlayers) do
		if v and v.Parent then
			v:SetAttribute("WasResurrected",nil)
		end
	end
	
	self.monitorSurvivorCons = {}
end

function M:GetActivePlayerCount()
	local n = 0
	for i,v in pairs(self.activePlayers) do
		n += 1
	end
	return n
end

function M:GetHumanCount()
	local n = 0
	for i,v in pairs(self.aliveHumans) do
		n += 1
	end
	
	if self.Config.NoGameOver then
		n = math.max(n,1)
	end
	
	return n
end

function M:SwitchTeams(plr,teamName)
	local team = self.teams[teamName]
	plr.Team = team
	plr.TeamColor = team.TeamColor
end

function M:GetCashCap(plr)
	return (plr and plr:GetAttribute("CashCap")) or self.Config.CashCap
end

function M:SetStarterCash(plr)
	if not plr:GetAttribute("CashCap") then
		plr:SetAttribute("CashCap",self.Config.CashCap)
	end
	
	local pd = PlayerbaseData:FindFirstChild(plr.Name)
	
	M.RefundPlayer(self,plr)
		
	if pd then
		if pd.Cash.Value < self.Config.StartingCash then
			local c = self.Config.StartingCash - pd.Cash.Value
			ServerStorage.Events3.nMonee:Fire("IU3898EJKLOY89TYZJDKLJGYI390WKHJSDHG9UKLJLEDGKLJERG9U",plr,"Cash",c)
		elseif pd.Cash.Value > M.GetCashCap(self,plr) then
			ServerStorage.Events3.SSetMoney:Fire("GERIJO340934923409I2IJOIFI",plr,"Cash",M.GetCashCap(self,plr))
		end
	end
end

function M:RefillAllAmmo()
	for v,_ in pairs(self.activePlayers) do
		local _s,_e = pcall(function()
			local hum = v.Character and v.Character:FindFirstChild("Humanoid")
			if hum then
				hum:UnequipTools()
				task.wait()
			end
			for i,t in pairs(v.Backpack:GetChildren()) do
				if t:IsA("Tool") and t:FindFirstChild("Values") then
					if t.Values:FindFirstChild("StoredAmmo") then
						t.Values.StoredAmmo.Value = t.Values.StoredAmmo.MaxValue
						t.Values.SERVER_StoredAmmo.Value = t.Values.SERVER_StoredAmmo.MaxValue
					end
					if t.Values:FindFirstChild("Ammo") then
						t.Values.Ammo.Value = t.Values.Ammo.MaxValue
						t.Values.SERVER_Ammo.Value = t.Values.SERVER_Ammo.MaxValue
					end

					if t.Values:FindFirstChild("SyncEvent") then
						t.Values.SyncEvent:Fire()
					end
				end
			end
		end)
		
		if not _s then
			warn("RefillAllAmmo error:",_e)
		end
	end
end

function M:GrantHourCash(plr,am)
	local cash = self.Config.StartHourCash
	
	if am ~= 12 then
		for i = 1, am do
			cash += self.Config.AddHourCash
		end
	end
	
	local tab = {
		Title = "Hour Grant";
		Text = "Granted $" .. tostring(cash) .. " for surviving the hour";
		Duration = 5;
	}
	
	local roundData = self.activePlayers[plr].roundData
	roundData.Profit += cash
	self.activePlayers[plr].roundData = roundData

	ReplicatedStorage.Events.Notification:FireClient(plr,tab,"BEEP")	
	ServerStorage.Events3.nMonee:Fire("IU3898EJKLOY89TYZJDKLJGYI390WKHJSDHG9UKLJLEDGKLJERG9U",plr,"Cash",cash)
end

function M:IncreaseWins(plr)
	local lStats = plr:FindFirstChild("leaderstats")
	
	if self.activePlayers[plr] then
		local data = self.activePlayers[plr]
		
		data.SaveData.Wins += 1
		
		if not data.SaveData.LeaderboardWins then
			data.SaveData.LeaderboardWins = {}
		end
		if not data.SaveData.LeaderboardWins[self.Config.Leaderboards.WinsKey] then
			data.SaveData.LeaderboardWins[self.Config.Leaderboards.WinsKey] = 0
		end
		
		data.SaveData.LeaderboardWins[self.Config.Leaderboards.WinsKey] += 1
		
		self.activePlayers[plr] = data
		
		if lStats then
			lStats.Wins.Value = data.SaveData.Wins
		end
		
		spawn(function()
			local ap_d = self.activePlayers[plr] and deepCopy(self.activePlayers[plr])
			local ah_d = self.aliveHumans[plr] and deepCopy(self.aliveHumans[plr])

			self.savingDataPlayers[plr.UserId] = true
			
			local pd = PlayerbaseData:FindFirstChild(plr.Name)

			M.SaveMainData(self,plr,pd,ap_d,ah_d)
			self.savingDataPlayers[plr.UserId] = nil
		end)
	end
end

function M:Resurrect(plr,char)
	local hum = char and char:FindFirstChild("Humanoid")
	if not hum then return end
	if hum:GetState() ~= Enum.HumanoidStateType.Dead then return end
	
	local root = char.HumanoidRootPart
	local rootCF = root.CFrame
	
	M.SwitchTeams(self,plr,"Infected")
	
	char:SetAttribute("IsInfected",true)
	char:SetAttribute("WillResurrect",true)
	plr:SetAttribute("WasResurrected",true)

	local armor = {}
	for i,v in pairs(char:GetChildren()) do
		if v:IsA("Folder") 
			and ServerStorage.Tools:FindFirstChild(v.Name) 
			and ServerStorage.Tools[v.Name]:GetAttribute("TSH_IsVest") == true 
		then
			table.insert(armor,ServerStorage.Tools[v.Name])
		end
	end
	
	plr:SetAttribute("ForceRandomAvatar",nil)
	
	local setRespawnTime = math.random(self.Config.InfectedRager.RespawnTime[1] * 10,self.Config.InfectedRager.RespawnTime[2] * 10) / 10
	plr:SetAttribute("RespawningPaused",true)
	task.delay(setRespawnTime,function()
		if plr and plr.Parent then
			plr:SetAttribute("RespawningPaused",nil)
		end
	end)
	
	task.delay(1,function()
		plr:SetAttribute("ForceRandomAvatar",nil)
	end)
	
	local charAdded = false
	task.spawn(function()
		repeat
			if root and root.Parent then
				rootCF = root.CFrame
			end
			
			task.wait(0.2)	
		until charAdded or not plr.Parent or not root.Parent
	end)
	
	
	plr.CharacterAdded:Wait()
	
	charAdded = true
	
	hum = nil
	char = nil
	
	local nChar = plr and plr.Parent and plr.Character

	if nChar and self.gMode == "game" and not self.gameEnding then
		plr.RespawnLocation = nil
		
		local newHumanoid = nChar:FindFirstChildOfClass("Humanoid");
		local newPrimary = nChar.PrimaryPart or (newHumanoid and newHumanoid.RootPart)
		
		if newHumanoid and newPrimary then
			local ff = Instance.new("ForceField")
			game.Debris:AddItem(ff,0.25)
			ff.Visible = false
			ff.Parent = nChar
			
			if plr then
				local cd = {}
				cd.killer = "[INFECTION]"
				cd.weapon = nil
				cd.distance = nil
				_G.CombatTagChar(plr,20,"RESURRECT" .. math.random(),nil,cd)
			end
			
			nChar:SetAttribute("NoNeckMovement",true)
			
			newHumanoid:SetAttribute("DontChangeHP",true)
			newHumanoid:SetAttribute("NoRandomAvatar",true)
			
			newHumanoid:SetAttribute("IsRagerInfected",true)

			newHumanoid:SetAttribute("NoAutoEquip",true)
			newHumanoid:UnequipTools()
			
			newHumanoid.MaxHealth = self.Config.InfectedRager.StartHP + 15
			newHumanoid.Health = newHumanoid.MaxHealth
			
			if _G.cTag then
				_G.cTag(nChar,"RE",2)
			end
			task.wait(); -- Let it finish loading character contents
			
			local forcefield = nChar:FindFirstChildOfClass("ForceField")
			if forcefield then
				forcefield:Destroy()
			end
			
			if armor then
				for i,v in pairs(armor) do
					v:Clone().Parent = nChar
				end
			end
			
			if newPrimary then
				local x, y, z = rootCF:ToEulerAnglesYXZ()
				
				newPrimary.CFrame = CFrame.new(rootCF.Position + Vector3.new(0,4,0)) * CFrame.Angles(0,y,0)
			else
				pcall(function()
					_G.cTag(newHumanoid,"CTP",1)
				end)
				nChar:MoveTo(rootCF.Position + Vector3.new(0,4,0))
			end
			
			local riseTime = self.Config.InfectedRager.RiseTime
			
			local anim = script.ResurrectAnim:Clone()
			anim.Parent = newHumanoid
			anim = newHumanoid:LoadAnimation(anim)
			anim:Play(0)
			
			newHumanoid.Died:Connect(function()
				if nChar.Parent and nChar:FindFirstChild("Head") then
					local s = self.audioF.RagerDeath:Clone()
					s.PlaybackSpeed *= (math.random(90,110) / 100)
					s.Parent = nChar.Head
					s:Play()
				end
			end)
			
			spawn(function()
				if newHumanoid.Parent then
					newHumanoid.MaxHealth = self.Config.InfectedRager.StartHP + 15
					newHumanoid.Health = newHumanoid.MaxHealth
					
					local vf = _G.GVF(nChar.Name)
					if vf then
						vf.NoRagdoll.Value = true
					end
					
					local t = tick()
					while newHumanoid.Parent and newHumanoid.Health > 0 and tick() - t < riseTime do
						newHumanoid.Health += self.Config.InfectedRager.RegenRate
						task.wait(0.1)
					end
				end
			end)
			
			delay(0.2,function()
				if nChar and nChar.Parent and nChar:FindFirstChild("ZombieSounds") then
					nChar.ZombieSounds:Destroy()
				end
			end)
			
			delay(0,function()
				if newHumanoid and newHumanoid.Parent and newHumanoid.Health > 0 then
					local s = self.audioF.RagerRise:Clone()
					s.PlaybackSpeed *= (math.random(90,110) / 100)
					s.Parent = nChar.Head
					s:Play()
				end
			end)
			
			local nms = {}
			
			table.insert(nms,_G.AffectChar(nChar,"CM",math.huge))
			table.insert(nms,_G.AffectChar(nChar,"JR",math.huge,"WKVL2",1000))
			table.insert(nms,_G.AffectChar(nChar,"AC",math.huge))
			table.insert(nms,_G.AffectChar(nChar,"AS",math.huge))
			table.insert(nms,_G.AffectChar(nChar,"B",math.huge))
			
			
			delay(riseTime,function()
				if nChar and nChar.Parent and newHumanoid and newHumanoid.Parent and newHumanoid.Health > 0 then
					for i,v in pairs(nms) do
						if v and v.Parent then
							v:Destroy()
						end
					end
					
					local vf = _G.GVF(nChar.Name)
					if vf then
						vf.NoRagdoll.Value = false
					end
					
					newHumanoid.MaxHealth = self.Config.InfectedRager.HP + 15
					newHumanoid.Health = newHumanoid.MaxHealth
					
					nChar:SetAttribute("NoNeckMovement",nil)
					
					local vF = _G.GVF(nChar.Name)
					
					local poisV = Instance.new("NumberValue")
					game.Debris:AddItem(poisV,4)
					poisV.Name = "POIZSKRATA"
					--poisV:SetAttribute("NoIcon",true)
					poisV.Value = 0
					TS:Create(poisV,TweenInfo.new(9,Enum.EasingStyle.Quart,Enum.EasingDirection.In),{Value = 1}):Play()
					poisV.Parent = vF.Currents
					
					newHumanoid:SetAttribute("NoAutoEquip",nil)

					local zf = plr.Backpack:FindFirstChild("__ZombieFists1")
					
					if zf then
						delay(0,function()
							if newHumanoid and not newHumanoid:GetAttribute("NoAutoEquip") and _G.CheckIfCan(char) then
								hum:EquipTool(zf)
							end
							spawn(function()
								while newHumanoid and newHumanoid.Parent and newHumanoid.Health > 0 do
									if zf.Parent and zf.Parent ~= char and not newHumanoid:GetAttribute("NoAutoEquip") and _G.CheckIfCan(char) then
										newHumanoid:EquipTool(zf)
									end
									task.wait(0.35)
								end
							end)
						end)
					end
					
					local rage = ServerStorage.Storage.Scripts.RageScript:Clone()
					rage.DMM.Value = self.Config.InfectedRager.Rage_DMM
					rage.SM.Value = self.Config.InfectedRager.Rage_SM
					rage.LastTime.Value = self.Config.InfectedRager.Rage_LastTime
					
					local color = Color3.fromRGB(255, 181, 53)
					
					rage.EyeParticle.Color = ColorSequence.new{
						ColorSequenceKeypoint.new(0, color),
						ColorSequenceKeypoint.new(1, color)
					}
					rage.RageParticle.Color = ColorSequence.new{
						ColorSequenceKeypoint.new(0, color),
						ColorSequenceKeypoint.new(1, color)
					}
								
					rage.Disabled = false
					rage.Parent = nChar	
					
					delay(self.Config.InfectedRager.Rage_DelayTime + self.Config.InfectedRager.Rage_LastTime,function()
						if nChar and nChar.Parent then
							local pois = ServerStorage.Tools.POISON_HANDLER:Clone()
							pois.Uncureable.Value = true
							pois.InstantStart.Value = true
							pois.Disabled = false
							pois.Parent = nChar
						end
					end)
					
					delay(self.Config.InfectedRager.Rage_DelayTime,function()
						if newHumanoid.Parent then
							local t = tick()
							repeat
								newHumanoid:TakeDamage(self.Config.InfectedRager.Rage_DamageAmt)
								task.wait(self.Config.InfectedRager.Rage_DamageTick)
							until not newHumanoid.Parent or newHumanoid.Health <= 0 or tick() -t >= (self.Config.InfectedRager.Rage_LastTime + 1)

							if newHumanoid and newHumanoid.Parent then
								newHumanoid:TakeDamage(10000)
								newHumanoid.Health = 0
							end
						end
					end)
				end
			end)
		end
		plr:SetAttribute("ForceRandomAvatar",true)
	end
end

function M:ZombifyKill(plr,char)
	local hum = char and char:FindFirstChild("Humanoid")
	if not hum then return end
	if plr.Team ~= self.teams.Survivors then return end
	
	local spends = ServerStorage.Events3.GetShopSpends:Invoke(plr)
	if spends then
		self.activePlayers[plr].spends = spends
	end
	
	local pH = ServerStorage.Tools.POISON_HANDLER:Clone()
	pH.InstantStart.Value = true
	pH.RefreshDiv.Value = 4
	pH.DamageMulti.Value = 1.2
	
	local anim = script.CoughAnim:Clone()
	anim.Parent = hum
	
	anim = hum:LoadAnimation(anim)
	anim:Play(0.1)
	
	hum:SetAttribute("WasZombified",true)
	
	_G.AffectChar(char,"SP",math.huge,"WKVL1",0.2)
	_G.AffectChar(char,"JR",math.huge,"WKVL1",1000)
	_G.AffectChar(char,"AS",math.huge,"WKVL1",0.2)
	
	pH.Parent = char
	
	plr:SetAttribute("NoRespawnUI",true)
	
	hum:UnequipTools()
	_G.AffectChar(char,"B",math.huge)
	
	delay(15,function()
		if char and char.Parent and hum and hum.Parent and hum.Health > 0 then
			hum:TakeDamage(1000)
			hum.Health = 0
		end
		
		task.wait(5)
		
		if plr.Character == char then
			plr:SetAttribute("NoRespawnUI",nil)
		end
	end)
end

function M:MonitorHuman(player)
	if player.Character and player.Character:FindFirstChild("Humanoid") and player.Character.Humanoid.Health > 0 
		--and 
	then
		local char = player.Character
		local hum = player.Character:FindFirstChild("Humanoid")

		local ded = false
		local function OnDied()
			if ded then return end
			ded = true
			
			self.aliveHumans[player] = nil
			if self.gMode == "game" or self.gMode == "commencing" then
				
				M.SwitchTeams(self,player,"Infected")
				--self.I.eventsFolder.PlaySound:FireAllClients("boom")
			end
			
			if char and char.Parent then
				if char:FindFirstChild("Head") then
					local ds = self.audioF.DeathSounds:GetChildren()[math.random(1,#self.audioF.DeathSounds:GetChildren())]:Clone()
					game.Debris:AddItem(ds,10)

					local v = Instance.new("BoolValue")
					v.Name = "Vocal2"
					v.Parent = ds

					ds.Name = "DeathSound"

					ds.Parent = char.Head
					ds:Play()
				end
			end
			
			local displayName = (player.Character and player.Character:FindFirstChild("Humanoid") and player.Character.Humanoid.DisplayName) or "[REDACTED]"
			local tab = {
				Title = "INFECTED";
				Text = displayName .. " has been infected";
				Duration = 5;
			}
			--if isReady then
			--	tab.Icon = content
			--end

			local fakeChar = CreateViewportCharacterM(player)
			tab.ViewportIcon = fakeChar

			ReplicatedStorage.Events.Notification:FireAllClients(tab,"boom")	
			
			M.Resurrect(self,player,char)
		end
		
		hum:SetAttribute("REGEN_STEP",self.Config.HUMAN_REGEN_STEP)
		hum:SetAttribute("REGEN_RATE",self.Config.HUMAN_REGEN_RATE)
		
		local vF = _G.GVF(char.Name)
		
		if vF and not char:GetAttribute("No_FDP_Change") then
			vF.FallDamageProof.Value = self.Config.HUMAN_FDP
		end

		if hum.Health <= 0 then
			spawn(OnDied)
		else
			--if not self.monitoredHumanChars[char] then
				--self.monitoredHumanChars[char] = true

				local c
				c = char.AncestryChanged:Connect(function(_,parent)
					if not parent then
						c:Disconnect()
						self.monitoredHumanChars[char] = nil
						OnDied()
					end
				end)
				
				table.insert(self.monitorSurvivorCons,c)
				table.insert(self.monitorSurvivorCons,hum.Died:Connect(OnDied))
				table.insert(self.monitorSurvivorCons,hum.HealthChanged:Connect(function(h)
					if h <=0 then
						OnDied()
					end
				end))
				
				self.aliveHumans[player] = self.activePlayers[player]
			--end
		end
	end
end

function M:GetInfectedTypeAliveCount(infectedType)
	local c = 0
	for i,v in pairs(workspace.Characters:GetChildren()) do
		if v:FindFirstChild("Humanoid") and v.Humanoid.Health > 0 and v:GetAttribute("InfectedType") == infectedType then
			c +=1
		end
	end
	return c
end

function M:MonitorInfected(player,char,noTypes,forceType)
	--player:SetAttribute("NoRespawnUI",nil)
	--player:SetAttribute("ForceRandomAvatar",true)
	char:SetAttribute("IsInfected",true)
	--char:SetAttribute("NoKillAssists",true)
	
	local typ = "Normal"
	
	local MPLAYERS = (ServerStorage.Values:FindFirstChild("MaxPlayers") and ServerStorage.Values.MaxPlayers.Value) or game.Players.MaxPlayers
	local PLAYER_COUNT = #self.teams.Infected:GetPlayers()

	local c = PLAYER_COUNT / MPLAYERS

	if self.Config.ForceMaxInfectedCountThing then
		c = 1
	else
		c = math.clamp(1 - c,0,1)
		c = 1 - c
	end
	
--	print("MONITORINFECTED,C:",c)
	
	local gotKillCashMulti = nil
	
	if forceType then
		local typC 
		for i,v in pairs(self.Config.SpecialInfectedChances) do
			if v.Name == forceType then
				typC = v
				break
			end
		end
		
		if typC then
			typ = typC.Name
			gotKillCashMulti = typC.KillCashMulti
		end
	else
		if not noTypes and tick() - self.roundStartTick > 10 then
			for _,v in pairs(self.Config.SpecialInfectedChances) do
				local i = v.Name

				--print(1,i,false)
				if not (v.MinAM and self.gameAM < v.MinAM) then
					local MIN,MAX = v.Chances[1],v.Chances[2]

					local chosenChance = Lerp(MIN,MAX,c)
					chosenChance = math.floor(chosenChance)
					chosenChance = math.max(chosenChance,1)
					local chosenRandom = math.random(1,chosenChance)

					--print(2,i,MIN,MAX,chosenRandom)

					if chosenRandom == 1 then
						--print(3,i)

						if not (v.CooldownTime and self.infectedTypeCooldowns[i] and tick() - self.infectedTypeCooldowns[i] < v.CooldownTime) then
							if not (v.MaxActive and M.GetInfectedTypeAliveCount(self,i) >= v.MaxActive) then
								if v.CooldownTime then
									self.infectedTypeCooldowns[i] = tick()
								end

								--print("MONITORINFECTED:",player,c,i,MIN,MAX,chosenRandom)
								gotKillCashMulti = v.KillCashMulti
								typ = i
								break
							end
						end		
					end
				end
			end
		end
	end

	
	if typ and gotKillCashMulti then
		local oldKillCash = player:GetAttribute("CustomKillCash")
		if oldKillCash then
			local nKillCash = oldKillCash * gotKillCashMulti
			nKillCash = math.round(nKillCash)
			
			player:SetAttribute("CustomKillCash",nKillCash)
		end
	end

	M.ZombifyM.new(self.Config,char,typ)
end

function M:RefundPlayer(player)
	if self.activePlayers[player] and self.activePlayers[player].spends then
		
		local amt = self.activePlayers[player].spends
		
		if amt > 0 then
			local tab = {
				Title = "Refunded";
				Text = "Refunded spend of $" .. tostring(amt);
				--Icon = "";
				Duration = 5;
			}

			ReplicatedStorage.Events.Notification:FireClient(player,tab,"BEEP")

			ServerStorage.Events3.nMonee:Fire("IU3898EJKLOY89TYZJDKLJGYI390WKHJSDHG9UKLJLEDGKLJERG9U",player,"Cash",amt)
		end
		
		
		self.activePlayers[player].spends = nil
	end
end

function M:SaveTempData(plr,pd,ap_d,ah_d)
	if not (pd and pd.Parent) then return end
	
	local data = deepCopy(DEFAULT_TEMP_DATA)
	
	data.StartTime = os.time()
	data.CashCap = M.GetCashCap(self,plr)
	
	--print("saving1....")
	
	local succ,err = pcall(function()
		data.Cash = math.min(pd.Cash.Value,data.CashCap)
		
		M.TempMemoryStore:UpdateAsync(
			tostring(plr.UserId),
			function(oldValue)
				return data
			end
			,self.Config.TempData_ExpireTime
		)
	end)
	
	if not succ then
		warn("SaveTempData Error:",plr,err)
	end
end

function M:SaveMainData(plr,pd,ap_d,ah_d)
	if not (ap_d and ap_d.SaveData) or (ap_d and ap_d.FailedToLoadMainData) then return end
	
	if RunService:IsStudio() and self.Config.NoStudioDataSave then
		warn("No Infection datasaving in studio!",plr)
		return
	end
	
	if self.isVipServer then
		warn("No vipserver save!",plr)
		return
	end
	
	local data = ap_d.SaveData
	

	data.LastPlayed = os.time()
	
	pcall(function()
		plr:SetAttribute("IsSavingInfectionData",true)
	end)

	--print("saving2....")

	local succ,err = pcall(function()
		M.MainSaveStore:UpdateAsync(
			tostring(plr.UserId),
			function(oldValue)
				return data
			end
		)
	end)
	
	pcall(function()
		plr:SetAttribute("IsSavingInfectionData",nil)
	end)
	
	if not succ then
		warn("SaveTempData Error:",plr,err)
	end
end

function M:DoTrySaveMainData(player)
	local ap_d = self.activePlayers[player] and deepCopy(self.activePlayers[player])
	local ah_d = self.aliveHumans[player] and deepCopy(self.aliveHumans[player])

	local pd = PlayerbaseData:FindFirstChild(player.Name)
	
	if pd then
		self.savingDataPlayers[player.UserId] = true
		M.SaveMainData(self,player,pd,ap_d,ah_d)
		self.savingDataPlayers[player.UserId] = nil
	end
end

local function GetTempData(plr)
	local gotData

	local succ,err = pcall(function()
		gotData = M.TempMemoryStore:GetAsync(tostring(plr.UserId))
	end)

	if succ then
		return gotData
	else
		warn("error with GetTempData",err)
	end
end

local function GetMainSaveData(plr)
	local gotData
	
	local errorCount = 0
	local lastErrorCode = ""
	
	local MAX_TRIES = 6
	
	repeat
		local succ,err = pcall(function()
			gotData = M.MainSaveStore:GetAsync(tostring(plr.UserId))
		end)
		
		if not err then
			break
		else
			errorCount += 1
			lastErrorCode = err
			task.wait(5)
		end
	until gotData or errorCount >= MAX_TRIES
	
	local errorDOut = errorCount >= MAX_TRIES

	if gotData and not errorDOut then
		if not gotData.Tokens then
			gotData.Tokens = deepCopy(DEFAULT_MAINSAVE_DATA.Tokens)
			gotData.Tokens.Juggernaut = gotData.JugTokens
			gotData.JugTokens = nil
		else
			for i,v in pairs(DEFAULT_MAINSAVE_DATA.Tokens) do
				if not gotData.Tokens[i] then
					gotData.Tokens[i] = 0
				end
			end
		end
		
		if not gotData.OtherStats then
			local t = deepCopy(DEFAULT_MAINSAVE_DATA.OtherStats)
			
			t.RoundsPlayed = gotData.RoundsPlayed or 0
			t.TotalKills = gotData.TotalKills or 0
			t.TotalAssists = gotData.TotalAssists or 0
			t.TotalProfit = gotData.TotalProfit or 0
			t.TotalCashSpent = gotData.TotalSpendings or 0
			
			for i,v in pairs(t) do
				if gotData[i] then
					gotData[i] = nil
				end
			end
			
			gotData.OtherStats = t
		else
			if gotData.OtherStats.TotalSpendings then
				gotData.OtherStats.TotalCashSpent = gotData.OtherStats.TotalSpendings
				gotData.OtherStats.TotalSpendings = nil
			end
			
			for i,v in pairs(DEFAULT_MAINSAVE_DATA.OtherStats) do
				if not gotData.OtherStats[i] then
					gotData.OtherStats[i] = 0
				end
			end
			
			if gotData.OtherStats.CashSpent then
				gotData.OtherStats.CashSpent = nil
			end
		end
		
		if gotData.WINS_KEY ~= WINS_KEY then
			gotData.WINS_KEY = WINS_KEY

			gotData.Wins = 0
		end
		
		if gotData.TOTAL_KILLS_KEY ~= TOTAL_KILLS_KEY then
			gotData.OtherStats.TotalKills = 0
			gotData.OtherStats.TotalAssists = 0
			gotData.OtherStats.RoundsPlayed = 0
			gotData.OtherStats.TotalProfit = 0
			gotData.OtherStats.TotalCashSpent = 0
			
			gotData.TOTAL_KILLS_KEY = TOTAL_KILLS_KEY
		end
		
		if not gotData.GiftedTokens then
			gotData.GiftedTokens = {}
		end

		--if gotData.ROUNDS_PLAYED_KEY ~= ROUNDS_PLAYED_KEY then
		--	gotData.OtherStats.RoundsPlayed = 0
		--	gotData.ROUNDS_PLAYED_KEY = ROUNDS_PLAYED_KEY
		--end
		
		return gotData
	else
		if errorDOut then
			warn("error with GetMainSaveData",lastErrorCode)
		end
		
		return nil,errorDOut
	end
end

function M:LeavePlayer(player,wasShutdown)
	if not M.PlayerHandler_IsSetUp then return end -- check setup
	if not self.activePlayers[player] then -- if they're not already loaded from the NewPlayer function, ignore
		return
	end
	if self.DidLeaveThing then return end
	
	--print("leave1")
	
	local pd = PlayerbaseData:FindFirstChild(player.Name)

	if pd then
		if wasShutdown then
			player:SetAttribute("ShutdownInfectionRefund",true)
		end
		--print("leave2")
		if pd.Cash.Value > self.Config.StartingCash or (self.activePlayers[player] and self.activePlayers[player].DataChanged) then
		--	print("leave3")
			player:SetAttribute("InfectionLeaving",true)
			
			task.wait(0.15)
			
			local ap_d = self.activePlayers[player] and deepCopy(self.activePlayers[player])
			local ah_d = self.aliveHumans[player] and deepCopy(self.aliveHumans[player])
			
			local wasB = self.savingDataPlayers[player.UserId]
			self.savingDataPlayers[player.UserId] = true
			
			spawn(function()
				M.SaveTempData(self,player,pd,ap_d,ah_d)
				
				if not wasB then
					M.SaveMainData(self,player,pd,ap_d,ah_d)	
				end
				
				self.savingDataPlayers[player.UserId] = nil
				
				
				--print("finished leave save")
			end)
		end
	end
	
	--if ReplicatedStorage.Values.ShuttingDown.Value then
	--	return
	--end
	
	self.aliveHumans[player] = nil
	self.activePlayers[player] = nil
	---....
end


function M:NewPlayer(player)
	--print("np",1)
	if not M.PlayerHandler_IsSetUp then return end -- check setup
	--print("np",2)
	--if ReplicatedStorage.Values.ShuttingDown.Value then return end
	
	--print("Trying player",player)
	
	local function WaitForLoad(n) -- this funciton kinda waits for them to actually load in and click play
		local ev = Instance.new("BindableEvent")
		
		local c
		local function onAttributeChanged()
			if not player or not player.Parent or player:GetAttribute("IsLeaving") == true then
				ev:Fire(false)
			elseif player:GetAttribute(n) == true then
				ev:Fire(true)	
			end
		end
		
		delay(0,function()
			c = player.AttributeChanged:Connect(onAttributeChanged)
			onAttributeChanged()
		end)

		local success = ev.Event:Wait()
		
		if c then
			c:Disconnect()
		end
		
		if not success then
			return false
		else
			local pd = PlayerbaseData:WaitForChild(player.Name,30)
			local pd2 = PlayerbaseData2:WaitForChild(player.Name,30)
			
			if not (pd and pd2) then
				return false
			else
				return true
			end
		end
	end
	
	local p = {}
	p.player = player
	
	p.roundData = deepCopy(DEFAULT_ROUND_DATA)
	
	--print("loading player",player)
	if not WaitForLoad("LoadingStart") then -- if not loaded in, return false
		return
	end
	
	p.gui = script.InfectionGUI:Clone()
	p.gui.Parent = p.player.PlayerGui
	player:SetAttribute("NoSpawnFF",true)

	
	if not WaitForLoad("LoadedIn") then -- if not loaded in, return false
		return
	end
	
	if self.savingDataPlayers[player.UserId] then
		repeat task.wait(1)
			
		until not player.Parent or not self.savingDataPlayers[player.UserId]
		
		if not player.Parent then
			return
		end
	end
	
	local tempDataSave = GetTempData(player)
	local mainDataSave,mDS_DidError = GetMainSaveData(player)
	
	print(mainDataSave)
	
	if mainDataSave then
		--print(mainDataSave)
		
		p.SaveData = mainDataSave
		
		if mainDataSave and not self.isVipServer then
			local d = false
			for i,v in pairs(mainDataSave.Tokens) do
				if v > 0 then
					if not d then
						d = true
						delay(0.5,function()
							if player and player.Parent then
								local tab = {
									Title = "Tokens Available";
									Text = "You have unused token(s) ready to be used.";
									Duration = 60;
									Button1 = "Close";
								}

								ReplicatedStorage.Events.Notification:FireClient(player,tab,"BEEP")
							end
						end)
						break
					end
					break
				end
			end
		end
	else
		p.SaveData = deepCopy(DEFAULT_MAINSAVE_DATA)
		
		p.SaveData.FirstLogin = os.time()
		
		if mDS_DidError then
			p.FailedToLoadMainData = true
		end
	end

	if tempDataSave then
		player:SetAttribute("CashCap",tempDataSave.CashCap)
		
		local tab = {
			Title = "Temp Data";
			Text = "Temp data from previous server successfully loaded!";
			Duration = 45;
			Button1 = "Close";
		}

		ReplicatedStorage.Events.Notification:FireClient(player,tab,"BEEP")	
		
		ServerStorage.Events3.SSetMoney:Fire("GERIJO340934923409I2IJOIFI",player,"Cash",tempDataSave.Cash)
	else
		ServerStorage.Events3.SSetMoney:Fire("GERIJO340934923409I2IJOIFI",player,"Cash",self.Config.StartingCash)
	end

	ServerStorage.Events3.SSetMoney:Fire("GERIJO340934923409I2IJOIFI",player,"Bank",0)
	
	--print("loaded",player)
	
	if self.gMode == "game" or self.gMode == "commencing" then
		player:SetAttribute("ForceRandomAvatar",true)
		M.SwitchTeams(self,player,"Infected")
	else
		player.Team = self.teams.Survivors
		player.TeamColor = self.teams.Survivors.TeamColor
	end
	
	player:SetAttribute("InfectionLoaded",true)
	
	self.activePlayers[player] = p
	
	M.UpdateActivePlayer(self,player)
	
	player:GetPropertyChangedSignal("TeamColor"):Connect(function()
		if player.TeamColor == self.teams.Infected.TeamColor then
			self.aliveHumans[player] = nil
		end
	end)
	
	player.CharacterAdded:Connect(function(char)
		player:SetAttribute("HideKillXP",true)
		
		if self.activePlayers[player] and self.activePlayers[player].spends then
			M.RefundPlayer(self,player)
		end
		
		self.aliveHumans[player] = nil
		
		if player.Team == self.teams.Infected and self.gMode == "game" then
			--player:SetAttribute("NoRespawnUI",true)
			if not player:GetAttribute("WasResurrected") and not player:GetAttribute("ForceRandomAvatar") then
				player:SetAttribute("ForceRandomAvatar",true)
				task.wait(0.5)
				M.LoadCharacter(self,player)
				return
			end
			
			player:SetAttribute("CustomKillCash",self.Config.KillCash_Infecteds)
			
			local forceType = player:GetAttribute("ForceInfectedType")
			if forceType then
				player:SetAttribute("ForceInfectedType",nil)
			end
			
			M.MonitorInfected(self,player,char,player:GetAttribute("WasResurrected"),forceType)
			player:SetAttribute("WasResurrected",nil)
		else
			--player:SetAttribute("NoRespawnUI",nil)
			player:SetAttribute("CustomKillCash",self.Config.KillCash_Humans)
			player:SetAttribute("ForceRandomAvatar",nil)
		end
	end)
	
	spawn(function()
		local lstats = player.Parent and player:WaitForChild("leaderstats",10)
		if lstats then
			--lstats:WaitForChild("Level",10)
			--local level = lstats:FindFirstChild("Level")
			--if level then
			--	level:Destroy()
			--end

			local winsStat = Instance.new("IntConstrainedValue")
			winsStat.MinValue = -1000
			winsStat.MaxValue = 1000000
			winsStat.Name = "Wins"
			
			if p.SaveData then
				winsStat.Value = p.SaveData.Wins
			end
			
			--local levelStat = Instance.new("IntConstrainedValue")
			--levelStat.MinValue = -1000
			--levelStat.MaxValue = 1000000
			--levelStat.Name = "Level"
			
			local cashStat = Instance.new("StringValue")
			cashStat.Name = "Cash"
			cashStat.Value = "$0"
			
			--pcall(function()
			--	levelStat.Value = PlayerbaseData[player.Name].Level.Value
			--end)
			
			winsStat.Parent = lstats
			--levelStat.Parent = lstats
			cashStat.Parent = lstats
			
			local function updt()
				cashStat.Value = "$" .. tostring(math.min(PlayerbaseData[player.Name].Cash.Value,1000000))
			end
			PlayerbaseData[player.Name].Cash.Changed:Connect(function()
				updt()
			end)
			updt()
		end
	end)
	
	if self.NewPlayerLoadedInFunc then
		self.NewPlayerLoadedInFunc(player)
	end
	
	task.elay(1,function()
		if not self.activeGame and self.gMode == "waiting" then
			local pCount = M.GetActivePlayerCount(self)
			if pCount < self.Config.MinimumPlayers then
				M.LoadCharacter(self,player)
			end
		end
	end)
	
	return self
end

function M.new(self)
	if M.PlayerHandler_IsSetUp then return end
	M.PlayerHandler_IsSetUp = true
	
	M.ZombifyM = require(script.Zombify)
	M.PurchaseHandler = require(script.Parent.PurchaseHandler)
	
	M.TempMemoryStore = MemoryStoreService:GetSortedMap(self.Config.TempData_DS_KEY)
	M.MainSaveStore = DatastoreService:GetDataStore(self.Config.MainSaveData_DS_KEY)
	
	self.monitorSurvivorCons = {}
	
	self.infectedTypeCooldowns = {}
	self.monitoredHumanChars = {}
	
	self.savingDataPlayers = {}
	
	--print("M NEW")

	local function NewPlayer(player)
		self.PlayerHandler.NewPlayer(self,player)
	end
	
	local c1,c2
	c1 = Players.PlayerAdded:Connect(NewPlayer)
	for i,v in pairs(Players:GetPlayers()) do
		spawn(function()
			NewPlayer(v)
		end)
	end
	c2 = Players.PlayerRemoving:Connect(function(player)
		self.PlayerHandler.LeavePlayer(self,player)
	end)
	
	local sh = false
	ServerStorage.Events3.SHDWN.Event:Connect(function()
		if sh then return end
		sh = true
		
		c1:Disconnect()
		c2:Disconnect()
		self.DidLeaveThing = true
		
		for v,_ in pairs(self.activePlayers) do
			spawn(function()
				M.LeavePlayer(self,v,true)
			end)
		end
	end)
	
	ServerStorage.Events3.KillAssistReceived.Event:Connect(function(player,victim,typ,rewardCash,rewardXP)
		if self.activePlayers[player] then
			local roundData = self.activePlayers[player].roundData
			
			if typ == "kill" then
				roundData.Kills +=1
			elseif typ == "assist" then
				roundData.Assists +=1
			end
			
			roundData.Profit += rewardCash
			
			self.activePlayers[player].roundData = roundData
			
			--print("ROUND DATA",player,victim,typ,rewardCash)
		end
	end)
	
	
end

return M