local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local M = {}
M.__index = M

M.SetUp = function(gameSettings)
	if M.isSetUp then return end
	warn("SETTING UP INFECTION GAMEMODE")
	
	M.isSetUp = true
	
	local self = {}
	
	self.Config = require(script.Config)
	
	self.I = {}
	self.I.folder = script.InfectionMode:Clone()
	
	self.I.valuesFolder = self.I.folder.Values
	self.I.eventsFolder = self.I.folder.Events
	
	self.I.values = {}
	
	self.I.values.timer = self.I.valuesFolder.Timer
	self.I.values.desc = self.I.valuesFolder.DescText
	self.I.values.title = self.I.valuesFolder.TitleText
	self.I.values.mode = self.I.valuesFolder.Mode
	self.I.values.descEnabledV = self.I.valuesFolder.DescEnabled
	self.I.values.titleEnabledV = self.I.valuesFolder.TitleEnabled
	self.I.values.hTrackingEnabledV = self.I.valuesFolder.HumanTrackingEnabled
	self.I.values.trussesEnabledV = self.I.valuesFolder.TrussesEnabled
	self.I.values.markersEnabledV = self.I.valuesFolder.MarkersEnabled
	self.I.values.sewersDisabledV = self.I.valuesFolder.SewersDisabled
	
	self.values = {}
	self.buyZonesV = ReplicatedStorage.Values.BuyZonesEnabled
	
	self.I.folder.Parent = ReplicatedStorage
	
	self.isVipServer = ReplicatedStorage.Values.IsVipServer.Value
	
	self.PlayerHandler = require(script.PlayerHandler)
	self.GameHandler = require(script.GameHandler)
	self.PurchaseHandler = require(script.PurchaseHandler)
	self.LeaderboardHandler = require(script.LeaderboardHandler)
	
	self.PlayerHandler.new(self)
	self.GameHandler.new(self)
	self.PurchaseHandler.new(self)
	self.LeaderboardHandler.new(self)
	
	setmetatable(self,M)
	
	warn("SUCCESSFULLY LOADED INFECTION GAMEMODE")
end

M.MainLoop = function()
end

return M