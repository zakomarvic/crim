local M = {}

local ServerStorage = game:GetService("ServerStorage")

function M.DoAppearance(char)
	local oldShirt = char:FindFirstChildOfClass("Shirt")
	local oldPants = char:FindFirstChildOfClass("Pants")
	if oldShirt then
		oldShirt:Destroy()
	end
	if oldPants then
		oldPants:Destroy()
	end
	
	for i,v in pairs(char.Humanoid:GetAccessories()) do
		if v.Name ~= "InfectedEyes" then
			v:Destroy()
		end
	end

	script.Shirt:Clone().Parent = char
	script.Pants:Clone().Parent = char
end

function M.new(char)
	local plr = game.Players:GetPlayerFromCharacter(char)
	local hum = char.Humanoid
	
	local HP = 80
	local SPEED_ADD = -2
	local JUMPADD = 0
	local ACCEL = 0.4

	local function DoMain()
		if not hum:GetAttribute("DontChangeHP") then
			hum.MaxHealth = HP + 15
			hum.Health = hum.MaxHealth
		end

		local vF = _G.GVF(char.Name)
		
		local vest = game.ServerStorage.Tools.VestB_1:Clone()
		vest.Parent = char
		
		local helmet = game.ServerStorage.Tools.HelmetB_2:Clone()
		helmet.Parent = char

		task.wait(0.1)

		if vF then
			if not hum:GetAttribute("DontChangeHP") then
				for _,v in pairs(vF.HealthValues:GetChildren()) do
					local h = HP
					if v.Name == "Head" then
						--h /= 2
					end
					v.MaxValue = h
					v.Value = v.MaxValue
				end
			end	
			
			vF.MovementSoundModifier.Value = 1.5
			vF.AccelerationModifier.Value = ACCEL
			vF.FallDamageProof.Value = 0.5
			vF.BleedProof.Value *= 2
			
			local ACCEL_MULTI = 0.35
			local ACCEL_MAX = 7

			local b = Instance.new("BoolValue")
			b.Name = "RBTMVB_S"
			b.Parent = vF.Currents

			local b1 = Instance.new("NumberValue")
			b1.Name = "ACCLTRR"
			b1.Value = ACCEL_MULTI

			local b2 = Instance.new("NumberValue")
			b2.Name = "M"
			b2.Value =ACCEL_MAX
			b2.Parent = b1
			
			b1.Parent = vF.Currents
			
			_G.AffectChar(char,"JR",math.huge,"WKVL2",-JUMPADD)
			_G.AffectChar(char,"SD",math.huge,"WKVL2",-SPEED_ADD)
		end
		

		local zf = game.ServerStorage.Tools["__ZombieFists2"]:Clone()
		zf.Parent = plr.Backpack
		
		delay(1,function()
			if not hum:GetAttribute("NoAutoEquip") and _G.CheckIfCan(char) then
				hum:EquipTool(zf)
			end
			spawn(function()
				while hum and hum.Parent and hum.Health > 0 do
					if zf.Parent and zf.Parent ~= char and not hum:GetAttribute("NoAutoEquip") and _G.CheckIfCan(char) then
						hum:EquipTool(zf)
					elseif not _G.CheckIfCan(char) then
						hum:UnequipTools()
					end
					task.wait(0.35)
				end
			end)
		end)
	
		hum:SetAttribute("ForceWalkStage",2)
		hum:SetAttribute("ZSPRN_M",1)

		local animateS = char:WaitForChild("Animate",3)
		if animateS then
			for i,v in pairs({"idle1","idle2","idle3"}) do
				for i,v in pairs(animateS[v]:GetChildren()) do
					v.AnimationId = "rbxassetid://127585051698508"
				end
			end
			for i,v in pairs({"walk1","walk2","walk3"}) do
				for i,v in pairs(animateS[v]:GetChildren()) do
					v.AnimationId = "rbxassetid://83810348098685"
				end
			end
			--for i,v in pairs({"run1","run2","run3"}) do
			--	for i,v in pairs(animateS[v]:GetChildren()) do
			--		v.AnimationId = "rbxassetid://75745553966418"
			--	end
			--end
		end
		
		local zSounds = script.Parent.Parent.ZombieSounds:Clone()
		script.Sounds:Clone().Parent = zSounds
		zSounds.Parent = char
		zSounds.Disabled = false
		zSounds.Enabled = true
		
		local bl = script.BreathingLoop:Clone()
		bl.Parent = char.Head
		bl:Play()
		
	end

	if plr then
		DoMain()
	end
	
	if not M.NormalM then
		M.NormalM = require(script.Parent.Normal)
	end
	
	M.NormalM.DoAppearance(char)
	M.DoAppearance(char)
	
	wait()

	local s = ServerStorage.Tools["__RESIZERT"]:Clone()
	s.Perc.Value = 1.05
	s.Parent = char
end

return M