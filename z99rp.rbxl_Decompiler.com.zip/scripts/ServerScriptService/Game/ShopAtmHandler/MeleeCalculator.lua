local Calcs = {}

local ReplicatedStorage =	game:GetService("ReplicatedStorage")
local ServerStorage = 		game:GetService("ServerStorage")

local MODULES	= ReplicatedStorage:WaitForChild("Modules")
	local CONFIG	= require(MODULES.Config)

local iS = ReplicatedStorage.Storage.ItemStats

local MaxSettings = {
	Damage =	100;
	UseRate =	0.3;
	Stamina =	65;
	Range =		5;
	Mobility =	8;
	
	AttackDelay = 0.7;
	AttackDebounce = 3.5;
	AttackTime = 1.5;
}

local function GetTool(name)
	return ServerStorage.Tools:FindFirstChild(name)
end

local configs = {}

local function GetConfig(name)
	if not configs[name] then
		local config = game.ServerStorage.ToolModules.Melees:FindFirstChild(name)
		if config then
			config = require(config)
		end
		
		configs[name] = config
		
		return config	
	else
		return configs[name]
	end
end


function Calcs:GetDamage(name)
	local tool = GetTool(name)
	if not tool then warn("No tool found: " .. name) return "N/A" end
	
	local Config		= GetConfig(name)
	if not Config then warn("No config found: " .. name) return "N/A" end
	
	local dmg = Config.Damage
	if Config.MultipleHits and Config.MultipleHits.Enabled then
--		dmg = dmg * (Config.Mains.S1.SwingTime / Config.MultipleHits.DB)
	end
	
	local perc = dmg / MaxSettings.Damage
	
	dmg = tostring(dmg)
	
	if Config.Mains.S1.BleedDmg > 0 then
		dmg = dmg .. "+" .. Config.Mains.S1.BleedDmg .. ""
	end
	
	return dmg,perc
end

--function Calcs:UpdateUseRate(name)
--	local tool = GetTool(name)
--	if not tool then warn("No tool found: " .. name) return 0 end
	
--	local Config		= GetConfig(name)
--	if not Config then warn("No config found: " .. name) return 0 end
	
--	local rate = Config.Mains.S1.DebounceTime
	
--	local perc = MaxSettings.UseRate / rate
--	perc = math.clamp( 1 - perc,0,1)
--	perc = 1 - perc
	
--	return perc
--end

--function Calcs:UpdateRange(name)
--	local tool = GetTool(name)
--	if not tool then warn("No tool found: " .. name) return 0 end
	
--	local range = iS.Melees[name].Bars.Range["Real"].Value
	
--	local perc = range / MaxSettings.Range
--	perc = math.clamp( 1 - perc,0,1)
--	perc = 1 - perc
	
--	return perc
--end

function Calcs:GetStamina(name)
	local tool = GetTool(name)
	if not tool then warn("No tool found: " .. name) return "N/A" end
	
	local Config		= GetConfig(name)
	if not Config then warn("No config found: " .. name) return "N/A" end
	
	local stamina = Config.StaminaUsage
	
	local perc = 1 - (stamina / MaxSettings.Stamina)
	perc = math.clamp( 1 - perc,0,1)
	
	return tostring(Config.StaminaUsage),perc
end

function Calcs:GetMobility(name)
	local tool = GetTool(name)
	if not tool then warn("No tool found: " .. name) return "N/A" end
	
	local Config		= GetConfig(name)
	if not Config then warn("No config found: " .. name) return "N/A" end
	
	local mobility = (Config.SlowDown.Enabled and (MaxSettings.Mobility - Config.SlowDown.Amount)) or MaxSettings.Mobility
	
	local perc = mobility / MaxSettings.Mobility
	perc = math.clamp( 1 - perc,0,1)
	perc = 1 - perc
	
	return mobility,perc
	
end

function Calcs:UpdateAttackStats(name,bars)
	local tool = GetTool(name)
	if not tool then warn("No tool found: " .. name) return "N/A" end

	local Config		= GetConfig(name)
	if not Config then warn("No config found: " .. name) return "N/A" end
	
	
	local cd = tostring(math.floor(Config.Mains.S1.DebounceTime * 10) / 10) .. "s"
	local cdPerc = Config.Mains.S1.DebounceTime / MaxSettings.AttackDebounce
	cdPerc = math.clamp( 1 - cdPerc,0,1)
	cdPerc = 1 - cdPerc

	bars.AttackCooldown.Value = cd
	bars.AttackCooldown.Bar.Value = cdPerc
	
	
	
	
	local sW = tostring(math.floor(Config.Mains.S1.SwingWait * 10) / 10) .. "s"
	local sWPerc = Config.Mains.S1.SwingWait / MaxSettings.AttackDelay
	sWPerc = math.clamp( 1 - sWPerc,0,1)
	sWPerc = 1 - sWPerc
	
	bars.AttackDelay.Value = sW
	bars.AttackDelay.Bar.Value = sWPerc
	
	
	
	
	
	local sT = tostring(math.floor(Config.Mains.S1.SwingTime * 10) / 10) .. "s"
	local sTPerc = Config.Mains.S1.SwingTime / MaxSettings.AttackTime
	sTPerc = math.clamp(1 - sTPerc,0,1)

	bars.AttackTime.Value = sT
	bars.AttackTime.Bar.Value = sTPerc




	bars.StunTime.Value = tostring(math.floor(Config.Mains.S1.FlinchTime * 10) / 10) .. "s"
	bars.StunTime.Bar.Value = Config.Mains.S1.FlinchTime
	
	--bars.BladeRange.Value = tostring(math.floor(bars.BladeRange.Value * 10) / 10)
end

return Calcs