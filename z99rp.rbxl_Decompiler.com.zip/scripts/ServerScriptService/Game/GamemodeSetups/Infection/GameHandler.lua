local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")
local TS = game:GetService("TweenService")
local RunService = game:GetService("RunService")

local M = {}
M.__index = M

local PlayerbaseData = ServerStorage:WaitForChild("PlayerbaseData")
local PlayerbaseData2 = ReplicatedStorage:WaitForChild("PlayerbaseData2")

local deepCopy = require(ReplicatedStorage.Modules.DeepCopy)

function M:ClearUp()
	ReplicatedStorage.Values.TimeState.Value = 10
	ReplicatedStorage.Values.TimeState.Enabled.Value = true
	ServerStorage.Events3.RegenAllDoors:Fire()
	ReplicatedStorage.Values.ResettingDisabled.Value = false
	self.I.values.hTrackingEnabledV.Value = false
	self.I.values.markersEnabledV.Value = false
	self.I.values.sewersDisabledV.Value = false

	M.ToggleTrusses(self,false)
	
	ServerStorage.Values.AreaDenialTK.Value = false
	ServerStorage.Values.AreaDenialTK.Perc.Value = 1
	
	ServerStorage.Values.DisableLoadInSpawnCharacter.Value = true
	ServerStorage.Values.DisableToolDropping.Value = true
	
	ReplicatedStorage.Values.FogAddValue.Value = 0
	
	self.ambientSound.Playing = false
	
	self.originalHumans = {}
	self.takenBridgeSpawns = {}
	
	if self.prepareCC and self.prepareCC.Parent then
		self.prepareCC:Destroy()
	end
	
	for v,_ in pairs(self.activePlayers) do
		local _s,_e = pcall(function()
			if v.Parent then
				v.TeamColor = self.teams.Survivors.TeamColor
				v.Team = self.teams.Survivors
			end
		end)
		if not _s then
			warn("CleanUpError:",_e)
		end
	end

	for v,_ in pairs(self.activePlayers) do
		if v and v.Parent then
			v:SetAttribute("NoRespawnUI",nil)
		end
	end
	
	M.PlayerHandler.ClearHumanCons(self)
	M.PlayerHandler.ResetAllRoundData(self)
	
	ServerStorage.Events3.RESTOCK:Fire("LPKRGF90T430WFLPDS")

	--workspace.Audio.UndergroundAmbience.Volume = 1
	--workspace.Audio.SewerAmbience.Volume = 1
end

function M:ToggleTrusses(m)
	self.I.values.trussesEnabledV.Value = m
end

function M:SmiteInfecteds(player,char)
	local sfF = ServerStorage.Storage.Other.CurseFinish
	
	local p = ServerStorage.Storage.Other.CurseFinish.LightningS:Clone()
	game.Debris:AddItem(p,10)
	p.CFrame = workspace.Filter.MapArea.CFrame + Vector3.new(0,1000,0)
	p.Parent = workspace.Debris
	p["Strike" .. math.random(1,3)]:Play()
	
	local expN = 1
	game.Lighting.ExposureCompensation += expN
	delay(0.15,function()
		game.Lighting.ExposureCompensation -= expN
	end)
	
	for v,_ in pairs(self.activePlayers) do
		local _s,_e = pcall(function()
			if v.Team == self.teams.Infected and v.Character and v.Character:FindFirstChild("HumanoidRootPart") then
				local tvf = _G.GVF(v.Name)
				
				delay(5,function()
					pcall(function()
						v.Character.Humanoid.Health = 0
					end)
				end)

				if tvf then
					local poisV = Instance.new("NumberValue")
					game.Debris:AddItem(poisV,4)
					poisV.Name = "POIZSKRATA"
					--poisV:SetAttribute("NoIcon",true)
					poisV.Value = 0.5
					TS:Create(poisV,TweenInfo.new(3,Enum.EasingStyle.Linear,Enum.EasingDirection.Out),{Value = 1}):Play()
					poisV.Parent = tvf.Currents
				end

				local s1 = sfF.ZapS:Clone()
				game.Debris:AddItem(s1,5)
				s1.Parent = v.Character.HumanoidRootPart
				s1:Play()

				local sc = ServerStorage.Storage.Scripts.BurningScript:Clone()
				sc.IsCursed.Value = true
				sc.NoExtinguish.Value = true
				sc.Time.Value = 15
				sc.Dmg.Value = 17
				sc.Parent = v.Character
				sc.Disabled = false
			end
		end)
		if not _s then
			warn("SmiteInfectedsError:",_e)
		end
	end
end

function M:InfectedsWin()
	self.winResult = "Infected"
	self.gMode = "gameover"
	self.I.values.mode.Value = self.gMode
	
	self.I.values.titleEnabledV.Value = false
	
	local s = self.audioF.InfectedWin:Clone()
	game.Debris:AddItem(s,60)
	s.Parent = workspace.Audio
	s:Play()
	
	self.ambientSound.Playing = false
	
	--local t = {
	--	Text = "INFECTED WIN";
	--	TextColor3 = Color3.new(1,0,0);
	--}
	
	----delay(20,function()
	----	local s = self.audioF.Laugh:Clone()
	----	game.Debris:AddItem(s,10)
	----	s.Name = "Sound"
	----	s.Volume /= 2
	----	s.Parent = workspace.Audio 
	----	s:Play()
	----end)
	
	--self.I.eventsFolder.ScreenText:FireAllClients(t,3,1.5,"boom")
	
	M.PlayerHandler.ClearHumanCons(self)
	
	M.PlayerHandler.DoEndScreen(self,self.winResult,s)
	
	task.wait(27)
	
	self.I.values.mode.Value = ""
	task.wait(3)
	-- game resets
end

function M:BellToll()
	local bsp = self.audioF.BellSoundPart:Clone()
	game.Debris:AddItem(bsp,10)
	bsp.Parent = workspace.Debris
	
	local s = self.audioF.BellRing:Clone()
	s.Parent = bsp
	s:Play()
end

function M:SurvivorsWin()
	local tween = TS:Create(ReplicatedStorage.Values.TimeState,TweenInfo.new(25,Enum.EasingStyle.Quad,Enum.EasingDirection.Out),{Value = 10})
	tween:Play()

	task.wait(0.5)

	local bsp = self.audioF.BellSoundPart:Clone()
	bsp.Parent = workspace.Debris

	spawn(function()
		for i = 1,5 do
			local s = self.audioF.BellRing:Clone()
			s.Parent = bsp
			s:Play()
			task.wait(4)
		end
	end)
	
	local setTimer = 15
	local timer = setTimer
	self.I.values.timer.Value = timer
	
	delay(10,function()
		for v,_ in pairs(self.aliveHumans) do
			if v and v.Parent and v.Character and v.Character:FindFirstChild("Humanoid") and v.Character.Humanoid.Health > 0 then
				local ff = Instance.new("ForceField")
				game.Debris:AddItem(ff,30)
				ff.Visible = false
				ff.Parent = v.Character
			end
		end
	end)
	
	local killedZombies = false
	repeat
		self.I.values.timer.Value -= 1
		
		if not killedZombies and self.I.values.timer.Value <= setTimer - 5 then
			killedZombies = true
			self.killedZombies = true
			delay(0.2,function()
				M.SmiteInfecteds(self)
			end)
		end
		
		task.wait(1)
	until self.I.values.timer.Value <= 0 or M.PlayerHandler.GetHumanCount(self) <= 0
	
	if M.PlayerHandler.GetHumanCount(self) > 0 then
		self.winResult = "Survivors"
		self.gMode = "gameover"
		self.I.values.mode.Value = self.gMode
		
		M.PlayerHandler.ClearHumanCons(self)
		M.ToggleTrusses(self,false)
		
		self.ambientSound.Playing = false
		
		--delay(2.35,function()
			
		--end)
		
		local s = self.audioF.SurvivorsWin:Clone()
		game.Debris:AddItem(s,60)
		s.Parent = workspace.Audio
		s:Play()
		
		--local t = {
		--	Text = "SURVIVORS WIN";
		--	TextColor3 = Color3.new(0,1,0);
		--}
		--self.I.eventsFolder.ScreenText:FireAllClients(t,8,1.5,"boom")
		
		self.I.values.titleEnabledV.Value = false
		
		M.PlayerHandler.DoEndScreen(self,self.winResult,s,3)
		
		for v,_ in pairs(self.aliveHumans) do
			local _s,_e = pcall(function()
				if v and v.Parent and v.Character and v.Character:FindFirstChild("Humanoid") and v.Character.Humanoid.Health > 0 then
					table.insert(self.winHumans,v)
				end
			end)
			if not _s then
				warn("Line247Error:",_e)
			end
		end
		task.wait(30)

		if bsp and bsp.Parent then
			bsp:Destroy()
		end
		if tween and not tween.Completed then
			tween:Cancel()
		end
		
		self.I.values.mode.Value = ""
		
		task.wait(3)
	else
		if bsp and bsp.Parent then
			bsp:Destroy()
		end
		if tween and not tween.Completed then
			tween:Cancel()
		end
		M.InfectedsWin(self)
	end
	-- game resets
end

function M:GameEnd()
	self.I.eventsFolder.PlaySound:FireAllClients("boom")
	
	self.I.values.hTrackingEnabledV.Value = false
	self.I.values.markersEnabledV.Value = false
	self.I.values.sewersDisabledV.Value = false

	ReplicatedStorage.Values.RespawningDisabled.Value = true
	ReplicatedStorage.Values.LoadingInDisabled.Value = true
	ReplicatedStorage.Values.ResettingDisabled.Value = true
	
	for v,_ in pairs(self.activePlayers) do
		if v and v.Parent then
			v:SetAttribute("NoRespawnUI",true)
		end
	end
	
	self.gameEnding = true
	
	if self.I.values.timer.Value <= 0 then
		self.I.values.desc.Value = "6 AM"
		self.I.valuesFolder.AMValue.Value = 6
	end
	
	if self.I.values.timer.Value <= 0 and M.PlayerHandler.GetHumanCount(self) > 0 then
		for v,_ in pairs(self.aliveHumans) do
			local _s,_e = pcall(function()
				M.PlayerHandler.GrantHourCash(self,v,6)
			end)

			if not _s then
				warn("GameEnd Grant cash error:",_e)
			end
		end
		
		M.SurvivorsWin(self)
	else
		M.InfectedsWin(self)
	end
	
	self.activeGame = false
end

function M:ChooseInfected()
	local humanCount = M.PlayerHandler.GetHumanCount(self)
	if humanCount > 0 then
		local infectedCount = math.round(humanCount * self.Config.InfectedPerc)
		
		for v,i in pairs(self.activePlayers) do
			if v and v.Parent and v.Team ~= self.teams.Survivors then
				infectedCount -= 1
			end
		end
		
		infectedCount = math.max(infectedCount,1)
		
		if #self.teams.Infected:GetPlayers() > 0 then
			infectedCount -= #self.teams.Infected:GetPlayers()
			
			if infectedCount <= 0 then
				--print("has enough infecteds already!")
				return
			end
		end
		
		local function RandomizeTable(tbl)
			local returntbl={}
			if tbl[1]~=nil then
				for i=1,#tbl do
					table.insert(returntbl,math.random(1,#returntbl+1),tbl[i])
				end
			end
			return returntbl
		end
		
		local humanTable = {}
		for v,_ in pairs(self.aliveHumans) do
			local _s,_e = pcall(function()
				if v and v.Parent then
					table.insert(humanTable,v)
				end
			end)
			if not _s then
				warn("Line 352Error:",_e)
			end
		end
		
		local function GetRandomToInfect(isOriginal)
			local chosen
			
			if isOriginal then
				local gg = false
				for i1 = 1,2 do
					local tab = humanTable
					tab = RandomizeTable(tab)

					for i,v in pairs(tab) do
						local got = v
						
						--print("got1",got)
						if got then
							--print("got2",got)
							local wasOriginalPlayer = table.find(self.originalHumans,got)
							local wasLastOriginalCreature = table.find(self.lastOriginalInfected,got.Name)

							--warn("--------")
							--warn(got.Name)
							
							if got.Character and got.Character:GetAttribute("NoRandomInfectChoose") then
								--warn("JuggernautInUse")
							elseif wasOriginalPlayer and i1 < 2 then
								--warn("Skipping",got.Name,"cause was original player..",i1)
							elseif wasLastOriginalCreature then
								--warn("Skipping",got.Name,"cause was infected last round..")
							else
								--warn("Not original or last, set",got.Name, " as chosen infected!")
								--warn("--------")
								chosen = got
								gg = true
								break
							end

							--warn("--------")
						end
					end

					if gg then
						break
					end
				end

				if not chosen then			
					for i,v in pairs(RandomizeTable(humanTable)) do
						if not v.Character and v.Character:GetAttribute("JuggernautInUse") then
							chosen = v
						end
						break
					end
					--warn("Couldn't find an orignal infected, choosing random!:",chosen.Name)
				end
				
				if chosen then
					table.insert(self.originalInfected,chosen)
					table.insert(self.lastOriginalInfected,chosen.Name)
				end
			else
				for v,_ in pairs(RandomizeTable(humanTable)) do
					if not v.Character and v.Character:GetAttribute("JuggernautInUse") then
						chosen = v
					end
					break
				end
			end
			
			return chosen
		end
		
		local infected_list = {}
		
		--print(infectedCount)
		for i = 1,infectedCount do
			local infected = GetRandomToInfect(true)
			if infected then
				table.insert(infected_list,infected.Name)
				M.PlayerHandler.ZombifyKill(self,infected,infected.Character)
			end
		end

		for i,v in pairs(self.lastOriginalInfected) do
			if not table.find(infected_list,v) or not Players:FindFirstChild(v) then
				--warn("removing",v,"from lastOriginalinfecteds..")
				table.remove(self.lastOriginalInfected,i)
			end
		end
	end
end

function M:EnableHumanTracking()
	self.I.values.hTrackingEnabledV.Value = true
	
	self.I.values.markersEnabledV.Value = self.Config.HumanTracking.MarkersEnabled
	
	for v,_ in pairs(self.activePlayers) do
		local 	t = {
			TextColor3 = Color3.fromRGB(255, 121, 123);
			TextStrokeColor3 = Color3.new(0,0,0);
			TextTransparency = 0;
			TextStrokeTransparency = 0;
		}
		if v.Team == self.teams.Survivors then
			t.Text = "YOU ARE BEING TRACKED"
		else
			t.Text = "SURVIVORS HAVE BEEN TRACKED"
			t.TextSize = 20
		end
		
		self.I.eventsFolder.DescMessage:FireClient(v,t,10)
	end
end

function M:DisableSewers()
	self.I.values.sewersDisabledV.Value = true
end

function M:GamePhase()

	--disable loading in
	-- set mode ting
	
	ReplicatedStorage.Values.LoadingInDisabled.Value = true
	
	task.wait(1)
	
	self.gMode = "commencing"
	self.I.values.mode.Value = self.gMode
	
	ReplicatedStorage.Values.ResettingDisabled.Value = true
	ReplicatedStorage.Values.RespawningDisabled.Value = true
	
	local arrivalSound
	local nms = {}
	for v,_ in pairs(self.activePlayers) do
		local _s,_e = pcall(function()
			local char = v and v.Parent and v.Character
			if char then
				local hum = char:FindFirstChildOfClass("Humanoid")
				if hum and hum.Health > 0 then
					hum:UnequipTools()

					local af = _G.AffectChar(char,"B",math.huge)
					if af then
						table.insert(nms,af)
					end
					--local ff = Instance.new("ForceField")
					--ff.Name = "Infection_FF1"
					--game.Debris:AddItem(ff,60)
					--ff.Visible = false
					--ff.Parent = char
					--table.insert(nms,ff)

					M.PlayerHandler.MonitorHuman(self,v)
				end
			end
		end)

		if not _s then
			warn("GameHandlerError1:",_e)		
		end
		--v:SetAttribute("NoRespawnUI",true)
	end
	
	if not self.skipEntireStartPhase then
		arrivalSound = self.audioF.RoundStart1:Clone()
		arrivalSound.Name = "Sound"
		arrivalSound.Parent = workspace.Audio

		if not arrivalSound.IsLoaded then
			arrivalSound.Loaded:Wait()
		end

		arrivalSound:Play()

		delay(11.5 - 2,function()
			local s = self.audioF.Laugh:Clone()
			game.Debris:AddItem(s,10)
			s.Name = "Sound"
			s.Parent = workspace.Audio 
			s:Play()
		end)

		task.wait(3)
	end
	
	coroutine.wrap(function()
		self.BlackoutM.Toggle(true,(not self.skipEntireStartPhase and "NoAlarm") or nil,true,2,40,120)
	end)()
	
	if not self.skipEntireStartPhase then
		task.wait(9.3)
	end

	
	--TS:Create(ReplicatedStorage.Values.TimeState,TweenInfo.new(1,Enum.EasingStyle.Quart,Enum.EasingDirection.In),{Value = 24}):Play()
	
	if not self.Config.NoStartInfecteds then
		local _s,_e = pcall(function()
			M.ChooseInfected(self)
		end)
		if not _s then
			warn("ChooseInfectedError:",_e)
		end
	end
	
	if not self.skipEntireStartPhase then
		task.wait(2.5)
	end
	-- sound done
	--print("sound done")
	
	if not self.skipEntireStartPhase then
		delay(30,function()
			arrivalSound:Destroy()
		end)
	end
	-- choose random infecteds
	-- clear all infecteds NMS/forcefield
	
	if not self.skipEntireStartPhase then
		for v,_ in pairs(self.activePlayers) do
			local _s,_e = pcall(function()
				local char = v and v.Parent and v.Character
				if char then
					local hum = char:FindFirstChildOfClass("Humanoid")
					if hum and hum.Health > 0 then -- AND NOT INFECTED
						table.insert(nms,_G.AffectChar(char,"SP",10,"WKVL1",0.2))
						table.insert(nms,_G.AffectChar(char,"JR",10,"WKVL2",1000))
						table.insert(nms,_G.AffectChar(char,"AS",10))
					end

					delay(0,function()
						if hum and hum.Parent and not hum:GetAttribute("WasZombified") then
							local anim = hum:LoadAnimation(ReplicatedStorage.Storage.Animations.BlindAnim)
							anim.Priority = Enum.AnimationPriority.Idle
							anim:Play(0.1,1,0.01)

							delay(11,function()
								if anim then
									anim:Stop(3)
								end
							end)
						end
					end)
				end
			end)
			if not _s then
				warn("BlindGameHandler Error:",_e)
			end
		end
		task.wait(13)
	end
	
	self.roundStartTick = tick()
	
	for v,_ in pairs(self.activePlayers) do
		local _s,_e = pcall(function()
			if v.TeamColor == self.teams.Survivors.TeamColor then
				local t = {
					Text = "SURVIVE";
					TextColor3 = Color3.new(1,0.2,0.2);
				}
				self.I.eventsFolder.ScreenText:FireClient(v,t,4,1,"boom")
			else
				local t = {
					Text = "INFECT";
					TextColor3 = Color3.new(1,0.2,0.2);
				}
				self.I.eventsFolder.ScreenText:FireClient(v,t,5,1,"boom")
			end
		end)
		
		if not _s then
			warn("Line631Error:",_e)
		end
	end
	

	task.wait(4)

	local s = self.audioF["InfectedStart" .. math.random(1,2)]:Clone()
	game.Debris:AddItem(s,30)
	s.Parent = workspace.Audio
	s:Play()
	
	self.ambientSound.Playing = true
	--print("boom")

	for i,v in pairs(nms) do
		if v and v.Parent then
			v:Destroy()
		end
	end

	nms = {}

	task.wait(5)

	ReplicatedStorage.Values.RespawningDisabled.Value = false
	ReplicatedStorage.Values.LoadingInDisabled.Value = false
	ReplicatedStorage.Values.ResettingDisabled.Value = false
	ServerStorage.Values.DisableToolDropping.Value = false
	
	M.ToggleTrusses(self,true)

	self.gMode = "game"
	self.I.values.mode.Value = self.gMode
	
	self.I.values.descEnabledV.Value = false
	self.I.values.titleEnabledV.Value = true
	self.I.values.desc.BlinkRed.Value = true
	self.I.values.desc.Value = "12 AM"
	self.I.values.title.Value = "SURVIVE"

	local timer = self.Config.GameTime
	self.I.values.timer.Value = timer
	self.I.values.descEnabledV.Value = true
	task.wait(1)
	
	M.PlayerHandler.ResetAllRoundData(self)

	local lastV = "12 AM"
	
	self.gameAM = 0
	
	for v,i in pairs(self.activePlayers) do
		local _s,_e = pcall(function()
			local survivorReset = not (v.Character and v.Character:FindFirstChild("Humanoid") and v.Character.Humanoid:GetState() ~= Enum.HumanoidStateType.Dead)
			local infectedReset = v.Team == self.teams.Infected and not (v.Character and v.Character:GetAttribute("IsInfected"))

			local isResurrecting = (v.Character and v.Character:GetAttribute("WillResurrect")) or (v.Team == self.teams.Infected and not v.Character)
			if  (survivorReset or infectedReset) 
			then
				M.PlayerHandler.SwitchTeams(self,v,"Infected")
				self.aliveHumans[v] = nil

				if not isResurrecting then
					v:SetAttribute("ForceRandomAvatar",true)
				end

				if M.PlayerHandler.GetHumanCount(self) > 0 then
					M.PlayerHandler.LoadCharacter(self,v)
				end
			else
				--v:SetAttribute("NoRespawnUI",true)
			end
		end)
		
		if not _s then
			warn("GameHandler Error @ 12 AM:",_e)
		end
	end
	
	ServerStorage.Values.AreaDenialTK.Value = self.Config.AreaDenialTK ~= nil
	ServerStorage.Values.AreaDenialTK.Perc.Value = self.Config.AreaDenialTK
	
	local doneHumanTracking = false
	
	repeat
		self.I.values.timer.Value -= 1

		local t = self.I.values.timer.Value

		local stage6 = 60
		local stage5 = 120
		local stage4 = 180
		local stage3 = 240
		local stage2 = 300

		local v
		local x = false
		if t <= stage6 then
			v = 5
		elseif t <= stage5 then
			v = 4
		elseif t <= stage4 then
			v = 3
		elseif t <= stage3 then
			v = 2
		elseif t <= stage2 then
			v = 1
		else
			v = 12
		end

		if v ~= lastV then
			lastV = v
			--self.I.eventsFolder.PlaySound:FireAllClients("boom")
			if not doneHumanTracking and self.Config.HumanTracking and self.Config.HumanTracking.Enabled and v == self.Config.HumanTracking.Hour then
				doneHumanTracking = true
				M.EnableHumanTracking(self)
			end
			
			self.I.valuesFolder.AMValue.Value = v
			
			if v ~= 12 then
				self.gameAM = v 
				
				M.BellToll(self)
				for p,_ in pairs(self.aliveHumans) do
					local _s,_e = pcall(function()
						if p and p.Parent then
							M.PlayerHandler.GrantHourCash(self,p,v)
						end
					end)
					if not _s then
						warn("GrantCashMainError:",_e)
					end
				end
				
				if v == 4 then
					local 	t = {
						TextColor3 = Color3.fromRGB(255, 121, 123);
						TextStrokeColor3 = Color3.new(0,0,0);
						TextTransparency = 0;
						TextStrokeTransparency = 0;
						Text = "THE HUNTERS AWAKEN"
					}

					self.I.eventsFolder.DescMessage:FireAllClients(t,10)
				elseif v == 3 then
					local 	t = {
						TextColor3 = Color3.fromRGB(255, 121, 123);
						TextStrokeColor3 = Color3.new(0,0,0);
						TextTransparency = 0;
						TextStrokeTransparency = 0;
						Text = "THEY GROW STRONGER"
					}

					self.I.eventsFolder.DescMessage:FireAllClients(t,10)
				end
			else
				self.gameAM = 0
			end
		end

		self.I.values.desc.BlinkRed.Value = self.I.values.timer.Value <= 10
		self.I.values.desc.Value = tostring(self.I.values.timer.Value)

		self.I.values.desc.Value = tostring(v) .. " AM"

		task.wait(1)
	until self.I.values.timer.Value <= 0 or M.PlayerHandler.GetHumanCount(self) <= 0

	M.GameEnd(self)
end

function M:GetBridgeSpawnLocation(plr)
	local possibleSpawns = {}
	for i,v in pairs(workspace.Filter.Spawns:GetChildren()) do
		if v.Neutral or v.TeamColor == plr.TeamColor then
			table.insert(possibleSpawns,v)
		end
	end

	local availableSpawns = {}
	for i,v in pairs(possibleSpawns) do
		if not self.takenBridgeSpawns[v] then
			table.insert(availableSpawns,v)
		end
	end

	if #availableSpawns > 0 then
		local chosenSpawn = availableSpawns[math.random(1,#availableSpawns)]
		return chosenSpawn
	end
end

function M:SetBridgeSpawnLocation(plr,noRespawn)
	local chosenSpawn = M.GetBridgeSpawnLocation(self,plr)
	
	if chosenSpawn then
		table.insert(self.takenBridgeSpawns,chosenSpawn)
		if noRespawn then
			local root = plr.Character and plr.Character:FindFirstChild("HumanoidRootPart")
			if root then
				pcall(function()
					_G.cTag(plr.Character.Humanoid,"CTP",2)
				end)
				coroutine.wrap(function()
					root.Anchored = true
					for i = 1,2 do
						root.CFrame = chosenSpawn.CFrame + Vector3.new(0,2,0)
						RunService.Heartbeat:Wait()
					end
					task.wait(1)
					root.Anchored = false
				end)()
			end
		else
			plr.RespawnLocation = chosenSpawn
			M.PlayerHandler.LoadCharacter(self,plr,nil,chosenSpawn)
		end
		
		--print("got bridge spawn",plr)
	else
		plr.RespawnLocation = nil
		--print("no available bridge spawns",plr)
	end
	
	return chosenSpawn
end

function M:PreparePhase()
	self.activeGame = true
	self.gMode = "prepare"
	self.I.values.mode.Value = self.gMode
	
	self.isStartPhase = true
	self.gameEnding = false
	self.killedZombies = false
	self.I.values.mode.Value = self.gMode

	self.BlackoutM.Toggle(false,false)
	
	M.ClearUp(self)

	ReplicatedStorage.Values.ResettingDisabled.Value = true
	ReplicatedStorage.Values.RespawningDisabled.Value = false
	
	self.prepareCC = Instance.new("ColorCorrectionEffect")
	for i,v in pairs(self.Config.PrepareCC) do
		self.prepareCC[i] = v
	end
	self.prepareCC.Parent = game.Lighting
	
	if self.winResult == "Survivors" then
		for v,t in pairs(self.aliveHumans) do
			local _s,_e = pcall(function()
				if v.Parent then
					local amt = self.Config.WinCash_Humans

					M.PlayerHandler.IncreaseWins(self,v)

					--print("reward",v,amt)

					ServerStorage.Events3.nMonee:Fire("IU3898EJKLOY89TYZJDKLJGYI390WKHJSDHG9UKLJLEDGKLJERG9U",v,"Cash",amt)
					pcall(function()
						local tab = {
							Title = "Cash Awarded";
							Text = "Awarded $" .. tostring(amt) .. " for surviving.";
							--Icon = "";
							Duration = 15;
							Button1 = "Close";
						}
						game:GetService("ReplicatedStorage").Events.Notification:FireClient(v,tab,"change")	
					end)
				end
			end)
			if not _s then
				warn("SurvivorsWinError888:",_e)
			end
		end
	elseif self.winResult == "Infected" then
		for i,v in pairs(self.originalInfected) do
			local _s,_e = pcall(function()
				if v.Parent then
					--M.PlayerHandler.IncreaseWins(self,v)

					local amt = self.Config.WinCash_OriginalInfected

					ServerStorage.Events3.nMonee:Fire("IU3898EJKLOY89TYZJDKLJGYI390WKHJSDHG9UKLJLEDGKLJERG9U",v,"Cash",amt)
					pcall(function()
						local tab = {
							Title = "Cash Awarded";
							Text = "Awarded $" .. tostring(amt) .. " for original Infected win.";
							--Icon = "";
							Duration = 15;
							Button1 = "Close";
						}
						game:GetService("ReplicatedStorage").Events.Notification:FireClient(v,tab,"change")	
					end)
				end
			end)
			if not _s then
				warn("InfectedsWinError888:",_e)
			end
		end
	end
	
	local oldAliveHumans = deepCopy(self.aliveHumans)
	
	--print(oldAliveHumans)
	
	self.winResult = nil
	self.aliveHumans = {}
	self.originalInfected = {}
	--give everyone their ammo back
	
	self.I.values.descEnabledV.Value = false
	self.I.values.titleEnabledV.Value = false
	
	ReplicatedStorage.Values.ResettingDisabled.Value = true
	ReplicatedStorage.Values.TimeState.Value = 14
	
	task.wait(0.1)
	
	local nms = {}
	local gottings = {}
	
	local function DoTingPlayer(v,justSpawned,noOrigin)
		if gottings[v] then return end
		gottings[v] = true
		
		v:SetAttribute("ForceRandomAvatar",nil)
		--v:SetAttribute("NoRespawnUI",nil)
		M.PlayerHandler.SetStarterCash(self,v)
		
		if not noOrigin then
			table.insert(self.originalHumans,v)
		end
		
		local isOldAliveHuman = oldAliveHumans[v]
		if isOldAliveHuman then
			if v.Character 
				and v.Character:FindFirstChild("Humanoid") 
				and v.Character.Humanoid.Health > 0 
				and v.Character:FindFirstChild("HumanoidRootPart") 
			then
				isOldAliveHuman = true
				v.Character.Humanoid:UnequipTools()
			else
				isOldAliveHuman = false
			end
		end
		
		if isOldAliveHuman then
			for i,z in pairs(v.Backpack:GetChildren()) do
				if z:GetAttribute("OneTimeUseWep") then
					v.Character:SetAttribute("Shop_HasGun",nil)
					game.Debris:AddItem(z,10)
					spawn(function()
						if v:FindFirstChild("DisconREMOTE") and z.DisconREMOTE.ClassName == "RemoteFunction" then
							z.DisconREMOTE:InvokeClient(v)
						end
						z:Destroy()
					end)	
				end
			end
		end
		
		M.SetBridgeSpawnLocation(self,v,isOldAliveHuman and not (v.Character and v.Character:GetAttribute("BridgeSetRespawn")))
		
		--if justSpawned then
		--	task.wait(0.2)
		--end

		local char = v and v.Parent and v.Character
		char = v and v.Parent and v.Character
		if char then
			local vf = _G.GVF and _G.GVF(v.Name)

			if vf then
				for _,v in pairs(vf.Tags:GetChildren()) do
					if string.find(v.Name,"inCombat_") or v.Name == "creator" or v.Name == "assist" then
						v:Destroy()
					end
				end
			end
			
			local ff = char:FindFirstChildOfClass("ForceField")
			if ff then
				ff:Destroy()
			end

			table.insert(nms,_G.AffectChar(char,"CM",math.huge))
			table.insert(nms,_G.AffectChar(char,"JR",math.huge,"WKVL2",1000))
			table.insert(nms,_G.AffectChar(char,"AC",0))
			table.insert(nms,_G.AffectChar(char,"AS",math.huge))
			table.insert(nms,_G.AffectChar(char,"B",math.huge))
		end
	end

	self.NewPlayerLoadedInFunc = function(plr)
		--print("yeahh new plr loaded in func")
		DoTingPlayer(plr,true)
	end

	for v,_ in pairs(self.activePlayers) do
		local _s,_e = pcall(function()
			DoTingPlayer(v)
		end)
		
		if not _s then
			warn("DoTingPlayer Error:",v,_e)
		end
	end
	
	ReplicatedStorage.Values.LoadingInDisabled.Value = false
	
	self.gMode = "intermission"
	self.I.values.mode.Value = self.gMode

	self.I.values.desc.Value = ""
	self.I.values.title.Value = "INTERMISSION"
	self.I.values.descEnabledV.Value = false
	self.I.values.titleEnabledV.Value = true
	self.I.values.desc.BlinkRed.Value = true
	
	spawn(function()
		for v,_ in pairs(self.activePlayers) do
			local _s,_e = pcall(function()
				if v and v.Parent then
					self.LeaderboardHandler.UpdateLeaderboardData(self,v)
					self.PlayerHandler.DoTrySaveMainData(self,v)
				end
			end)
			if not _s then
				warn("Line1057Error:",_e)
			end			
		end
	end)
	
	if not self.skipEntireStartPhase then
		local timer = self.Config.IntermissionTime
		self.I.values.timer.Value = timer
		self.I.values.desc.Value = tostring(timer)
		self.I.values.descEnabledV.Value = true
		task.wait(1)
		self.I.values.desc.BlinkRed.Value = false

		repeat
			self.I.values.timer.Value -= 1
			self.I.values.desc.BlinkRed.Value = self.I.values.timer.Value <= 10
			self.I.values.desc.Value = tostring(self.I.values.timer.Value)
			task.wait(1)
		until self.I.values.timer.Value <= 0

		self.I.values.titleEnabledV.Value = false
	end
	
	ServerStorage.Values.DisableLoadInSpawnCharacter.Value = false

	task.wait(1)
	
	self.NewPlayerLoadedInFunc = function(plr)
		--print("yeahh new plr loaded in func")
		DoTingPlayer(plr,true,true)
	end
	
	M.PlayerHandler.RefillAllAmmo(self)
	
	if not self.skipEntireStartPhase then
		local t = {
			Text = "GEAR UP";
		}
		self.I.eventsFolder.ScreenText:FireAllClients(t,3,1,"boom")

		task.wait(5)

		--self.I.eventsFolder.PlaySound:FireAllClients("boom")
		
		if self.purchasedTokenContent["Juggernaut"] then
			local stock = ReplicatedStorage.Values.GlobalStocks.CurrentStocks["Juggernaut"]
			stock.Value = 0
			self.purchasedTokenContent["Juggernaut"] = nil
		end
		if self.purchasedTokenContent["UTS_15"] then
			--local stock = ReplicatedStorage.Values.GlobalStocks.CurrentStocks["UTS-S"]
			--stock.Value = 0
			self.purchasedTokenContent["UTS_15"] = nil
		end
		if self.purchasedTokenContent["RayGun"] then
			local stock = ReplicatedStorage.Values.GlobalStocks.CurrentStocks["RayGun"]
			stock.Value = 0
			self.purchasedTokenContent["RayGun"] = nil
		end
		if self.purchasedTokenContent["PrecisionStrike"] then
			--local stock = ReplicatedStorage.Values.GlobalStocks.CurrentStocks["PrecisionStrike"]
			--stock.Value = 0
			self.purchasedTokenContent["PrecisionStrike"] = nil
		end
		
		self.buyZonesV.Value = true
		self.I.values.desc.Value = ""
		self.I.values.title.Value = "GEAR UP"
		self.I.values.descEnabledV.Value = false
		self.I.values.titleEnabledV.Value = true

		local timer = self.Config.BuyTime
		self.I.values.timer.Value = timer
		self.I.values.desc.Value = tostring(timer)
		self.I.values.descEnabledV.Value = true
		task.wait(1)
		self.I.values.desc.BlinkRed.Value = false

		repeat
			self.I.values.timer.Value -= 1
			self.I.values.desc.BlinkRed.Value = self.I.values.timer.Value <= 10
			self.I.values.desc.Value = tostring(self.I.values.timer.Value)
			task.wait(1)
		until self.I.values.timer.Value <= 0
	end

	self.I.values.titleEnabledV.Value = false
	self.buyZonesV.Value = false
	self.isStartPhase = false
	
	self.NewPlayerLoadedInFunc = nil
	ReplicatedStorage.Values.ResettingDisabled.Value = true
	ReplicatedStorage.Values.RespawningDisabled.Value = true
	ReplicatedStorage.Values.LoadingInDisabled.Value = true
	
	if not self.skipEntireStartPhase then
		task.wait(1)

		local t = {
			Text = "GET READY";
		}
		self.I.eventsFolder.ScreenText:FireAllClients(t,3,1,"boom")

		TS:Create(self.prepareCC,TweenInfo.new(6,Enum.EasingStyle.Quart,Enum.EasingDirection.In),{Saturation = 0;Contrast = 0;Brightness = 0}):Play()
		

		local sewersDisabled = math.random(1,3) ~= 1
		
		if sewersDisabled then
			M.DisableSewers(self)
		end

		task.wait(6)
		self.I.values.desc.Value = ""
		self.I.values.title.Value = "GET READY"
		self.I.values.descEnabledV.Value = false
		self.I.values.titleEnabledV.Value = true
		
		delay(2,function()
			for v,_ in pairs(self.activePlayers) do
				local 	t = {
					
					TextStrokeColor3 = Color3.new(0,0,0);
					TextTransparency = 0;
					TextStrokeTransparency = 0;
				}
				
				if sewersDisabled then
					t.Text = "SEWERS BLOCKED"
					t.TextColor3 = Color3.fromRGB(255, 121, 123);
				else
					t.Text = "SEWERS OPEN"
					t.TextColor3 = Color3.fromRGB(123, 255, 134);
				end
				
				self.I.eventsFolder.DescMessage:FireClient(v,t,5,true)
			end
		end)

		for i,v in pairs(nms) do
			if v and v.Parent then
				v:Destroy()
			end
		end
		nms = {}

		local timer = self.Config.PrepareTime
		self.I.values.timer.Value = timer
		self.I.values.desc.Value = tostring(timer)
		self.I.values.descEnabledV.Value = true
		task.wait(1)
		self.I.values.desc.BlinkRed.Value = false

		repeat
			self.I.values.timer.Value -= 1
			self.I.values.desc.BlinkRed.Value = self.I.values.timer.Value <= 10
			self.I.values.desc.Value = tostring(self.I.values.timer.Value)
			task.wait(1)
		until self.I.values.timer.Value <= 0
	else
		TS:Create(self.prepareCC,TweenInfo.new(0,Enum.EasingStyle.Quart,Enum.EasingDirection.In),{Saturation = 0;Contrast = 0;Brightness = 0}):Play()
		for i,v in pairs(nms) do
			pcall(function()
				v:Destroy()
			end)
		end
	end
	
	self.I.values.titleEnabledV.Value = false
	
	M.GamePhase(self)
end

function M:MainGame()
	M.PreparePhase(self)
end

function M:WaitForPlayers()
	local dontWait = false

	ReplicatedStorage.Values.TimeState.Value = 10
	local pCount = M.PlayerHandler.GetActivePlayerCount(self)
	
	self.gMode = "waiting"
	self.I.values.mode.Value = self.gMode
	
	self.I.values.desc.Value = "WAITING FOR PLAYERS [" .. tostring(pCount) .. "/" .. self.Config.MinimumPlayers .. "]"
	self.I.values.title.Value = ""
	self.I.values.descEnabledV.Value = true
	self.I.values.titleEnabledV.Value = true

	if pCount >= self.Config.MinimumPlayers then
		M.MainGame(self)
	end
end

function M:MainLoop()
	if not M.GameHandler_IsSetUp then return end
	if self.activeGame then
		
	else
		M.WaitForPlayers(self)
	end
end

function M:HardCleanUp()
	self.gameValues = {}
	self.aliveHumans = {}
	self.originalInfected = {}
	self.lastOriginalInfected = {}
	self.originalHumans = {}
	self.winHumans = {}

	self.gMode = ""
	self.I.values.mode.Value = self.gMode

	self.buyZonesV.Value = false
	self.I.values.desc.Value = ""
	self.I.values.title.Value = ""
	self.I.values.descEnabledV.Value = false
	self.I.values.titleEnabledV.Value = false
	self.takenBridgeSpawns = {}
	self.gameAM = 0
	self.roundStartTick = 0
	
	self.purchasedTokenContent = {}
	
	ServerStorage.Values.DeathCashDropMulti.Value = 0
	ServerStorage.Values.SpawnCloseToOthers.Value = true
	ReplicatedStorage.Values.DisableDropHighlights.Value = true
	ServerStorage.Values.DisableDroppingCash.Value = true
	ServerStorage.Values.RemoveDealers.Value = true
	ReplicatedStorage.Values.AllowanceDisabled.Value = true
	--ReplicatedStorage.Values.UI_RemoveLevelBar.Value = true
	ReplicatedStorage.Values.SkipMenuIntro.Value = true
	ServerStorage.Values.NoCashDrop.Value = true
	ServerStorage.Values.DeathCashDropMulti.Value = 0
	
	ReplicatedStorage.Values.LoadingInDisabled.Value = false
	
	ServerStorage.Values.DisableMinCashToBank.Value = true
	
	workspace.Audio.UndergroundAmbience.Volume = 0
end

function M:new()
	if M.GameHandler_IsSetUp then return end
	M.GameHandler_IsSetUp = true
	
	M.PlayerHandler = require(script.Parent.PlayerHandler)
	self.BlackoutM = require(game.ServerScriptService.Blackout)
	
	self.activePlayers = {}
	self.teams = {}
	self.skipEntireStartPhase = self.Config.TestSkipStartPhase
	
	self.teams.Survivors = Instance.new("Team")
	self.teams.Infected = Instance.new("Team")
	self.teams.Survivors.Name = "Survivors"
	self.teams.Infected.Name = "Infected"
	self.teams.Survivors.TeamColor = BrickColor.new("Bright blue")
	self.teams.Infected.TeamColor = BrickColor.new("Bright green")
	self.teams.Survivors.AutoAssignable = false
	self.teams.Infected.AutoAssignable = false
	self.teams.Survivors.Parent = game:GetService("Teams")
	self.teams.Infected.Parent = game:GetService("Teams")
	
	self.audioF = script.Sounds
	
	script.InfectedTrusses:Clone().Parent = workspace:WaitForChild("Debris")
	
	self.ambientSound = workspace.Audio.SewerAmbience:Clone()
	self.ambientSound.Parent = workspace.Audio
	self.ambientSound.Name = ""
	self.ambientSound.SoundId = "rbxassetid://11489684479"	
	self.ambientSound.Volume = 1
	self.ambientSound.Looped = true
	self.ambientSound.Playing = false

	M.ClearUp(self)
	M.HardCleanUp(self)
	
	spawn(function()
		task.wait(5)
		ServerStorage.Values.NoAssistIfDie.Value = false
		while task.wait(1) do
			local _s,_e = pcall(function()
				M.MainLoop(self)
			end)
			
			if not _s then
				warn("MAINLOOP ERROR!:",_e)
				M.HardCleanUp(self)
				self.activeGame = false
				wait(1)
			end
			
		end
	end)
end

return M