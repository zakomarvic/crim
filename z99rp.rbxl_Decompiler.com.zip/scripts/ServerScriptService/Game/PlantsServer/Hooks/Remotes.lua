-- SERVER

local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
local sessions = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Objects"):WaitForChild("Sessions"))
--
local Calls = {}
--
Calls["LookVector"] = function(plr,data)
	if plr.Character and plr.Character:FindFirstChild("Humanoid") and typeof(data)=="Vector3" then
		plr.Character.Humanoid:SetAttribute("LookVector",data)
	end
end
--
Calls["ClientLoaded"] = function(plr)
	plr:SetAttribute("PlantsClientLoaded", true)
end
--
Calls["SaveBefriendingSetting"] = function(plr, data)
	plr:SetAttribute("BSetting".. data.setting, data.value)
end
--
Calls["UseEmote"] = function(plr, data)
	_G.EmotesSystem.play(plr.Character, data.emote)
end
--
Calls["UpdateRagdoll"] = function(plr, data)
	framework.networking.toClientsExcept(nil, true, "UpdateCharacter", {action = "ragdollCFrames", data = {cframes = data, character = plr.Character}})
end
--
Calls["ResettingCharacter"] = function(plr, data)
	--
	local char = plr.Character
	local root = char:FindFirstChild("HumanoidRootPart")
	local hum = char:FindFirstChild("Humanoid")
	local values = _G.GVF(char.Name)
	--
	if (_G.SafeCheck({char, root, hum, values}) and (char:GetAttribute("IsResetting") ~= true)) then
		task.spawn(function() 
			--
			local endthis = false
			local timer = (_G.InCombatCheck(plr, true) and 10) or 3
			--
			local lasthp = hum.Health
			local lastpos = root.Position
			char:SetAttribute("IsResetting", true)
			local gui = game:GetService("ReplicatedStorage").PlantsStorage.Assets.Storage.ResetGui:Clone()
			gui.Enabled = true
			gui.Parent = root
			--
			repeat
				local delta = task.wait()
				--
				timer -= delta
				gui.Label.Text = math.ceil(timer)
				--
				if (hum.Health ~= lasthp) then
					if (hum.Health < lasthp) then
						endthis = true
					end
					--
					lasthp = hum.Health end
				if (root.Position - lastpos).Magnitude >= 0.2 then
					endthis = true end
				--
			until (endthis or not _G.SafeCheck({char, root, hum, values}) or timer <= 0)
			--
			_G.SafeDestroy(gui)
			if (timer <= 0) then
				_G.ApplyDeathLegitimacy(char, "RESET", true, 10)
				hum:TakeDamage(math.huge)
				hum.Health -= math.huge
			end
			--
			char:SetAttribute("IsResetting", false)
		end)
	end
end
--
Calls["SessionAction"] = function(plr, data)
	--
	local id = data.id
	local action = data.action
	local ddata = data.data
	--
	local session = sessions.get(id)
	session:received(action, ddata)
	--
end
--
Calls["BefriendRequest"] = function(plr, data)
	--	
	local who = data.who
	local whoPlr = game.Players:GetPlayerFromCharacter(who)
	if (who == nil or whoPlr == nil) then end
	local brqc = plr:GetAttribute("brqcooldown")
	local obrqc = whoPlr:GetAttribute(plr.Name.."_brqcooldown")
	-- Cooldown Checks
	
	if (brqc ~= nil and (os.clock() - brqc) <= 10) then
		game:GetService("ReplicatedStorage").Events.ClientWarn:FireClient(plr,{"Please wait a bit before sending another glory request.",1,Color3.fromRGB(255, 121, 121),Color3.new(0,0,0),"lost"}) 
		return end
	if (obrqc ~= nil and (os.clock() - obrqc) <= 25) then
		game:GetService("ReplicatedStorage").Events.ClientWarn:FireClient(plr,{"Please wait a bit before sending another glory request to this person.",1,Color3.fromRGB(255, 121, 121),Color3.new(0,0,0),"lost"}) 
		return end
	-- Status Checks
	
	if not framework.Gs.SafeCheck({plr.Character, whoPlr.Character}) then 
		return end
	if not _G.CheckIfCan(plr.Character,"Any") or not _G.CheckIfCan(whoPlr.Character,"Any") then
		return end
	-- Functionality
	
	plr:SetAttribute("brqcooldown", os.clock())
	whoPlr:SetAttribute(plr.Name.."_brqcooldown", os.clock())
	local session = sessions.new(nil, whoPlr)
	framework.networking.toClient(whoPlr, false, "BefriendRequest", {who = plr.Character.Humanoid.DisplayName, sid = session.id})
	--
	task.delay(10, function() if (session.active) then session:destroy() end end)
	session.onReceived:Connect(function(action, data) 
		--
		if (data == "a") then
			--
			local triggersession = sessions.new(nil, plr)
			framework.networking.toClient(plr, false, "BefriendFinalize", {sid = triggersession.id})
			--
			task.delay(25, function() if (triggersession.active) then triggersession:destroy() end end)
			triggersession.onReceived:Connect(function(action) 
				--
				if (action == "finalized") then
					--
					local extra = {}
					local selected = plr.Character:GetAttribute("SelectedAnim")
					local module = _G.keyboarding.getBefriendModule(selected)
					if (module) then
						if (module:GetAttribute("RequiresWall")) then
							extra.WallCFrame = _G.getBefriendingWall(plr.Character.HumanoidRootPart.CFrame).cframe end
					end _G.keyboarding.hug(plr.Character, whoPlr.Character, selected, extra)
					--
				end
				--
				triggersession:destroy()
			end)
			--
		elseif (data == "d") then
			game:GetService("ReplicatedStorage").Events.Notification:FireClient(plr, {Title = "Request Denied"; Text = "Your glory request has been denied."; Duration = 10; Button1 = "Close"}, "Beep2")	
		end
		--
		session:destroy()
	end)
	--
end
-- Added

local function insert(module: ModuleScript)
	for i, f in pairs(require(module)) do
		Calls[i] = f end end

--
return Calls