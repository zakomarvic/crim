local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local TS = game:GetService("TweenService")

local M = {}
M.__index = M

function M:Grant(player)
	local char = player.Character
	local hum = char and char:FindFirstChild("Humanoid")
	
	local stock = ReplicatedStorage.Values.GlobalStocks.CurrentStocks["PrecisionStrike"]
	
	--print("trying jugg...")
	
	local result
	local _s,_e = pcall(function()
		if char and hum and hum.Health > 0 and stock.Value > 0 and self.buyZonesV.Value and player.Team == self.teams.Survivors then
			stock.Value = 0
			--print("got1")
			
			self.purchasedTokenContent["PrecisionStrike"] = player

			local p = ServerStorage.Tools["PrecisionStrike"]:Clone()
			
			p:SetAttribute("CantDrop",true)
			p:SetAttribute("CantSell",true)
			p:SetAttribute("DisableBulletTypeChange",true)
			
			
			p.Parent = player.Backpack
			
			local conChange
			conChange = p.AncestryChanged:Connect(function(_,parent)
				if not parent or parent:IsDescendantOf(workspace.Debris) or parent == workspace.Debris then
					conChange:Disconnect()
					
					task.wait(0.25)
					
					if player and player.Parent then
						player:SetAttribute("TokenInUse_PrecisionStrike",nil)
					end
					
					if hum and hum.Parent and hum.Health > 0 then
						--
					else
						self.purchasedTokenContent["PrecisionStrike"] = nil
					end
				end
			end)
			
			local tab = {
				Title = "Precision Strike Purchased";
				Text = "Single use - Exiting server or dying will result in loss.";
				Duration = 60;
				Button1 = "Close";
			}
			ReplicatedStorage.Events.Notification:FireClient(player,tab,"purchase")	
			
			player:SetAttribute("TokenInUse_PrecisionStrike",true)
			--char:SetAttribute("NoRandomInfectChoose",true)
			--char:SetAttribute("BridgeSetRespawn",true)

			self.activePlayers[player].DataChanged = true
			
			
			local con1,con2,con3
			
			local function DoRefundCheck()
				if  player:GetAttribute("TokenInUse_PrecisionStrike")
				then
					player:SetAttribute("TokenInUse_PrecisionStrike",nil)
					M.PurchaseHandler.GrantToken(self,player,"PrecisionStrike")
					
					if player and player.Parent then
						local tab = {
							Title = "Token Refunded";
							Text = "'Precision Strike' token refunded.";
							Duration = 60;
							Button1 = "Close";
						}
						ReplicatedStorage.Events.Notification:FireClient(player,tab,"BEEP")	
					end
				end
			end
			
			local function Disconnect(doCheck)
				if con1 then
					con1:Disconnect()
					con1 = nil
				end
				if con2 then
					con2:Disconnect()
					con2 = nil
				end
				if con3 then
					con3:Disconnect()
					con3 = nil
				end
				
				print("disconnect",doCheck)
				
				if doCheck then
					DoRefundCheck()
				end
			end
			
			con1 = player:GetAttributeChangedSignal("InfectionLeaving"):Connect(function()
				Disconnect(true)
			end)
			
			con2 = char.AncestryChanged:Connect(function(_,parent)
				print(3)
				if not parent then
					print(4)
					con2:Disconnect()
					Disconnect(true)
				end
			end)
			
			con3 = ReplicatedStorage.Values.ShuttingDown.Changed:Connect(function()
				print(5)
				Disconnect(true)
			end)
			
			hum.Died:Connect(function()
				print(6)
				Disconnect(true)
			end)
			
			local c
			c = hum:GetAttributeChangedSignal("WasZombified"):Connect(function()
				c:Disconnect()
				
				Disconnect()
				DoRefundCheck(true)
			end)

			result = true
		end
	end)
	
	if not _s then
		warn("Precision Spawn Error:",_e)
		return false
	end
	
	return result
end

function M.new(self)
	if M.IsSetUp then return end
	M.IsSetUp = true
	
	M.CurrentSelf = self
	
	M.PlayerHandler = require(script.Parent.Parent.Parent.PlayerHandler)
	M.PurchaseHandler = require(script.Parent.Parent.Parent.PurchaseHandler)
	
	if self.Config.TokenContent.PrecisionStrike and self.Config.TokenContent.PrecisionStrike.Enabled then
		--print("Yeah enabled")
		
		self.PrecisionStrike_Enabled = true
		
		local j_is = ReplicatedStorage.Storage.ItemStats.Throwables["PrecisionStrike"]
		j_is.IsDevProduct.ID.Value = self.Config.TokenContent.PrecisionStrike.ProductID
		j_is.ForSale.Value = true
		j_is.MaxStock.Value = 1
		j_is.MinStock.Value = 1
		
		self.ProductIds[self.Config.TokenContent.PrecisionStrike.ProductID] = "precision_strike"

	end
end

return M