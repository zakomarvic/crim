wait(0.5)

local p_types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local p_framework: p_types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))

local TS =					game:GetService("TweenService")
local PhysicsService =		game:GetService("PhysicsService")
local ReplicatedStorage =	game:GetService("ReplicatedStorage")
local ServerStorage =		game:GetService("ServerStorage")

local model = script.Parent
local assetStorage = ServerStorage.Storage.CashRegisterStuff

local eventsDir = ReplicatedStorage.Events
local eventsDir3 = ServerStorage.Events3

local safeOpenedEvent = eventsDir3.SafeRegisterOpened

local values =		model.Values
local events =		model.Events

local primary = model.PrimaryPart
local posPart = model.PosPart
local spawnPoses = model.SpawnPoses

local bGui = ReplicatedStorage.Storage.GUIs.RequiresLockpickBGUI:Clone()

local healthV =	values.Health
local brokenV = values.Broken
local dropAmountV = model:WaitForChild("DropA")
local dropCountV = model:WaitForChild("DropC")
local bountyV = model:WaitForChild("BountV")
local alarmV = model:FindFirstChild("AlarmValue")

dropAmountV.Parent,dropCountV.Parent,bountyV.Parent = nil,nil,nil

local lPlayer = nil

local posT = {}
local amts = {}

local function alarmCheck()
	return alarmV and alarmV.Value ~= nil and alarmV.Value.Parent and alarmV.Value:FindFirstChild("Ring")
end

local function Lerp(a, b, c)
	return a + ((b - a) * c)
end

local function CalcWPerc(amt)
	local ogamt = amt
	local players_ingame = #game.Players:GetPlayers()
	local players_max = 15
	local max = amt
	local min = (max / values.MPerc.Value)
	local factor = math.clamp(players_ingame / players_max, 0, 1)
	amt = (min + ((max - min) * factor))
	return math.clamp(amt, 1, ogamt)
end

function onDamage(dmg,player)
	if brokenV.Value then return end

	local hitS = assetStorage.Sounds.Hit:GetChildren()[math.random(1,#assetStorage.Sounds.Hit:GetChildren())]:Clone()
	hitS.Parent = primary
	hitS:Play()
	game.Debris:AddItem(hitS,2)

	--if player then
	--	--eventsDir3.nBount:Fire("KLGHJRKR90U3893KJZDGNKDFZJKNWU9023JKWRG02",player,bountyV.Value)
	--end
	lPlayer = player

	healthV.Value = healthV.Value - dmg
end

function calcLoot()
	
	posT = {}
	local cashCount = math.random(dropAmountV.MinValue, dropAmountV.MaxValue) * _G.RegisterCashMulti
	local dropCount = math.random(dropCountV.MinValue,dropCountV.MaxValue)
	local cashRange = math.ceil(cashCount / dropCount)
	
	local placement = 0
	local drops = dropCount
	local locations = {}
	for i = 1, dropCountV.MaxValue do table.insert(locations, i) end
	
	while (cashCount > 0) do
		--
		local cashDrop = math.random(math.ceil(cashRange * 0.15), cashRange)
		cashDrop = math.clamp(cashDrop, 0, cashCount)
		--
		if (cashCount <= (dropCount*2)) then
			cashDrop = cashCount end
		cashCount -= cashDrop
		--
		if (drops > 0) then
			--
			drops -= 1
			local spot = locations[math.random(1, #locations)]
			_G.RemoveFromArray(locations, spot)
			local drop = {spot, cashDrop}
			table.insert(posT, drop)
			--
		else
			--
			placement += 1
			if (placement > dropCount) then placement = 1 end
			posT[placement][2] += cashDrop
			--
		end
		--
	end
	
end

function onOpen(doBreak)
	if brokenV.Value then return end

	brokenV.Value = true

	dropAmountV:Destroy()
	dropCountV:Destroy()
	bountyV:Destroy()

	bGui.Frame.Visible = false

	if model:FindFirstChild("BreakM") then
		require(model.BreakM)(lPlayer,not doBreak and TweenInfo.new(1,Enum.EasingStyle.Quint,Enum.EasingDirection.Out))
	end

	if primary:FindFirstChild("EffectA") then
		primary.EffectA.Sparkle.Enabled = false

		if primary.EffectA:FindFirstChild("PointLight") then
			primary.EffectA.PointLight:Destroy()
		end
	end

	if doBreak then
		if alarmCheck() then
			delay(math.random(75,150) / 100,function()
				alarmV.Value.Ring:Fire(90)
			end)
		end

		primary.Material = Enum.Material.CorrodedMetal

		if model:FindFirstChild("Parts") then
			for _,v in pairs(model.Parts:GetChildren()) do
				if v.Name == "CP" or v:FindFirstChild("CP") then
					v.Material = Enum.Material.CorrodedMetal
				end
			end
		end

		primary.EffectA.Smoke:Emit(20)
		primary.EffectA.Spark:Emit(15)
		spawn(function()
			while task.wait(1) do
				wait(math.random(500,2000) / 1000)
				primary.EffectA.Spark:Emit(math.random(3,6))
			end
		end)
	end

	if lPlayer then
		
		local lCharacter = lPlayer.Character
		p_framework.Gs.AffectReputation(lPlayer, -1, "Cash theft.")

		if (_G.CharHasTrait(lPlayer, "pickyrobber") and model.Type.Value == 1) then
			local registerWorth = 0
			for _, v in ipairs(posT) do
				registerWorth += CalcWPerc(v[2]) end
			--
			task.delay(_G.Random(0.5, 0.85, 100), function() 
				eventsDir3.nMonee:Fire("IU3898EJKLOY89TYZJDKLJGYI390WKHJSDHG9UKLJLEDGKLJERG9U",lPlayer,"Cash", math.ceil(registerWorth*0.15))
				_G.PlaySound(script.LooseChange, model.PrimaryPart, _G.Random(0.9, 1.1, 100))
			end)
			--
		end
		
		if doBreak then
			eventsDir3.nBount:Fire("KLGHJRKR90U3893KJZDGNKDFZJKNWU9023JKWRG02",lPlayer,bountyV.Value)
		end

		local xp = 10
		if script.Parent:FindFirstChild("LP_Bars") then
			xp = script.Parent.LP_Bars.Value * 3.333333333333333333333333333
			xp = math.floor(xp)
			if xp == 9 then
				xp = 10
			end
		end

		if not doBreak then
			xp = xp * 3
		end

		xp = math.min(xp,50)

		eventsDir3.AyuP:Fire("KLJ8902209SANK8234LDFG0OKJAKA984231ZZ04LGXBNBZ1U912",lPlayer,xp)

		safeOpenedEvent:Fire(lPlayer,model)
	end

	local s1

	if doBreak then
		s1 = assetStorage.Sounds.Break:GetChildren()[math.random(1,#assetStorage.Sounds.Break:GetChildren())]:Clone()
	else
		s1 = assetStorage.Sounds.Open:Clone()
	end

	s1.Parent = primary
	s1:Play()
	game.Debris:AddItem(s1,2)

	local s2 = assetStorage.Sounds.Drop:Clone()
	s2.Parent = primary
	s2:Play()
	game.Debris:AddItem(s2,2)

	local dCount = math.random(dropCountV.MinValue,dropCountV.MaxValue)
	dCount = math.min(dCount,10)

	local n = 0
	
	print("\nCASH DROP LOOT: ", posT)
	for _,v in pairs(posT) do
		local dAmount = v[2]
		dAmount = CalcWPerc(dAmount)
		if (_G.CharHasTrait(lPlayer, "prestinerobber")) then
			dAmount += (dAmount*0.20)
		end

		n = n + dAmount

		local ting = (model and model:FindFirstChild("RangeAdd") and model.RangeAdd.Value) or 0

		local part = spawnPoses["Pos" .. v[1]]

		local cf = part.CFrame

		local n = 5
		if model.Type.Value > 1 then
			n = 15
		end

		cf = cf * CFrame.Angles(0,math.rad(math.random(-n,n)),0)

		local cash = eventsDir3.D_CSH2:Invoke("8DR002",cf,1,dAmount,360,true)

		if doBreak and model.Type.Value > 1 then
			local force = primary.CFrame.LookVector * math.random(5,10) + (primary.CFrame.RightVector * math.random(-20,20) / 100)
			delay(0.1,function()
				_G.SMains.ForceT(cash,force,0.1,0)
			end)
		elseif model.Type.Value == 1 then
			local w = Instance.new("Weld")
			w.Part0 = model.Parts.Drawer
			w.Part1 = cash
			w.C0 = cash.CFrame:toObjectSpace(model.Parts.Drawer.CFrame):Inverse()
			w.Parent = cash
		end
	end

end

function SetUp()
	calcLoot()

	dropAmountV.Parent = values
	dropCountV.Parent = values
	bountyV.Parent = values

	if alarmV then
		alarmV.Parent = values
	end

	if model.Type.Value == 2 then
		healthV.MaxValue = 90
	elseif model.Type.Value == 3 then
		healthV.MaxValue = 120
	end
	healthV.Value = healthV.MaxValue

	local hCon
	hCon = healthV.Changed:Connect(function(x)
		if x <= 0 then
			hCon:Disconnect()
			onOpen(true)
		end		
	end)

	if model.Type.Value > 1 then	
		bGui.Parent = posPart
		bGui.Adornee = posPart
	end

	primary.EffectA.Sparkle.Enabled = true

	if model:FindFirstChild("LP_Bars") then
		values.LockpickBars.Value = model.LP_Bars.Value
		model.LP_Bars:Destroy()
	end

	events.Damage.Event:Connect(onDamage)

	events.Open.Event:Connect(function(player)
		lPlayer = player

		onOpen()
	end)
end

SetUp()