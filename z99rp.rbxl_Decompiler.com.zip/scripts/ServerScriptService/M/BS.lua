

local DATA_STORE_SERVICE =	game:GetService("DataStoreService")
local PLAYERS =				game:GetService("Players")
local SERVER_STORAGE = 		game:GetService("ServerStorage")
local MESSAGING_SERVICE = 	game:GetService("MessagingService")
local RUNSERVICE = 			game:GetService("RunService")
local ReplicatedStorage =	game:GetService("ReplicatedStorage")

local BanSystem = {
	-------
	DS_KEY =			"CRIM_MOD_SYSTEMa";
	DS_SCOPE =			"NBANSYSTEM.V1";

	L_KEY = 			"CRIM_MOD_LISTa";
	L_SCOPE_OLD =		"N_BANLIST.V1";	
	L_SCOPE =			"N_BANLIST.V2";	
	

	L_CURRENTVERSION = "V3";
	L_PASTVERSIONS = {
		"V2";
	};
	
	--L_VERSION =			"V2";
	--L_VERSION_OLD =		"V1";	
	-------

	MinReports = 3;
	ReportClearTime = 3600; --1hr
	ReportTimeOutTime = 1209600; -- 2 weeks
	
	LegacyBanWaves = {
		["BANWAVE_0"] = {
			enabled = true;
			menuOnly = true;
			
			code = "bw_0"; -- bw_0
		};
	};
	
	BanWaves = {
		
		
		--["BANWAVE_1"] = {
		--	enabled = false;
			
		--	minTime = 1659504516;
		--};
	};
	
	WarningOutdate = {
		Time =  1666750322 -- any warning before this time will instantly be revoked
	};

	AltRestrict = {
		Enabled = true;
		Code = "v2.0-t"; 
		RestrictTime = 604800; -- 7 days
	};
	
	["Unbannable"] = {
		29761878;
		2457253857;
	};
	
	["BlacklistedGroups"] = {
		--8513856; --opps
		--8976904; -- pizza
		--4509666; -- synapse
	};
	
	STUDIO_BANS = false;
	
	["Messages"] = {
		["Legacy"] =	"\n\n You've been permanently banned. \n\n If you wish to appeal, create a ticket through our Support Server.";
		["Temp"] =		"\n\n You've been banned. \n\n Reason: %s \n\n Unbanned in: %s \n\n If you wish to appeal, create a ticket through our Support Server.";
		["Anti1"] =		"\n\n You've been banned. \n\n Reason: %s \n\n Unbanned in: %s \n\n This type of ban may not be appealed." ;
		["Anti2"] =		"\n\n You've been banned. \n\n Reason: %s \n\n This type of ban may not be appealed." ;
		["Shadow"] = 	"ASCLI: Unexpected critical error [data malformed?]";
		["OnBan"] = 	"Account status updated.";
		["OnWarn"] = "Account status updated.";
		["OnReportTimeOut"] = "Account status updated.";
		["TimeOut"] = "\n\n Account placed under review for suspicious activity. \n\n If you wish to appeal, create a ticket through our Support Server.";
		["AltRestrict"] =  "\n\n Suspicious alt account detected. \n\n For the purpose of security and authenticity, blank accounts are restricted from entering. \n\n (Owning the prime gamepass bypasses this restriction)\n";
		
		["AntiDisplay"] = {
			"Tampering with client";
			"Exploiting";
			"Exploiting.";
			"exploiting.";
			"exploiting.";
			"Injecting exploits";
			"injecting scripts";
			"Using an injector";
			"Tampering with client data";
			"Running cheat software";
			"Running injector";
			"Modifying client framework";
			"Unauthorised data manipulation";
			"Client cheats";
			"Client exploits";
			"Tampering with data";
			"Modifying client data";
		}

		--Start =		"\n\n You've been banned from the game. \n\n Reason: ";
		--Middle =	"\n\n Unbanned in ";
		--End =		"\n\n If you wish to appeal, create a ticket through our Communications Server.";
	},
	
	["ErrorMessages"] = {
		["FailedToBan"] = "Unhandled error: Failed to ban player: %s, UserId: %d. Reason: %s",
		["GetData"] = "Failed to get data from user: %s with UserId: %d. Reason: %s",
		["MessageError"] = "Failed to get ban message from user: %s. Reason: User is currently not banned and Ban Object is nil",
		["FailedToKick"] = "Failed to kick player: %s Result: %s",
		["InvaildId"] = "Failed to ban %s. Reason: %d is an Invaild id. Id must be in a range from 1 - %d",
		["SubscriptionError"] = [[Failed to subscribe to a topic. 
		Some things maybe not work. Iff this happens multiple times then please add a random number to your BanSystem Module in Configuration in Topics in KickPlayerTopic.]],
		["FailedToUnban"] = "Failed to unban player: %s with UserId: %d. Reason: %s!",
		["NotEnoughPermissionsToBan"] = "Failed to ban player: %s with UserId: %d. Reason: Player is unbannable!",
		["FailedToResetModerationHistory"] = "Failed to reset moderation history of player: %s with UserId %d. Reason: %s"
	},
	["SuccessMessages"] = {
		["SuccessfullyBannedPlayer"] = "Successfully banned player: %s with UserId %d. Reason: %s, Length %s",
		["SuccessfullyBannedPlayer2"] = "Successfully anti-cheat banned player: %s with UserId %d. Reason: %s, Length %s",
		["SuccessfullyUnbannedPlayer"] = "Successfully unbanned player: %s with UserId %d",
		["SuccessfullyResetedModerationHistory"] = "Successfully reseted moderation history of player: %s with UserId %d"
	},
	
	["Topics"] = {
		["KickPlayerTopic"] = "BANSYSTEM_KICK%d";
	},
	
	MAX_BAN_DATE = 4102358400;
	
	GOLID = "ZKLFXG890ZDFGJKN43SU8IOG";
	
	["DefaultData"] = {
		Infractions =		0;
		ModerationHistory =	{};
		DataLogHistory = {};
		IsBanned =			false;
		
		BanWaveChecks = {};
	};
	
	["CachedUsers"] = {}; -- getdata
	["CachedUsers2"] = {}; -- checkibanned
	
	uid_cache = {};

	lastBanListUpdate = 0;
	CachedBanList = nil;
	
	NoStudioDo = true;
}

local banDataStore,listDataStore,antiBanStore,L_PERM_BANS,L_TIME_BANS

local repr = require(game.ServerScriptService.repr)

local logRemote = SERVER_STORAGE:WaitForChild("Events3"):WaitForChild("OLGR")
local _SH = false

local isStudio = RUNSERVICE:IsStudio()
----------------
local function DataStoreRetry(player, func, maxTries,x)
	for tries = 1, maxTries do
		if x or (player and player.Parent) then
			local success, receive = pcall(func)
			if success then
				return success, receive, tries
			else
				warn("Failed to grab datastrore, retrying...",receive)
				wait(10)
			end
		else
			return false, "nil", tries
		end
	end
end

local function getPlrKey(plr)
	return "Player-"..plr.UserId
end

local function RoundToPlace(num, places)
	return math.floor((num*(10^(places or 0)))+0.5)/(10^(places or 0))
end;

local deepCopy = require(ReplicatedStorage.Modules.DeepCopy)

local function getUserIdFromUsername(name)
	-- First, check if the cache contains the name
	if BanSystem.uid_cache[name] then return BanSystem.uid_cache[name] end
	-- Second, check if the user is already connected to the server
	local player = PLAYERS:FindFirstChild(name)
	if player then
		BanSystem.uid_cache[name] = player.UserId
		return player.UserId
	end 
	-- If all else fails, send a request
	local id
	pcall(function ()
		id = PLAYERS:GetUserIdFromNameAsync(name)
	end)
	BanSystem.uid_cache[name] = id
	return id
end

local function _isNotBannable(userId)
	for _, unbannableUserId in pairs(BanSystem.Unbannable) do
		if (unbannableUserId == userId) then
			return true
		end
	end
	
	--if userId == game.CreatorId then
	--	return true
	--end
	
	return false
end

local function _GetUsername(userId)
	local name = "n/a"
	pcall(function()
		name = PLAYERS:GetNameFromUserIdAsync(userId)
	end)
	return name
end

local function _GetPlrInstance(tab)
	return PLAYERS:FindFirstChild(tab.UserName)
end

local RoundToPlace = function(num, places)
	return math.floor((num*(10^(places or 0)))+0.5)/(10^(places or 0))
end;

local function Warn(m)
	warn(m)
end

----------------

BanSystem.SetUp = function()
	if _SH then return end
	_SH = true
	
	banDataStore =	DATA_STORE_SERVICE:GetDataStore(BanSystem.DS_KEY,BanSystem.DS_SCOPE)
	
	listDataStore =	DATA_STORE_SERVICE:GetDataStore(BanSystem.L_KEY,BanSystem.L_SCOPE)
	
	antiBanStore =	DATA_STORE_SERVICE:GetDataStore("CRIM_AA_BANSTOREa",1)
	
	L_PERM_BANS = 	require(script:WaitForChild("Legacy_PermBans"))
	wait()
	L_TIME_BANS =	require(script:WaitForChild("Legacy_TimeBans"))
	script.Legacy_TimeBans:Destroy()
	script.Legacy_PermBans:Destroy()
	
	local success: boolean, connection: any = pcall(function() : any
		return MESSAGING_SERVICE:SubscribeAsync(BanSystem.Topics.KickPlayerTopic, function(message: any)
			for _, player: Player in pairs(PLAYERS:GetPlayers()) do
				if (player.Name == message.Data.Player) then
					pcall(function()
						local vf = _G.GVF and _G.GVF(player.Name)					
						if vf then
							for _,z in pairs(vf.Tags:GetChildren()) do
								if string.find(z.Name,"inCombat_") or z.Name == "creator" or z.Name == "assist" then
									z:Destroy()
								end
							end
						end
					end)
					player:Kick(message.Data.Message);
				end
			end
		end)
	end)
end

BanSystem.new = function(userId)	
	local self: typeof(BanSystem)= {
		["UserName"] = _GetUsername(userId),
		["UserId"] = userId,
		["Bannable"] = nil
	};

	self.Bannable = not _isNotBannable(self.UserId);
	self.GetPlayer = function()
		return PLAYERS:FindFirstChild(self.UserName)
	end
	
	self.AdminCheck = function()
		return _G.Adonis and self.GetPlayer() and _G.Adonis.GetLevel(self.GetPlayer()) > 10
	end
	
	self.GetAdminLevel = function()
		return (_G.Adonis and self.GetPlayer() and _G.Adonis.GetLevel(self.GetPlayer())) or 0
	end

	setmetatable(self, BanSystem);

	return self;
end

BanSystem.FormatTime = function(startTime,endTime,customTime)
	endTime = math.min(endTime,BanSystem.MAX_BAN_DATE)
	local timeLeft = endTime-os.time()
	
	if customTime then
		timeLeft = customTime
	end

	local banDesc = "days"
	local banDiv = 86400
	local roundPoint = 0

	--local date = os.date("*t",endTime)
	--local tim = tostring(date.month .. "/" .. date.day .. "/" .. date.year)

	if timeLeft < 86400 and timeLeft > 3600 then
		banDesc = "hours"
		banDiv = 3600
	elseif timeLeft <= 3600 and timeLeft > 60 then
		banDesc = "minutes"
		banDiv = 60				
	elseif timeLeft <= 60 then
		banDesc = "seconds"
		banDiv = 1
	end

	local banTime = tostring(RoundToPlace(timeLeft/banDiv, roundPoint)) .. " " .. banDesc 
	--.. " (" .. tim .. ")"
	--TFM:Convert(timeLeft, "default", false)

	return banTime  
end


BanSystem.UpdateBanList = function(dataah)
	local pastDatas = {}
	
	local data2 = {}
	local data_old = {}

	local success1,errorMessage1,tries1
	--if not dataah then
		success1, errorMessage1, tries1 = DataStoreRetry(
			nil,
			function() 
				data2 = listDataStore:GetAsync(BanSystem.L_CURRENTVERSION);
			end,
			3,
			true
		)
	--else
	--	success1 = true
	--	dataah = data2
	--end
	
	if not success1 then
		error("Failed to get")
	end
	
	for i,key in pairs(BanSystem.L_PASTVERSIONS) do
		local success2,errorMessage2,tries2
		if not dataah then
			success2, errorMessage2, tries2 = DataStoreRetry(
				nil,
				function() 
					local result = listDataStore:GetAsync(key)
					
					if result then
						table.insert(pastDatas,result)
					else
						warn("Error getting result for PastVersion",key)
					end
				end,
				2,
				true
			)
		else
			success2 = true
			--dataah = data
		end
	end
	
	
	
	--local success2,errorMessage2,tries2
	--if not dataah then
	--	success2, errorMessage2, tries2 = DataStoreRetry(
	--		nil,
	--		function() 
	--			data_old = listDataStore:GetAsync(BanSystem.L_VERSION_OLD);
	--		end,
	--		2,
	--		true
	--	)
	--else
	--	success2 = true
	--	--dataah = data
	--end

	if success1 then
		if data2 then
			data2 = data2.List
			
			--if data_old then
			--	--data.BanCount += data_old.BanCount // lol
			--	for i,v in pairs(data_old.List) do
			--		table.insert(data,v)
			--	end
			--end
			
			for i,v in pairs(pastDatas) do
				for i2,v2 in pairs(v.List) do
					table.insert(data2,v2)
				end
			end
			
			for i,v in pairs(data2) do
				if v.BanStartTime and not v.StartTime then
					v.StartTime = v.BanStartTime
				end
				
				if not v.StartTime then
					v.StartTime = 0
				end

				if not v.EndTime and (v.BanTime and v.BanStartTime) then
					v.EndTime = v.BanStartTime + v.BanTime
				end
			end
			
			warn("Got datastore ban list")

			for _,v in pairs(L_TIME_BANS) do
				if math.min(v.EndTime,BanSystem.MAX_BAN_DATE) - os.time() > 0 then
					v.IsLegacy = true;
					table.insert(data2,v)
				end
			end

			for _,v in pairs(L_PERM_BANS) do
				local pN,pU = v:match("^(.*):(.*)")
				local t = {
					Type =		"perm";
					Reason =	"N/A";
					UserId =	pU;
					Name =	pN;

					IsOld =		true;

					EndTime = BanSystem.MAX_BAN_DATE;
					StartTime = 0;
				}

				table.insert(data2,t)
			end
		else
			warn("Failed to get datastore banlist")
			return
		end
	end

	if (success1 == false) then
		warn("Failed to get ban list")
		return nil
	else

		--if data2[v.UserId] then
		--	if v.StartTime < data2[v.UserId].StartTime then
		--		table.remove(data,i)
		--	elseif v.StartTime > data2[v.UserId].StartTime then
		--		table.remove(data,data2[v.UserId].nPos)
		--		v.nPos = i
		--		data2[v.UserId] = v
		--	end	
		--else
		--	v.nPos = i
		--	data2[v.UserId] = v
		--end

		table.sort(data2,function(a,b)
			return a.StartTime > b.StartTime
		end)

		BanSystem.CachedBanList = data2
		BanSystem.lastBanListUpdate = os.time()
		delay(300,function()
			if os.time() - BanSystem.lastBanListUpdate >= 299 then
				BanSystem.CachedBanList = nil
			end
		end)

		return data2
	end
end

BanSystem.GetBanList = function()
	if not BanSystem.CachedBanList or os.time() - BanSystem.lastBanListUpdate > 300 then
		BanSystem.UpdateBanList()
	end
	
	return BanSystem.CachedBanList
end

----------------

function BanSystem:GetBanMessage(banData,banType)
	if banType == "old" then
		return BanSystem.Messages.Legacy
	elseif banType == "anti" then
		if not banData.ShadowTime then
			return string.format(BanSystem.Messages.Anti1,"Exploiting", BanSystem.FormatTime(banData.BanStartTime,math.min(banData.BanStartTime + banData.BanTime,BanSystem.MAX_BAN_DATE)))
		else
			return string.format(BanSystem.Messages.Anti2,"Exploiting")
		end
	elseif banType == "shadow" then
		return BanSystem.Messages.Shadow
	elseif banType == "timeout" then
		return BanSystem.Messages.TimeOut
	elseif banType == "altrestrict" then
		return BanSystem.Messages.AltRestrict
	else
		return string.format(BanSystem.Messages.Temp, banData.Reason, BanSystem.FormatTime(banData.StartTime,math.min(banData.EndTime,BanSystem.MAX_BAN_DATE)))
	end
end

function BanSystem:GetCachedData(m)
	local z = (m == 1 and BanSystem.CachedUsers) or BanSystem.CachedUsers2
	if z[self.UserId] then
		return z[self.UserId].data
	end
end

function BanSystem:ClearCachedData(m)
	local z = (m == 1 and BanSystem.CachedUsers) or BanSystem.CachedUsers2
	if z[self.UserId] then
		warn("cleared cached",self.UserId)
		z[self.UserId] = nil
	end
end

function BanSystem:UpdateCachedData(m,id,data)
	local z = (m == 1 and BanSystem.CachedUsers) or BanSystem.CachedUsers2
	
	z[id] = {cacheTick = tick(); data = data}
	delay(60,function()
		if z[self.UserId] and os.time() -  z[self.UserId].cacheTick > 59 then
			z[self.UserId] = nil
		end
	end)
end

function BanSystem:GetData(doUpdate)
	local data = not doUpdate and self:GetCachedData(1)
	
	local success, errorMessage, tries
	if not data then
		success, errorMessage, tries = DataStoreRetry(
		nil,
		function() 
			data = banDataStore:GetAsync(tostring(self.UserId));
		end,
		3,
		true
	)
	end

	if (success == false) then
		warn(string.format(BanSystem.ErrorMessages.GetData, self.UserName, self.UserId, errorMessage));
	else
		if doUpdate then
			BanSystem:UpdateCachedData(1,self.UserId,data)
		end
	end

	return data,success;
end

function BanSystem:GetCurrentWarning(doUpdate)
	local data = self:GetData()
	
	if data then
		return data.CurrentWarning
	end
end

function BanSystem:GetDataHistory(doUpdate)
	local data = self:GetData()

	if data then
		print(data.DataLogHistory)
		return data.DataLogHistory
	end
end

function BanSystem:GetEntire(str)
	local data = self:GetData()

	if data then
		if str then
			return repr(data)
		else
			return data
		end
	end
end

function BanSystem:AddExploitLog(logDesc) -- xp, cash level etc
	if not logDesc then return end
	
	logDesc = logDesc or "N/A"
	logDesc = tostring(logDesc)

	warn("adding exploit log for",self.Name)
	
	local code = math.floor(math.random() * 1000000)

	local success, errorMessage, tries = DataStoreRetry(
		nil,
		function() 
			return banDataStore:UpdateAsync(tostring(self.UserId), function(oldValue)
				local newValue = oldValue or deepCopy(BanSystem.DefaultData)

				local logData = {
					Log = string.sub(logDesc,0,500);
					StartTime = os.time();
					Code = code;
				}

				if not newValue.ExploitLogHistory then
					newValue.ExploitLogHistory = {}
				else
					pcall(function()
						if #game:GetService("HttpService"):JSONEncode(newValue.ExploitLogHistory) >= 20000 then
							local l = math.huge
							local ii
							for i,v in pairs(newValue.ExploitLogHistory) do
								if v.StartTime < l then
									ii = i
									l = v.StartTime
								end
							end

							if ii then
								table.remove(newValue.ExploitLogHistory,ii)
							end
						end
					end)
				end

				table.insert(newValue.ExploitLogHistory, #newValue.ExploitLogHistory + 1, logData);

				return newValue;
			end)
		end,
		3,
		true
	)

	if not success then
		warn("Failed to add exploit-log to",self.UserName .. ":" .. tostring(self.UserId))
		return false
	else
		warn("Successfully added exploit-log to",self.UserName .. ":" .. tostring(self.UserId))

		--BanSystem.CachedUsers[self.UserId] = nil
		--self:Kick(BanSystem.Messages.OnWarn)
	end
	
	local l_success = logRemote:Invoke(BanSystem.GOLID,"ExploitLog",self.UserName,"SERVER-LOG","LID:" .. tostring(code) .. " | Log Info:",logDesc)

	--local l_success = logRemote:Invoke(BanSystem.GOLID,"ModLog",self.UserName,modName,"Warn","Warned player",reason,true)

	return true
end

function BanSystem:AddDataLog(modName,logType,logText,reason) -- xp, cash level etc
	if not logType then return end
	if RUNSERVICE:IsStudio() and BanSystem.NoStudioDo then
		warn("Not doing DataLog in studio")
		return
	end
	
	logText = logText and tostring(logText) or "N/A";
	reason = tostring(reason) or "N/A";
	
	warn("adding data log for",self.Name,modName,logType,logText,reason)
	
	local success, errorMessage, tries = DataStoreRetry(
		nil,
		function() 
			return banDataStore:UpdateAsync(tostring(self.UserId), function(oldValue)
				local newValue = oldValue or deepCopy(BanSystem.DefaultData)

				local logData = {
					Type = logType;
					Log = logText;
					Reason = reason;
					StartTime = os.time();
				}

				if modName then
					local modUID = getUserIdFromUsername(modName)
					logData.Moderator = {
						Name = modName;
						UserId = modUID or nil;
					}
				end

				if not newValue.DataLogHistory then
					newValue.DataLogHistory = {}
				end

				table.insert(newValue.DataLogHistory, #newValue.DataLogHistory + 1, logData);

				return newValue;
			end)
		end,
		3,
		true
	)

	if not success then
		warn("Failed to add data-log to",self.UserName .. ":" .. tostring(self.UserId))
		return false
	else
		warn("Successfully added data-log to",self.UserName .. ":" .. tostring(self.UserId))

		--BanSystem.CachedUsers[self.UserId] = nil
		--self:Kick(BanSystem.Messages.OnWarn)
	end
	
	local l_success = logRemote:Invoke(BanSystem.GOLID,"ModLog",self.UserName,modName,logType,logText,reason,false,"Data")

	--local l_success = logRemote:Invoke(BanSystem.GOLID,"ModLog",self.UserName,modName,"Warn","Warned player",reason,true)

	return true
end

function BanSystem:ManualTimeout(setTime,reason,modName)
	if _isNotBannable(self.UserId) then
		return false
	end
	
	local timeoutTime = tonumber(setTime)
	
	local reportTimeOutData = {}
	
	local modUID = getUserIdFromUsername(modName) or nil	

	local success, errorMessage, tries = DataStoreRetry(
		nil,
		function() 
			return banDataStore:UpdateAsync(tostring(self.UserId), function(oldValue)
				local newValue = oldValue or deepCopy(BanSystem.DefaultData)

				if not newValue.Infractions then
					newValue.Infractions = 0
				end
				newValue.Infractions += 1;

				if not newValue.ModerationHistory then
					newValue.ModerationHistory = {}
				end

				reportTimeOutData.Type = "timeout"
				reportTimeOutData.StartTime = os.time()
				reportTimeOutData.Reporter = modUID
				reportTimeOutData.Reason = reason
				reportTimeOutData.Moderator = {
					Name = modName;
					UserId = modUID or nil;
				}
				reportTimeOutData.Manual = true;
				reportTimeOutData.EndTime =	math.min(tonumber(os.time())+timeoutTime);

				table.insert(newValue.ModerationHistory, #newValue.ModerationHistory + 1, reportTimeOutData);

				newValue.CurrentTimeOut = reportTimeOutData;

				return newValue;
			end)
		end,
		3,
		true
	)
	
	if not (success) then
		warn("FAILED TO TIMEOUT",self.UserName,errorMessage)
		error("FAILED TO TIMEOUT",self.UserName,self.UserId)
		
		--warn(string.format(BanSystem.ErrorMessages.FailedToBan, self.UserName, self.UserId, errorMessage1));
		return false
	else
		--if not success2 then
		--	warn("failed to update to banlist",self.UserName,self.UserId)
		--end

		warn("Successfully timed out " .. self.UserName .. " for " .. tostring(setTime))

		BanSystem.CachedUsers[self.UserId] = nil
		
		local date = os.date("%x",reportTimeOutData.EndTime) 

		self:Kick(BanSystem.Messages.OnBan)
		--self:Kick(self:GetBanMessage(banData,banType))

		local banTM = "Manual-Timeout"

		local l_success = logRemote:Invoke(BanSystem.GOLID,"ModLog",self.UserName,modName,banTM,"Duration: " .. tostring(math.floor((setTime / 86400) * 1000) / 1000) .. "d" .. " | " .. date,reason,true)
	end
	
	return true
end

function BanSystem:AddReport(modName,reportData)
	--if _isNotBannable(self.UserId) then
	--	return false
	--end
	

	local nReportData = {}
	nReportData.Tick = os.time()
	nReportData.ReportId = reportData.ReportID
	nReportData.ReporterId = reportData.ReporterID
	
	local gotReportCount = 0
	local didReportTimeout = false
	
	local function CanTimeOutCheck()
		return not self.AdminCheck()
	end

	local function GetCountsToTimeOut(plr,level,timePlayed,hasPrime,reportLog)
		local c = 0
		
		local joinData = plr and plr:GetJoinData()
		
		--if not hasPrime and level <= 5 and plr and joinData and joinData[4] ~= nil and typeof(joinData[4]) == "number" and joinData[4] >= 3 then
		--	c = 1
		if level <= 7 and reportLog and (tonumber(reportLog.KDR) >= 7 or tonumber(reportLog.Bounty) > 7000) then
			c = 1
		elseif level <= 5 and timePlayed < 3600 then
			c = 2
		elseif level <= 5 then
			c = 3
		elseif level <= 15 then
			c = 4
		elseif level <= 30 then
			c = 5
		else
			c = 8
		end
		
		if not hasPrime and level < 30 then
			c = math.min(c,3)
		end
		
		--print(plr,c)
		
		return c
	end
	
	local success, errorMessage, tries = DataStoreRetry(
		nil,
		function() 
			return banDataStore:UpdateAsync(tostring(self.UserId), function(oldValue)
				local newValue = oldValue or deepCopy(BanSystem.DefaultData)
				
				--print(newValue.ReportHistory)
				--print(repr(newValue.ReportHistory))

				if not newValue.ReportHistory then
					newValue.ReportHistory = {}
				end
				
				for i,v in pairs(newValue.ReportHistory) do
					if v.Tick and os.time() - v.Tick > 604800 then
						--print("removed a log")
						table.remove(newValue.ReportHistory,i)
					end
				end

				table.insert(newValue.ReportHistory, #newValue.ReportHistory + 1, nReportData);	
				
				local reportCount = 0
				local nz = {}
				for i,v in pairs(newValue.ReportHistory) do
					if v.Tick and not v.Excused and os.time() - v.Tick < BanSystem.ReportClearTime then
						--print(v.ReporterId)
						pcall(function()
							if not nz[v.ReporterId] then
								nz[v.ReporterId] = true
								reportCount +=1
							end
						end)
						
					else
						--print("nah",v.Tick)
					end
				end
				
				--print("Cc",reportCount)
				
				pcall(function()
					reportData.reportLog["Bank"] = "$" .. tostring(SERVER_STORAGE["PlayerbaseData"][self.UserName].Bank.Value)
				end)
				pcall(function()
					local gamepasses = ""
					for _,v in pairs(SERVER_STORAGE["PlayerbaseData"][self.UserName].Gamepasses:GetChildren()) do
						gamepasses = gamepasses .. v.Name .. " | "
					end
					
					if gamepasses == "" then
						gamepasses = "[None]"
					end
					
					reportData.reportLog["Gamepasses"] = gamepasses
				end)
				pcall(function()
					local n = SERVER_STORAGE["PlayerbaseData"][self.UserName].BMB.Value
					
					if n > 1000000 then
						n = "1000000+"
					end
					
					reportData.reportLog["Purchased Money"] = "$" .. tostring(n)
				end)
				
				gotReportCount = reportCount			
				
			--	print("CHECKING COUNT",1)
				if CanTimeOutCheck() then
					--print("CHECKING COUNT",2)
					local pd = SERVER_STORAGE.PlayerbaseData:FindFirstChild(self.UserName)
					if pd then
						--print("CHECKING COUNT",3)
						local level = pd.Level.Value
						local timePlayed = pd.TimePlayed.Value
						local hasPrime = pd.Prime.Value
	
						local c = GetCountsToTimeOut(PLAYERS:FindFirstChild(self.UserName),level,timePlayed,hasPrime,reportData.reportLog)
						
						for i,v in pairs(reportData.reportLog) do
							if i == "Weapon" or i == "Distance" or i == "Bounty" then
								reportData.reportLog[i] = nil
							end
						end
						
						if gotReportCount >= c then
							--print("CHECKING COUNT",4)
							if not (newValue.CurrentTimeOut) then
								if not newValue.Infractions then
									newValue.Infractions = 0
								end
								newValue.Infractions += 1;
								
								if not newValue.ModerationHistory then
									newValue.ModerationHistory = {}
								end
								
								if reportData.reportLog["Bounty"] then
									reportData.reportLog["Bounty"] = "$" .. reportData.reportLog["Bounty"]
								end
								
								local timeoutTime = tonumber(BanSystem.ReportTimeOutTime)
								
								local reportTimeOutData = {}
								reportTimeOutData.Type = "timeout"
								reportTimeOutData.StartTime = os.time()
								reportTimeOutData.Reporter = nReportData.ReporterId
								reportTimeOutData.EndTime =	math.min(tonumber(os.time())+timeoutTime);

								table.insert(newValue.ModerationHistory, #newValue.ModerationHistory + 1, reportTimeOutData);
								newValue.CurrentTimeOut = reportTimeOutData;
								
								warn("Added timeout to",self.UserName .. ":" .. tostring(self.UserId),"for: ",timeoutTime)
								
								didReportTimeout = true
								
								delay(math.random(20,60),function()
									local _s,_e = pcall(function()
										self:Kick(BanSystem.Messages.OnReportTimeOut) -- string.rep("ㅤ",999999)
									end)
									if not _s then
										warn("failed to report-timeout kick",self.UserName,_e)
									else
										warn("successfully report-timeout kicked",self.UserName)
									end
								end)
								
							end
						end
					end
				end
				
				return newValue;
			end)
		end,
		3,
		true
	)
	
	if not success then
		warn("Failed to add report to",self.UserName .. ":" .. tostring(self.UserId))
		return false
	else
		warn("Successfully added report to",self.UserName .. ":" .. tostring(self.UserId))
		reportData.ReportCount = gotReportCount

		if gotReportCount and gotReportCount >= BanSystem.MinReports then		
			local l_success = logRemote:Invoke("ZKLFXG890ZDFGJKN43SU8IOG","ReportMultiLog",self.UserName,reportData,ReplicatedStorage.Values.PrimeServer.Value)
		end
		
		if didReportTimeout then
			local l_success = logRemote:Invoke("ZKLFXG890ZDFGJKN43SU8IOG","ReportMultiLog",self.UserName,reportData,ReplicatedStorage.Values.PrimeServer.Value,true)
		end
	end
	

	--delay(math.random(120,900),function()
	--	if self then
	--		self:Kick(BanSystem.Messages.Shadow,true)
	--	end
	--end)

	--local l_success = logRemote:Invoke(BanSystem.GOLID,"ModLog",self.UserName,modName,"Warn","Warned player",reason,true)

	return true,didReportTimeout
end

function BanSystem:RemoveTimeout(reason,modName,wasAuto)
	local function Do()
		local wasBanned = nil

		local banType = "timeout"

		local success1, errorMessage1, tries1 = DataStoreRetry(
			nil,
			function() 
				return banDataStore:UpdateAsync(self.UserId, function(oldValue: any)
					local newValue: any = oldValue or {};

					wasBanned = newValue.CurrentTimeOut ~= nil

					if newValue.CurrentTimeOut then
						banType = newValue.CurrentTimeOut.Type
					end

					if wasBanned then
						local unbanData = {
							Type = "un-timeout";
							Reason = reason;
							StartTime = os.time();
							WasAuto = wasAuto;
						}

						if modName then
							local modUID = getUserIdFromUsername(modName)
							unbanData.Moderator = {
								Name = modName;
								UserId = modUID or nil;
							}
						end

						if not newValue.ModerationHistory then
							newValue.ModerationHistory = {}
						end
						
						newValue.CurrentTimeOut = nil
						
						if not newValue.ReportHistory then
							newValue.ReportHistory = {}
						end
						for i,v in pairs(newValue.ReportHistory) do
							v.Excused = true
						end

						table.insert(newValue.ModerationHistory, #newValue.ModerationHistory + 1, unbanData);
					end

					return newValue;
				end)
			end,
			3,
			true
		)

		if not (success1) then
			warn(BanSystem.ErrorMessages.FailedToUnban, self.UserName, self.UserId, errorMessage1);
			return false
		end

		if wasBanned then
			if not wasAuto then

				local typ = "Un-Report-Timeout"

				local desc = "Automatic report-timeout manually removed by mod"


				local l_success = logRemote:Invoke(BanSystem.GOLID,"ModLog",self.UserName,modName,typ,desc,reason,true)
			else
				local desc = "Automatic report-timeout auto-ended and removed by system"

				local l_success = logRemote:Invoke(BanSystem.GOLID,"ModLog",self.UserName,nil,"Un-Timeout","Report-timeout automatically ended",reason,true,"TimeOut_Expire")
			end
			
			return true
		end
	end

	return Do()
end

function BanSystem:Warn(reason,doKick,modName)
	if _isNotBannable(self.UserId) then
		return false
	end

	local success, errorMessage, tries = DataStoreRetry(
		nil,
		function() 
			return banDataStore:UpdateAsync(tostring(self.UserId), function(oldValue)
				local newValue = oldValue or deepCopy(BanSystem.DefaultData)

				if not newValue.Infractions then
					newValue.Infractions = 0
				end
				newValue.Infractions += 1;

				local warnData = {
					Type = "warn";
					Reason = reason;
					StartTime = os.time()
				}
				
				if modName then
					local modUID = getUserIdFromUsername(modName)
					warnData.Moderator = {
						Name = modName;
						UserId = modUID or nil;
					}
				end
				
				if not newValue.ModerationHistory then
					newValue.ModerationHistory = {}
				end

				table.insert(newValue.ModerationHistory, #newValue.ModerationHistory + 1, warnData);
				newValue.CurrentWarning = warnData;

				return newValue;
			end)
		end,
		3,
		true
	)

	if not success then
		warn("Failed to add warning to",self.UserName .. ":" .. tostring(self.UserId))
		return false
	else
		warn("Successfully added warning to",self.UserName .. ":" .. tostring(self.UserId))
		
		BanSystem.CachedUsers[self.UserId] = nil
		self:Kick(BanSystem.Messages.OnWarn)
	end

	local l_success = logRemote:Invoke(BanSystem.GOLID,"ModLog",self.UserName,modName,"Warn","Warned player",reason,true,"Warn")

	return true
end

function BanSystem:Kick(reason,onlyServer)
	reason = reason or "Unspecified"
	
	local plr = _GetPlrInstance(self)
	if plr then
		pcall(function()
			local vf = _G.GVF and _G.GVF(plr.Name)					
			if vf then
				for _,v in pairs(vf.Tags:GetChildren()) do
					if string.find(v.Name,"inCombat_") or v.Name == "creator" or v.Name == "assist" then
						v:Destroy()
					end
				end
			end
		end)
		plr:Kick(reason)
	elseif not onlyServer then
		local publishSuccess: boolean, publishResult: any = pcall(function() : nil
			MESSAGING_SERVICE:PublishAsync(BanSystem.Topics.KickPlayerTopic, {
				Message = reason,
				Player = self.UserName
			});
		end)

		if (not publishSuccess) then
			if (publishResult == '"The rate of publish requests exceeds the allowed limit." MessagingService: Please retry after -2147483648 seconds.') then
				local randomNumber: number = math.random(1, 10000);

				warn(string.format([[

		!!!THIS IS A ROBLOX-ERROR!!!
		
		1. To fix this open your BanSystem module, and then you will see Topics in the configuration of the BanSystem.
		2. Insert the number %d to value from KickPlayerTopic. You can find the KickPlayerTopic in Topics. 
		3. It should look like: ["KickPlayerTopic"] = "KICK_PLAYER_TOPIC%d"
		
		--OR--
		
		Write in your script after you require it: banSystem.Topics.KickPlayerTopic = "KICK_PLAYER_TOPIC%d"
		
		---------------------
		
		Info: %d is the random number that you need to insert to fix this. 
		
		It now should be fixed.			
		]], randomNumber, randomNumber, randomNumber, randomNumber));
			end

			warn(string.format(BanSystem.ErrorMessages.FailedToKick, self.UserName, publishResult));

			return false;
		else
			return true;
		end
	end
end

function BanSystem:Ban(reason,banTime,banType,modName,reason2,isExploitBan)
	if _isNotBannable(self.UserId) then
		return false
	end
	
	if banType ~= "temp" and banType ~= "shadow" then
		return
	end
	
	banType = banType or "temp"

	local banData = {
		Type =		banType;
		Name = 		self.UserName;
		UserId = 	self.UserId;
		StartTime =	os.time();
		EndTime =	math.min(tonumber(os.time())+tonumber(banTime),BanSystem.MAX_BAN_DATE);
		Reason =	reason;
		Reason2 = reason2 or nil;
		isExploit = isExploitBan;
	}
	
	if modName then
		local modUID = getUserIdFromUsername(modName)
		banData.Moderator = {
			Name = modName;
			UserId = modUID or nil;
		}
	end
	
	local success1, errorMessage1, tries1 = DataStoreRetry(
		nil,
		function() 
			return banDataStore:UpdateAsync(tostring(self.UserId), function(oldValue)
				local newValue = oldValue or deepCopy(BanSystem.DefaultData)
				
				if not newValue.IsBanned then
					if not newValue.Infractions then
						newValue.Infractions = 0
					end
					newValue.Infractions += 1;
				end
				newValue.IsBanned = true;
				
				if not newValue.ModerationHistory then
					newValue.ModerationHistory = {}
				end

				table.insert(newValue.ModerationHistory, #newValue.ModerationHistory + 1, banData);

				newValue.CurrentBan = newValue.ModerationHistory[#newValue.ModerationHistory];
				
				return newValue;
			end)
		end,
		3,
		true
	)
	
	if success1 then
		delay(0,function()
			local success2, errorMessage2, tries2 = DataStoreRetry(
				nil,
				function() 
					return listDataStore:UpdateAsync(BanSystem.L_CURRENTVERSION, function(oldValue)
						local newValue = oldValue or {
							BanCount = 0;
							List = {};
						}

						newValue.BanCount +=1;
						table.insert(newValue.List, #newValue.List + 1, banData);

						return newValue;
					end)
				end,
				3,
				true
			)
			
			if not success2 then
				warn(":BAN ERROR","SUCCESS2:",success2)
			end
		end)
	end
	
	if not (success1) then
		error("FAILED TO BAN",self.UserName,self.UserId)
		--warn(string.format(BanSystem.ErrorMessages.FailedToBan, self.UserName, self.UserId, errorMessage1));
		return false
	else
		--if not success2 then
		--	warn("failed to update to banlist",self.UserName,self.UserId)
		--end
		
		warn(string.format(BanSystem.SuccessMessages.SuccessfullyBannedPlayer, self.UserName, self.UserId, tostring(reason), tostring(banTime)));
		
		BanSystem.CachedBanList = nil
		BanSystem.CachedUsers[self.UserId] = nil
		
		local timeLeft = banData.EndTime-os.time()

		local banDesc = "days"
		local banDiv = 86400
		--2628000
		local rtp = 1

		if timeLeft < 86400 and timeLeft > 3600 then
			rtp = 1
			banDesc = "hours"
			banDiv = 3600
		elseif timeLeft <= 3600 and timeLeft > 60 then
			rtp = 1
			banDesc = "minutes"
			banDiv = 60				
		elseif timeLeft <= 60 then
			rtp = 1
			banDesc = "seconds"
			banDiv = 1
		end
		local timeLeftM = tostring(RoundToPlace(timeLeft/banDiv, rtp))  .. " " .. banDesc

		local date =  os.date("%x",banData.EndTime) 
		
		self:Kick(BanSystem.Messages.OnBan)
		--self:Kick(self:GetBanMessage(banData,banType))
		
		local banTM = (banType == "shadow" and "Temp-Blacklist") or (isExploitBan and "Exploit-Ban") or "Temp-Ban"
		
		local l_success = logRemote:Invoke(BanSystem.GOLID,"ModLog",self.UserName,modName,banTM,"Duration: " .. tostring(timeLeftM) .. " | " .. date,reason2 or reason,true)

		--logRemote:Invoke(BanSystem.GOLID,"ModLog",self.UserName,nil,"test","test2","test3",false)
		
		SERVER_STORAGE.Events3.ONPLRBANNED:Fire("K9W0SLKDJI0SDSD09IF9ISO",self.UserId)
	end
	
	return true
end

function BanSystem:Unban(reason,modName,wasAuto)
	local function Do()
		local wasBanned = nil
		
		local banType = "temp"

		local success1, errorMessage1, tries1 = DataStoreRetry(
			nil,
			function() 
				return banDataStore:UpdateAsync(self.UserId, function(oldValue: any)
					local newValue: any = oldValue or {};

					wasBanned = newValue.IsBanned and newValue.CurrentBan
					
					if newValue.CurrentBan then
						banType = newValue.CurrentBan.Type
					end

					newValue.CurrentBan = {};
					newValue.IsBanned = false;
					
					if not newValue.ModerationHistory then
						newValue.ModerationHistory = {}
					end

					newValue.CurrentTimeOut = nil

					if not newValue.ReportHistory then
						newValue.ReportHistory = {}
					end
					for i,v in pairs(newValue.ReportHistory) do
						v.Excused = true
					end

					if wasBanned then
						local unbanData = {
							Type = "unban";
							Reason = reason;
							StartTime = os.time();
							WasAuto = wasAuto;
						}

						if modName then
							local modUID = getUserIdFromUsername(modName)
							unbanData.Moderator = {
								Name = modName;
								UserId = modUID or nil;
							}
						end
						
						if not newValue.ModerationHistory then
							newValue.ModerationHistory = {}
						end

						table.insert(newValue.ModerationHistory, #newValue.ModerationHistory + 1, unbanData);
					end

					return newValue;
				end)
			end,
			3,
			true
		)
		
		
		if success1 then
			task.delay(0,function()
				local success2, errorMessage2, tries2 = DataStoreRetry(
					nil,
					function() 
						return listDataStore:UpdateAsync(BanSystem.L_CURRENTVERSION, function(oldValue)
							local newValue = oldValue or {
								BanCount = 0;
								List = {};
							}

							for i,v in pairs(newValue.List) do
								if v.UserId == self.UserId then
									table.remove(newValue.List,i)
									newValue.BanCount -=1;
									--break
								end
							end

							return newValue;
						end)
					end,
					1,
					true
				)
				
				local success3, errorMessage3, tries3
				
				for i,key in pairs(BanSystem.L_PASTVERSIONS) do
					success3, errorMessage3, tries3 = DataStoreRetry(
						nil,
						function() 
							return listDataStore:UpdateAsync(key, function(oldValue)
								local newValue = oldValue or {
									BanCount = 0;
									List = {};
								}

								for i,v in pairs(newValue.List) do
									if v.UserId == self.UserId then
										pcall(function()
											table.remove(newValue.List,i)
											newValue.BanCount -=1;
										end)

										--break
									end
								end

								return newValue;
							end)
						end,
						1,
						true
					)
				end
				
				--local success3, errorMessage3, tries3 = DataStoreRetry(
				--	nil,
				--	function() 
				--		return listDataStore:UpdateAsync(BanSystem.L_VERSION_OLD, function(oldValue)
				--			local newValue = oldValue or {
				--				BanCount = 0;
				--				List = {};
				--			}

				--			for i,v in pairs(newValue.List) do
				--				if v.UserId == self.UserId then
				--					table.remove(newValue.List,i)
				--					newValue.BanCount -=1;
				--					--break
				--				end
				--			end

				--			return newValue;
				--		end)
				--	end,
				--	1,
				--	true
				--)
				
				if not (success2 and success3) then
					warn(":UNBAN ERROR |","SUCCESS2:",success2,"SUCCESS3:",success3)
				end
			end)
		end

		if not (success1) then
			error("FAILED TO BAN",self.UserName,self.UserId)
			--warn(string.format(BanSystem.ErrorMessages.FailedToBan, self.UserName, self.UserId, errorMessage1));
			return false
		else
			--if not success2 then
			--	warn("failed to update to banlist",self.UserName,self.UserId)
			--end
			
			warn(string.format(BanSystem.SuccessMessages.SuccessfullyUnbannedPlayer, self.UserName, self.UserId));

			BanSystem.CachedBanList = nil
			BanSystem.CachedUsers[self.UserId] = nil
		end

		if wasBanned then
			if not wasAuto then
				
				local typ = "Un-Temp-Ban"
				
				local desc = "Player was unbanned"
				
				if banType == "shadow" then
					typ = "Un-Temp-Blacklist"
					desc = "Player was unblacklisted"
				end
				
				local l_success = logRemote:Invoke(BanSystem.GOLID,"ModLog",self.UserName,modName,typ,desc,reason,true,(wasAuto and "AutoUnban") or "Unban")
			else
				local desc = "Ban auto ended"
				
				if banType == "shadow" then
					desc = "Blacklist auto ended"
				end
				
				local l_success = logRemote:Invoke(BanSystem.GOLID,"ModLog",self.UserName,nil,"Ban-Ended","Ban automatically ended",reason,true,(wasAuto and "AutoUnban") or "Unban")
			end
		end
	end
	
	return Do()
end


function BanSystem:ClearBanWaveCheckHistory()
	local success, errorMessage, tries = DataStoreRetry(
		nil,
		function() 
			return banDataStore:UpdateAsync(tostring(self.UserId), function(oldValue)
				local newValue = oldValue or deepCopy(BanSystem.DefaultData)

				if not newValue.Infractions then
					newValue.Infractions = 0
				end

				--newValue.IsBanned = true;

				if not newValue.ModerationHistory then
					newValue.ModerationHistory = {}
				end

				--if not newValue.BanWaveChecks then
					newValue.BanWaveChecks = {} -- clears it!
				--end

				return newValue;
			end)
		end,
		3,
		true
	)

	if not success then
		error("FAILED TO CLEAR BAN HISTORY",self.UserName,self.UserId)
		--warn(string.format(BanSystem.ErrorMessages.FailedToBan, self.UserName, self.UserId, errorMessage1));
		return false
	else
		warn("successfully cleared ban history",self.UserName,self.UserId)
	end

	return true
end

function BanSystem:AntiBan(reason,banDays,noShadow,banWaveName,customCode)
	if _isNotBannable(self.UserId) or self.GetAdminLevel() >= 200 then
		return false
	end

	local shadowTime = (noShadow and 0) or math.random(18000,259200)

	local banData = {
		BanStartTime = os.time(); 
		BanTime = banDays * 86400;
		Reason = reason;
		Type = "anti";
		ShadowTime = shadowTime;	
		UserId = self.UserId;
		
		waveName = banWaveName;
		code = customCode;
	}
	--DisplayMessage = BanSystem.Messages.AntiDisplay[math.random(1,#BanSystem.Messages.AntiDisplay)];
	
	local actualDo = not (isStudio and not BanSystem.STUDIO_BANS)
	
	local success1, errorMessage1, tries1
	local success2, errorMessage2, tries2
	
	if actualDo then
		local do2 = false
		
		success2, errorMessage2, tries2 = DataStoreRetry(
			nil,
			function() 
				return banDataStore:UpdateAsync(tostring(self.UserId), function(oldValue)
					local newValue = oldValue or deepCopy(BanSystem.DefaultData)

					if not newValue.Infractions then
						newValue.Infractions = 0
					end
				
					--newValue.IsBanned = true;

					if not newValue.ModerationHistory then
						newValue.ModerationHistory = {}
					end
					
					if not newValue.BanWaveChecks then
						newValue.BanWaveChecks = {}
					end
					
					newValue.Infractions += 1;
					
					if banWaveName then
						newValue.BanWaveChecks[banWaveName] = true;
					end

					table.insert(newValue.ModerationHistory, #newValue.ModerationHistory + 1, banData);

					--	newValue.CurrentBan = newValue.ModerationHistory[#newValue.ModerationHistory];
			
					return newValue;
				end)
			end,
			3,
			true
		)
		
		success1, errorMessage1, tries1 = DataStoreRetry(
			nil,
			function() 
				return antiBanStore:SetAsync(tostring(self.UserId), banData)
			end,
			3,
			true
		)
	else
		success1 = true
		success2 = true
	end
	
	if success1 then
		task.delay(0,function()
			local success3, errorMessage3, tries3 = DataStoreRetry(
				nil,
				function() 
					return listDataStore:UpdateAsync(BanSystem.L_CURRENTVERSION, function(oldValue)
						local newValue = oldValue or {
							BanCount = 0;
							List = {};
						}

						newValue.BanCount +=1;
						table.insert(newValue.List, #newValue.List + 1, banData);

						return newValue;
					end)
				end,
				3,
				true
			)
			
			if not success3 then
				warn(":ANTIBAN ERROR |","SUCCESS3:",success3)
			end
		end)
	end
	

	if not (success1 and success2) then
		error("FAILED TO BAN",self.UserName,self.UserId)
		--warn(string.format(BanSystem.ErrorMessages.FailedToBan, self.UserName, self.UserId, errorMessage1));
		return false
	else
		--if not success3 then
		--	warn("failed to update to banlist",self.UserName,self.UserId)
		--end
		
		warn(string.format(BanSystem.SuccessMessages.SuccessfullyBannedPlayer2, self.UserName, self.UserId, tostring(reason), tostring(banDays)));

		BanSystem.CachedBanList = nil
		BanSystem.CachedUsers[self.UserId] = nil

		local timeLeft = banData.BanTime

		local banDesc = "days"
		local banDiv = 86400
		--2628000
		local rtp = 1

		if timeLeft < 86400 and timeLeft > 3600 then
			rtp = 1
			banDesc = "hours"
			banDiv = 3600
		elseif timeLeft <= 3600 and timeLeft > 60 then
			rtp = 1
			banDesc = "minutes"
			banDiv = 60				
		elseif timeLeft <= 60 then
			rtp = 1
			banDesc = "seconds"
			banDiv = 1
		end
		local timeLeftM = tostring(RoundToPlace(timeLeft/banDiv, rtp))  .. " " .. banDesc

		local date =  os.date("%x",banData.BanStartTime + banData.BanTime) 
		
		local plr = self:GetPlayer()
		if plr then
			local pd = _G.GetPlayerData and _G.GetPlayerData(plr)
			if pd then
				pd.Shadowed.Value = true
			end
		end

		delay(math.random(120,900),function()
			if self then
				self:Kick(BanSystem.Messages.Shadow,true)
			end
		end)
		
		if actualDo then
			local desc = "Duration: " .. tostring(timeLeftM) .. " | " .. date
			desc = ""
			
			local l_success = logRemote:Invoke(BanSystem.GOLID,"ExploitLog",self.UserName,"AC-BAN",desc,reason,banWaveName and "Banwave" or "Ban")
		end
		
		SERVER_STORAGE.Events3.ONPLRBANNED:Fire("K9W0SLKDJI0SDSD09IF9ISO",self.UserId)
	end

	return true
end

function BanSystem:UnAntiBan(reason,wasAuto,modName)

	local wasBanned = false

	local success1, errorMessage1, tries1 = DataStoreRetry(
		nil,
		function() 
			return antiBanStore:UpdateAsync(tostring(self.UserId),function(oldValue)
				if oldValue then
					wasBanned = true
				end
				return false
			end)
		end,
		3,
		true
	)

	local success2, errorMessage2, tries2 = DataStoreRetry(
		nil,
		function() 
			return banDataStore:UpdateAsync(self.UserId, function(oldValue: any)
				local newValue: any = oldValue or {};
				
				if wasBanned then
					local unbanData = {
						Type = "unantiban";
						Reason = reason;
						StartTime = os.time();
						WasAuto = wasAuto;
					}

					if modName then
						local modUID = getUserIdFromUsername(modName)
						unbanData.Moderator = {
							Name = modName;
							UserId = modUID or nil;
						}
					end
					
					if not newValue.ModerationHistory then
						newValue.ModerationHistory = {}
					end

					table.insert(newValue.ModerationHistory, #newValue.ModerationHistory + 1, unbanData);
				end

				return newValue;
			end)
		end,
		3,
		true
	)
	
	if success1 then
		task.delay(0,function()
			local success3, errorMessage3, tries3 = DataStoreRetry(
				nil,
				function() 
					return listDataStore:UpdateAsync(BanSystem.L_CURRENTVERSION, function(oldValue)
						local newValue = oldValue or {
							BanCount = 0;
							List = {};
						}

						for i,v in pairs(newValue.List) do
							if v.UserId == self.UserId then
								newValue.BanCount -=1;
								table.remove(newValue.List,i)
								break
							end
						end

						return newValue;
					end)
				end,
				3,
				true
			)
			
			local success4, errorMessage4, tries4
			
			for i,key in pairs(BanSystem.L_PASTVERSIONS) do
				success4, errorMessage4, tries4 = DataStoreRetry(
					nil,
					function() 
						return listDataStore:UpdateAsync(key, function(oldValue)
							local newValue = oldValue or {
								BanCount = 0;
								List = {};
							}

							for i,v in pairs(newValue.List) do
								if v.UserId == self.UserId then
									pcall(function()
										table.remove(newValue.List,i)
										newValue.BanCount -=1;
									end)

									--break
								end
							end

							return newValue;
						end)
					end,
					1,
					true
				)
			end

			--local success4, errorMessage4, tries4 = DataStoreRetry(
			--	nil,
			--	function() 
			--		return listDataStore:UpdateAsync(BanSystem.L_VERSION_OLD, function(oldValue)
			--			local newValue = oldValue or {
			--				BanCount = 0;
			--				List = {};
			--			}

			--			newValue.BanCount -=1;
			--			for i,v in pairs(newValue.List) do
			--				if v.UserId == self.UserId then
			--					table.remove(newValue.List,i)
			--					break
			--				end
			--			end

			--			return newValue;
			--		end)
			--	end,
			--	3,
			--	true
			--)
			
			if not (success3 and success4) then
				warn(":ANTIUNBAN ERROR |","SUCCESS3:",success3,"SUCCESS4:",success4)
			end
		end)
	end


	if not (success1 and success2) then
		error("FAILED TO BAN",self.UserName,self.UserId)
		--warn(string.format(BanSystem.ErrorMessages.FailedToBan, self.UserName, self.UserId, errorMessage1));
		return false
	else
		warn("Unanticheat banned",self.UserName)
		BanSystem.CachedUsers[self.UserId] = nil
		
		local l_success = logRemote:Invoke(BanSystem.GOLID,"ModLog",self.UserName,modName,"Un-AC-Ban","Manually removed anti-cheat ban",reason,true,wasAuto and "AutoUnban" or "Unban")
	end

	return true
end

function BanSystem:UpdateBanData()
	local data,dataSuccess = self:GetData(self.UserId,true)
	local currentTime = os.time()

	local antiBanData
	local 	aSuccess, aErrorMessage, aTries = DataStoreRetry(
		nil,
		function() 
			antiBanData = antiBanStore:GetAsync(tostring(self.UserId));
		end,
		3,
		true
	)
	
	local tab = {["data"] = data; ["dataSuccess"] = dataSuccess; ["aSuccess"] = aSuccess; ["antiBanData"] = antiBanData;  ["t"] = os.time()}
	
	if dataSuccess then
		warn("Updated ban data for",self.UserName .. ":" .. self.UserId)
	else
		warn("Failed to update ban data for",self.UserName .. ":" .. self.UserId)
	end
	
	return dataSuccess and tab
end

function BanSystem:CheckBanWave()
	if _isNotBannable(self.UserId) then
		warn(self.UserName .. " is BS Whitelisted")
		return false
	end
	
	local cachedData = self:GetCachedData(2)

	if not cachedData then
		cachedData = self:UpdateBanData()
	end
	
	local dataSuccess,data = cachedData and cachedData.dataSuccess,cachedData and cachedData.data
	
	if not dataSuccess then 
		return false
	end
	
	--["BANWAVE_0"] = {
	--	enabled = true;

	--	menuOnly = true;

	--	isFolderSave = true;
	--	customFolder = SERVER_STORAGE:FindFirstChild("BANWAVE_0");
	--};
	

	
	local function checkWaves()
		for i,v in pairs(BanSystem.LegacyBanWaves) do
			--print(data.BanWaveChecks,i,data.BanWaveChecks)
			if v.enabled then
				if data and not (data.BanWaveChecks and data.BanWaveChecks[i]) then
					if v.menuOnly and not SERVER_STORAGE:FindFirstChild("IsMenuPlace") then
						continue
					end

					local folder = SERVER_STORAGE.LegacyBanWaves:FindFirstChild(i)

					if folder then
						local found = folder:FindFirstChild(self.UserId)

						if found then
							local doAntiBan = self:AntiBan(i,3000,true,i,v.code)

							if doAntiBan then
								self:ClearCachedData(2)
								
								warn(self.UserId,"caught in LegacyBanWave",i)

								if not BanSystem.STUDIO_BANS then
									self:Kick(BanSystem.Messages.Shadow,true)
								end

								break
							end
						end
					else
						warn("Couldnt find LegacyBanF",i)
					end
				else
					warn(self.UserId,"already checked LegacyBanWave",i)
				end
			end
		end
	end
	checkWaves()
end

function BanSystem:CheckIfBanned(requireStore,isModHistory,doUpdate,ignoreTimeout)
	self:CheckBanWave()
	
	if _isNotBannable(self.UserId) then
		warn(self.UserName .. " is BS Whitelisted")
		return false
	end
	
	local cachedData = not doUpdate and self:GetCachedData(2)
	
	if not cachedData or not isModHistory then
		cachedData = self:UpdateBanData()
	end
	
	if not cachedData then return end
	
	local dataSuccess,data = cachedData and cachedData.dataSuccess,cachedData and cachedData.data

	local currentTime = os.time()

	if not dataSuccess and requireStore then
		return
	end
	
	local function getNewData()
		if data and typeof(data) == "table" then
			return data
		end
	end

	local function Old_TempCheck()
		local function tempcheck()
			for _,v in pairs(L_TIME_BANS) do
				if v.UserId == self.UserId and math.min(v.EndTime,BanSystem.MAX_BAN_DATE) -os.time() > 0 then
					return v
				end
			end
		end

		local tempData = tempcheck()
		if tempData then
			tempData.Type = "temp"
			tempData.IsLegacy = true;
			return true,tempData
		end
	end
	
	local function Old_PermCheck()
		local function permcheck()
			for _,v in pairs(L_PERM_BANS) do
				if string.find(v,self.UserId) then
					return true
				end
			end
		end

		local permData = permcheck()
		if permData then
			return true,{
				IsLegacy = true;
				Type = "perm";
				StartTime = 0;
				EndTime = BanSystem.MAX_BAN_DATE + 1000;
			}
		end
	end
	
	local isBanned,banData,banDataType,nIsBanned,nBanData,oIsTempBanned,oTempBanData,oIsPermBanned,oPermBanData
	local aSuccess,antiBanData = cachedData.aSuccess,cachedData.antiBanData
	local oBanData = "bruh"
	
	--aSuccess = true
	--antiBanData = {BanStartTime = os.time() - 1000; BanTime = 14 * 86400;Reason = "bruh"}
	
	isBanned = false
	
	nBanData = getNewData()
	
	local nBanTry = (nBanData and nBanData.IsBanned == false) 
	
	local function CheckBanTime()
		if nBanData then
			if (nBanData.CurrentBan == nil or nBanData.IsBanned == false) then
				--
			else
				if (tick() < math.min(nBanData.CurrentBan.EndTime,BanSystem.MAX_BAN_DATE)) then
					nIsBanned = true
				else
					nIsBanned = false
					nBanTry = true
					warn(self.UserName .. "'s ban has ended")
					self:Unban("System unban",nil,true);
					return false,nil;
				end
			end
		end
	end
	
	CheckBanTime()

	if antiBanData then
		antiBanData.StartTime = antiBanData.BanStartTime
	end

	if not nBanTry or isModHistory then
		oIsTempBanned,oTempBanData = Old_TempCheck()
		oBanData = oTempBanData

		if isModHistory or not oIsTempBanned then
			oIsPermBanned,oPermBanData = Old_PermCheck()
			
			if not oIsTempBanned then
				oBanData = oPermBanData
			end
			
			if isModHistory or not oIsTempBanned then
				CheckBanTime()
			end
		end
	end
	
	local modHistory = (nBanData and nBanData.ModerationHistory) or {}

	local isNewBanned = nIsBanned and nBanData and nBanData.IsBanned == true
		--not ((not nIsBanned) and (not nBanData or not nBanData.IsBanned or nBanData.IsBanned == false))
	local isAntiBanned = aSuccess and antiBanData and antiBanData.StartTime + antiBanData.BanTime > os.time()
	
	if antiBanData then
		antiBanData.Type = "anti";
	end
	
	local timeOutBanData = nBanData and nBanData.CurrentTimeOut
	local isTimeOutBanned = timeOutBanData ~= nil
	
	if isModHistory then
		for _,v in pairs(modHistory) do
			if v.Type == "anti" and not v.StartTime then
				v.StartTime = v.BanStartTime
			end
		end
		
		if isAntiBanned then
			antiBanData.StartTime = antiBanData.BanStartTime
			table.insert(modHistory,antiBanData)
		end
		if oIsTempBanned and oTempBanData then
			table.insert(modHistory,oTempBanData)
		end
		if oIsPermBanned then
			table.insert(modHistory,oPermBanData)
		end
		if isTimeOutBanned then
			table.insert(modHistory,timeOutBanData)
		end

		table.sort(modHistory,function(a,b)
			return a.StartTime > b.StartTime
		end)
	end
	
	if isNewBanned then
		banData = nBanData.CurrentBan
		warn(self.UserName .. ": New | " .. tostring(banData.Type))
		isBanned = true
		banDataType = "new"	
	else
		if (oIsTempBanned or oIsPermBanned) and not nBanTry then
			warn(self.UserName .. ": Old |" .. tostring(oBanData.Type or ""))
			isBanned = true
			banDataType = (oBanData.Type == "perm" and "old") or "legacy"
			banData = oBanData
		elseif isAntiBanned then
			--antiBanData = {BanStartTime = os.time(); BanTime = 150 * 86400;Reason = "bruh"}
			isBanned = true
			banData = antiBanData
			banDataType = "anti"
		elseif isTimeOutBanned and not ignoreTimeout then
			if (os.time() < math.min(timeOutBanData.EndTime,BanSystem.MAX_BAN_DATE)) then
				isBanned = true
				banData = timeOutBanData
				banDataType = "timeout"
			else
				isTimeOutBanned = false
				self:RemoveTimeout("Auto-ended (system)",nil,true);
			end
		end
	end
	
	if nBanData and nBanData.CurrentWarning and nBanData.CurrentWarning.StartTime < BanSystem.WarningOutdate.Time then
		self:ClearCurrentWarning(nil,nil,nil,true)			
		nBanData.CurrentWarning = nil
	end
	
	local isAltRestricted = false

	local function altRestrictedCheck()
		if BanSystem.AltRestrict and BanSystem.AltRestrict.Enabled and nBanData and nBanData.AltRestrictData and type(nBanData.AltRestrictData) == "table" then
			if nBanData.AltRestrictData.Code == BanSystem.AltRestrict.Code then
				local stillBanned = os.time() - (nBanData.AltRestrictData.StartTime + BanSystem.AltRestrict.RestrictTime) < 0
				if stillBanned then
					isAltRestricted = true;
				end
			end
		end
	end

	altRestrictedCheck()

	return isBanned,banData,banDataType,modHistory,nBanData,isAltRestricted
end
------------------------------------------------------------------------------------------


function BanSystem:GetModHistory()
	local data = self:GetData(self.UserId,true)
	return data.ModerationHistory,data.IsBanned,data.Infractions,data.CurrentWarning;
end

function BanSystem:ClearModHistory(reason,modName)
	local success, errorMessage, tries = DataStoreRetry(
		nil,
		function() 
			return banDataStore:UpdateAsync(self.UserId, function(oldValue: BanData | nil)
				local newValue: BanData = oldValue or nil;

				if (newValue ~= nil) then
					newValue.Infractions = 0;
					newValue.ModerationHistory = {};
				end

				return newValue;
			end)
		end,
		3,
		true
	)

	if (success == true) then
		warn(string.format(BanSystem.SuccessMessages.SuccessfullyResetedModerationHistory, self.UserName, self.UserId));

		return true;
	else
		warn(string.format(BanSystem.ErrorMessages.FailedToResetModerationHistory, self.UserName, self.UserId, errorMessage));
	end
	
	local l_success = logRemote:Invoke(BanSystem.GOLID,"ModLog",self.UserName,modName,"Cleared-Mod-History","All moderation history on this user has been cleared.",reason,true)
end

function BanSystem:ClearCurrentWarning(reason,modName,wasAbided,wasAuto)
	local isWarned = false

	local success, errorMessage, tries = DataStoreRetry(
		nil,
		function() 
			return banDataStore:UpdateAsync(self.UserId, function(oldValue)
				local newValue = oldValue or deepCopy(BanSystem.DefaultData) 

				isWarned = newValue.CurrentWarning ~= nil

				newValue.CurrentWarning = nil;
				
				if modName then
					local unbanData = {
						Type = "warning-removed";
						Reason = reason;
						StartTime = os.time();
					}

					if modName then
						local modUID = getUserIdFromUsername(modName)
						unbanData.Moderator = {
							Name = modName;
							UserId = modUID or nil;
						}
					end

					if not newValue.ModerationHistory then
						newValue.ModerationHistory = {}
					end

					table.insert(newValue.ModerationHistory, #newValue.ModerationHistory + 1, unbanData);
				end

				return newValue;
			end)
		end,
		3,
		true
	)

	if not success then
		warn("Failed to clear warnings of ",self.UserName .. ":" .. tostring(self.UserId))
		return false
	else
		warn("Successfully cleared warnings of ",self.UserName .. ":" .. tostring(self.UserId))
	end

	if modName and not wasAuto then
		local l_success = logRemote:Invoke(BanSystem.GOLID,"ModLog",self.UserName,modName,"Warning-Removed","Warning manually removed",nil,true,"AutoUnWarn")
	elseif not wasAuto and wasAbided then
		local l_success = logRemote:Invoke(BanSystem.GOLID,"ModLog",self.UserName,nil,"Warning-Abided","Warning accepted by player",reason,true,"Warn")
	else
		local l_success = logRemote:Invoke(BanSystem.GOLID,"ModLog",self.UserName,nil,"Warning-Removed","Warning automatically cleared by system","Outdated & cleared",true,"AutoUnWarn")
	end

	return true,isWarned
end

function BanSystem:ClearWarningHistory(reason,maxTime,modName)
	local success, errorMessage, tries = DataStoreRetry(
		nil,
		function() 
			return banDataStore:UpdateAsync(self.UserId, function(oldValue)
				local newValue = oldValue or {
					Infractions =		0;
					ModerationHistory =	{};
					IsBanned =		 	false;
				};

				local n = 0
				for i,v in pairs(newValue.Infractions) do
					if typeof(v) == "table" and v.Type and v.Type == "warn" and os.time() - v.StartTime > maxTime then
						n = n + 1
						table.remove(newValue.Infractions,i)
					end
				end

				newValue.CurrentWarning = nil;
				
				if not newValue.Infractions then
					newValue.Infractions = 0
				end

				newValue.Infractions -= n;
				newValue.Infractions = math.max(newValue.Infractions,0)

				return newValue;
			end)
		end,
		3,
		true
	)

	if not success then
		warn("Failed to clear warnings of ",self.UserName .. ":" .. tostring(self.UserId))
		return false
	else
		warn("Successfully cleared warnings of ",self.UserName .. ":" .. tostring(self.UserId))
	end

	local l_success = logRemote:Invoke(BanSystem.GOLID,"ModLog",self.UserName,modName,"Cleared-Warnings","Cleared all warning infractions from history",reason,true)

	return true
end

function BanSystem:AddAltRestrict(restrictData)
	if _isNotBannable(self.UserId) then
		return false
	end

	local function Do()
		local success1, errorMessage1, tries1 = DataStoreRetry(
			nil,
			function() 
				return banDataStore:UpdateAsync(self.UserId, function(oldValue: any)
					local newValue: any = oldValue or deepCopy(BanSystem.DefaultData)

					newValue.AltRestrictData = {
						Code = BanSystem.AltRestrict.Code;
						StartTime = os.time();
					}				

					return newValue;
				end)
			end,
			3,
			true
		)

		if not (success1) then
			warn("Failed to add alt restrict datastore data",self.UserName,self.UserId)
			return false
		else
			warn("successfully alt restricted user",self.UserName,self.UserId)
			--local desc = "Automatic report-timeout auto-ended and removed by system"

			local l_success = logRemote:Invoke(BanSystem.GOLID,"ModLog",self.UserName,nil,"Alt-Restrict","Alt detected, restricted from joining",nil,true,"AltRestrict")
			print(l_success)
		end

		self:Kick(BanSystem.Messages.AltRestrict)
	end

	return Do()
end

------------------------------------------------------------------------------------------	

--function BanSystem:PlayerAdded()
--	local isBanned,banData,banPeriod = self:CheckIfBanned()
	
--	if isBanned then
--		if banData.Type == "Perm" then
--			self:Kick(BanSystem.Messages.Legacy)
--		elseif banData.Type == "Temp" then
--			local reason = (banData.Reason and  ("\"" .. banData.Reason .. "\"")) or "Unspecified"
--			self:Kick(string.format(BanSystem.Messages.Temp, reason, BanSystem.FormatTime(banData.StartTime,banData.EndTime)))
--		elseif banData.Type == "Shadow" then
--			return false
--		end
--		return false
--	end
	
--	return true
--end


--[[Change : nil
	* Used to change the owner of banObject
	
	* Usage - banObject:Change(playerName);
	
	* newUserName - To which player should the table be transfered
]]

function BanSystem:Change(newUserName: string) : nil
	self.UserName =	newUserName;
	self.UserId =	PLAYERS:GetUserIdFromNameAsync(newUserName);
end

--[[Destroy : nil
	* Used to make a banObject not usuable
	
	* Usage - banObject:Destroy()
]]

function BanSystem:Destroy() : nil
	setmetatable(self, {});

	for key: string, _ in pairs(self) do
		self[key] = nil;
	end
end

--//Meta\\--

-------------
--BanSystem.__newindex = function() : nil
--	error("Can't change protected table.");
--end
BanSystem.__index = BanSystem;

BanSystem.__call = function() : string
	return "Version: 0.0.0";
end
BanSystem.__tostring = function(object: any) : string
	local result: string = "";

	for key: string, value: any in pairs(object) do
		result = result .. "Key: " .. tostring(key) .. " - Value: " .. tostring(value) .. " \n";
	end

	return result;
end
BanSystem.__concat = function(object1: any, object2: any) : string
	return tostring(object1) .. tostring(object2);
end

--BanSystem.Call = function(code,...)
--	if code == 3598981304 then
--		return X.PlayerAdded(...)
--	elseif code == 1034961901 then
--		return X.CheckIfBanned(...)
--	elseif code == 65309808934 then
--		return X.AddTempBan(...)
--	elseif code == 7859175927 then
--		return X.UnBan(...)
--	end
--end

return BanSystem