local PropertiesExplorer = {}

local GuiService = game:GetService("GuiService")
local RunService = game:GetService("RunService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")


local Components = script.Parent.Components
local Modules = script.Parent.Modules

local Fusion = require(Modules.Fusion)
local Maid = require(Modules.Maid)
local StringCalculator = require(Modules.StringCalculator)
local Signal = require(Modules.Signal)
local Shared = require(script.Parent.Shared)
local RepShared = require(ReplicatedStorage:WaitForChild("InGameExplorer_Shared"):WaitForChild("InGameExplorerShared"))

local StudioComponents = Components.StudioComponents
local Slider = require(StudioComponents.Slider)
local Label = require(StudioComponents.Label)
local Background = require(StudioComponents.Background)
local Button = require(StudioComponents.Button)
local ProgressBar = require(StudioComponents.ProgressBar)
local Checkbox = require(StudioComponents.Checkbox)
local BoxBorder = require(StudioComponents.BoxBorder)
local TextInput = require(StudioComponents.TextInput)
local ScrollFrame = require(StudioComponents.ScrollFrame)
local VerticalExpandingList = require(StudioComponents.VerticalExpandingList)
local Dropdown = require(StudioComponents.Dropdown)
local ColorPicker = require(StudioComponents.ColorPicker)
local IconButton = require(StudioComponents.IconButton)
local Loading = require(StudioComponents.Loading)
local VerticalCollapsibleSection = require(StudioComponents.VerticalCollapsibleSection)

local ExplorerMaid = Maid.new()

local PickingColorValue = Fusion.Value(Color3.new(1,1,1))
local InitialColorValue = Fusion.Value(PickingColorValue:get())

local PickingColor = Fusion.Value(false)
local ColorWidgetClosedEvent = Instance.new("BindableEvent")
local ColorWidgetClosed = ColorWidgetClosedEvent.Event


local function selectAllText(box)
	box.SelectionStart = 0
	task.delay(0.2,function() -- roblox pls
		box.CursorPosition = #box.Text + 1
	end)
end

local function buttonHover(button)

end
local function CustomDropdown(parent,instance,fusionValue,EnabledComputed)
	local value = instance.Value
	if not value then
		return
	end
	local success,enumType = pcall(function()
		return tostring(value.EnumType)
	end)
	if not enumType then
		return
	end
	local enum = PropertiesExplorer.Enums[enumType]
	if not enum then
		return
	end
	local buttonMaid = Maid.new()

	local transparencyComputed = Fusion.Computed(function()
		if EnabledComputed:get() then
			return 0 
		else
			return 0.5
		end
	end)

	local button = Fusion.New "TextButton"
	{
		BackgroundColor3 = Color3.fromRGB(39, 39, 39),
		BackgroundTransparency = transparencyComputed,
		AnchorPoint = Vector2.new(0,0.5),
		Position = UDim2.new(0,0,0.5,0),
		Size = UDim2.new(0,150,1,-7),
		Text = "",
		AutoButtonColor = EnabledComputed,
		Parent = parent
	}
	local textLabel = Label
	{
		Parent = button,
		Text = Fusion.Computed(function()
			local val = fusionValue:get()
			if val then
				return val.Name
			end
		end),
		TextXAlignment = "Left",
		TextTransparency = transparencyComputed,
		AnchorPoint = Vector2.new(0.5,0.5),
		Position = UDim2.fromScale(0.5,0.5),
		Size = UDim2.new(1,-10,1,0)
	}

	local observer = Fusion.Observer(fusionValue)
	local disconnect = observer:onChange(function()
		textLabel.Text = fusionValue:get().Name
	end)
	buttonMaid:Add(disconnect)


	local frame = parent.Parent
	button.MouseButton1Down:Connect(function()
		if not EnabledComputed:get() then
			return
		end
		local numEnums = #enum

		Shared.WidgetEnabled:set(true)

		local root = PropertiesExplorer.ExplorerRoot
		local dropDownFrame = Instance.new("ScrollingFrame",root)
		dropDownFrame.ScrollBarThickness = 4
		dropDownFrame.BackgroundColor3 = button.BackgroundColor3
		dropDownFrame.Name = "DropdownFrame"

		local absPos = button.AbsolutePosition - root.AbsolutePosition
		local absSize = button.AbsoluteSize
		dropDownFrame.AnchorPoint = Vector2.new(0,0)
		dropDownFrame.Size = UDim2.fromOffset(absSize.X - 30,absSize.Y * numEnums)
		dropDownFrame.Position = UDim2.fromOffset(absPos.X,absPos.Y + (1 * absSize.Y))
		dropDownFrame.CanvasSize = UDim2.fromOffset(0,(numEnums * button.AbsoluteSize.Y)*2) -- Cant seem to get something proper working here, Automatic Canvas Size doesn't work either
		dropDownFrame.Parent = root
		local listLayout = Instance.new("UIListLayout",dropDownFrame)

		buttonMaid:Add(dropDownFrame)

		local options = {}
		for i = 1,numEnums do 
			local newButton = button:Clone()
			local root = PropertiesExplorer.ExplorerRoot.PropertiesExplorer
			local absPos = button.AbsolutePosition - root.AbsolutePosition
			local absSize = button.AbsoluteSize
			newButton.AnchorPoint = Vector2.new(0,0)
			newButton.Size = UDim2.fromOffset(absSize.X,absSize.Y)
			newButton.Parent = dropDownFrame
			newButton.Label.Text = enum[i]
			newButton.LayoutOrder = i
			newButton.MouseButton1Down:Connect(function()
				if instance.SetValue then
					instance.SetValue(Enum[enumType][newButton.Label.Text])
					textLabel.Text = newButton.Label.Text
					buttonMaid:Cleanup()
				end
			end)
			buttonMaid:Add(newButton)
			table.insert(options,newButton)
		end
		ExplorerMaid:Add(buttonMaid)
		buttonMaid:Add(function()
			Shared.WidgetEnabled:set(false)
		end)
		
		buttonMaid:Add(PropertiesExplorer.BGButton.MouseButton1Down:Connect(function()
			buttonMaid:Cleanup()
		end))
	end)
	local function setter(value)
		textLabel.Text = value.Name
	end
	return setter
end


function PropertiesExplorer:UpdateExplorer(Parent,instance,layer,order)

	local ExplorerPadding = 15
		
	local IsRoot = not Parent

	local HasChildren = instance.Children and #instance.Children > 0

	local valueType = instance.ValueType

	if not IsRoot then
		local IsCollapsed = (instance.IsCollapsed == nil and true or instance.IsCollapsed)

		local instanceName = instance.Name or "Root"
		local ReadOnly = instance.ReadOnly
		local IgnoreChanges = false
		local latestValue = instance.Value

		local instanceButton = self.InstanceTemplate:clone()
		instanceButton.LayoutOrder = order
		instanceButton.Name = instanceName
		instanceButton.Parent = self.ExplorerWindow

		local EnabledComputed = Fusion.Computed(function()
			return Shared.WidgetEnabled:get() == false and not ReadOnly
		end)



		Fusion.Hydrate(instanceButton)
		{
			Active = EnabledComputed
		}


		local instanceButtonFrame = instanceButton.Frame

		--[[ Value Frame ]]

		local ValueX = 200

		local valueFrame = instanceButton.PropertyValue
		local divider = instanceButton.Divider
		divider.Visible = not instance.IsRoot
		local valuePosition = UDim2.fromOffset(ValueX,0)
		valueFrame.Position = valuePosition
		divider.Position  = valuePosition
		
		local typeOf = typeof(instance.Value)

		local isNumber = (valueType) and (valueType:match("int") or valueType:match("float") or valueType:match("double")) or typeOf == "number"

		local fusionValue = Fusion.Value(instance.Value)

		if instance.ValueChanged then
			ExplorerMaid:Add(instance.ValueChanged:Connect(function(newValue)
				latestValue = newValue
				if not IgnoreChanges then
					fusionValue:set(newValue)
				end
			end))
		end

		
		if valueType == "Content" then
			valueType = "string"
		end
		local isString = valueType == "string"
		local isVector3 = valueType == "Vector3"
		local isVector2 = valueType == "Vector2"
		local isCFrame = valueType == "CFrame"
		local enum = valueType and self.Enums[valueType]
		local isInstance = valueType == "Instance" or self.Classes[valueType] ~= nil
		local isBool = valueType and valueType:match("bool")
	
		
		local function ParseTextInput(value)
			if isNumber then
				if not tonumber(value) then
					return
				end
				if valueType:match("float") or valueType:match("double") then
					return string.format("%.3f",value)
				else
					return tostring(value)
				end
			elseif isVector3 then
				if typeof(value) ~= "Vector3" then
					return
				end
				return string.format("%.3f, %.3f, %.3f",value.X,value.Y,value.Z)
			elseif isVector2 then
				if typeof(value) ~= "Vector2" then
					return
				end
				return string.format("%.3f, %.3f",value.X,value.Y)
			elseif isCFrame then
				if typeof(value) ~= "CFrame" then
					return
				end
				local x,y,z = value.Position.X,value.Position.Y,value.Position.Z
				local ax,ay,az = value:toEulerAnglesYXZ()
				ax = math.deg(ax)
				ay = math.deg(ay)
				az = math.deg(az)
				return string.format("{%.3f, %.3f, %.3f}, {%.3f, %.3f, %.3f}",x,y,z,ax,ay,az)
			else
				return tostring(value)
			end
		end

		if isBool then
			local valueBox = Checkbox 
			{

				AnchorPoint = Vector2.new(0,0.5),
				Size = UDim2.fromOffset(250,32),
				Position = UDim2.new(0,5,0.5,0),
				Parent = valueFrame,
				Value = fusionValue,
				OnChange = function(newValue)
					instance.SetValue(newValue)
				end,
				Enabled = EnabledComputed,
				Visible = true
			}
			local scale = Instance.new("UIScale",valueBox)
			scale.Scale = 0.8
		elseif isInstance then
			local label = Label
			{

				BackgroundTransparency = 1,
				Size = UDim2.fromScale(1,1),
				Position = UDim2.fromOffset(5,0),
				Parent = valueFrame,
				TextXAlignment = "Left",
				Text = Fusion.Computed(function()
					local value = fusionValue:get()
					if value then
						return value.Name
					else
						return ""
					end
				end),
				Enabled = EnabledComputed,
				Visible = true
			}
		elseif isString or isNumber or isVector3 or isVector2 or isCFrame then
			local valueBox = TextInput 
			{

				BackgroundTransparency = 1,
				Size = UDim2.fromScale(1,1),
				Position = UDim2.fromOffset(0,0),
				Parent = valueFrame,
				Text = Fusion.Computed(function()
					local value = fusionValue:get()
					local val = ParseTextInput(value)
					if val then
						return val
					else
						return ""
					end
				end),
				Enabled = EnabledComputed,
				TextEditable = EnabledComputed,
				Visible = true
			}
			valueBox.Focused:Connect(function()
				if ReadOnly then
					return
				end
				IgnoreChanges = true
				selectAllText(valueBox)
			end)
			valueBox.FocusLost:Connect(function(enterPressed)
				if ReadOnly then
					return
				end
				IgnoreChanges = false
				fusionValue:set(latestValue)
				if enterPressed then
					local value = valueBox.Text

					--[[ Arithmetic ]]
					local ran,num = pcall(StringCalculator,value)
					if ran and isNumber then
						num = tonumber(num)
						if num then
							value = num
						end
					end
					--

					local parsed = ParseTextInput(value)
					local num
					if parsed then
						num = tonumber(parsed)
					end


					local valid = false
					if isNumber then
						if num then
							valid = num
						end
					elseif isVector3 then
						local x,y,z = value:gsub("%s",""):match("(.-),(.-),(.+)")
						if x and y and z then
							local xNum = tonumber(x)
							local yNum = tonumber(y)
							local zNum = tonumber(z)
							if xNum and yNum and zNum then
								valid = Vector3.new(xNum,yNum,zNum)
							end
						end
					elseif isVector2 then
						local x,y = value:gsub("%s",""):match("(.-),(.+)")
						if x and y then
							local xNum = tonumber(x)
							local yNum = tonumber(y)
							if xNum and yNum then
								valid = Vector2.new(xNum,yNum)
							end
						end
					elseif isCFrame then
						local x,y,z,ax,ay,az = value:gsub("[%s{}]",""):match("(.-),(.-),(.-),(.-),(.-),(.+)")
						if x and y and z and ax and ay and az then
							local xNum = tonumber(x)
							local yNum = tonumber(y)
							local zNum = tonumber(z)
							local axNum = tonumber(ax)
							local ayNum = tonumber(ay)
							local azNum = tonumber(az)
							if xNum and yNum and zNum and axNum and ayNum and azNum then
								valid = CFrame.new(Vector3.new(xNum,yNum,zNum)) * CFrame.fromEulerAnglesYXZ(math.rad(axNum),math.rad(ayNum),math.rad(azNum))
							end
						end
					elseif isString then
						valid = value
					end

					if not valid then
						valueBox.Text = ParseTextInput(latestValue)
						return
					end
					instance.SetValue(valid)
				else
					valueBox.Text = ParseTextInput(latestValue)
				end
			end)
		elseif instance.ValueType == "Color3" then
			local valueButton = Fusion.New "TextButton" 
			{
				Text = "",
				Size = UDim2.fromOffset(12,12),
				AnchorPoint = Vector2.new(0.5,0.5),
				Position = UDim2.new(0,12,0.5,0),
				AutoButtonColor = false,
				BackgroundColor3 = Fusion.Computed(function()
					if PickingColor:get() then
						return PickingColorValue:get()
					else
						return fusionValue:get()
					end
				end),
				BackgroundTransparency = Fusion.Computed(function()
					if EnabledComputed:get() then
						return 0 
					else
						return 0.5
					end
				end),
				Parent = valueFrame,
				Visible = true
			}
			local valueBox = TextInput 
			{

				BackgroundTransparency = 1,
				Size = UDim2.fromScale(1,1),
				Position = UDim2.fromOffset(25,0),
				Parent = valueFrame,
				Text = Fusion.Computed(function()
					local value = fusionValue:get()
					return string.format("%d, %d, %d",value.R * 255,value.G * 255,value.B * 255)
				end),
				Visible = true,
				Enabled = EnabledComputed
			}
			valueBox.Focused:Connect(function()
				if ReadOnly then
					return
				end
				IgnoreChanges = true
				selectAllText(valueBox)
			end)
			valueBox.FocusLost:Connect(function(enterPressed)
				if ReadOnly then
					return
				end
				IgnoreChanges = false
				fusionValue:set(latestValue)
				if enterPressed then
					local value = valueBox.Text

					local valid = false

					local r,g,b = value:gsub("%s",""):match("(.-),(.-),(.+)")
					if r and g and b then
						r = tonumber(r)
						g = tonumber(g)
						b = tonumber(b)
						if r and g and b then
							valid = Color3.fromRGB(r,g,b)
						end
					end
					if not valid then
						valueBox.Text = ParseTextInput(latestValue)
						return
					end
					instance.SetValue(valid)
				else
					valueBox.Text = ParseTextInput(latestValue)
				end
			end)
			valueButton.MouseButton1Down:Connect(function()
				if ReadOnly then
					return
				end
				IgnoreChanges = true
				local root = PropertiesExplorer.ExplorerRoot
				PickingColorValue:set(instance.Value)
				InitialColorValue:set(PickingColorValue:get())
				PickingColor:set(true)
				Shared.WidgetEnabled:set(true)
				local lastColor = instance.Value
				local disconnect = Fusion.Observer(PickingColorValue):onChange(function()
					instance.SetValue(PickingColorValue:get())
				end)
				ExplorerMaid:Add(disconnect)
				local pickedColor = ColorWidgetClosed:Wait()
				IgnoreChanges = false
				Shared.WidgetEnabled:set(false)
				PickingColor:set(false)
				disconnect()
				if pickedColor then
					instance.SetValue(pickedColor)
					fusionValue:set(pickedColor)
				else
					instance.SetValue(lastColor)
				end
			end)
		elseif enum then
			CustomDropdown(valueFrame,instance,fusionValue,EnabledComputed)
		end

		--

		instanceButton.Disabled.Visible = ReadOnly

		local instanceButtonHover = instanceButton.Hover

		local IsHovered = Fusion.Value(instance.Hovered)
		local HoverFunction = Fusion.Computed(function()
			return EnabledComputed:get() and IsHovered:get() and not ReadOnly
		end)
		Fusion.Hydrate(instanceButtonHover)
		{
			Visible = HoverFunction
		}

		instanceButtonFrame.PropertyName.Text = instanceName
		instanceButtonFrame.Arrow.Rotation = IsCollapsed and -90 or 0


		local paddingx = layer * ExplorerPadding

		if (not HasChildren) and layer == 0 then
			paddingx -= ExplorerPadding
		end

		paddingx = math.max(paddingx,0)

		if HasChildren then
			instanceButtonFrame.PropertyName.Position = UDim2.fromOffset(30,0)
		else
			instanceButtonFrame.PropertyName.Position = UDim2.fromOffset(15,0)
		end
		instanceButtonFrame.UIPadding.PaddingLeft = UDim.new(0,paddingx)


		instanceButtonFrame.Arrow.Visible = HasChildren


		local HoverTransparency = 0.9

		local HoveredInstance = instance.Hovered
		local SelectedInstance = instance.Selected


		instanceButton.MouseEnter:connect(function()
			if SelectedInstance then
				return
			end
			instance.Hovered = true
			IsHovered:set(true)
		end)
		instanceButton.MouseLeave:connect(function()
			instance.Hovered = false
			IsHovered:set(false)
		end)
		instanceButtonFrame.Arrow.MouseButton1Down:connect(function()
			if Shared.WidgetEnabled:get() then
				return
			end
			if instance.IsCollapsed == nil then
				instance.IsCollapsed = false
			else
				instance.IsCollapsed = not instance.IsCollapsed
			end
			--[[ Trigger explorer refresh ]]
			self:RefreshExplorer()
		end)
		ExplorerMaid:Add(instanceButton)

		if IsCollapsed then
			return order
		end
	end

	if HasChildren then
		for i = 1,#instance.Children do 
			local child = instance.Children[i]
			order += 1000
			order = self:UpdateExplorer(instance,child,layer + 1,order)
		end
	end
	return order
end
function PropertiesExplorer:RefreshExplorer()
	local canvasPos = self.ExplorerWindow.CanvasPosition
	ExplorerMaid:Cleanup()
	self:UpdateExplorer(nil,self.Tree,-1,0)
	self.ExplorerWindow.CanvasPosition = canvasPos
end
function PropertiesExplorer:Close()
	ExplorerMaid:Cleanup()
	if self.EventMaid then
		self.EventMaid:Cleanup()
	end
	self.Tree = nil
end

local DataTypesToChildren = {}


DataTypesToChildren.Vector2 = {
	{Name = "X",ValueType = "float",
		ValueFn = function(parent) 
			return parent.Value.X 
		end,
		SetValueFn = function(value,parent)
			if parent.SetValue then
				parent.SetValue(Vector2.new(value,parent.Value.Y))
			end
		end,
	},
	{Name = "Y",ValueType = "float",
		ValueFn = function(parent) 
			return parent.Value.Y 
		end,
		SetValueFn = function(value,parent)
			if parent.SetValue then
				parent.SetValue(Vector2.new(parent.Value.X,value))
			end
		end,
	}
}

DataTypesToChildren.Vector3 = {
	{Name = "X",ValueType = "float",
		ValueFn = function(parent) 
			return parent.Value.X 
		end,
		SetValueFn = function(value,parent)
			if parent.SetValue then
				parent.SetValue(Vector3.new(value,parent.Value.Y,parent.Value.Z))
			end
		end,
	},
	{Name = "Y",ValueType = "float",
		ValueFn = function(parent) 
			return parent.Value.Y 
		end,
		SetValueFn = function(value,parent)
			if parent.SetValue then
				parent.SetValue(Vector3.new(parent.Value.X,value,parent.Value.Z))
			end
		end,
	},
	{Name = "Z",ValueType = "float",
		ValueFn = function(parent)
			return parent.Value.Z 
		end,
		SetValueFn = function(value,parent)
			if parent.SetValue then
				parent.SetValue(Vector3.new(parent.Value.X,parent.Value.Y,value))
			end
		end,
	}
}

DataTypesToChildren.CFrame = {
	{Name = "Position",
		ValueFn = function(parent) 
			return parent.Value.Position 
		end,
		SetValueFn = function(value,parent)
			local cfAngle = parent.Value - parent.Value.Position
			local cf = CFrame.new(value) * cfAngle
			parent.SetValue(cf)
		end,
		ValueType = "Vector3",
		Children = DataTypesToChildren.Vector3
	},
	{Name = "Orientation",ValueType = "Vector3",
		ValueFn = function(parent) 
			local x,y,z = parent.Value:toEulerAnglesYXZ()
			return Vector3.new(math.deg(x),math.deg(y),math.deg(z))
		end,
		SetValueFn = function(value,parent)
			local cfPos = parent.Value.Position
			local ax,ay,az = value.X,value.Y,value.Z
			ax = math.rad(ax)
			ay = math.rad(ay)
			az = math.rad(az)
			local ang = CFrame.fromOrientation(ax,ay,az)
			local cf = CFrame.new(cfPos) * ang 
			parent.SetValue(cf)
		end,
		Children = DataTypesToChildren.Vector3}
}
local clientBlacklist = {
	"PrivateServerOwnerId",
	"PrivateServerId",
	"VIPServerId",
	"VIPServerOwnerId"
}

function PropertiesExplorer:Open(instance)
	local classInfo = self.Classes[instance.ClassName]
	if not classInfo then
		return
	end
	self:Close()
	local Tree,EventMaid = RepShared:Open(nil,instance,classInfo,Shared.RemoteEvent,Shared.ListeningReplicator:get())
	self.EventMaid = EventMaid
	self.Tree = Tree
	self:RefreshExplorer()
end
function PropertiesExplorer:ReplicatorTreeChangedValue(path,value)
	if not self.Tree then
		return
	end
	local foundChild = RepShared:FindFromPath(path,self.Tree)
	if not foundChild then
		return
	end
	if foundChild.SetValue then
		foundChild.Value = value
		local valueChanged = foundChild.ValueChanged
		if valueChanged then
			valueChanged:Fire(value)
			RepShared:updateChildren(foundChild)
		end
	end
end


function PropertiesExplorer:Init(UI,Classes,Enums)

	local colorPickerUI = script.ColorPicker
	colorPickerUI.Name = "PropertyColorPicker"
	colorPickerUI.Visible = false
	colorPickerUI.Parent = UI

	self.colorPickerUI = colorPickerUI

	Fusion.Hydrate(colorPickerUI)
	{
		Visible = PickingColor
	}

	local colorCancelTemplate = colorPickerUI.Cancel
	local colorConfirmTemplate = colorPickerUI.Confirm
	local colorRGBTemplate = colorPickerUI.RGB
	local colorFrameTemplate = colorPickerUI.ColorPicker

	Fusion.Hydrate(colorRGBTemplate)
	{
		Text = Fusion.Computed(function()
			local colorValue = PickingColorValue:get()
			local r,g,b = colorValue.R * 255,colorValue.G * 255,colorValue.B * 255
			return string.format("%i,%i,%i",r,g,b)
		end)
	}
	colorRGBTemplate.FocusLost:Connect(function()
		local val = colorRGBTemplate.Text
		local r,g,b = val:gsub("%s",""):match("(.-),(.-),(.+)")
		if r and g and b then
			r = tonumber(r)
			g = tonumber(g)
			b = tonumber(b)
			if r and g and b then
				PickingColorValue:set(Color3.fromRGB(r,g,b))
			end
		end
	end)

	self.colorPickerCancel = Button{
		Parent = colorPickerUI,
		Position = colorCancelTemplate.Position,
		Size = colorCancelTemplate.Size,
		Text = "Cancel",
		Activated = function()
			ColorWidgetClosedEvent:Fire()
		end
	}
	colorCancelTemplate:Destroy()

	self.colorPickerConfirm = Button{
		Parent = colorPickerUI,
		Position = colorConfirmTemplate.Position,
		Size = colorConfirmTemplate.Size,
		Text = "Confirm",
		Activated = function()
			ColorWidgetClosedEvent:Fire(PickingColorValue:get())
		end,
	}
	colorConfirmTemplate:Destroy()

	self.colorPickerFrame = ColorPicker{
		Parent = colorPickerUI,
		Position = colorFrameTemplate.Position,
		Size = colorFrameTemplate.Size,
		Value = InitialColorValue,
		OnChange = function(newColor)
			PickingColorValue:set(newColor)
		end,
	}
	self.colorPickerFrame.Slider.Position = UDim2.new(1,0,0,0)
	self.colorPickerFrame.Slider.Size = UDim2.new(0,30,1,0)

	colorFrameTemplate:Destroy()

	self.colorPickerRGB = colorRGBTemplate

	local newEnums = {}
	for i,enumList in Enums do
		table.sort(enumList)
		newEnums[i] = enumList
	end
	Enums = newEnums

	self.Classes = Classes
	self.Enums = Enums
	
	self.UI = UI.PropertiesExplorer
	self.BGButton = self.UI.BGButton
	
	self.Highlight = script.Highlight
	self.Highlight.Parent = self.UI
	self.HighlightInstance = Fusion.Value(nil)
	self.HighlightCFrame = Fusion.Value(nil)
	self.HighlightSize = Fusion.Value(nil)
	self.HighlightBox = Instance.new("Part",workspace.CurrentCamera)
	self.HighlightBox.Anchored = true
	self.HighlightBox.Transparency = 0.9
	
	Fusion.Observer(self.HighlightInstance):onChange(function()
		local instance = self.HighlightInstance:get()
		if instance then
			self.Highlight.Adornee = instance
		else
			self.Highlight.Adornee = nil
		end
	end)

	
	
	Fusion.Hydrate(self.BGButton)
	{
		Visible = Shared.WidgetEnabled
	}
	
	self.ExplorerWindow = UI.PropertiesExplorer.Body.ScrollingFrame
	UI.PropertiesExplorer.Active = true
	Fusion.Hydrate(self.ExplorerWindow)
	{
		ScrollingEnabled = Fusion.Computed(function()
			return Shared.WidgetEnabled:get() == false
		end)
	}

	self.InstanceTemplate = self.ExplorerWindow.PropertyTemplate:Clone()
	self.ExplorerWindow.PropertyTemplate:Destroy()
	self.ExplorerRoot = UI
	Fusion.Hydrate(UI.PropertiesExplorer)
	{
		Visible = Fusion.Computed(function()
			return Shared.SelectedInstance:get() ~= nil and Shared.ExportFrameEnabled:get() == false
		end)
	}
	local Body = UI.PropertiesExplorer.Body
	local ExplorerWindow = Body.ScrollingFrame


	Fusion.Observer(Shared.SelectedInstance):onChange(function()
		local HighlightInstance
		local SelectedInstance = Shared.SelectedInstance:get()
		if SelectedInstance then
			self:Open(SelectedInstance)
			if typeof(SelectedInstance) == "Instance" and (SelectedInstance:IsA("Model") or SelectedInstance:IsA("BasePart")) then
				HighlightInstance = SelectedInstance
			end
		else
			self:Close()
		end		
		self.HighlightInstance:set(HighlightInstance)
	end)
	
	Fusion.Observer(Shared.ListeningReplicator):onChange(function()
		self:Close()
		Shared.SelectedInstance:set(nil)
	end)
	
	
	
	local TopBar = UI.PropertiesExplorer.Body.TopBar
	local ExportProperties = Button 
	{

		Size = UDim2.new(0,100,0,20),
		Position = UDim2.new(0,7,0,5),
		Parent = TopBar,
		LayoutOrder = 0,
		Text = "Export Changes",
		Activated = function()
			Shared.ExportFrameEnabled:set(true)
			
		end,
		Visible = true
	}
	
	Shared.RemoteEvent.OnClientEvent:Connect(function(message, ...)
		if message == "OpenProperties" then
			local id,instanceTable = ...
			if id and instanceTable then
				instanceTable.ID = id
				Shared.SelectedInstance:set(instanceTable)
			end
		elseif message == "TreeChangedValue" then
			local path,value = ... 
			self:ReplicatorTreeChangedValue(path,value)			
		end
	end)
end

return PropertiesExplorer
