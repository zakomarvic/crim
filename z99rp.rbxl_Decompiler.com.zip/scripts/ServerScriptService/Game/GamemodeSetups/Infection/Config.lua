local RunService = game:GetService("RunService")

local M = {
	MinimumPlayers = (RunService:IsStudio() and 1) or 8;	
	StartingCash = 500;
	CashCap = 10000;
	
	BuyTime = 45; -- 45 secs
	PrepareTime = 60; -- 60 secs
	IntermissionTime = (RunService:IsStudio() and 0) or 15; -- 30 secs
	
	GameTime = 420;
	
	WinCash_Humans = 5000;
	WinCash_OriginalInfected = 500;
	
	KillCash_Infecteds = 250;
	KillCash_Humans = 750;
	
	HUMAN_REGEN_STEP = 1/120;
	HUMAN_REGEN_RATE = 1;
	HUMAN_FDP = 1.25; -- fall damage
	
	INFECTED_REGEN_STEP = 1/40;
	INFECTED_REGEN_RATE = 0.5;
	INFECTED_CLIMB_SD = 10;
	
	InfectedRager = { -- resurrected one
		StartHP = 200;
		RegenRate = 10; -- this much per 0.1 while rising
		
		RiseTime = 3.2;
		HP = 100;
		
		RespawnTime = {4,7}; -- time until can resurrect
		
		Rage_DMM = 0.3; -- rage damage multi
		Rage_SM = 1.15; -- speed multi
		Rage_LastTime = 20; -- rage effect last time
		Rage_DelayTime = 3; -- rage effect delay  time

		Rage_DamageTick = 0.2;
		Rage_DamageAmt = 2;
	};
	
	SpecialInfectedChances = {
		[1] = {
			Name = "Hunter";
			
			Chances = {2,15}; -- 25,50
			MinAM = 4;
			MaxActive = 1;
			
			CooldownTime = 45;
			
			KillCashMulti = 4;
		};
		[2] = {
			Name = "Brute";

			MinAM = 4;
			Chances = {2,30};
			MaxActive = 1;
			
			CooldownTime = 45;

			KillCashMulti = 3;
		};
		

		[3] = {
			Name = "Spitter";

			MinAM = 3;
			Chances = {2,20};
			MaxActive = 2;

			KillCashMulti = 1.5;
		};
		
		[4] = {
			Name = "Riot";
			
			MinAM = 3;
			Chances = {-3,15};
			MaxActive = 5;
			
			KillCashMulti = 1.5;
		};
	};
	
	ForceMaxInfectedCountThing = false;
	
	InfecedExplode = {
		Enabled = true;
		Chance = {4,16};
		Delay = {3,4};
	};
	
	PrepareCC = {
		Enabled = true;
		Saturation = -0.5;
		Contrast = 0.5;
		Brightness = 0.2;
	};
	
	HumanTracking = {
		Enabled = true;
		Hour = 2; -- enables at this hour
		
		MarkersEnabled = true;
	};
	
	StartHourCash = 50;
	AddHourCash = 50;
	
	InfectedPerc = 0.25;
	
	NoGameOver = RunService:IsStudio();--RunService:IsStudio();
	NoStartInfecteds = RunService:IsStudio();--RunService:IsStudio();--RunService:IsStudio();
	
	AreaDenialTK = 0.1;
	
	TestSkipStartPhase = false;-- RunService:IsStudio(); --unService:IsStudio();-- RunService:IsStudio(); -- RunService:IsStudio();-- RunService:IsStudio();

	TokenContent = {
		["Juggernaut"] = {
			Enabled = true;
			ProductID = 1336586005; --1336262835;
			
			Title = "Juggernaut";

			HP = 300;
			LimbHP = 500;
			FallDamageProof = 0.25;

			CustomKillCash = 3000;
			
			OrderNum = 1;
		};
		
		["RayGun"] = { -- shotgun
			Enabled = true;
			ProductID = 1338437343;
			Title = "Ray Gun";

			OrderNum = 2;
		};
		
		["UTS_15"] = { -- shotgun
			Enabled = true;
			ProductID = 1338437467;
			Title = "UTS-15";

			OrderNum = 3;
		};
		
		["PrecisionStrike"] = {
			Enabled = true;
			ProductID = 1338437518;
			Title = "Precision Strike";
			
			OrderNum = 4;
		};	
		
		["BecomeHunter"] = {
			IsBecome = true;
			
			Enabled = true;
			ProductID = 1338437559;
			
			Title = "Become Hunter";
			
			Name = "Hunter";
			MinAM = 4;
			
			OrderNum = 5;
			ProductName = "become_hunter";
		};
		["BecomeBrute"] = {
			IsBecome = true;

			Enabled = true;
			ProductID = 1338437619;

			Title = "Become Brute";

			Name = "Brute";
			MinAM = 4;

			OrderNum = 6;
			ProductName = "become_brute";
		};
		["BecomeSpitter"] = {
			IsBecome = true;

			Enabled = true;
			ProductID = 1338437647;

			Title = "Become Spitter";

			Name = "Spitter";
			MinAM = 3;

			OrderNum = 7;
			ProductName = "become_spitter";
		};
	};
	
	BuyCash = {
		Enabled = true;
		ProductID = 1336586038; -- 1336513537;
		Amount = 10000;
	};
	
	Leaderboards = {
		Enabled = true;
		Key = "INFECTION_LEADERBOARDS_MAIN.2";
		
		WinsKey = "WINS.2";
		
		MaxItems = 50; -- Max number of items to be displayed on the leaderboard
		MinValueDisplay = 1; -- Any numbers lower than this will be excluded
		MaxValueDisplay = 100000; -- (10 ^ 15) Any numbers higher than this will be excluded
		UpdateEvery = 60; -- (in seconds) How often the leaderboard has to update
	};
	
	------------
	
	NoStudioDataSave = true;

	TempData_DS_KEY = "INFECTION_TEST.1";
	TempData_ExpireTime = 60 * 15;

	MainSaveData_DS_KEY = "INFECTION_MAIN_TEST.1";
};

--if game.GameId == 1857700501 then --brrr
--	M.BuyCash.ProductID = 1336513537
	
--	M.TokenContent.BecomeSpitter.ProductID = 1338404423
--	M.TokenContent.BecomeBrute.ProductID = 1338404424
--	M.TokenContent.BecomeHunter.ProductID = 1338397380
--	M.TokenContent.PrecisionStrike.ProductID = 1337693639
--	M.TokenContent.UTS_15.ProductID = 1337679813
--	M.TokenContent.RayGun.ProductID = 1338376216
--	M.TokenContent.Juggernaut.ProductID = 1336262835
	
--	if not RunService:IsStudio() then
--		M.MinimumPlayers = 1
--		M.NoStartInfecteds = true
--	end
--elseif game.GameId == 2881451226 then -- bane
--	M.BuyCash.ProductID = 1336564695

--	M.TokenContent.BecomeSpitter.ProductID = 1338446227
--	M.TokenContent.BecomeBrute.ProductID = 1338446272
--	M.TokenContent.BecomeHunter.ProductID = 1338446335
--	M.TokenContent.PrecisionStrike.ProductID = 1338446421
--	M.TokenContent.UTS_15.ProductID = 1338446463
--	M.TokenContent.RayGun.ProductID = 1338446532
--	M.TokenContent.Juggernaut.ProductID = 1336564741
--end


return M

