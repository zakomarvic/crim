local ServerStorage = game:GetService("ServerStorage")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local PhysicsService = game:GetService("PhysicsService")
local RunService = game:GetService("RunService")
local TS = game:GetService("TweenService")

local SupplyCrate = {}
local M = require(script.Parent)

function SupplyCrate.new(spawnCF,crateTier,targetXZPos,givenPlane)
	assert(typeof(spawnCF ~= "CFrame"),"SupplyCrate spawnCF not CFrame")
	local t = tick()
	_G.T = t

	--print("YEAHH DORP CRATE")

	local crate = script.SupplyCrate:Clone()
	local box = crate.Box
	local parachute = crate.Parachute

	local hitbox = box.HitBox
	local can_at = parachute.Canister.Attachment

	for i,v in pairs(crate:GetDescendants()) do
		if v:IsA("BasePart") 
		then
			v.CFrame = spawnCF

			pcall(function()
				v.CollisionGroupId = PhysicsService:GetCollisionGroupId("NoCharCollide2") or 0
			end)
		end	
	end

	local pP = crate.Box.MeshPart
	if crateTier == 1 then
		pP.TextureID = "rbxassetid://137288873147435"
		pP.Material = Enum.Material.Fabric
	elseif crateTier == 2 then
		pP.TextureID = "rbxassetid://106556705947104"
		pP.Material = Enum.Material.Metal
	elseif crateTier == 3 then
		pP.TextureID = "rbxassetid://70977026934564"
		pP.Material = Enum.Material.Plastic
	elseif crateTier == "4J" then
		pP.TextureID = "rbxassetid://129307019269949"
		pP.Material = Enum.Material.Wood
	end


	hitbox.BodyVelocity.Velocity = Vector3.new(0,M.Settings.CrateSettings.Velocity,0)

	if targetXZPos then
		local bodyPos = Instance.new("BodyPosition")
		bodyPos.MaxForce = Vector3.new(10e10,0,10e10)
		bodyPos.Position = targetXZPos
		bodyPos.D = 1000
		bodyPos.P = 500
		bodyPos.Parent = hitbox
	end

	crate.Parent = workspace.Debris.VParts

	for i,v in pairs(crate:GetDescendants()) do
		if v:IsA("BasePart") and v:CanSetNetworkOwnership() then
			v:SetNetworkOwner(nil)
		end
	end

	can_at.Sound:Play()

	ReplicatedStorage.Events.SupplyBoxHandler:FireAllClients(crate)

	local con,con2
	local landed = false

	local function OnLand()
		if landed then return end
		landed = true

		--print("lanmded")

		if con then
			con:Disconnect()
		end
		if con2 then
			con2:Disconnect()
		end

		if not (hitbox and hitbox.Parent) then return end

		--print(tick() - t)

		if can_at and can_at.Parent then
			can_at.Land2:Play()
		end

		task.wait(0.3)

		if can_at and can_at.Parent then
			local wcf = can_at.WorldCFrame

			can_at.Parent = workspace.Terrain
			can_at.ParticleEmitter.Enabled = false
			can_at.HookRelease:Play()
			can_at.Land:Play()
			can_at.Sound:Stop()
			can_at.WorldCFrame = wcf
			game.Debris:AddItem(can_at,60)
		end

		if parachute and parachute.Parent then
			--parachute:Destroy()
			parachute.ConstraintFolder.Bs:ClearAllChildren()

			local pp = parachute.ParachutePart.Velocity

			game.Debris:AddItem(parachute,60)


			parachute.ParachutePart.Velocity = Vector3.new(pp.X,5,pp.Z)
			parachute.ParachutePart.BodyForce.Force = Vector3.new(math.random(-70,70),36000,math.random(-70,70))
		end

		if box and box.Parent and hitbox and hitbox.Parent then
			local cf = hitbox.CFrame

			box:Destroy()

			local spawnCF = cf
			local rarity = crateTier
			local gotN = "CrateConfig_T" .. tostring(rarity)
			local isLocked = false

			ServerStorage.Events3.SpawnCrate:Invoke("IJ98W9POJIFW09F9ES",spawnCF,rarity,gotN,isLocked,nil,1000)
		end
	end
	
	local function onTouched(h)
		if not h:IsDescendantOf(crate) 
			and (h == workspace.Terrain or (h.CanCollide
				and not h:IsDescendantOf(workspace.Characters)
				))
				and not (givenPlane and h:IsDescendantOf(givenPlane))
		then
			con:Disconnect()
			OnLand()
		end
	end

	con = crate.Box.HitBox.Touched:Connect(onTouched)
	
	spawn(function()
		while not landed do
			for i,v in pairs(crate.Box.HitBox:GetTouchingParts()) do
				onTouched(v)
			end
			
			wait(2)
		end
	end)

	con2 = hitbox.AncestryChanged:Connect(function(_,parent)
		if not parent then
			con2:Disconnect()
			OnLand()
		end
	end)
end

return SupplyCrate