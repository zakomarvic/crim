--[[ This is a game explorer and properties window for in-game debugging purposes
	It is only intended to be used for developers of an experience
	
	Setup Instructions:
	1. Drag InGameExplorer script to ServerScriptService
	2. Set up Permissions and Keybind modules to what you desire
	
	There's a plugin in here too which you can use to import properties and attributes of changed things in-game back to studio
	Save ImportPropertiesPlugin as a local plugin if you want to use this
	
	Feel free to tweak as needed, and report any bugs to me(tyridge77#5390 on discord or https://twitter.com/rblx_tyridge77)
]]