local ts = game:GetService("TweenService")
local rs = game:GetService("RunService")
--
local effectsData = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Media"):WaitForChild("Statuses"))
local static = {}
static.__index = static
--
local statusEffects = {
	gui = script:WaitForChild("StatusGUI"), 
	sid = 0,
	statuses = {}, 
	--
	hovering = false,
	hoverstats = {},
	hoveros = os.clock(),
	hoversid = 0,
	hoverkey = 0,
	--
}
--
function statusEffects.new(status, statusdata)
	statusEffects.sid+=1
	--
	local obj = {
		sid = statusEffects.sid,
		ui = nil,
		tweens = {},
		connections = {},
		statusIns = status,
		dataRef = statusdata,
		flashing = false,
		removed = false,
		--
		flasherValueBefore = (status:GetAttribute("flasher") or 0),
		valueBefore = status.Value,
		--
	}
	--
	local ui = script.effect:Clone()
	ui.Parent = statusEffects.gui.statuses.list
	obj.ui = ui
	--
	setmetatable(obj, static)
	obj.__index = static
	table.insert(statusEffects.statuses, obj)
	obj:init()
	--
	return obj
end
--
function statusEffects.init()
	--
	statusEffects.gui.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")
	local player = game.Players.LocalPlayer
	--
	player.CharacterAdded:Connect(function(character) 
		task.spawn(function() 
			for _, obj in ipairs(statusEffects.statuses) do obj:remove() end
			local gvf = _G.GVF(character.Name)
			--
			gvf.Statuses.ChildAdded:Connect(function(status) 
				if (effectsData[status.Name] ~= nil) then
					--
					local obj = statusEffects.new(status, effectsData[status.Name]) 
					local anc
					anc = status.AncestryChanged:Connect(function() 
						if (gvf == nil or gvf.Parent == nil or gvf:FindFirstChild("Statuses") == nil) or (status.Parent ~= gvf.Statuses) then
							anc:Disconnect()
							obj:remove()
							obj = nil end end)
					--
				else
					warn("No status effect data defined for status named: ".. status.Name.."!") end end)
			--
		end)
	end)
	--
end
--
function statusEffects:hover(sid, dataRef, statusIns)
	for _, stat in ipairs(statusEffects.hoverstats) do stat[2]:Disconnect() stat[1]:Destroy() end
	statusEffects.hoverkey += 1
	local key = statusEffects.hoverkey
	statusEffects.hoversid = sid
	statusEffects.hovering = true
	--
	self.gui.statuses.hover.Visible = true
	self.gui.statuses.hover.statusname.Text = dataRef.name
	self.gui.statuses.hover.statusdescription.Text = dataRef.description
	self.gui.statuses.hover.statusname.TextTransparency = 1
	self.gui.statuses.hover.statusdescription.TextTransparency = 1
	game:GetService("TweenService"):Create(self.gui.statuses.hover.statusname, TweenInfo.new(0.4, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {TextTransparency = 0}):Play()
	game:GetService("TweenService"):Create(self.gui.statuses.hover.statusdescription, TweenInfo.new(0.4, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {TextTransparency = 0}):Play()
	--
	for sind, statins in ipairs(statusIns:GetChildren()) do
		--
		local statui = script.stat:Clone()
		statui.Parent = self.gui.statuses.hover.effects
		statui.LayoutOrder = (statins:GetAttribute("order") or sind)
		--
		local function updateText()
			local bounds = game:GetService("TextService"):GetTextSize(statins.Value, 20, Enum.Font.Merriweather, Vector2.new(275, 20))
			statui.Size = UDim2.new(1, 0, 0, 28 + (bounds.Y - 20))
			statui.text.Text = statins.Value
			--
			local condition = statins:GetAttribute("condition")
			if (condition == nil or condition == 0) then
				statui.text.TextColor3 = Color3.fromRGB(200, 200, 200)
			elseif (condition == 1) then
				statui.text.TextColor3 = Color3.fromRGB(75, 175, 75)
			elseif (condition == -1) then
				statui.text.TextColor3 = Color3.fromRGB(175, 75, 75) end
			--
		end
		--
		updateText()
		local updateConnection = statins:GetPropertyChangedSignal("Value"):Connect(updateText)
		table.insert(statusEffects.hoverstats, {statui, updateConnection})
		--
	end
	--
end
--
function statusEffects:unhover(sid)
	if (statusEffects.hoversid == sid) then
		task.spawn(function() 
			statusEffects.hoversid = nil
			local key = statusEffects.hoverkey
			task.wait(0.2)
			--
			if (key == statusEffects.hoverkey) then
				statusEffects.hovering = false
				self.gui.statuses.hover.Visible = false end
			--
		end)
	end
end
--
function static:stopTweens()
	for _, tw in ipairs(self.tweens) do tw:Pause() end
	self.tweens = {}
end
--
function static:createTween(ins, info, props, autoplay)
	local tw = ts:Create(ins, info, props)
	if (autoplay == nil or autoplay == true) then tw:Play() end
	table.insert(self.tweens, tw)
	return tw
end
--
function static:flash(vdif)
	if (not self.flashing) then
		task.spawn(function() 
			self.flashing = true
			--
			local indur = (self.dataRef.flashing.durationIn or 0.25)
			local outdur = (self.dataRef.flashing.durationOut or 0.25)
			local color
			--
			if (self.dataRef.condition == nil or self.dataRef.condition == 0) then
				color = self.dataRef.flashing.color
			elseif (self.dataRef.condition == 1) then
				if (vdif > 0) then
					color = (self.dataRef.flashing.positiveColor or Color3.fromRGB(100, 255, 100)) else
					color = (self.dataRef.flashing.negativeColor or Color3.fromRGB(255, 100, 100)) end
			elseif (self.dataRef.condition == -1) then
				if (vdif > 0) then
					color = (self.dataRef.flashing.negativeColor or Color3.fromRGB(255, 100, 100)) else
					color = (self.dataRef.flashing.positiveColor or Color3.fromRGB(100, 255, 100)) end
			end
			--
			self:createTween(self.ui.flash, TweenInfo.new(indur, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, 0, false, 0), {BackgroundColor3 = color, BackgroundTransparency = (self.dataRef.flashing.transparency or 0.5)})
			task.wait(indur)
			if (not self.removed) then
				self:createTween(self.ui.flash, TweenInfo.new(outdur, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, 0, false, 0), {BackgroundColor3 = Color3.fromRGB(255,255,255), BackgroundTransparency = 1})
				task.wait(outdur) end
			--
			self.flashing = false
		end)
	end
end
--
function static:init()
	--
	self.ui.Size = UDim2.new(0, 5, 0, 50)
	self.ui.background.ImageTransparency = 1
	self.ui.statusIcon.Image = self.dataRef.icon
	self.ui.statusIcon.statusIconShad1.Image = self.dataRef.icon
	self.ui.statusIcon.statusIconShad2.Image = self.dataRef.icon
	self.ui.statusIcon.ImageTransparency = 1
	self.ui.statusIcon.statusIconShad1.ImageTransparency = 1
	self.ui.statusIcon.statusIconShad2.ImageTransparency = 1
	--
	table.insert(self.connections, self.ui.MouseEnter:Connect(function() 
		if (not self.removed) then statusEffects:hover(self.sid, self.dataRef, self.statusIns) end end))
	--
	table.insert(self.connections, self.ui.MouseLeave:Connect(function() 
		statusEffects:unhover(self.sid) end))
	--
	local uiopeninfo = TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0)
	local uiiconopeninfo = TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, 0, false, 0.2)
	self:createTween(self.ui, uiopeninfo, {Size = UDim2.new(0, 50, 0, 50)})
	self:createTween(self.ui.background, uiopeninfo, {ImageTransparency = 0.1})
	self:createTween(self.ui.statusIcon, uiiconopeninfo, {Size = UDim2.new(0.9, 0, 0.9, 0), ImageTransparency = 0})
	self:createTween(self.ui.statusIcon.statusIconShad1, uiiconopeninfo, {ImageTransparency = 0.1})
	self:createTween(self.ui.statusIcon.statusIconShad2, uiiconopeninfo, {ImageTransparency = 0.1})
	--
	local function updateProgress()
		--
		if (self.statusIns:IsA("DoubleConstrainedValue")) then
			self.ui.progress.Visible = true
			self.ui.progress.Size = UDim2.new(1, 0, (self.statusIns.Value / self.statusIns.MaxValue), 0)
		else self.ui.progress.Visible = false end
		--
	end
	--
	updateProgress()
	self.statusIns:GetPropertyChangedSignal("Value"):Connect(function() 
		updateProgress() end)
	--
	local function flashCheck(flasher)
		if (self.dataRef.flashing ~= nil) then
			local difference
			--
			if (flasher == true and self.statusIns:GetAttribute("flasher") ~= nil) then
				difference = (self.statusIns:GetAttribute("flasher")-self.flasherValueBefore)
				self.flasherValueBefore = self.statusIns:GetAttribute("flasher")
			else
				difference = (self.statusIns.Value-self.valueBefore)
				self.valueBefore = self.statusIns.Value
			end
			--
			self:flash(difference)
		end
	end
	--
	if (self.statusIns:GetAttribute("flasher")) then
		table.insert(self.connections, self.statusIns:GetAttributeChangedSignal("flasher"):Connect(function() 
			flashCheck(true) end))
	else
		table.insert(self.connections, self.statusIns:GetPropertyChangedSignal("Value"):Connect(function() 
			flashCheck(false) end))
	end
	--
end
--
function static:remove()
	self:stopTweens()
	for _, con in ipairs(self.connections) do con:Disconnect() end
	local iconinfo = TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0)
	local frameinfo = TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, 0, false, 0.2)
	self:createTween(self.ui.statusIcon, iconinfo, {Size = UDim2.new(0, 0, 0, 0), ImageTransparency = 1})
	self:createTween(self.ui.statusIcon.statusIconShad1, iconinfo, {ImageTransparency = 1})
	self:createTween(self.ui.statusIcon.statusIconShad2, iconinfo, {ImageTransparency = 1})
	self:createTween(self.ui, frameinfo, {Size = UDim2.new(0, 0, 0, 50)})
	self:createTween(self.ui.background, frameinfo, {ImageTransparency = 1})
	_G.RemoveElementFromArray(statusEffects.statuses, self)
	self.removed = true
	statusEffects:unhover(self.sid)
	task.wait(1)
	self.ui:Destroy()
end
--
return statusEffects