return { -- grey scraps
	
	["val_WeaponParts"] = {
		Rarity = 1;
		Chance = 10;
	};
	["val_Gunpowder"] = {
		Rarity = 1;
		Chance = 13;
	};
	
	["val_Wires"] = {
		Rarity = 1;
		Chance = 13;
	};
	["val_MilitaryCable"] = {
		Rarity = 1;
		Chance = 13;
	};
	["val_Lighter"] = {
		Rarity = 1;
		Chance = 14;
	};
	["val_Cloth"] = {
		Rarity = 1;
		Chance = 13;
	};
	
	
	

	["Lockpick"] = {
		Rarity = 1;
		Chance = 3;
	};

	["Shiv"] = {
		Rarity = 1;
		Chance = 3; -- %
	};

	["Wrench"] = {
		Rarity = 1;
		Chance = 3; -- %
	};

	["Bayonet"] = {
		Rarity = 1;
		Chance = 3; -- %
	};

	["Golfclub"] = {
		Rarity = 1;
		Chance = 3; -- %
	};

	["Crowbar"] = {
		Rarity = 2;
		Chance = 3; -- %
	};

	["Shovel"] = {
		Rarity = 2;
		Chance = 3; -- %
	};

	["Molotov"] = {
		Rarity = 2;
		Chance = 3; -- %
	};

	["Beretta"] = {
		Rarity = 4;
		Chance = 1; -- %
	};

	["Sawn-Off"] = {
		Rarity = 4;
		Chance = 1; -- %
	};	
	
	

}