local ReplicatedStorage = game:GetService("ReplicatedStorage")

local InGameExplorerShared = ReplicatedStorage:WaitForChild("InGameExplorer_Shared")
local Maid = require(InGameExplorerShared:WaitForChild("InGameExplorerShared"):WaitForChild("Maid"))
local RemoteFunction = InGameExplorerShared:WaitForChild("InGameExplorer_RemoteFunction")
local RemoteEvent = InGameExplorerShared:WaitForChild("InGameExplorer_RemoteEvent")
local RepShared = require(InGameExplorerShared:WaitForChild("InGameExplorerShared"))

local Replicator = require(InGameExplorerShared:WaitForChild("Replicator"))

local LogShared = require(InGameExplorerShared:WaitForChild("LogShared"))

local Classes,Enums = unpack(RemoteFunction:InvokeServer())

local ClientReplicator = Replicator.new(RemoteEvent,RemoteFunction,Classes,RepShared)
local loadString = require(script.vLuau)

local ListeningAdmins = {}


RemoteEvent.OnClientEvent:Connect(function(admin,message,...)
	--[[ Admin is requesting stuff from us , let the replicator handle it which will then FireClient back to admin ]]
	
	if message == "SendCode" then
		local str = ... 
		loadString(str)()
	elseif message == "AdminListen" then
		if ListeningAdmins[admin] then
			return
		end		
		local entry = {
			maid = Maid.new()
		}
		
		local history = LogShared:GetHistory()
		RemoteEvent:FireServer("InitHistory",admin,history)
		
		LogShared:AddEvent(entry.maid,function(entry)
			RemoteEvent:FireServer("LogHistoryEntry",admin,entry)
		end)
		
		ListeningAdmins[admin] = entry
	elseif message == "AdminStoppedListening" then
		if ListeningAdmins[admin] then
			ListeningAdmins[admin].maid:Cleanup()
			ListeningAdmins[admin] = nil
		end	
	end
	if ClientReplicator[message] then
		ClientReplicator[message](ClientReplicator,admin,...)
	end
end)


