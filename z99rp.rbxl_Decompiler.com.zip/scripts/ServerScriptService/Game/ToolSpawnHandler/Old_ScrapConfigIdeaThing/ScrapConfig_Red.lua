return { -- red scraps

	["val_Watch"] = {
		Rarity = 1;
		Chance = 12;
	};
	["val_SkullRing"] = {
		Rarity = 1;
		Chance = 12;
	};
	["val_Dogtag"] = {
		Rarity = 1;
		Chance = 12;
	};
	["val_Keytool"] = {
		Rarity = 1;
		Chance = 12;
	};
	["val_Jerrycan"] = {
		Rarity = 1;
		Chance = 11;
	};
	["val_FloppyDrive"] = {
		Rarity = 1;
		Chance = 10;
	};
	["val_Blueprint"] = {
		Rarity = 1;
		Chance = 5;
	};
	["val_Documents"] = {
		Rarity = 1;
		Chance = 3;
	};
	
	-- 23
	
	["Balisong"] = {
		Rarity = 2;
		Chance = 2; -- %
	};

	["Rambo"] = {
		Rarity = 3;
		Chance = 2; -- %
	};
	
	["Fire-Axe"] = {
		Rarity = 3;
		Chance = 2; -- %
	};
	
	["Machete"] = {
		Rarity = 3;
		Chance = 2; -- %
	};
	
	["Metal-Bat"] = {
		Rarity = 3;
		Chance = 2; -- %
	};
	
	["Chainsaw"] = {
		Rarity = 4;
		Chance = 2;
	};
	
	["M1911"] = {
		Rarity = 4;
		Chance = 2; -- %
	};
	
	["Deagle"] = {
		Rarity = 4;
		Chance = 2; -- %
	};
	["Uzi"] = {
		Rarity = 4;
		Chance = 2; -- %
	};
	
	["MAC-10"] = {
		Rarity = 4;
		Chance = 2; -- %
	};
	
	["Tommy"] = {
		Rarity = 4;
		Chance = 1;
	};

	["C4"] = {
		Rarity = 4;
		Chance = 2; -- %
	};
}