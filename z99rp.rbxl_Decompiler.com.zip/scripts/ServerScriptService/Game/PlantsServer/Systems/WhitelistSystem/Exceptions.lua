local exceptions = {}

exceptions = {
	["CottonMip"] = 1,
	["RAVENOUSHUNGERSLAYER"] = 1,
}

return exceptions