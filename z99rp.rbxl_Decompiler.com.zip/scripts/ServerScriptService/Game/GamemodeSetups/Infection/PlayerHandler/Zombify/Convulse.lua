local ServerStorage = game:GetService("ServerStorage")
local TS = game:GetService("TweenService")

return function(char,infectedType)
	--print("convulse",3)
	
	local vF = _G.GVF(char.Name)
	if not vF or not char:FindFirstChild("Torso") then return end

	--print("convulse",4)
	
	if char.Humanoid:GetAttribute("IsHighInfected") then
		return
	end
	
	if vF.HealthValues.Head.Destroyed.Value then return end

	--print("convulse",5)
	
	local plr = game.Players:GetPlayerFromCharacter(char)
	if not (char and char:GetAttribute("WasTagKilled")) then return end
	
	--print("convulse",6)
	
	local sound = script.ConvulseSound:Clone()
	
	if infectedType == "Riot" then
		for i,v in pairs(script.RS:GetChildren()) do
			v:Clone().Parent = sound
		end
	end
	
	sound.Parent = char.Torso
	sound:Play()
	
	local ang = Instance.new("BodyAngularVelocity")
	_G.cTag(ang,"BM")
	
	local n = 10
	if math.random(1,2) == 1 then
		n = -n
	end
	
	local vel = Vector3.new(n,n / 2, 0)
	
	ang.MaxTorque = Vector3.new(10e10,10e10,10e10)
	ang.AngularVelocity = Vector3.new()

	ang.Parent = char.Torso
	
	TS:Create(ang,TweenInfo.new(2.3,Enum.EasingStyle.Quart,Enum.EasingDirection.In),{AngularVelocity = vel}):Play()
	
	for i,v in pairs(vF.HealthValues:GetChildren()) do
		if not v.Destroyed.Value then
			v.Value = 1
		end
	end
	
	task.wait(2.6)
	
	if char and char.Parent and char:FindFirstChild("Torso") and vF and vF.Parent then
		if ang and ang.Parent then
			ang:Destroy()
		end
		local exp = ServerStorage.Projectiles["__InfectedConvulseExplosion"]:Clone()
		exp.CFrame = char.Torso.CFrame
		game.Debris:AddItem(exp,15)
		exp.Creator.Value = plr
		exp.Parent = workspace.Debris
		exp.Main.Disabled = false
		
		task.wait(1)
	end
end