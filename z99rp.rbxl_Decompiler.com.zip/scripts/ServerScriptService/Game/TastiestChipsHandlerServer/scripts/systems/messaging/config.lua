return {
	--
	showDebug = false,
	maximumTimeForGetRequests = 3,
	failSafeMaximum = 3, -- The maximum number of times a request can retry,.
	failSaveInterval = 2, -- The amount of time inbetween before it retrys a request.
	--
}