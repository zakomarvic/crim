-- SERVER

local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
--
local assets = game:GetService("ReplicatedStorage").PlantsStorage.Assets
local sounds = assets.Sounds.LootContainer.WeaponsLocker
--
return {
	--
	loot = "Scrap",
	model = script.toolbox,
	poffset = Vector3.new(0, 0.25, -0.875),
	--
	regenerationTime = {720, 1200},
	maxItems = 7,
	minPower = 4,
	maxPower = 9,
	absoluteMaxPower = 5,
	--
	isTheft = true,
	cashBoost = 0.80, -- +80% Cash
	powerStartMultiplier = 0.6,
	powerTickEverySeconds = {90, 200},
	powerTickIncreaseRange = {3, 7},
	--
	onOpen = function(container, model)
		_G.PlaySound(sounds.open, model.Base, (math.random(90, 110)/100)*1.4)
		local HAngle = math.random(65, 80)
		local HCFrame = (CFrame.new() * CFrame.Angles(math.rad(-HAngle), 0, 0))
		framework.networking.toClients(nil, false, "Tween", {model.Base.Hinge, {0.225, Enum.EasingStyle.Sine,Enum.EasingDirection.Out, 0, false, _G.Random(0.03, 0.075, 1000)}, {C1 = HCFrame}})
	end,
	--
	onClose = function(container, model)
		_G.PlaySound(sounds.open, model.Base, (math.random(80, 90)/100)*1.4)
		_G.PlaySound(sounds.close, model.Base, (math.random(95, 105)/100)*1.4, 0.2)
		framework.networking.toClients(nil, false, "Tween", {model.Base.Hinge, {0.225, Enum.EasingStyle.Sine,Enum.EasingDirection.Out, 0, false, _G.Random(0.03, 0.075, 1000)}, {C1 = CFrame.new()}})
	end,
	--
	overwriteLoot = {
		--
		{name = "Wrench", weight = 15, power = 32, isMelee = true},
		--
		{name = "val_Jerrycan", weight = 0},
		{name = "val_Documents", weight = 0},
		{name = "val_FloppyDrive", weight = 0},
		{name = "val_CDCase", weight = 0},
		{name = "val_Watch", weight = 0},
		{name = "val_WeaponParts", weight = 0},
		{name = "val_SkullRing", weight = 0},
		{name = "val_Dogtag", weight = 0},
		{name = "val_Gunpowder", weight = 0},
	}
	--
}