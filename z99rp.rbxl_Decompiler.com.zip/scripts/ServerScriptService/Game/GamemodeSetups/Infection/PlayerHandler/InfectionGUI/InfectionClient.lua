local gui = script.Parent
require(script:WaitForChild("MainHandler")).new(gui)