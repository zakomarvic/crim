local HttpService = game:GetService("HttpService")
local RunService = game:GetService("RunService")

local ServerViewList = {
	"Workspace",
	"Players",
	"Lighting",
	"MaterialService",
	"ReplicatedFirst",
	"ReplicatedStorage",
	"ServerScriptService",
	"ServerStorage",
	"StarterGui",
	"StarterPack",
	"StarterPlayer",
	"SoundService"
}
local ClientViewList = {
	"Workspace",
	"Players",
	"CoreGui",
	"Lighting",
	"MaterialService",
	"PluginGuiService",
	"ReplicatedFirst",
	"ReplicatedStorage",
	"RobloxPluginGuiService",
	"StarterGui",
	"StarterPack",
	"StarterPlayer",
	"Teams",
	"SoundService",
	"TextChatService"
}


local Replicator = {}
Replicator.__index = Replicator 
function Replicator.new(RemoteEvent,RemoteFunction,Classes,RepShared)
	local self = setmetatable({
		RemoteEvent = RemoteEvent,
		RemoteFunction = RemoteFunction,
		ListeningAdmins = {},
		Classes = Classes,
		RepShared = RepShared
	},Replicator)
	return self
end
function Replicator:GetViewlist()
	return self.Server and ServerViewList or ClientViewList
end

function Replicator:FireClient(admin,...)
	if self.Server then
		self.RemoteEvent:FireClient(admin,...)
	else
		self.RemoteEvent:FireServer("FireClient",admin,...)
	end
end
function Replicator:Cleanup()
	
end


-- Initialize and track the information for instances within the game (for example, objects and characters)
-- This also sets up listeners that fire when a child is added or removed from the instance.

function Replicator:InitInstance(listening, inst)
	local id = listening.IdCounter
	listening.IdCounter += 1

	local instanceDetails = {
		Instance = inst,
		Id = id,
		Name = inst.Name,
		ClassName = inst.ClassName,
		Connections = {},

		Children = inst:GetChildren(),
		ChildIndices = {},

		Listening = false
	}
	
	if inst == game then
		for i = #instanceDetails.Children, 1, -1 do
			local child = instanceDetails.Children[i]
			if not table.find(self:GetViewlist(), child.ClassName) then
				table.remove(instanceDetails.Children, i)
			end
		end
	end

	for i,v in instanceDetails.Children do
		instanceDetails.ChildIndices[v] = i
	end

	listening.InstancesById[instanceDetails.Id] = instanceDetails
	listening.InstancesByObject[instanceDetails.Instance] = instanceDetails

	instanceDetails.Connections.NameChanged = inst:GetPropertyChangedSignal("Name"):Connect(function()
		instanceDetails.Name = inst.Name
		self:FireClient(listening.Admin, "Update", instanceDetails.Id, { Name = instanceDetails.Name })
	end)

	instanceDetails.Connections.ChildAdded = inst.ChildAdded:Connect(function(child)
		if inst == game then
			if not table.find(self:GetViewlist(), child.ClassName) then
				return
			end
		end

		local index = #instanceDetails.Children + 1
		instanceDetails.Children[index] = child
		instanceDetails.ChildIndices[child] = index

		if instanceDetails.Listening then
			local childDetails = self:InitInstance(listening, child)

			self:FireClient(listening.Admin, "Init", instanceDetails.Id, {
				Id = childDetails.Id,
				Name = childDetails.Name,
				ClassName = childDetails.ClassName,
				HasChildren = #childDetails.Children > 0
			})
		else
			if #instanceDetails.Children == 1 then
				self:FireClient(listening.Admin, "Update", instanceDetails.Id, { HasChildren = true })
			end
		end
	end)

	instanceDetails.Connections.ChildRemoved = inst.ChildRemoved:Connect(function(child)
		local index = instanceDetails.ChildIndices[child]
		if not index then return end

		local finalIndex = #instanceDetails.Children
		local final = instanceDetails.Children[finalIndex]

		instanceDetails.Children[index] = final
		instanceDetails.ChildIndices[final] = index

		instanceDetails.Children[finalIndex] = nil
		instanceDetails.ChildIndices[child] = nil

		if instanceDetails.Listening then
			local childDetails = assert(listening.InstancesByObject[child])
			self:ClearInstance(listening, childDetails)
		else
			if #instanceDetails.Children == 0 then
				self:FireClient(listening.Admin, "Update", instanceDetails.Id, { HasChildren = false })
			end
		end
	end)

	return instanceDetails
end

-- Initialize a selected instance and begin listening for events that occur within the instance.

function Replicator:InitInstanceListeners(listening, instanceDetails)
	assert(not instanceDetails.Listening)

	instanceDetails.Listening = true

	local children = {}

	for _,child in instanceDetails.Children do
		local childDetails = self:InitInstance(listening, child)

		table.insert(children, {
			Id = childDetails.Id,
			Name = childDetails.Name,
			ClassName = childDetails.ClassName,
			HasChildren = #childDetails.Children > 0
		})
	end

	self:FireClient(listening.Admin, "Update", instanceDetails.Id, { Children = children })
end

-- a admin has started listening

function Replicator:StartListening(admin, id)	
		
	local listening = self.ListeningAdmins[admin]

	if not listening then
		assert(not id)
		
		-- Started listening for the first time
		
		listening = {
			InstancesById = {},
			InstancesByObject = {},
			SelectedInstance = nil,
			Admin = admin,
			IdCounter = 0
		}

		self.ListeningAdmins[admin] = listening
	end

	if id then
		local instanceDetails = assert(listening.InstancesById[id])
		self:InitInstanceListeners(listening, instanceDetails)
	else
				
		assert(not listening.Root)
		
		-- Start listening to game
				
		local rootDetails = self:InitInstance(listening, game)
		listening.Root = rootDetails
				
		self:FireClient(listening.Admin, "Init", nil, {
			Id = rootDetails.Id,
			Name = rootDetails.Name,
			ClassName = rootDetails.ClassName,
			HasChildren = #rootDetails.Children > 0
		})
	end
end

-- a admin has stopped listening 

function Replicator:StopListening(admin, id)
	
	local listening = self.ListeningAdmins[admin]
	if not listening then return end
	
	self:StopSelectingInstance(admin)

	if id == nil then
		self.ListeningAdmins[admin] = nil

		for _,inst in listening.InstancesById do
			for i,v in inst.Connections do
				v:Disconnect()
			end
		end

		self:FireClient(listening.Admin, "Remove", nil)
	else
		local instanceDetails = assert(listening.InstancesById[id])
		self:ClearInstanceListeners(listening, instanceDetails)
	end
end


function Replicator:StopSelectingInstance(admin)
	local listening = self.ListeningAdmins[admin]
	if listening then
		local maid = listening.SelectedInstanceMaid 
		if maid then
			maid:Cleanup()
		end
		listening.SelectedInstance = nil
	end
end

-- Remove a listening instance and all its child instances from the list of managed instances.
-- Also fires a remote event to the client, telling it to remove the instance from the client's view.

function Replicator:ClearInstance(listening, instanceDetails, skipUpdate)
	if instanceDetails.Listening then
		self:ClearInstanceListeners(listening, instanceDetails, true)
	end

	for i,v in instanceDetails.Connections do
		v:Disconnect()
	end

	listening.InstancesById[instanceDetails.Id] = nil
	listening.InstancesByObject[instanceDetails.Id] = nil

	if not skipUpdate then
		self:FireClient(listening.Admin, "Remove", instanceDetails.Id)
	end
end

-- Ceases listening for changes on a specific instance and all of its child instances.
-- Does not remove them from the list of managed instances.

function Replicator:ClearInstanceListeners(listening, instanceDetails, skipUpdate)
	assert(instanceDetails.Listening)

	instanceDetails.Listening = false

	for _,child in instanceDetails.Children do
		local childDetails = assert(listening.InstancesByObject[child])
		self:ClearInstance(listening, childDetails, true)
	end

	if not skipUpdate then
		self:FireClient(listening.Admin, "Update", instanceDetails.Id, { HasChildren = #instanceDetails.Children > 0 })
	end
end

-- Select a game instance to inspect its properties

function Replicator:SelectInstance(admin,id)
	if id then
		local listening = self.ListeningAdmins[admin]
		if listening then
			self:StopSelectingInstance(admin)
			local instanceDetails = assert(listening.InstancesById[id])

			if not instanceDetails then
				return
			end

			local instance = instanceDetails.Instance

			local instanceTable = {}

			local classInfo = self.Classes[instanceDetails.ClassName]
			if not classInfo then
				return
			end

			--[[ Filter out bad properties to send ]]
			for i,info in classInfo.Categorized_Properties do
				local properties = info.list
				for i,propertyInfo in properties do
					local propertyName = propertyInfo.propertyName

					local success,currentValue = pcall(function()
						return instance[propertyName]
					end)

					if not success then
						continue
					end

					local valueType = propertyInfo.valueType
					local tags = propertyInfo.tags

					if tags and (tags.Deprecated or tags.NotScriptable or tags.Hidden) then
						continue
					end

					instanceTable[propertyName] = currentValue
				end
			end

			local attributes = instance:GetAttributes()
			instanceTable.AttributesList = attributes

			local Tree,EventMaid = self.RepShared:Open(admin,instance,classInfo,self.RemoteEvent)

			listening.SelectedInstance = Tree
			listening.SelectedInstanceMaid = EventMaid
			instanceTable.FullName = instance:GetFullName()


			self:FireClient(admin,"OpenProperties",instanceDetails.Id,instanceTable)
		end
	end
end

-- Request a change in the properties of an instance.

function Replicator:RequestPropertyChange(admin,path,val)
	local listening = self.ListeningAdmins[admin]
	if listening then
		local selectedInstance = listening.SelectedInstance
		if not selectedInstance then
			return
		end
		if not path or (val == nil) then
			return
		end

		task.spawn(function()
			local foundChild = self.RepShared:FindFromPath(path,selectedInstance)
			if foundChild then
				if foundChild.SetValue then
					foundChild.SetValue(val)
				end
			end
		end)
	end
end

return Replicator