local RagdollModule = {}

local RunService = 		game:GetService("RunService")
local PhysicsService = 	game:GetService("PhysicsService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local mod =  require(ReplicatedStorage.Modules.WaterCheck2)
local ragdollStuff = ServerStorage.Storage.RagdollStuff

function RagdollModule.Initilize(Character)
	local Player = game.Players:GetPlayerFromCharacter(Character)

	local Humanoid: Humanoid = Character:WaitForChild("Humanoid")
	Humanoid.BreakJointsOnDeath = false

	local HumanoidRootPart = Character:WaitForChild("HumanoidRootPart")
	local Torso = Character:WaitForChild("Torso")

	local EventsFolder = ReplicatedStorage.Events

	local MainParts = {
		Head = Character:WaitForChild("Head");
		Torso = Character:WaitForChild("Torso");
		LeftArm = Character:WaitForChild("Left Arm",1);
		RightArm = Character:WaitForChild("Right Arm",1);
		LeftLeg = Character:WaitForChild("Left Leg",1);
		RightLeg = Character:WaitForChild("Right Leg",1);
	}

	local Settings = {
		RagdollOnDeath = true;
		ColliderSize = 0.5;
		ColliderSize2 = 0.4;
	}

	local originalColliderSizes = {}

	local ConstraintSettings = { -- normal
		["Shoulder"] = {
			UpperAngle = 90;
			TwistLowerAngle = -90;
			TwistUpperAngle = 90;
		};
		["Hip"] = {
			UpperAngle = 35;
			TwistLowerAngle = -90;
			TwistUpperAngle = 90;
		};
		["Neck"] = {
			UpperAngle = 55;
			TwistLowerAngle = -75;
			TwistUpperAngle = 45;
		};
	}

	local ConstraintSettings2 = { -- grabbed
		["Shoulder"] = {
			UpperAngle = 25;
			TwistLowerAngle = -100;
			TwistUpperAngle = 100;
		};
		["Hip"] = {
			UpperAngle = 15;
			TwistLowerAngle = -100;
			TwistUpperAngle = 150;
		};
		["Neck"] = {
			UpperAngle = 45;
			TwistLowerAngle = -75;
			TwistUpperAngle = 75;
		};
	}

	local ConstraintSettings3 = { -- broken
		["Shoulder"] = {
			UpperAngle = 20;
			TwistLowerAngle = -20;
			TwistUpperAngle = 20;
		};
		["Hip"] = {
			UpperAngle =20;
			TwistLowerAngle = -20;
			TwistUpperAngle = 20;
		};
		["Neck"] = {
			UpperAngle = 20;
			TwistLowerAngle = -20;
			TwistUpperAngle = 20;
		};
	}

	local values = _G.GVF(Character.Name)

	local Constraints = {}
	local Colliders = {}
	local Motor6Ds = {}
	local Ragdolling = false
	local ragdollDB = false
	local ragdollManaging = false
	local stopped = false

	local conz = {}

	local Attachment0s_Table = {}
	local Attachment1s_Table = {}
	local constrainttoname = {}

	local RagdollTime = values:WaitForChild("RagdollTime")
	local RagdollSwitch = RagdollTime:FindFirstChild("RagdollSwitch")

	local Namez = {"Left Shoulder";"Right Shoulder";"Left Hip";"Right Hip";"Neck";"RootJoint"}

	local function updateConstraints()
		if not Constraints then return end

		local gV = values.Grabbed.Value
		for _,Constraint in pairs(Constraints) do
			if Constraint:FindFirstChild("Origin") then
				
				if (Constraint.Attachment1 == nil or Constraint.Attachment1.Parent == nil) then continue end
				
				local M = Constraint.Origin.Value

				local cS = ConstraintSettings

				if Constraint.Attachment1 and values.HealthValues:FindFirstChild(Constraint.Attachment1.Parent.Name) and values.HealthValues[Constraint.Attachment1.Parent.Name].Broken.Value then
					cS = ConstraintSettings3
				elseif gV then
					cS = ConstraintSettings2
				end

				local S
				if M == "Right Shoulder" or M == "Left Shoulder" then
					S = cS.Shoulder
				elseif M == "Right Hip" or M == "Left Hip" then
					S = cS.Hip	
				elseif M == "Neck" then
					S = cS.Neck
				end

				if S then
					Constraint.UpperAngle =			S.UpperAngle
					Constraint.TwistLowerAngle =	S.TwistLowerAngle
					Constraint.TwistUpperAngle =	S.TwistUpperAngle
				end
			end
		end

		for _,v in pairs(Colliders) do
			local oS = originalColliderSizes[v]
			local cS = Settings.ColliderSize

			if gV then
				cS = Settings.ColliderSize2
			end
			if oS then
				v.Size = oS * cS
			end
		end		
	end

	wait()

	local function StopIt()
		if stopped then return end
		stopped = true

		for _,v in pairs(conz) do
			if v then
				pcall(function()
					v:Disconnect()
				end)
			end
		end

		--Constraints,MainParts,Motor6Ds = nil,nil,nil
	end

	local function SortMotor6Ds()
		for _,Motor6D in pairs(Character:GetDescendants()) do
			if Motor6D:IsA("Motor6D") and not Motor6D:FindFirstChild("ParentValue") then
				local Got = false
				for _,v in pairs(Namez) do
					if Motor6D.Name == v then
						Got = true
						break
					end
				end
				if Got then
					local ObjectValue = Instance.new("ObjectValue")
					ObjectValue.Name = "ParentValue"
					ObjectValue.Value = Motor6D.Parent
					ObjectValue.Parent = Motor6D
					Motor6Ds[Motor6D.Name] = Motor6D
					--table.insert(Motor6Ds,Motor6D)
				end
			end
		end
	end

	local function CreateAttachments()
		local LLJoint = Instance.new("Attachment")
		LLJoint.Name = "Torso_Left Leg"
		LLJoint.Position = Vector3.new(-0.5, -1, 0)
		LLJoint.Parent = MainParts.Torso
		table.insert(Attachment0s_Table,LLJoint)



		local RLJoint = Instance.new("Attachment")
		RLJoint.Name = "Torso_Right Leg"
		RLJoint.Position = Vector3.new(0.5, -1, 0)	
		RLJoint.Parent = MainParts.Torso
		table.insert(Attachment0s_Table,RLJoint)



		local RAJoint = Instance.new("Attachment")
		RAJoint.Name = "Torso_Right Arm"
		RAJoint.Position = Vector3.new(1.5, 0.5, 0)	
		RAJoint.Parent = MainParts.Torso
		table.insert(Attachment0s_Table,RAJoint)



		local LAJoint = Instance.new("Attachment")
		LAJoint.Name = "Torso_Left Arm"
		LAJoint.Position = Vector3.new(-1.5, 0.5, 0)	
		LAJoint.Parent = MainParts.Torso
		table.insert(Attachment0s_Table,LAJoint)



		local NJoint = Instance.new("Attachment")
		NJoint.Name = "Torso_Head"
		NJoint.Position = Vector3.new(0,1,0)
		NJoint.Parent = MainParts.Torso
		table.insert(Attachment0s_Table,NJoint)



		local Attachment = Instance.new("Attachment")
		Attachment.Name = "RagdollAttachment"
		Attachment.Position = Vector3.new(0, 0.5, 0)
		Attachment.Parent = MainParts.LeftArm
		table.insert(Attachment1s_Table,Attachment)

		local Attachment = Instance.new("Attachment")
		Attachment.Name = "RagdollAttachment"
		Attachment.Position = Vector3.new(0, 0.5, 0)
		Attachment.Parent = MainParts.RightArm
		table.insert(Attachment1s_Table,Attachment)

		local Attachment = Instance.new("Attachment")
		Attachment.Name = "RagdollAttachment"
		Attachment.Position = Vector3.new(0, -0.5, 0)
		Attachment.Parent = MainParts.Head
		table.insert(Attachment1s_Table,Attachment)

		local Attachment = Instance.new("Attachment")
		Attachment.Name = "RagdollAttachment"
		Attachment.Position = Vector3.new(0, 1, 0)
		Attachment.Parent = MainParts.LeftLeg
		table.insert(Attachment1s_Table,Attachment)

		local Attachment = Instance.new("Attachment")
		Attachment.Name = "RagdollAttachment"
		Attachment.Position = Vector3.new(0, 1, 0)
		Attachment.Parent = MainParts.RightLeg
		table.insert(Attachment1s_Table,Attachment)
	end

	local function CreateColliders()
		for _,part in pairs(MainParts) do
			if part and not part:FindFirstChild(part.Name .. "Collider") then

				--local Collider = Instance.new("Part")

				--originalColliderSizes[Collider] = Part.Size

				--Collider.Size = Part.Size * Settings.ColliderSize
				--Collider.CFrame = Part.CFrame
				--Collider.Name = "Collider"
				--Collider.CanCollide = false
				--Collider.CanTouch = false
				--Collider.Locked = true
				--Collider.Massless = true


				local colliderPart = ragdollStuff:FindFirstChild(part.Name .. "Collider"):Clone()
				local cWeld = ragdollStuff:FindFirstChild(part.Name .. "CWeld"):Clone()
				cWeld.Part0 = part
				cWeld.Part1 = colliderPart
				cWeld.Parent = colliderPart

				colliderPart:SetAttribute("IsRagdollCollider",true)
				colliderPart.Transparency = 1
				colliderPart.Anchored = false
				colliderPart.CollisionGroup = "RagdollCollide1"
				colliderPart.Parent = part

				--local Weld = Instance.new("Weld")
				--Weld.Name = Collider.Name .. "'s Weld"
				--Weld.Part0 = Part
				--Weld.Part1 = Collider
				--Weld.Parent = Collider

				Colliders[colliderPart.Parent.Name] = colliderPart
				--table.insert(Colliders,Collider)
			end
		end
	end

	local function CreateConstraints()
		local f = Instance.new("Folder")
		f.Name = "CTs"
		f.Parent = HumanoidRootPart

		for i,M in pairs(Motor6Ds) do
			local Constraint = Instance.new("BallSocketConstraint")
			Constraint.Name = "RGCT_" .. M.Name

			constrainttoname[Constraint.Name] = M.Part1.Name

			Constraint.Parent = f

			local Origin = Instance.new("StringValue")
			Origin.Name = "Origin"
			Origin.Value = M.Name
			Origin.Parent = Constraint

			Constraint.LimitsEnabled = true
			Constraint.TwistLimitsEnabled = true

			local S
			if M.Name == "Right Shoulder" or M.Name == "Left Shoulder" then
				S = ConstraintSettings.Shoulder
			elseif M.Name == "Right Hip" or M.Name == "Left Hip" then
				S = ConstraintSettings.Hip	
			elseif M.Name == "Neck" then
				S = ConstraintSettings.Neck
			elseif M.Name == "RootJoint" then
				Constraint.UpperAngle = 0
				Constraint.TwistLowerAngle = 0
				Constraint.TwistUpperAngle = 0
			end

			if S then
				Constraint.UpperAngle =			S.UpperAngle
				Constraint.TwistLowerAngle =	S.TwistLowerAngle
				Constraint.TwistUpperAngle =	S.TwistUpperAngle
			end

			local Attachment0 = nil
			local Attachment1 = nil

			for _,Attachment in pairs(Attachment0s_Table) do
				if Attachment0 == nil then
					local NameTing = string.sub(Attachment.Name,7)
					if NameTing == M.Part1.Name then
						Attachment0 = Attachment
					end
				end
			end

			for _,Attachment in pairs(Attachment1s_Table) do
				if Attachment1 == nil then
					if Attachment:IsDescendantOf(M.Part1) then
						Attachment1 = Attachment
					end
				end
			end

			Constraint.Attachment0 = Attachment0
			Constraint.Attachment1 = Attachment1

			Constraints[Constraint.Name] = Constraint
			--table.insert(Constraints,Constraint)
		end

		local Accessories = Humanoid:GetAccessories()
		for _,Accessory in pairs(Accessories) do
			local Part = Accessory:FindFirstChildWhichIsA("BasePart")
			Part.CanCollide = false
			if Part.Name == "Handle" then
				Part.Size = Vector3.new(0,0,0)
			end

			local h = Instance.new("HingeConstraint")
			h.Name = "HingeConstraint"
			h.Parent = Accessory
			h.LimitsEnabled = true
			h.LowerAngle = 0
			h.UpperAngle = 0
			local A1 = Part:FindFirstChildOfClass("Attachment")
			for _,Part in pairs(MainParts) do
				if A1 and A1.Parent then
					local Z = Part:FindFirstChild(A1.Name)
					if Z then
						h.Attachment0 = Z
						break
					end
				end
			end
			h.Attachment1 = A1
		end
	end

	local function CantGetUpCheck()
		if values and values.Parent then
			return (_G.LimbCheck(Character,"Right Leg","Destroyed") and _G.LimbCheck(Character,"Left Leg","Destroyed")) or _G.LimbCheck(Character,"Head","Broken") or _G.DoesCharAffectExist(Character, "TIEDUP")
		end
		return false
	end

	local function Ragdoll(Mode,bruh)
		Ragdolling = Mode
		if Mode == true then
			local oldNetworkOwner
			if MainParts.Torso:GetAttribute("NoNetworkOwnerSet") then
				oldNetworkOwner = MainParts.Torso:GetNetworkOwner()
			end

			RagdollSwitch.Value = true
			values.Downed.Resisting.Value = false

			local cfz = {}

			for _,v in pairs(MainParts) do
				if v and v.Parent then
					cfz[v] = {v.CFrame,v.Velocity}
				end
			end

			RagdollTime.SRagdolled.Value = true

			Humanoid.AutoRotate = false
			Humanoid.Jump = false

			local cf = Torso.CFrame

			_G.FlinchChar(Character,Humanoid,0.1,true,false,false,true)

			Humanoid:SetStateEnabled(Enum.HumanoidStateType.RunningNoPhysics,false)
			Humanoid:SetStateEnabled(Enum.HumanoidStateType.Swimming,false)
			Humanoid:SetStateEnabled(Enum.HumanoidStateType.Running,false)				
			Humanoid:SetStateEnabled(Enum.HumanoidStateType.Jumping,false)
			Humanoid:SetStateEnabled(Enum.HumanoidStateType.FallingDown,false)
			Humanoid:SetStateEnabled(Enum.HumanoidStateType.GettingUp,false)
			Humanoid:SetStateEnabled(Enum.HumanoidStateType.Freefall,false)				
			Humanoid:SetStateEnabled(Enum.HumanoidStateType.Landed,false)
			Humanoid:SetStateEnabled(Enum.HumanoidStateType.Ragdoll,true)

			Humanoid:ChangeState(Enum.HumanoidStateType.Ragdoll)

			coroutine.resume(coroutine.create(function()
				for i = 1,5 do
					Humanoid:ChangeState(Enum.HumanoidStateType.Ragdoll)
					wait()
				end
			end))

			for _,Motor6D in pairs(Motor6Ds) do
				local g = true
				if ( (Motor6D.Name == "Right Shoulder" or Motor6D.Name == "Left Shoulder") and (values and values.Handcuffed.Value) )  then g = false end

				if g and Motor6D.Part0 ~= HumanoidRootPart and (Motor6D:GetAttribute("RagdollEnabled") == nil or Motor6D:GetAttribute("RagdollEnabled") <= 0) then
					pcall(function()
						Motor6D.Enabled = false
					end)
				end
			end			

			for _,Constraint in pairs(Constraints) do				
				local g = true
				--if ( (Constraint.Name == "RGCT_Right Shoulder" or Constraint.Name == "RGCT_Left Shoulder") and (values and values.Handcuffed.Value) )  then 
				--g = false
				if constrainttoname[Constraint.Name] 
					--and values.HealthValues:FindFirstChild(constrainttoname[Constraint.Name]) and values.HealthValues:FindFirstChild(constrainttoname[Constraint.Name]).Broken.Value 
				then
					g = false
				end

				if g then
					Constraint.Enabled = true
				end
			end

			for _,Collider in pairs(Colliders) do
				if Collider and Collider.Parent then
					local g = true
					if ( (Collider.Parent.Name == "Right Arm" or Collider.Parent.Name == "Left Arm") and ( values and values.Handcuffed.Value) )  then g = false end
					--if values.HealthValues:FindFirstChild(Collider.Parent.Name) and values.HealthValues[Collider.Parent.Name].Broken.Value then
					--	g = false
					--end
					if g then
						Collider.CanCollide = true
					end
				end
			end

			local Accessories = Humanoid:GetAccessories()
			for _,Accessory in pairs(Accessories) do
				local Part = Accessory:FindFirstChildWhichIsA("BasePart")
				if Part then
					Part.CanCollide = false
				end
				if Accessory:FindFirstChild("HingeConstraint") then
					Accessory.HingeConstraint.Enabled = true
				end
			end

			--if Humanoid.Health > 0 then

			--end
			HumanoidRootPart.CanCollide = false
			--for i,v in pairs(MainParts) do
			--	if v and v.Parent then
			--		v.CanCollide = false
			--		if Humanoid.Health > 0 then
			--			v.CollisionGroup = "RagdollCollide2"
			--		end
			--	end
			--end
			for i,v in pairs(MainParts) do
				if v.Parent then
					v.CanCollide = false
					if Humanoid.Health > 0 then
						v.CollisionGroup = "RagdollCollide2"
					end
				end
			end
			coroutine.wrap(function()
				for i = 1,15 do
					if not Ragdolling then
						break
					end
					for i,v in pairs(MainParts) do
						if v.Parent then
							v.CanCollide = false
						end
					end
					task.wait(0.1)
				end
			end)()

			--if MainParts.Torso and MainParts.Torso.Velocity.Magnitude < 2 then
			--	local PushForce = Instance.new("BodyForce")
			--	_G.cTag(PushForce,"BM")
			--	PushForce.Force = (MainParts.Torso.CFrame.LookVector) * 300
			--	PushForce.Parent = MainParts.Torso
			--	game.Debris:AddItem(PushForce,0.1)
			--end

			if Player then
				EventsFolder.ChangeState:FireClient(Player,Enum.HumanoidStateType.PlatformStanding,25)
			end

			if Vector3.new(0,HumanoidRootPart.Velocity.Y,0).Magnitude <= 15 then
				for i,z in pairs(cfz) do
					local v = MainParts[i]
					if v and v.Parent then
						if i == MainParts.Torso then
							HumanoidRootPart.CFrame = z[1]
							HumanoidRootPart.Velocity = z[2]
						end
						v.CFrame = z[1]
						v.Velocity = z[2]
					end
				end
			end

			if oldNetworkOwner then
				for i,v in pairs(Character:GetDescendants()) do
					if v:IsA("BasePart") and v:CanSetNetworkOwnership() then
						v:SetNetworkOwner(oldNetworkOwner)
					end
				end
			end
		elseif Mode == false and Humanoid.Health > 0 then
			local oldNetworkOwner
			if MainParts.Torso:GetAttribute("NoNetworkOwnerSet") then
				oldNetworkOwner = MainParts.Torso:GetNetworkOwner()
			end

			RagdollSwitch.Value = false
			--Humanoid.PlatformStand = false
			--HumanoidRootPart.Anchored = false
			RagdollTime.SRagdolled.Value = false
			Humanoid.AutoRotate = true
			values.Downed.Resisting.Value = false

			local cf = Torso.CFrame

			Humanoid:SetStateEnabled(Enum.HumanoidStateType.RunningNoPhysics,true)
			Humanoid:SetStateEnabled(Enum.HumanoidStateType.Swimming,true)
			Humanoid:SetStateEnabled(Enum.HumanoidStateType.Running,true)				
			Humanoid:SetStateEnabled(Enum.HumanoidStateType.Jumping,true)
			Humanoid:SetStateEnabled(Enum.HumanoidStateType.FallingDown,true)
			Humanoid:SetStateEnabled(Enum.HumanoidStateType.GettingUp,true)
			Humanoid:SetStateEnabled(Enum.HumanoidStateType.Freefall,true)				
			Humanoid:SetStateEnabled(Enum.HumanoidStateType.Landed,true)
			Humanoid:SetStateEnabled(Enum.HumanoidStateType.Ragdoll,false)

			Humanoid:ChangeState(Enum.HumanoidStateType.GettingUp)

			for _,Collider in pairs(Colliders) do
				if Collider and Collider.Parent
					--(not values.HealthValues:FindFirstChild(Collider.Parent.Name) or (values.HealthValues:FindFirstChild(Collider.Parent.Name) and not values.HealthValues[Collider.Parent.Name].Broken.Value)) 
				then
					Collider.CanCollide = false
				end
			end

			for i,v in pairs(MainParts) do
				if v and v.Parent then
					v.CanCollide = true
					if Humanoid.Health > 0 then
						v.CollisionGroup = "Character"
					end
				end
			end

			for _,Motor6D in pairs(Motor6Ds) do
				local x = true
				if Motor6D.Part1 and values.HealthValues:FindFirstChild(Motor6D.Part1.Name)
					and values.HealthValues[Motor6D.Part1.Name].Destroyed.Value
				then
					x = false
				end
				if Motor6D:FindFirstChild("ParentValue") and x then
					pcall(function()
						Motor6D.Enabled = true
					end)
				end
			end

			--			for _,Constraint in pairs(Constraints) do
			--				--Constraint.Enabled = false
			--			end

			local Accessories = Humanoid:GetAccessories()
			for _,Accessory in pairs(Accessories) do
				local Part = Accessory and Accessory:FindFirstChildWhichIsA("BasePart")
				if Part then
					Part.CanCollide = false
					local h = nil
				end
				if Accessory and Accessory:FindFirstChild("HingeConstraint") then
					Accessory.HingeConstraint.Enabled = false
				end
			end

			if Player then
				EventsFolder.ChangeState:FireClient(Player,Enum.HumanoidStateType.GettingUp,5)
			else
				for i = 1,5 do
					Humanoid:ChangeState(Enum.HumanoidStateType.GettingUp)
					wait(0.05)
				end
			end

			if not bruh then
				HumanoidRootPart.CFrame = cf + Vector3.new(0,1,0)	
			end

			if oldNetworkOwner then
				for i,v in pairs(Character:GetDescendants()) do
					if v:IsA("BasePart") and v:CanSetNetworkOwnership() then
						v:SetNetworkOwner(oldNetworkOwner)
					end
				end
			end
		end
	end

	--if values then
	--	local function bruh()
	--		if not values.Downed.Value and CantGetUpCheck() then
	--			RagdollTime.Value = RagdollTime.Value + 1
	--		end
	--	end
	--	for _,v in pairs(values.HealthValues:GetChildren()) do
	--		v.Broken.Changed:Connect(bruh)
	--	end
	--end

	local con1 = RagdollTime:GetPropertyChangedSignal("Value"):Connect(function()
		RagdollTime.Tick.Value = tick()

		if RagdollTime.Value > 0 and not ragdollManaging then
			RagdollSwitch.Value = true
			ragdollManaging = true

			Humanoid.PlatformStand = true
			Humanoid:ChangeState(Enum.HumanoidStateType.None)

			local sT = tick()

			local function WaterCheck()
				if values.Downed.Value then
					local inW,undW = mod(HumanoidRootPart)
					return inW
				end
			end

			local endT = nil

			repeat wait(0.2) 
				if Humanoid:GetState() == Enum.HumanoidStateType.Running then
					Humanoid:SetStateEnabled(Enum.HumanoidStateType.Running,false)
					Humanoid:ChangeState(Enum.HumanoidStateType.Ragdoll)
				end

				if not (RagdollTime.Value <= 1 and CantGetUpCheck()) then

					RagdollTime.Value = RagdollTime.Value - 0.2
				end

				if RagdollTime.Value <= 0 and not endT then
					endT = tick()
				end

			until not CantGetUpCheck() 
				and (RagdollTime.Value <= 0 
					and not values.Grabbed.Value 
					and Humanoid:GetState() ~= Enum.HumanoidStateType.Dead 
					and Torso 
					and Torso.Parent 
					and (Torso.Velocity.Magnitude < 5 or (endT and tick() - endT > 3 and Torso.Velocity.Magnitude < 30)) and not WaterCheck()) 
				or (RagdollTime.Value <= 0 and tick() - sT > 180)

			Humanoid.PlatformStand = false
			RagdollSwitch.Value = false

			ragdollManaging = false
		end
	end)
	table.insert(conz,con1)

	local con2 = RagdollSwitch:GetPropertyChangedSignal("Value"):Connect(function(v)
		if Humanoid:GetState() ~= Enum.HumanoidStateType.Dead then
			Ragdoll(RagdollSwitch.Value)
		end
	end)
	table.insert(conz,con2)

	local con3 = Humanoid.HealthChanged:Connect(function(h)
		if Humanoid:GetState()==Enum.HumanoidStateType.Dead or (h<=0 and not Humanoid:GetAttribute("SecondStatus")) then
			Ragdoll(true)
			StopIt()
		end
	end)
	table.insert(conz,con3)

	local con4 = Humanoid.Changed:Connect(function(prop)
		if prop and prop == "Jump" and Ragdolling then
			Humanoid.Jump = false
		end
	end)
	table.insert(conz,con4)

	local con5 = Character.changed:Connect(function(x)
		if not Character or not Character.Parent then
			StopIt()
		end
	end)
	table.insert(conz,con5)

	for _,v in pairs(values.HealthValues:GetChildren()) do
		v.Broken.Changed:Connect(updateConstraints)
	end

	SortMotor6Ds()
	CreateColliders()
	CreateAttachments()
	pcall(CreateConstraints)

	Ragdoll(false,true)
end
return RagdollModule