-- SERVER

local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
--
local assets = game:GetService("ReplicatedStorage").PlantsStorage.Assets
local sounds = assets.Sounds.LootContainer.Dumpster
--
return {
	--
	loot = "Scrap",
	model = script.dumpster,
	poffset = Vector3.new(0, 1.75, -4),
	--
	regenerationTime = {720, 1200},
	maxItems = 15,
	minPower = 8,
	maxPower = 18,
	absoluteMaxPower = 224,
	--
	isTheft = false, -- Bit weird for dumpster diving though... 👶🏿
	cashBoost = -0.10, -- -10% Cash
	powerStartMultiplier = 0.6,
	powerTickEverySeconds = {75, 180},
	powerTickIncreaseRange = {4, 9},
	--
	onOpen = function(container, model)
		_G.PlaySound(sounds.open, model.pivot, math.random(90, 110)/100)
		local RInfo = TweenInfo.new()
		local LInfo = TweenInfo.new()
		local RAngle = math.random(65, 80)
		local LAngle = math.random(65, 80)
		local RCFrame = CFrame.new(0, 0.2, 3.175) * CFrame.Angles(math.rad(-RAngle), 0, 0)
		local LCFrame = CFrame.new(0, 0.2, 3.175) * CFrame.Angles(math.rad(-LAngle), 0, 0)
		framework.networking.toClients(nil, false, "Tween", {model.pivot.right_top, {0.45, Enum.EasingStyle.Sine,Enum.EasingDirection.Out, 0, false, _G.Random(0.03, 0.075, 1000)}, {C1 = RCFrame}})
		framework.networking.toClients(nil, false, "Tween", {model.pivot.left_top, {0.45, Enum.EasingStyle.Sine,Enum.EasingDirection.Out, 0, false, _G.Random(0.03, 0.075, 1000)}, {C1 = LCFrame}})
	end,
	--
	onClose = function(container, model)
		_G.PlaySound(sounds.open, model.pivot, math.random(80, 90)/100)
		_G.PlaySound(sounds.close, model.pivot, math.random(95, 105)/100, 0.325)
		local RCFrame = CFrame.new(0, 0.2, 3.175)
		local LCFrame = CFrame.new(0, 0.2, 3.175)
		framework.networking.toClients(nil, false, "Tween", {model.pivot.right_top, {0.35, Enum.EasingStyle.Sine,Enum.EasingDirection.In, 0, false, 0.03}, {C1 = RCFrame}})
		framework.networking.toClients(nil, false, "Tween", {model.pivot.left_top, {0.35, Enum.EasingStyle.Sine,Enum.EasingDirection.In, 0, false, 0.03}, {C1 = LCFrame}})
	end,
	--
}