return { -- grey crates
	
	["MaxItems"] = 2;
	["ReRollRate"] = 25;
	
	["StoredAmmo_TakePerc"] = {33,66}; -- Up to this % of the stored ammo can be taken
	["Ammo_TakePerc"] = {0,50}; -- Up to this % of the ammo can be taken
	
	--["AP_TakePerc"] = {33,66}; -- Up to this % of the armor AP can be taken
	
	["ItemsTable"] = {
		--["PumpkinHelmet"] = {
		--	Chance = 8;
		--	Weight = 55;
		--	IsHelmet = true;
		--	MaxDrops = 1;
		--};
		
		--["VestA_1"] = {
		--	Chance = 100;
		--	Weight = 65;
		--	IsVest = true;
		--};	
		
		
		--// guns 
		["Sawn-Off"] = {
			Chance = 3;
			Weight = 65;
			IsGun = true;
			MaxDrops = 1;
		};	
		
		["Beretta"] = {
			Chance = 3;
			Weight = 65;
			IsGun = true;
			MaxDrops = 1;
		};	

		["G-17"] = {
			Chance = 3;
			Weight = 65;
			IsGun = true;
			MaxDrops = 1;
		};

		["TEC-9"] = {
			Chance = 3;
			Weight = 65;
			IsGun = true;
			MaxDrops = 1;
		};

		["SKS"] = {
			Chance = 3;
			Weight = 100;
			IsGun = true;
			MaxDrops = 1;
		};

		["Uzi"] = {
			Chance = 2;
			Weight = 100;
			IsGun = true;
			MaxDrops = 1;
		};
		---------------------
		
		--v 83%
		--// melees
		
		["Bayonet"] = {
			Chance = 6;
			Weight = 35;
			MaxDrops = 1;
		};
		
		["Balisong"] = {
			Chance = 6;
			Weight = 35;
			MaxDrops = 1;
		};

		["Rambo"] = {
			Chance = 6;
			Weight = 35;
			MaxDrops = 1;
		};
		
		["Taiga"] = {
			Chance = 6;
			Weight = 55;
			MaxDrops = 1;
		};
		
		["Bat"] = {
			Chance = 6;
			Weight = 65;
			MaxDrops = 1;
		};
		
		["Shovel"] = {
			Chance = 6;
			Weight = 65;
			MaxDrops = 1;
		};
		
		["Crowbar"] = {
			Chance = 6;
			Weight = 65;
			MaxDrops = 1;
		};
		
		["Golfclub"] = {
			Chance = 6;
			Weight = 65;
			MaxDrops = 1;
		};

		["Fire-Axe"] = {
			Chance = 6;
			Weight = 100;
			MaxDrops = 1;
		};
		---------------------
		
		
		--// throwables
		
		["Molotov"] = {
			Chance = 6;
			Weight = 25;
		};
		["Smoke-Grenade"] = {
			Chance = 6;
			Weight = 25;
		};
		["Grenade"] = {
			Chance = 5;
			Weight = 25;
		};
		
		
		--["FireworkLauncher"] = {
		--	Chance = 0.5;
		--	Weight = 51;
		--	IsGun = true;
		--	MaxDrops = 1;
		--};
	};
}