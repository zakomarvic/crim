--34GKB8495GJNNJR44FV
RunService = game:GetService("RunService")

Player = game.Players.LocalPlayer

SpeedHeatMeter = script.Parent.SpeedHeatMeter
FlightHeatMeter = script.Parent.FlightHeatMeter
VelocityHeatMeter = script.Parent.VelocityHeatMeter

function Update()
	local Diagnostics =
		Player.Character and
		Player.Character:FindFirstChild("FJsMovementAnticheat")
	local SpeedHeat = Diagnostics and Diagnostics:FindFirstChild("SpeedHeat")
	local FlightHeat = Diagnostics and Diagnostics:FindFirstChild("FlightHeat")
	local VelocityHeat = Diagnostics and Diagnostics:FindFirstChild("VelocityHeat")
	local function doMeter(meter, progressSource)
		if progressSource ~= nil then
			local progress = math.max(0, math.min(progressSource.Value, 1))
			meter.Bar.Size = UDim2.new(progress, 0, 1, 0)
			meter.TextLabel.Text = math.ceil(progress * 100) .. "%"
		else
			meter.Bar.Size = UDim2.new(0, 0, 1, 0)
			meter.TextLabel.Text = "???"
		end
	end
	doMeter(SpeedHeatMeter, SpeedHeat)
	doMeter(FlightHeatMeter, FlightHeat)
	doMeter(VelocityHeatMeter, VelocityHeat)
end

RunService.RenderStepped:Connect(Update)
