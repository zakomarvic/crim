-- SERVER

local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
--
local assets = game:GetService("ReplicatedStorage").PlantsStorage.Assets
local sounds = assets.Sounds.LootContainer.WeaponsLocker
--
return {
	--
	loot = "WeaponsLocker",
	model = script:WaitForChild("weaponslocker"),
	poffset = Vector3.new(0, 1.5, -1.75),
	--
	regenerationTime = {1080, 1800},
	maxItems = 6,
	minPower = 16,
	maxPower = 42,
	absoluteMaxPower = 124,
	--
	isTheft = true,
	cashBoost = -0.10, -- -10% Cash
	powerStartMultiplier = 0.6,
	powerTickEverySeconds = {40, 75},
	powerTickIncreaseRange = {4, 12},
	--
	onOpen = function(container, model)
		_G.PlaySound(sounds.hinge, model.pivot, math.random(90, 110)/100)
		_G.PlaySound(sounds.open, model.pivot, math.random(90, 110)/100)
		local twninfo = TweenInfo.new(0.6, Enum.EasingStyle.Sine,Enum.EasingDirection.In, 0, false, 0.03)
		local RAngle = 105 + math.random(5, 20)
		local LAngle = 105 + math.random(5, 20)
		local RCFrame = CFrame.new(-1.692, 0.07, -0.699) * CFrame.Angles(0, math.rad(RAngle), 0)
		local LCFrame = CFrame.new(1.692, 0.07, -0.699) * CFrame.Angles(0, math.rad(-LAngle), 0)
		game:GetService("TweenService"):Create(model.base.rdoor, twninfo, {C0 = RCFrame}):Play()
		game:GetService("TweenService"):Create(model.base.ldoor, twninfo, {C0 = LCFrame}):Play()
	end,
	--
	onClose = function(container, model)
		_G.PlaySound(sounds.hinge, model.pivot, math.random(90, 110)/100)
		_G.PlaySound(sounds.close, model.pivot, math.random(90, 110)/100, 0.35)
		local twninfo = TweenInfo.new(0.375, Enum.EasingStyle.Sine,Enum.EasingDirection.In, 0, false, 0.03)
		local RCFrame = CFrame.new(-1.692, 0.07, -0.699)
		local LCFrame = CFrame.new(1.692, 0.07, -0.699)
		game:GetService("TweenService"):Create(model.base.rdoor, twninfo, {C0 = RCFrame}):Play()
		game:GetService("TweenService"):Create(model.base.ldoor, twninfo, {C0 = LCFrame}):Play()
	end,
	--
}