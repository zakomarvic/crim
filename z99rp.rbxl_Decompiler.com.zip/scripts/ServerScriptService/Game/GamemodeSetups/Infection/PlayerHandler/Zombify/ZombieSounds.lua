wait()

if script.Parent.Name == "Backpack" then
	script.Parent = script.Parent.Parent.Character
end

local char = script.Parent
local plr = game.Players:GetPlayerFromCharacter(char)

if char:FindFirstChild(script.Name) and char:FindFirstChild(script.Name) ~= script then script:Destroy() wait(100) end

if not (script.Parent and script:FindFirstChild("Sounds")) then
	return
end

local Head = char:WaitForChild("Head")
local Humanoid = char:WaitForChild("Humanoid")

local sounds = {}
local lSound
local lastHealth = Humanoid.Health
local ded = false

for _,v in pairs(Head:GetChildren()) do
	if v:FindFirstChild("Vocal") then
		v.PlaybackSpeed = 0
		v.Volume = 0
	end
end

for _,child in pairs(script.Sounds:GetChildren()) do
	local x = Head:FindFirstChild(child.Name)

	if x then x:Destroy() end

	sounds[child.Name] = child
	child.Parent = Head
end

function CancelSounds()
	for _,v in pairs(sounds) do
		if v and v.Parent then
			v:Stop()
		end
	end
end

function PlaySound(x,c)
	if sounds[x] then
		if lSound and lSound.Parent and c and (lSound.Name == "Pain1" or lSound.Name == "Pain2" or lSound.Name == "Pain3" or lSound.Name == "Pain4") and lSound.Playing then return end
		CancelSounds()
		lSound = sounds[x]
		lSound:Play()	
	end
end

Head.ChildAdded:Connect(function(c)
	wait()
	if c:IsA("Sound") then
		if c:FindFirstChild("Vocal") or c:FindFirstChild("Vocal2") then
			c.Volume = 0
		end
	end
end)

local c1

local function onDeath()
	ded = true
	c1:Disconnect()
	--hpCon:Disconnect()
	CancelSounds()
	PlaySound("ZDeath" .. math.random(1,6),true)
end

c1 = Humanoid.HealthChanged:Connect(function(h)
	if h > 0 and (h <= 10 or _G.DownedCheck(char)) then
		Humanoid:TakeDamage(100)
		Humanoid.Health = 0
		wait()
		Humanoid.Health = 0
		Humanoid:TakeDamage(100)
		
		onDeath()
	elseif h <= 0 then
	 	onDeath()
	end
end)

task.wait(0.5)

if Humanoid.Health > 0 and not Humanoid:GetAttribute("IsRagerInfected") then
	while Humanoid.Health > 0 do
		PlaySound("Growl" .. math.random(1,4),true)
		wait(math.random(5,20))
	end
end

