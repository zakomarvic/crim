-- CLIENT

local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
local system = {}
--
function system.getBounds(text, size, width, weight, style)
	local titleBoundParams = Instance.new("GetTextBoundsParams")
	titleBoundParams.Text = text
	titleBoundParams.Size = size
	titleBoundParams.Width = width
	titleBoundParams.Font = Font.new("rbxasset://fonts/families/Montserrat.json", weight or Enum.FontWeight.Bold, style or Enum.FontStyle.Normal)
	return game:GetService("TextService"):GetTextBoundsAsync(titleBoundParams)
end
--
function system.show(notification)
	local plantsGui = _G.PlantsGui
	local _n = {}
	--
	local header = notification.header or "NOTIFICATION"
	local titleBounds = system.getBounds(notification.header or "NOTIFICATION", 20, 200)
	--
	local size = UDim2.new(1, 0, 0, 20)
	local ui = plantsGui.Templates.Notification:Clone()
	ui.Main.header.Text = header
	ui.Main.header.Size = UDim2.new(1, 0, 0, titleBounds.Y)
	ui.Main.Size = UDim2.new(1, 0, 0, 10 + titleBounds.Y)
	size += UDim2.new(0, 0, 0, titleBounds.Y)
	--
	if (notification.message) then
		local message = notification.message
		local messageBounds = system.getBounds(message, 18, 200, Enum.FontWeight.Regular)
		ui.Main.message.Text = message
		ui.Main.message.Position = UDim2.new(0, 0, 0, 7 + titleBounds.Y)
		ui.Main.message.Size = UDim2.new(1, 0, 0, 1+messageBounds.Y)
		ui.Main.Size += UDim2.new(0, 0, 0, messageBounds.Y + 5)
		size += UDim2.new(0, 0, 0, messageBounds.Y + 5)
	end
	--
	if (notification.buttons) then
		ui.Main.buttonsDivider.Visible = true
		--
		local yf = math.ceil(#notification.buttons/2)
		ui.Main.Size += UDim2.new(0, 0, 0, yf*25)
		size += UDim2.new(0, 0, 0, yf*25)
		ui.Main.buttonsDivider.Position -= UDim2.new(0, 0, 0, 25 * (yf - 1))
		ui.Main.buttons.Size += UDim2.new(0, 0, 0, 25 * (yf - 1))
		--
		for bi, button in ipairs(notification.buttons) do
			--
			local bui = plantsGui.Templates.NotificationButton:Clone()
			bui.Parent = ui.Main.buttons
			bui.Visible = true
			bui.main.header.Text = (button.header or "BUTTON")
			local buibutton: TextButton = bui.main.button
			--
			buibutton.MouseEnter:Connect(function() 
				framework.services.TweenService:Create(bui.main, TweenInfo.new(0.3, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {BackgroundColor3 = Color3.fromRGB(70, 70, 70)}):Play()
				_G.PlayGuiSound("hover") end)
			buibutton.MouseLeave:Connect(function() 
				framework.services.TweenService:Create(bui.main, TweenInfo.new(0.3, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {BackgroundColor3 = Color3.fromRGB(25, 25, 25)}):Play() end)
			buibutton.MouseButton1Click:Connect(function() 
				if (not _n.clicked) then
					_n.clicked = true
					_G.PlayGuiSound("click")
					_n.selected:Fire(button.id or bi)
					_n.despawn()
				end
			end)
			--
			if (notification.buttons[bi+1] == nil and bi%2 ~= 0) then
				bui.Size = UDim2.new(1, 0, 0, 25)
			else
				bui.Size = UDim2.new(0.5, 0, 0, 25) 
			end
			--
		end
		--
	end
	--
	local info = TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0)
	ui.Visible = true
	ui.Parent = plantsGui.Notifications
	ui.Size = UDim2.new(1, 0, 0, 0)
	ui.Main.Position = UDim2.new(1, 150, 1, 0)
	framework.services.TweenService:Create(ui, info, {Size = size}):Play()
	framework.services.TweenService:Create(ui.Main, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0.1), {Position = UDim2.new(0, 0, 01, 0)}):Play()
	--
	if (notification.duration) then
		task.delay(notification.duration, function() 
			_n.despawn()
		end)
	end
	--
	_n.selected = framework.signal.new()
	_n.ui = ui
	_n.clicked = false
	_n.despawned = false
	_n.despawn = function()
		if (not _n.despawned) then
			_n.despawned = true
			framework.services.TweenService:Create(ui, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0.1), {Size = UDim2.new(1, 0, 0, 0)}):Play()
			framework.services.TweenService:Create(ui.Main, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {Position = UDim2.new(1, 150, 1, 0)}):Play()
			framework.Gs.SafeDestroy(_n.ui, 2)
		end
	end
	--
	return _n
end
--
_G.NotificationsSystem = system
return system