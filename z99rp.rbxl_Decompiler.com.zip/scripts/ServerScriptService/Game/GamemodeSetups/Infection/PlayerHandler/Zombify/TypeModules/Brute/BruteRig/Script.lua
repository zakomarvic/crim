local RigFolder = script.Parent
local Character = RigFolder.Parent

local Parts = RigFolder:WaitForChild("Parts")

_G.cTag(RigFolder,"CD")
_G.cTag(Parts,"CD")

function RigPartFolder(Part)
	local function FindInFolder(FindPart)
		for i,v in pairs(Parts:GetChildren()) do
			if v.Name == FindPart.Name then
				return v
			end
		end
	end
	local FolderToRig = FindInFolder(Part)
	if FolderToRig ~= nil and FolderToRig:FindFirstChild("OriginPart") then
		for i,RigPart in pairs(FolderToRig:GetDescendants()) do
			if RigPart:IsA("BasePart") and RigPart.Name ~= "OriginPart" then
				local Weld = Instance.new("Weld")
				Weld.Name = RigPart.Name .. "_Weld"
				Weld.Part0,Weld.Part1 = Part,RigPart

				Weld.C0 = FolderToRig["OriginPart"].CFrame:Inverse()
				Weld.C1 = RigPart.CFrame:Inverse()

				Weld.Parent = RigPart

				--delay(1,function()
				RigPart.Anchored = false
				RigPart.Massless = true
				RigPart.CanCollide = false
				--end)
				--wait()
			end
		end
	end
end

function Rig()
	for i,cpart in pairs(Character:GetChildren()) do
		if cpart:IsA("BasePart") then
			RigPartFolder(cpart)
		end
	end	
end

Rig()

for i,v in pairs(RigFolder:GetDescendants()) do
	if v.Name == "OriginPart" then
		v:Destroy()
	end
end

game.Debris:AddItem(script,0.2)