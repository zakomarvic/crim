local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local TS = game:GetService("TweenService")
local MemoryStoreService = game:GetService("MemoryStoreService")
local DatastoreService = game:GetService("DataStoreService")
local MarketplaceService = game:GetService("MarketplaceService")

local M = {}
M.__index = M

local PlayerbaseData = ServerStorage:WaitForChild("PlayerbaseData")
local PlayerbaseData2 = ReplicatedStorage:WaitForChild("PlayerbaseData2")

local purchaseHistoryStore = DatastoreService:GetDataStore("PurchaseHistory")

local logRemote = ServerStorage.Events3:WaitForChild("OLGR")

local IS_STUDIO = RunService:IsStudio()

local function ProcessReceiptFunc(receiptInfo)
	-- Determine if the product was already granted by checking the data store  
	
	if not M.IsSetUp then
		return Enum.ProductPurchaseDecision.NotProcessedYet
	end
	
	--print("prf",1,receiptInfo)

	local playerProductKey = receiptInfo.PlayerId .. "_" .. receiptInfo.PurchaseId
	local purchased = false
	local success, errorMessage = pcall(function()
		purchased = purchaseHistoryStore:GetAsync(playerProductKey)
	end)
	
	--print("prf",2)
	
	-- If purchase was recorded, the product was already granted
	if success and purchased and receiptInfo.PlayerId > 1 then
		return Enum.ProductPurchaseDecision.PurchaseGranted
	elseif not success and receiptInfo.PlayerId > 1 then
		error("Data store error:" .. errorMessage)
	end
	
	--print("prf",3)

	local player = (receiptInfo.PlayerId > 1 and Players:FindFirstChild(Players:GetNameFromUserIdAsync(receiptInfo.PlayerId))) or Players:GetPlayers()[1]

	if not player then
		-- The player probably left the game
		-- If they come back, the callback will be called again
		--print("prf",4)
		return Enum.ProductPurchaseDecision.NotProcessedYet
	end
	
	--print("prf",5)

	local pd = PlayerbaseData and PlayerbaseData.Parent and PlayerbaseData:FindFirstChild(player.Name)
	local pd2 = PlayerbaseData2 and PlayerbaseData2.Parent and PlayerbaseData2:FindFirstChild(player.Name)

	if not (pd) then
		return Enum.ProductPurchaseDecision.NotProcessedYet
	end
	
	--print("prf",6)

	local id = receiptInfo.ProductId

	local productName = M.CurrentSelf.ProductIds[id]

	if not productName then return Enum.ProductPurchaseDecision.NotProcessedYet end
	
	--print("prf",7)

	local x,x2 = false,"N/A"
	
	local tokenBought = nil
	local tokenBoughtText = nil
	
	--print(productName)
	
	if productName == "infection_cash" then
		--db:AddMoney("Bank",10000,true)
		
		if M.CurrentSelf.Config.BuyCash and M.CurrentSelf.Config.BuyCash.Enabled then
			x = true
			
			local n = player:GetAttribute("CashCap") or M.CurrentSelf.Config.CashCap
			
			if n < 30000 then
				n = math.min(n + M.CurrentSelf.Config.BuyCash.Amount,20000)
			end	
			
			player:SetAttribute("CashCap",n)

			local tab = {
				Title = "Cash Purchased";
				Text = "Single-use | Only available in this gamemode and expires 5 mins after leaving.";
				Duration = 60;
				Button1 = "Close";
			}
			ReplicatedStorage.Events.Notification:FireClient(player,tab,"purchase")

			ServerStorage.Events3.nMonee:Fire("IU3898EJKLOY89TYZJDKLJGYI390WKHJSDHG9UKLJLEDGKLJERG9U",player,"Cash",M.CurrentSelf.Config.BuyCash.Amount)
		end
	elseif productName == "juggernaut" then
		x = true
		tokenBought = "Juggernaut"
	elseif productName == "uts-15" then
		x = true
		tokenBoughtText = "UTS-15"
		tokenBought = "UTS_15"
	elseif productName == "ray_gun" then
		x = true
		tokenBoughtText = "Ray Gun"
		tokenBought = "RayGun"
	elseif productName == "precision_strike" then
		x = true
		tokenBoughtText = "Precision Strike"
		tokenBought = "PrecisionStrike"
	elseif productName == "become_hunter" then
		x = true
		tokenBoughtText = "Become Hunter"
		tokenBought = "BecomeHunter"
	elseif productName == "become_brute" then
		x = true
		tokenBoughtText = "Become Brute"
		tokenBought = "BecomeBrute"
	elseif productName == "become_spitter" then
		x = true
		tokenBoughtText = "Become Spitter"
		tokenBought = "BecomeSpitter"
	end
	
	warn("PRODUCTPURCHASE:",player,productName,x,tokenBought)

	if not x then
		return Enum.ProductPurchaseDecision.NotProcessedYet
	else
		if tokenBought then
			local result = M.GrantToken(M.CurrentSelf,player,tokenBought)
			if not result then
				return Enum.ProductPurchaseDecision.NotProcessedYet
			else
				local tab = {
					Title = "Token Purchased";
					Text = "Single-use '" .. (tokenBoughtText or tostring(tokenBought)) .. "' Token has been successfully purchased!";
					Duration = 60;
					Button1 = "Close";
				}
				ReplicatedStorage.Events.Notification:FireClient(player,tab,"purchase")
			end
		end

	end
	
	if x then
		M.AddRobuxSpent(M.CurrentSelf,player,id)
	end

	-- Record transaction in data store so it isn't granted again

	if not IS_STUDIO and receiptInfo.PlayerId > 1 then
		local success, errorMessage = pcall(function()
			purchaseHistoryStore:SetAsync(playerProductKey, true)
		end)
		if not success then
			error("Cannot save purchase data: " .. errorMessage)
		end
	end

	-- IMPORTANT: Tell Roblox that the game successfully handled the purchase
	return Enum.ProductPurchaseDecision.PurchaseGranted
end

function M:AddRobuxSpent(player,productID)
	local data = self.activePlayers[player]

	if data and data.SaveData and data.SaveData.OtherStats then
		if not data.SaveData.OtherStats.RobuxSpent then
			data.SaveData.OtherStats.RobuxSpent = 0
		end
		
		local _s,_e = pcall(function()
			local info = MarketplaceService:GetProductInfo(productID,Enum.InfoType.Product)
			
			if info then
				data.SaveData.OtherStats.RobuxSpent += math.floor(info.PriceInRobux)
			end
		end)
		
		if not _s then
			warn("AddRobuxSpent error:",player,_e)
		end
	end
end

function M:GrantToken(player,tokenName,doNegative)
	if not (player and player.Parent) then return end

	local data = self.activePlayers[player]

	if data and data.SaveData and data.SaveData.Tokens[tokenName] then
		data.DataChanged = true

		if doNegative then
			data.SaveData.Tokens[tokenName] = math.max(data.SaveData.Tokens[tokenName] - 1,0)
			
			if data.SaveData.GiftedTokens[tokenName] and data.SaveData.GiftedTokens[tokenName] > 0 then
				print("removed gifted token count from",player)
				data.SaveData.GiftedTokens[tokenName] = math.max(data.SaveData.GiftedTokens[tokenName] - 1,0)
			end
			--print("used token",player)
		else
			data.SaveData.Tokens[tokenName] += 1
			--print("gave token",player)
		end

		self.activePlayers[player] = data
		M.PlayerHandler.UpdateActivePlayer(self,player)
		
		ReplicatedStorage.Events.ShopEvent:FireClient(player,"Refresh")
		
		if doNegative then
			warn("took/used token:",tokenName,player)
		else
			warn("granted token:",tokenName,player)
		end
		
		self.I.eventsFolder.GotTokenData:FireClient(player,M.GetTokenClientData(self,player))
		
		return true
	end
	return false
end

function M:GetTokenClientData(player)
	local data = self.activePlayers[player]
	
	if not data then
		return {}
	end
	
	local saveData = data.SaveData
	if not saveData then
		return {}
	end
	
	local t = {}
	
	for i,v in pairs(saveData.Tokens) do
		local tokenConfig = self.Config.TokenContent[i]
		if tokenConfig then
			t[i] = {
				Name = tokenConfig.Title or i;
				Amount = tonumber(v) or 0;
				ProductID = tokenConfig.ProductID;
				LO = tokenConfig.OrderNum or 1000;
			};
		end
	end
	
	return t
end

function M.new(self)
	if M.IsSetUp then return end
	M.IsSetUp = true
	
	M.CurrentSelf = self
	
	self.ProductIds = {}
	
	M.PlayerHandler = require(script.Parent.PlayerHandler)
	
	M.TokenHandlerMs = {}
	
	if not self.isVipServer then
		for i,v in pairs(script.TokenHandlers:GetChildren()) do
			local x = require(v)
			x.new(self)
			M.TokenHandlerMs[v.Name] = x
		end
	end
	--print("juggernaut try setupo")

	if self.Config.BuyCash and self.Config.BuyCash.Enabled and not self.isVipServer then
		--print("buy cash enabled")

		self.BuyCashEnabled = true
		
		self.I.valuesFolder.CanBuyCash.ID.Value = self.Config.BuyCash.ProductID
		self.I.valuesFolder.CanBuyCash.Amount.Value = self.Config.BuyCash.Amount
		
		self.I.valuesFolder.CanBuyCash.Value = true
		self.ProductIds[self.Config.BuyCash.ProductID] = "infection_cash"
		
		local function UpdatePrice()
			local info 

			pcall(function()
				info = MarketplaceService:GetProductInfo(self.Config.BuyCash.ProductID, Enum.InfoType.Product)
			end)
			
			if info then
				self.I.valuesFolder.CanBuyCash.Price.Value = info.PriceInRobux
			end
		end
		
		UpdatePrice()
		
		spawn(function()
			while wait(60) do
				UpdatePrice()
			end
		end)
	end
	
	self.I.eventsFolder.GetTokenData.OnServerInvoke = function(plr)
		if self.isVipServer then
			return
		end
		
		return M.GetTokenClientData(self,plr)
	end
	
	self.I.eventsFolder.GiftToken.OnServerInvoke = function(plr,tokenType,giftPlr)
		if self.isVipServer then
			return
		end
		--print(111)
		
		if ReplicatedStorage.Values.ShuttingDown.Value then
			return
		end
		
		local saveData = self.activePlayers[plr].SaveData
		if not saveData then
			return
		end
		--print(222)
		
		if typeof(tokenType) ~= "string" then return end
		
		--print(333)
		
		local tokenConfig = self.Config.TokenContent[tokenType]
		
		if not tokenConfig or not tokenConfig.Enabled then
			return
		end
		
		if not saveData.Tokens[tokenType] or saveData.Tokens[tokenType] <= 0 then
			return
		end
		--print(444)
		
		if typeof(giftPlr) ~= "Instance" or giftPlr.ClassName ~= "Player" then return end
		--print(555)
		if not giftPlr:GetAttribute("InfectionLoaded") or giftPlr:GetAttribute("IsSavingInfectionData") then return end
		
		if giftPlr == plr then
			return
		end
		
		if saveData.GiftedTokens and saveData.GiftedTokens[tokenType] and saveData.GiftedTokens[tokenType] >= saveData.Tokens[tokenType] then
			pcall(function()
				local tab = {
					Title = "Gifting Error";
					Text = "Cannot gift pre-gifted Tokens!";
					Duration = 60;
					Button1 = "Close";
				}
				ReplicatedStorage.Events.Notification:FireClient(plr,tab,"error")
			end)
			return false
		elseif saveData.Tokens and saveData.Tokens[tokenType] >= 3 then
			pcall(function()
				local tab = {
					Title = "Gifting Error";
					Text = "Chosen player is at the max tokens for this token type!";
					Duration = 60;
					Button1 = "Close";
				}
				ReplicatedStorage.Events.Notification:FireClient(plr,tab,"error")
			end)
			return false
		end
		
		--print(666)
		local result1 = M.GrantToken(self,plr,tokenType,true)
		
		--print(777)
		
		if result1 then
			--print(888)
			local result2 = M.GrantToken(self,giftPlr,tokenType)
			
			--print(999)
			if result2 then
				
				pcall(function()
					local tab = {
						Title = "Token Received";
						Text = "You were gifted a '" .. (tokenConfig.Title or tostring(tokenType)) .. "' Token from @" .. plr.Name .. "!";
						Duration = 600;
						Button1 = "Close";
					}
					ReplicatedStorage.Events.Notification:FireClient(giftPlr,tab,"allowance")
				end)
				pcall(function()
					local tab = {
						Title = "Token Gifted";
						Text = "'" .. (tokenConfig.Title or tostring(tokenType)) .. "' Token successfully gifted to @" .. giftPlr.Name .. "!";
						Duration = 60;
						Button1 = "Close";
					}
					ReplicatedStorage.Events.Notification:FireClient(plr,tab,"purchase")
				end)
				
				local gSaveData = self.activePlayers[giftPlr].SaveData
				
				if gSaveData then
					if not gSaveData.GiftedTokens[tokenType] then 
						gSaveData.GiftedTokens[tokenType] = 0
					end
					gSaveData.GiftedTokens[tokenType] += 1
					
					self.activePlayers[giftPlr].SaveData = gSaveData
				end
				
				return true, M.GetTokenClientData(self,plr)
			end
		end
	end
	
	ReplicatedStorage.Events.AttemptClaimShopProduct.OnServerInvoke = function(plr,arg)
		if not self.activePlayers[plr] then return end
		if self.isVipServer then
			return
		end
		
		if arg == "UTS-S" then
			arg = "UTS_15"
		end
		
		if not M.TokenHandlerMs[arg] then
			return
		end
		
		local saveData = self.activePlayers[plr].SaveData
		if not saveData then
			return
		end
		
		if not saveData.Tokens[arg] then
			return
		elseif saveData.Tokens[arg] <=0 then
			return
		end
		
		local result = M.TokenHandlerMs[arg].Grant(M.CurrentSelf,plr,arg)
		
		if result then
			result = M.GrantToken(M.CurrentSelf,plr,arg,true)
		else
			pcall(function()
				local tab = {
					Title = "Token Use Unavailable";
					Text = "Unable to use '" .. arg .. "' Token at this time.";
					Duration = 600;
					Button1 = "Close";
				}

				ReplicatedStorage.Events.Notification:FireClient(plr,tab,"Beep2")	
			end)
		end
		
		return (result and true) or false
	end
	
	self.I.eventsFolder.GrantToken.Event:Connect(function(plr,tokenName)
		if not self.activePlayers[plr] then return end
		
		if self.activePlayers[plr].SaveData.Tokens[tokenName] and self.activePlayers[plr].SaveData.Tokens[tokenName] < 3 then
			local result = M.GrantToken(M.CurrentSelf,plr,tokenName)
			
			if result then
				pcall(function()
					local tab = {
						Title = "Token Grant";
						Text = "You were manually granted a '" .. tostring(tokenName) .. "' Token!";
						Duration = 600;
						Button1 = "Close";
					}

					ReplicatedStorage.Events.Notification:FireClient(plr,tab,"BEEP")	
				end)
			end
		end
	end)
	
	if not self.isVipServer then
		MarketplaceService.ProcessReceipt = ProcessReceiptFunc
	else
		MarketplaceService.ProcessReceipt = function()
			
		end
	end

	ServerStorage.Events3.RESTOCK:Fire("LPKRGF90T430WFLPDS")
end

return M