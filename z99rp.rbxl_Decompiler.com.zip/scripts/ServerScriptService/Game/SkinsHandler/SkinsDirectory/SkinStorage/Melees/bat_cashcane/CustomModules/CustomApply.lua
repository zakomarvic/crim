
return function(model)
	if model.ClassName == "Tool" then

		
		model.WeaponHandle:FindFirstChild("BatStuff"):Destroy()
		
		local mesh = script.papu:Clone()
		mesh.Parent = model.WeaponHandle
		mesh.Weld.Part1 = model.WeaponHandle
		

	end
	return true
end