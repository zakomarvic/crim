local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local TS = game:GetService("TweenService")

local M = {}
M.__index = M

function M:Grant(player)
	local char = player.Character
	local hum = char and char:FindFirstChild("Humanoid")
	
	local stock = ReplicatedStorage.Values.GlobalStocks.CurrentStocks["RayGun"]
	
	--print("trying jugg...")
	
	local result
	local _s,_e = pcall(function()
		if char and hum and hum.Health > 0 and stock.Value > 0 and self.buyZonesV.Value and player.Team == self.teams.Survivors then
			stock.Value = 0
			--print("got1")
			
			self.purchasedTokenContent["RayGun"] = player

			local uts = ServerStorage.Tools["RayGun"]:Clone()
			
			uts:SetAttribute("CantDrop",true)
			uts:SetAttribute("CantSell",true)
			uts:SetAttribute("DisableBulletTypeChange",true)
			
			uts:SetAttribute("OneTimeUseWep",true)
			
			char:SetAttribute("Shop_HasGun",true)
			
			uts.Parent = player.Backpack
			
			local tab = {
				Title = "Ray Gun Purchased";
				Text = "Single use - Exiting server or dying will result in loss.";
				Duration = 60;
				Button1 = "Close";
			}
			ReplicatedStorage.Events.Notification:FireClient(player,tab,"purchase")	
			
			player:SetAttribute("TokenInUse_RayGun",true)
			--char:SetAttribute("NoRandomInfectChoose",true)
			--char:SetAttribute("BridgeSetRespawn",true)

			self.activePlayers[player].DataChanged = true
			
			local con1,con2,con3
			
			local function DoRefundCheck()
				if  	(
						self.I.values.mode.Value == "commencing"
							or self.I.values.mode.Value == "game"
							or self.I.values.mode.Value == "prepare"
							or self.I.values.mode.Value == "intermission"
					)
						and player:GetAttribute("TokenInUse_UTS15")
				then
					if not ReplicatedStorage.Values.ShuttingDown.Value 
						and _G.InCombatCheck(player,true)
					then
						return
					else
						player:SetAttribute("TokenInUse_RayGun",nil)
						M.PurchaseHandler.GrantToken(self,player,"RayGun")
						

						if player and player.Parent then
							local tab = {
								Title = "Token Refunded";
								Text = "'Ray Gun' token refunded.";
								Duration = 60;
								Button1 = "Close";
							}
							ReplicatedStorage.Events.Notification:FireClient(player,tab,"BEEP")	
						end
					end
				end
			end
			
			local function Disconnect(doCheck)
				if con1 then
					con1:Disconnect()
					con1 = nil
				end
				if con2 then
					con2:Disconnect()
					con2 = nil
				end
				if con3 then
					con3:Disconnect()
					con3 = nil
				end
				
				if doCheck then
					DoRefundCheck()
				end
			end
			
			con1 = player:GetAttributeChangedSignal("InfectionLeaving"):Connect(function()
				Disconnect(true)
			end)
			
			con2 = char.AncestryChanged:Connect(function(_,parent)
				if not parent then
					con2:Disconnect()
					
					task.wait(0.2)
					
					if not ReplicatedStorage.Values.ShuttingDown.Value then
						player:SetAttribute("TokenInUse_RayGun",nil)
					end
					Disconnect()
				end
			end)
			
			con3 = ReplicatedStorage.Values.ShuttingDown.Changed:Connect(function()
				Disconnect(true)
			end)
			
			hum.Died:Connect(function()
				if not ReplicatedStorage.Values.ShuttingDown.Value then
					player:SetAttribute("TokenInUse_RayGun",nil)
				end	
			end)
			
			local c
			c = hum:GetAttributeChangedSignal("WasZombified"):Connect(function()
				c:Disconnect()
				
				player:SetAttribute("TokenInUse_RayGun",nil)
				self.purchasedTokenContent["RayGun"] = nil
				
				M.PurchaseHandler.GrantToken(self,player,"RayGun")
				
				local tab = {
					Title = "Token Refunded";
					Text = "'Ray Gun' token refunded.";
					Duration = 60;
					Button1 = "Close";
				}
				ReplicatedStorage.Events.Notification:FireClient(player,tab,"BEEP")	
				
				Disconnect()
			end)

			result = true
		end
	end)
	
	if not _s then
		warn("UTS Spawn Error Error:",_e)
		return false
	end
	
	return result
end

function M.new(self)
	if M.IsSetUp then return end
	M.IsSetUp = true
	
	M.CurrentSelf = self
	
	M.PlayerHandler = require(script.Parent.Parent.Parent.PlayerHandler)
	M.PurchaseHandler = require(script.Parent.Parent.Parent.PurchaseHandler)
	
	if self.Config.TokenContent.RayGun and self.Config.TokenContent.RayGun.Enabled then
		--print("Yeah enabled")
		
		self.UTS_15_Enabled = true
		
		local j_is = ReplicatedStorage.Storage.ItemStats.Guns["RayGun"]
		j_is.IsDevProduct.ID.Value = self.Config.TokenContent.RayGun.ProductID
		j_is.ForSale.Value = true
		j_is.MaxStock.Value = 1
		j_is.MinStock.Value = 1
		
		self.ProductIds[self.Config.TokenContent.RayGun.ProductID] = "ray_gun"
	end
end

return M