local Attachment = script.Parent

Attachment.Orientation = Vector3.new(math.random(-10,10),math.random(-10,10),math.random(-10,10))
local boomEmitter = Attachment:FindFirstChild("ExplosionEmitter"):Clone()
boomEmitter.Size = NumberSequence.new(
	{
	NumberSequenceKeypoint.new(0,0),
	NumberSequenceKeypoint.new(0.25,15),
	NumberSequenceKeypoint.new(1,26)
	}
)
boomEmitter.Parent = Attachment
boomEmitter:Emit(35)

Attachment.Smoke:Emit(75)

--local debrisEmitter = Attachment:FindFirstChild("DebrisEmitter"):Clone()
--debrisEmitter.Size = NumberSequence.new(20, 0)
--debrisEmitter.Parent = Attachment
--debrisEmitter:Emit(50)

local explosionRing = Attachment:FindFirstChild("ExplosionRing"):Clone()
explosionRing.Parent = Attachment
explosionRing:Emit(100)

Attachment:FindFirstChild("Shockwave").Size = NumberSequence.new(0, 50)
Attachment:FindFirstChild("Shockwave"):Emit(1)
