local TS = game:GetService("TweenService")

local MorsecodeHandler = {}
local MORSE_CODE_DICT = require(script.MorseDictionary)
local SPEED_MULTI = 1

function MorsecodeHandler:Do(t,removeTime,speedMulti,finishSound,onFinishFunc)
	SPEED_MULTI = speedMulti or 1
	removeTime = removeTime or 1
	
	local label = script.TextLabel:Clone()
	game.Debris:AddItem(label,removeTime + 20)
	
	label.Text = ""
	label.Parent = self.gui

	for i,letter in pairs(string.split(t.Text,"")) do
		local ld = MORSE_CODE_DICT[string.upper(letter)]
		if ld then
			if i > 1 then
				label.Text = label.Text .. " "
			end
			label.Text = label.Text .. ld
			for _,t in pairs(string.split(ld,"")) do
				if t == "-" then
					local s = script.beep:Clone()
					s.Parent = self.gui
					game.Debris:AddItem(s,1)
					s:Play()
					
					task.wait(0.25 / SPEED_MULTI)
				else
					local s = script.beep:Clone()
					s.Parent = self.gui
					game.Debris:AddItem(s,1)
					s:Play()
					coroutine.wrap(function()
						task.wait(0.05)
						s:Destroy()
					end)()
					
					if ld == "." then
						task.wait(0.15 / SPEED_MULTI)
					else
						task.wait(0.1 / SPEED_MULTI)
					end
					
				end
			end
			task.wait(0.1 / SPEED_MULTI)
		end
		if letter == " " then
			label.Text = label.Text .. " /"
			task.wait(0.25 / SPEED_MULTI)
		end
	end
	
	if finishSound and self.uiSounds:FindFirstChild(finishSound) then
		self.uiSounds[finishSound]:Play()
	end
	
	label.TextSize = 65
	local font = label.FontFace
	label.FontFace = Font.new(font.Family, Enum.FontWeight.Regular, font.Style)
	for i,v in pairs(t) do
		if i ~= "Text" then
			label[i] = v
		end
	end
	
	label.Text = t.Text
	
	if onFinishFunc then
		onFinishFunc()
	end
	
	task.wait(removeTime)
	
	TS:Create(label,TweenInfo.new(1,Enum.EasingStyle.Sine,Enum.EasingDirection.In),{TextTransparency = 1;TextStrokeTransparency = 1}):Play()
	
	task.wait(1)
	
	label:Destroy()
end

return MorsecodeHandler