
repeat wait()
	
until script.Target ~= nil

local mog = script.Parent
local char = script.Parent.Parent.Parent
local moggedtarget = mog.Parent.MogTarget
local ts = game:GetService("TweenService")
local letters = script.Parent.letters:GetChildren()

mog.CFrame = char.CFrame
print(char.Name)
mog.Rotation = Vector3.new(math.random(-360,360),math.random(-360,360),math.random(-360,360))
local alig1 = Instance.new("AlignPosition",mog)
local alig2 = Instance.new("AlignOrientation",mog)

alig1.Attachment0 = mog.to
alig2.Attachment0 = mog.to
alig1.Attachment1 = moggedtarget.mog
alig2.Attachment1 = moggedtarget.mog
alig1.Responsiveness = 5
alig2.Responsiveness = 5
mog.Anchored = false

--mog.music:Play()
ts:Create(mog,TweenInfo.new(1.7,Enum.EasingStyle.Linear,Enum.EasingDirection.InOut),{Size = mog.Parent.MogTarget.Size}):Play()
wait(1.7)
print("mogg")
mog.Fire:Emit(200)
--mog.spawn:Play()
wait(0.1)
for i,v in pairs(mog.welds:GetChildren()) do
	v.Part0 = mog
end
for i,v in pairs(letters) do
	v.Transparency = 0
end
for i,v in pairs(mog:GetChildren()) do
	if v:IsA("ParticleEmitter") and v.Name ~= "Fire" then
		v.Enabled = true
	end
end
mog.PointLight.Range = 8
wait(2)
for i,v in pairs(mog:GetChildren()) do
	if v:IsA("ParticleEmitter") and v.Name ~= "Fire" then
		v.Enabled = false
	end
end
for i,v in pairs(letters) do
	ts:Create(v,TweenInfo.new(1,Enum.EasingStyle.Linear,Enum.EasingDirection.InOut),{Transparency = 1}):Play()

end
ts:Create(mog.PointLight,TweenInfo.new(1,Enum.EasingStyle.Linear,Enum.EasingDirection.InOut),{Range = 1}):Play()

wait(1)
ts:Create(mog,TweenInfo.new(0.5,Enum.EasingStyle.Quad,Enum.EasingDirection.InOut),{Size = Vector3.new(0,0,0)}):Play()
wait(2)
moggedtarget:Destroy()
mog:Destroy()






