-- SERVER

local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
--
local exceptions = require(script:WaitForChild("Exceptions"))
local trelloAPI = require(script.Parent.Parent.Resources.TrelloAPI)
local whitelist = {cache = {}, ready = false}
--
local function retryingCall(call, retries, ...)
	retries = (retries == nil and 0) or retries
	--
	local stuff = table.pack(...)
	local succ, ret = pcall(function() 
		return call(table.unpack(stuff))
	end)
	--
	if (not succ or ret == false) then
		retries +=1
		task.wait((retries%5 == 0 and 3) or 0.5)
		return retryingCall(call, retries, ...)
	else
		return ret
	end
	--
end
--
function whitelist.kick_chud(chud: Player, reason: string)
	local message = "\nSlimeatron 9000:\n".. reason
	chud:Kick(message)
end
--
function whitelist.init()
	framework.Gs.Put("Whitelist initiated!", "WHITELIST")
	_G.PTempWhitelist = {}
	whitelist.obtainWhitelist()
	--
	local function checkPlayer(player: Player)
		-- Bans
		
		if (not _G.PTempWhitelist[player.Name] and exceptions[player.Name] ~= 1) then
			-- Account Age
			
			if player.AccountAge<100 and not game:GetService("RunService"):IsStudio() then
				whitelist.kick_chud(player, "Account not old enough.")
				return
			end
			--
		end
		-- Whitelist
		
		if (game:GetService("ReplicatedStorage").Values.WhitelistEnabled.Value) then
			task.spawn(function() 
				local isWhitelisted = false
				local isPrivateServer = (game.PrivateServerId ~=  "" and game.PrivateServerOwnerId ~= 0 and true) or false
				--
				if (not game:GetService("RunService"):IsStudio() or script:GetAttribute("VerifyWhitelistInStudio")) then
					--
					if (not whitelist.ready) then
						repeat task.wait() until whitelist.ready
						task.wait(1)
					end
					--
					local isTempWhitelisted = (_G.PTempWhitelist[player.Name] == true and true) or false
					local tag = player.Name.."_".. tostring(player.UserId)
					--
					if (script:GetAttribute("IgnoreFirstRules") ~= true) and (isTempWhitelisted or player.UserId == game.CreatorId or _G.permissions.users[player.Name] ~= nil or framework.services.RunService:IsStudio()) then
						player:SetAttribute("WhitelistVerified", true)
						isWhitelisted = true
					else
						--
						if (whitelist.cache[tag] ~= nil or isTempWhitelisted) then
							local player_cache = whitelist.cache[tag]
							--
							if (not player_cache.allowed) then
								player:SetAttribute("NotAllowedIngame", true)
								whitelist.kick_chud(player, "no")
							else
								player:SetAttribute("WhitelistVerified", true)
								player:SetAttribute("DiscUser", (tonumber(player_cache.discorduser) ~= nil and tostring(player_cache.discorduser)) or nil)
								isWhitelisted = true
							end
							--
						else
							player:SetAttribute("NotAllowedIngame", true)
							whitelist.kick_chud(player, "Boi leave.")
						end
					end
				else
					player:SetAttribute("WhitelistVerified", true)
					isWhitelisted = true
				end
				--
				if (_G.JoinTrackLogs == nil) then _G.JoinTrackLogs = {} end
				if (_G.JoinTrackLogs[player.Name] == nil) then
					_G.JoinTrackLogs[player.Name] = {-os.clock(), 1}
				else
					_G.JoinTrackLogs[player.Name][2] += 1
				end
				--
				if (_G.JoinTrackLogs[player.Name] == nil or (os.clock() - _G.JoinTrackLogs[player.Name][1]) >= 30) then
					pcall(function() 
						--
						local date = os.date("!*t")
						local hour = (date.hour - 5) % 24 -- the -5 is to convert to EST since the og is UTC
						local timestamp = string.format("%02i:%02i", hour, date.min)
						local fulldate = date.month.."/"..date.day.."/"..date.year..", ".. timestamp
						--
						local data = {
							["content"] = (isWhitelisted and "join log") or "some nr tried joining that isn't whitelisted",
							["embeds"] = {{
								["title"] = player.Name.. ' ('.. tostring(player.UserId)..')',
								["fields"] = {
									--
									{
										["name"] = "Is Whitelisted";
										["value"] = tostring(isWhitelisted);
										["inline"] = true;
									},
									--
									{
										["name"] = "Was Private Server";
										["value"] = tostring(isPrivateServer);
										["inline"] = true;
									}	,	
									--
									{
										["name"] = "Join Count";
										["value"] = tostring(_G.JoinTrackLogs[player.Name][2]);
										["inline"] = true;
									}		,
									--
									{
										["name"] = "Timestamp";
										["value"] = fulldate;
										["inline"] = false;
									}		,
									--
								}
							}}
						}
						--
						if (not game:GetService("RunService"):IsStudio() or script:GetAttribute("LogJoinsInStudio")) then
							framework.Gs.Put("Join Log posted for ".. player.Name.."!", "WHITELIST")
							game:GetService("HttpService"):PostAsync("https://webhook.lewisakura.moe/api/webhooks/1325884313715216404/zN4wvRG8pbVGFULhuvNULx1i1VdTW5ak0p7bqjKiNbchfkTBgfbHYQQDMwgHVFOrisRv", data)
						end
						--
					end)
				end
				--
			end)
		else
			player:SetAttribute("WhitelistVerified", true)
		end
	end
	--
	game.Players.PlayerAdded:Connect(checkPlayer)
	for _, plr in ipairs(game.Players:GetChildren()) do
		checkPlayer(plr) end
	--
	game:GetService("ReplicatedStorage").Values.WhitelistEnabled.Changed:Connect(function(n) 
		if (n) then
			for _, plr in ipairs(game.Players:GetChildren()) do
				checkPlayer(plr) end end end)
	--
end
--
function whitelist.obtainWhitelist()
	whitelist.ready = false
	whitelist.cache = {}
	--
	if (not framework.services.RunService:IsStudio() or script:GetAttribute("ObtainWhitelistInStudio")) then
		--
		local playersBoard = "6727a34674bcd8ae0f32ce6d"
		local specialCardsList = "6727a37de047e094c052cce3"
		local whitelistedCardsList = "6727a381e02137389f248791"
		local bannedCardsList = "6727a384459aab83fc36828b"
		local blacklistedCardsList = "6727a38af634e56157805dcd"
		--
		local special = retryingCall(trelloAPI.CardsAPI.GetCardsOnList, 0, specialCardsList)
		local whitelisted = retryingCall(trelloAPI.CardsAPI.GetCardsOnList, 0, whitelistedCardsList)
		local banned = retryingCall(trelloAPI.CardsAPI.GetCardsOnList, 0, bannedCardsList)
		local blacklisted = retryingCall(trelloAPI.CardsAPI.GetCardsOnList, 0, blacklistedCardsList)
		--
		local function validateCard(card)
			local nsplit = string.split(card.name, " - ")
			local name = nsplit[1]
			local userid = tonumber(nsplit[2])
			local listid = card.idList
			--
			local allowed = (listid == specialCardsList and true) or (listid == whitelistedCardsList and true) or false
			whitelist.cache[name.."_"..tostring(userid)] = {allowed = allowed, discorduser = card.desc}
			--
		end
		--
		print(whitelisted)
		for _, card in ipairs(special) do
			validateCard(card) end
		for _, card in ipairs(whitelisted) do
			validateCard(card) end
		for _, card in ipairs(banned) do
			validateCard(card) end
		for _, card in ipairs(blacklisted) do
			validateCard(card) end
		--
	end
	--
	whitelist.ready = true
	workspace:SetAttribute("WhitelistReady", true)
end
--
whitelist.init()
_G.playersWhitelist = whitelist
return whitelist