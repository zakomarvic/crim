--[[ Default Keybind to open the tool ]]

return Enum.KeyCode.F4