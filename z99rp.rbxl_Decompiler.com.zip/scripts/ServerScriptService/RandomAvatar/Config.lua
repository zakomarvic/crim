return {
	BodyColors = {
		BrickColor.new("Burlap");
		BrickColor.new("Cork");
		BrickColor.new("Fawn brown");
		BrickColor.new("Bronze");
		BrickColor.new("Pine Cone");
		BrickColor.new("Medium brown");
		BrickColor.new("Brown");

		BrickColor.new("Pastel brown");
		BrickColor.new("Light orange");
		BrickColor.new("Pastel brown");
		BrickColor.new("Nougat");
		BrickColor.new("Nougat");
		BrickColor.new("Nougat");
		BrickColor.new("Linen");
	};
	
	Accessories  = {
		Hats = {
			["1038669"] = { -- ThugBeanie
				NoHair = true;
				Priority = 2;
			},
			["125886373"] = { -- FishermansCap
				IsCap = true;
				Priority = 2;
			},
			["1309911"] = { -- NinjaMaskOfShadows
				Priority = 2;
				NoHair = true;
				Filter = {
					"304085055";
				};
			}, 
			["3810360649"] = { -- Balaclava
				Priority = 2;
				NoMask = true;
				NoHair = true;
			},
			["4753644287"] = { -- TacticalBala
				Priority = 2;
				NoHair = true;
			},
			["4888533638"] = { -- CombatCap
				IsCap = true;
				Priority = 2;
			},
			["4932728913"] = { -- BlackHood
				Priority = 2;
			},
			["4932728913"] = { -- BlackHood
				Priority = 2;
			},
			["4932728913"] = { -- BlackHood
				Priority = 2;
			},
			["4932728913"] = { -- BlackHood
				Priority = 2;
			},
			["4932728913"] = { -- BlackHood
				Priority = 2;
			},
			["4932728913"] = { -- BlackHood
				Priority = 2;
			},
			["4932728913"] = { -- BlackHood
				Priority = 2;
			},
			["4932728913"] = { -- BlackHood
				Priority = 2;
			},
			["4932728913"] = { -- BlackHood
				Priority = 2;
			},
			["4932728913"] = { -- BlackHood
				Priority = 2;
			},
			["5028569767"] = { -- Skull Balaklava
				Priority = 2;
				NoHair = true;
				Filter = {
					"4772321953";
				};
			}, 
			["5066371299"] = { -- OliveTacticalBalaclava
				Priority = 2;
				NoHair = true;
				NoMask = true;
			}, 
			["5257627634"] = { -- b e a n
				Priority = 2;
				NoHair = true;
			}, 
			["5674066697"] = { -- Periodt NecklaceAccessory (bali)
				Priority = 3;
				IsBala = true;
				NoBandana = true;
				NoHair = true;
				Filter = {
					"4507911797";
					"5227164371";
					"4772321953";
				};
			}, 
			["6201649565"] = { -- Black Beanie
				Priority = 2;
			},
			["6201761190"] = { -- Black Slavaclava
				Priority = 2;
				NoHair = true;
			}, 
			["6202412344"] = { -- Meshes/baseball_CubeAccessory
				IsCap = true;
				Priority = 2;
			},
			["6202430280"] = { -- Meshes/baseball_CubeAccessory
				IsCap = true;
				Priority = 2;
			}, 
			["6238724671"] = { -- Tactical Camoclava
				Priority = 2;
				NoHair = true;
				Filter = {
					"74221074";
				};
			},
			["6238726840"] = { -- Tan Camoclava
				Priority = 2;
				NoHair = true;
				Filter = {
					"74221074";
				};
			}, 
			["6312754500"] = { -- BlackCadetCap
				IsCap = true;
				Priority = 2;
			}, 
			["6377276400"] = { -- Black Flat Cap
				IsCap = true;
				Priority = 2;
			}, 
			["6377367924"] = { -- Black Patrol Cap
				IsCap = true;
				Priority = 2;
			}, 
			["6532474450"] = { -- Balaclava
				Priority = 2;
				NoHair = true;
				NoMask = true;
				Filter = {
					"5231192146";
					"4772321953";
				};
			},
			["6808352477"] = { -- Sideways Fitted Cap
				IsCap = true;
				Priority = 2;
			},
			["6810623653"] = { -- AngledBackwordsCap
				IsCap = true;
				Priority = 2;
			}, 
			["7321849823"] = { -- CarRadioSkiMask
				Priority = 2;
				NoHair = true;
				Filter = {
					"31252891";
					"7901886774";
				};
			},
			["7389843259"] = { -- ShyAwaySkiMask
				Priority = 2;
				NoHair = true;
				Filter = {
					"5231192146";
					"5227164371";
				};
			},
			["7442471648"] = { -- HairBandanaWoodland
				Priority = 2;
			}, 
			["7668537321"] = { -- Plaid Fedora
				IsCap = true;
				Priority = 2;
			}, 
			["7961301097"] = { -- Coyote Camoclava
				Priority = 2;
				NoHair = true;
				Filter = {
					"74221074";
				};
			},
			
			["7607393861"] = {
				Priority = 4;
			},
			["7607390264"] = {
				Priority = 4;
			},
			["6441489879"] = {
				NoFaceA = true;
				Priority = 4;
			},
			["5728165119"] = {
				Priority = 4;
			},
			["5728166624"] = {
				Priority = 4;
			},
			["6773691585"] = {
				Priority = 4;
			},
			["7540526086"] = {
				Priority = 2;
			},
			["7791163247"] = {
				Priority = 2;
			},
			
			["3963966260"] = {
				IsCap = true;
				Priority = 2;
			},
			["4391699255"] = {
				Priority = 4;
			},
			["4420280348"] = {
				IsCap = true;
				Priority = 2;
			},
			["4482799753"] = {
				IsCap = true;
				Priority = 2;
			},
			["4524484062"] = {
				IsCap = true;
				Priority = 2;
			},
			["4875632893"] = {
				Priority = 2;
				IsCap = true;
				NoMask = true;
			},
			["4875645970"] = {
				Priority = 2;
				IsCap = true;
				NoMask = true;
			},
			["4875649333"] = {
				Priority = 2;
				IsCap = true;
				NoMask = true;
			},
			["5064018621"] = {
				IsCap = true;
				Priority = 2;
			},
			["5064027152"] = {
				IsCap = true;
				Priority = 2;
			},
			["5591492062"] = {
				IsCap = true;
				Priority = 2;
			},
			["5591494219"] = {
				IsCap = true;
				Priority = 2;
			},
			["6201737341"] = {
				Priority = 1;
			},
			["6201775519"] = {
				Priority = 2;
				NoHair = true;
				Filter = {
					"74221074";
				};
			},
			["7389815623"] = {
				IsCap = true;
				Priority = 2;
			},
			["7969718248"] = {
				IsCap = true;
				Priority = 2;
			},
			["7969762570"] = {
				IsCap = true;
				Priority = 2;
			},
			["7969930640"] = {
				IsCap = true;
				Priority = 2;
			},
			["10832141"] = {
				IsCap = true;
				Priority = 2;
			},
			["9127689055"] = {
				Priority = 2;
				NoHair = true;
				IsCap = false;
			},
			["8950755817"] = {
				Priority = 2;
				NoHair = false;
				IsCap = true;
			},
			["7243982417"] = {
				Priority = 2;
				NoHair = false;
				IsCap = true;
			},
			["7028762683"] = {
				Priority = 2;
				NoHair = true;
				IsCap = true;
			},
			["8998009778"] = {
				Priority = 2;
				NoHair = false;
				IsCap = true;
			},
			["8997890531"] = {
				Priority = 2;
				NoHair = false;
				IsCap = false;
			},
			["7442434428"] = {
				Priority = 2;
				NoHair = false;
				IsCap = true;
			},
			["8741696706"] = {
				Priority = 2;
				NoHair = false;
				IsCap = true;
			},
			["7442471648"] = {
				Priority = 2;
				NoHair = true;
				IsCap = false;
			},
			["7084418627"] = {
				Priority = 2;
				NoHair = false;
				IsCap = true;
			},
			["6410139388"] = {
				Priority = 2;
				NoHair = false;
				IsCap = false;
			},
			["10130979"] = {
				Priority = 2;
				NoHair = false;
				IsCap = false;
				Filter = {
					"8473612629";
					"8468517631";
					"8464806581";
					"6569175486";
				};
			},
			["10130964"] = {
				Priority = 2;
				NoHair = false;
				IsCap = false;
				Filter = {
					"8473612629";
					"8468517631";
					"8464806581";
					"6569175486";
				};
			},
			["26342443"] = {
				Priority = 2;
				NoHair = false;
				IsCap = false;
			},
			["12436480"] = {
				Priority = 2;
				NoHair = false;
				IsCap = true;
			},
			["10860590"] = {
				Priority = 2;
				NoHair = true;
				IsCap = true;
			},
			["1029025"] = {
				Priority = 2;
				NoHair = false;
				IsCap = true;
			},
			["1029597"] = {
				Priority = 2;
				NoHair = false;
				IsCap = true;
			},
			["11297708"] = {
				Priority = 2;
				NoHair = false;
				IsCap = false;
			},
			["11297746"] = {
				Priority = 2;
				NoHair = false;
				IsCap = false;
			},
			["7796030210"] = {
				Priority = 2;
				NoHair = false;
				IsCap = false;
				Filter = {
					"8473612629";
					"8468517631";
					"8464806581";
					"6569175486";
					"6532493303";
				};
			},
		};
		
		Hairs = {
			[1] = { -- male
				["12270145"] = {
					Priority = 2;
				}, -- JE Hair,w
				["12270336"] = {
					Priority = 3;
				}, -- Afro,b
				
				["13477818"] = {
					Priority = 2;
				}, -- BoyNormalHair1,w
				["13655562"] = {
					Priority = 2;	
				}, -- Brooding Black,w
				["15913837"] = {
					Priority = 2;	
				}, -- Kent,w
				["16630147"] = {
					Priority = 2;	
				}, -- Ultra-Fabulous Hair,w
				["17877340"] = {
					Priority = 2;	
				}, -- Ultra-Fabulous Hair Brown,w
				["233615637"] = {
					Priority = 2;	
				}, -- Ultra-Fabulous Hair(blonde),w
				["248286896"] = {
					Priority = 2;	
				}, -- DefaultioHair,w
				["24939213"] = {
					Priority = 1;	
				}, -- Wave of the Future,-
				["26658141"] = {
					Priority = 2;	
				}, -- MessyHair,w
				["32278814"] = {
					Priority = 1;	
				}, -- NerdHair,w
				["323476364"] = {
					Priority = 2;	
				}, -- MessyHairBrown,w
				["343584973"] = {
					Priority = 2;	
				}, -- ManBun,w
				["4584980640"] = {
					Priority = 2;	
				}, -- Meshes/MediumFadeAccessory,b
				["4584983773"] = {
					Priority = 2;	
				}, -- Meshes/DeadsAccessory,b
				["4602282575"] = {
					Priority = 2;	
				}, -- new stlish hairAccessory,w
				["4773873546"] = {
					Priority = 1;	
				}, -- Black Low Cut,b
				["5100703261"] = {
					Priority = 3;	
				}, -- Afro,b
				["5153072488"] = {
					Priority = 2;	
				}, -- Hair,b
				["5164439083"] = {
					Priority = 2;	
				}, -- Hair,b
				["5269022822"] = {
					Priority = 2;	
				}, -- Hair,b
				["5269153561"] = {
					Priority = 2;	
				},
				["62743701"] = {
					Priority = 2;	
				}, -- Dr. Smyth Hair,w
				["6311258677"] = {
					Priority = 2;
				}, -- Black Messy Dreads,b
				["6413034281"] = {
					Priority = 2;
				},
				["7104671488"] = {
					Priority = 2;	
				},
			
				["7149241246"] = {
					Priority = 1;
				},
				["5100625864"] = {
					Priority = 2;
				},
				["3993395372"] = {
					Priority = 3;
				},
				["4846306965"] = {
					Priority = 2;
				},
				["6690010241"] = {
					Priority = 2;
				},
				["6597946508"] = {
					Priority = 2;
				},
				["6712905660"] = {
					Priority = 1;
				},
				["5163640422"] = {
					Priority = 2;
				},
				["7097787052"] = {
					Priority = 2;
				},
				["5644883846"] = {
					Priority = 2;
				},
				["5132741773"] = {
					Priority = 3;
				},
				["6903783856"] = {
					Priority = 2;
				},
				["5591241418"] = {
					Priority = 2;
				},
				["5591301519"] = {
					Priority = 2;
				},
				["5197352502"] = {
					Priority = 2;
				},
			};
			
			[2] = { -- female
				["11913660"] = {
					Priority = 1;
				},
				["13476917"] = {
					Priority = 1;
				},
				["13745548"] = {
					Priority = 1;
				},
				["14815761"] = {
					Priority = 1;
				},
				["1772372988"] = {
					Priority = 1;
				},
				["25517576"] = {
					Priority = 1;
				},
				["4376076289"] = {
					Priority = 2;
				},
				["4524481392"] = {
					Priority = 2;
				},
				["4933291135"] = {
					IsCap = true;
					Priority = 3;
				},
				["4933370451"] = {
					IsCap = true;
					Priority = 3;
				},
				["5028644000"] = {
					Priority = 3;
				},
				["5028650868"] = {
					Priority = 3;
				},
				["5063539766"] = {
					Priority = 3;
				},
				["5099867090"] = {
					Priority = 2;
				},
				["5100028001"] = {
					IsCap = true;
					Priority = 3;
				},
				["5164275842"] = {
					Priority = 3;
				},
				["5164291974"] = {
					Priority = 3;
				},
				["5168712155"] = {
					Priority = 3;
				},
				["5168714719"] = {
					Priority = 3;
				},
				["5230721625"] = {
					Priority = 1;
				},
				["5371279441"] = {
					Priority = 2;
				},
				["5411808118"] = {
					Priority = 2;
				},
				["5591091620"] = {
					Priority = 2;
				},
				["5699726784"] = {
					Priority = 2;
				},
				["5769259024"] = {
					Priority = 2;
				},
				["6122765091"] = {
					Priority = 2;
				},
				["6275634645"] = {
					Priority = 3;
				},
				["6594642172"] = {
					Priority = 3;
				},
				["7175874678"] = {
					Priority = 3;
				},
				["7441026964"] = {
					Priority = 3;
				},
				["7657750567"] = {
					Priority = 2;
				},
				["7667707103"] = {
					Priority = 3;
				}
				,
				["80922251"] = {
					Priority = 1;
				}
			},
		};
		
		FaceAccessories = {
			["13702134"] = {
				NoCap = true;
				IsMask = true;
			},
			["13702160"] = {
				NoCap = true;
				IsMask = true;	
			},
			["14128354"] = {
				NoCap = true;
				IsMask = true;
			},
			["20642008"] = {},
			["304085055"] = {},
			["31252891"] = {},
			["4772321953"] = {},
			["4932535459"] = {
				IsMask = true;
				NoCap = true;
			},
			["51245241"] = {},
			["5231192146"] = {},
			["5520275850"] = {
				NoCap = true;
				IsMask = true;	
			},
			["5733528225"] = {},
			["5973838476"] = {},
			["5973866061"] = {},
			["6201641018"] = {},
			["62745127"] = {},
			["6441183736"] = {
				IsMask = true;	
			},
			["6698685281"] = {
				NoCap = true;
				IsMask = true;	
			},
			["74221074"] = {
				IsMask = true;	
			},
			["7901886774"] = {},
			
			["255797408"] = {
				IsMask = true;	
			},
			["4391089678"] = {},
			["4507911797"] = {},
			["4510537113"] = {
				IsMask = true;	
			},
			["5227164371"] = {},
			["62147392"] = {
				IsMask = true;	
			},
			["6808010154"] = {
				IsMask = true;
			},
			["7168603740"] = {
				NoCap = true;
				IsMask = true;
			},
			["7168625196"] = {
				NoCap = true;
				IsMask = true;
			},
			["7168674789"] = {
				NoCap = true;
				IsMask = true;
			},
			["7790700082"] = {
				IsMask = true;
			},
			["7790760200"] = {
				NoCap = true;
				IsMask = true;	
			},
			["7889181898"] = {
				NoCap = true;
				IsMask = true;
			},
			
			--- new
			["8468517631"] = {
				NoCap = true;
				IsMask = true;
			},
			["8473612629"] = {
				NoCap = true;
				IsMask = true;
			},
			["4735681380"] = {
				NoCap = false;
				IsMask = true;
			},
			["17926686"] = {
				NoCap = true;
				IsMask = true;
			},
			["5197237539"] = {
				NoCap = true;
				IsMask = true;
			},
			["7135056846"] = {
				NoCap = true;
				IsMask = true;
			},
			["4735668170"] = {
				NoCap = false;
				IsMask = true;
			},
			["6569175486"] = {
				NoCap = false;
				IsMask = true;
				Filter = {
					"26342443";
				};
			},
			["6532493303"] = {
				NoCap = false;
				IsMask = true;
				Filter = {
					"9120924781";
					"10832141";
				};
			},
			["9254521"] = {
				NoCap = false;
				IsMask = true;
				Filter = {
					"8473612629";
					"8468517631";
					"8464806581";
					"6569175486";
				};
			},
			["6906162061"] = {
				NoCap = true;
				IsMask = true;
			},
			["8717655432"] = {
				NoCap = true;
				IsMask = true;
			},
			["8779937330"] = {
				NoCap = true;
				IsMask = true;
			},
			["8464806581"] = {
				NoCap = true;
				IsMask = true;
			},
			["9120924781"] = {
				NoCap = true;
				IsMask = true;
			},
		};
	};
	
	NoHairChance = 4;
	NoFaceAChance = 4;
	Female_NoHatChance = 1;
	Male_NoHatChance = 3;
	
	FemaleChance = 3;
}