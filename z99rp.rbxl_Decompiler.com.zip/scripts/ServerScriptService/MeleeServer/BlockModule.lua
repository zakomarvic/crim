local b = 
	{
		["Fists"] = 			{"Fists";		"Knuckledusters";	"Nunchucks","Coal"};
		["Knuckledusters"] =	{"Fists";		"Knuckledusters";	"Nunchucks","Coal"};
		["Ballbusters"] =	{"Fists";		"Knuckledusters";	"Nunchucks","Coal"};
		["Nunchucks"] = 		{"Fists","		Knuckledusters",		"Nunchucks","Coal"};

		["Bat"] =			{"Fists",		"Knuckledusters",	"Wrench",	"Hammer",	"Coal",		"Taiga",	"Crowbar","Golfclub", "Bat",	"Machete",	"Katana",	"Metal-Bat",	"Nunchucks"			,			"BBaton";"Scythe","Spear","Guitar"};
		["Guitar"] =			{"Fists",		"Knuckledusters",	"Wrench",	"Hammer",	"Coal",		"Taiga",	"Crowbar","Golfclub", "Bat",	"Machete",	"Katana",	"Metal-Bat",	"Nunchucks"			,			"BBaton";"Scythe","Spear","Guitar"};
		["Shovel"] =			{"Fists",		"Knuckledusters",	"Wrench",	"Hammer",	"Coal",		"Taiga",	"Bat",	"Golfclub",			"Shovel", 	"Machete",	"Katana",	"Metal-Bat",	"Nunchucks"			,			"BBaton";"Scythe","Spear","Guitar"};

		["Crowbar"] =		{"Fists",		"Knuckledusters",	"Wrench",	"Hammer",	"Coal",		"Shiv",	"Bayonet", "Balisong",	"HallowsBlade",	"BlackBayonet",	"Rambo",	"Taiga",	"Crowbar", "Golfclub",	"Bat",		"Machete",	"Katana",											"Nunchucks",			"BBaton","Spear","Guitar","RailBlade","Karambit"};
		["Machete"] = 		{"Fists",		"Knuckledusters",	"Wrench",	"Hammer",	"Coal",		"Shiv",	"Bayonet",	"Balisong", "HallowsBlade", "BlackBayonet",	"Rambo",	"Taiga",	"Crowbar",	"Golfclub","Bat",		"Machete",	"Katana",											"Nunchucks",			"BBaton";"Scythe","Spear","Guitar","RailBlade","Karambit"};
		["Taiga"] = 			{"Fists",		"Knuckledusters",	"Wrench",	"Hammer",	"Coal",		"Shiv",	"Bayonet",	"Balisong", "HallowsBlade", "BlackBayonet",	"Rambo",	"Taiga",	"Crowbar",		"Machete",	"Katana",											"Nunchucks",			"BBaton","RailBlade"};
		["Katana"] = 		{"Thermal-Katana", "Fists",		"Knuckledusters",	"Wrench",	"Hammer",	"Coal",		"Shiv",	"Bayonet",	"Balisong","HallowsBlade", "BlackBayonet",	"Rambo",	"Taiga",	"Crowbar",	"Golfclub","Machete",	"Katana",														"Nunchucks",			"BBaton";"Scythe","Spear","Guitar","RailBlade","Karambit"};
		["Thermal-Katana"] = 		{"Thermal-Katana", "Fists",		"Knuckledusters",	"Wrench",	"Hammer",	"Coal",		"Shiv",	"Bayonet",	"Balisong","HallowsBlade", "BlackBayonet",	"Rambo",	"Taiga",	"Crowbar",	"Golfclub","Machete",	"Katana",														"Nunchucks",			"BBaton";"Scythe","Spear","Guitar","RailBlade","Karambit"};
		["BBaton"] = 		{"Fists",		"Knuckledusters",	"Wrench",	"Hammer",	"Coal",		"Shiv",	"Bayonet",	"Balisong", "HallowsBlade", "BlackBayonet",	"Rambo",	"Taiga",	"Crowbar",		"Machete",	"Katana",											"Nunchucks",			"BBaton","RailBlade"};
		["Metal-Bat"] = 		{"Fists",		"Knuckledusters",	"Wrench",	"Hammer",	"Coal",		"Shiv",	"Bayonet",	"Balisong","HallowsBlade", "BlackBayonet",	"Rambo",	"Taiga",	"Fire Axe",	"Crowbar",	"Golfclub","Bat",		"Shovel",	"Machete",	"Katana",	"Metal-Bat",	"Sledgehammer",	"Nunchucks",			"BBaton";"Scythe","Spear","Guitar","Pale-Morning","RailBlade","Karambit"};

		["Sledgehammer"] = 		{"Fists",		"Knuckledusters",	"Wrench",	"Hammer",	"Coal",		"Shiv",	"Bayonet",	"Balisong","HallowsBlade", "BlackBayonet",	"Rambo",	"Taiga",	"Fire Axe",	"Crowbar",	"Golfclub","Bat",		"Shovel",	"Machete",	"Katana",	"Metal-Bat",	"Sledgehammer","Nunchucks",			"BBaton";"Scythe","Spear","Guitar","Pale-Morning","RailBlade","Karambit"};
		["Spear"] = 		{"Fists",		"Knuckledusters",	"Wrench",	"Hammer",	"Coal",		"Shiv",	"Bayonet",	"Balisong","HallowsBlade", "BlackBayonet",	"Rambo",	"Taiga",	"Fire Axe",	"Crowbar",	"Golfclub","Bat",		"Shovel",	"Machete",	"Katana",	"Metal-Bat",	"Sledgehammer","Nunchucks",			"BBaton";"Scythe","Spear","Guitar","Pale-Morning","RailBlade","Karambit"};


		["SlayerSword"] = 	{"Fists",		"Knuckledusters",	"Wrench",	"Hammer",	"Coal",		"Shiv",	"Bayonet",	"Balisong", "HallowsBlade", "BlackBayonet",	"Rambo",	"Taiga",	"Fire Axe",	"Crowbar",	"Golfclub","Bat",		"Shovel",	"Machete",	"Katana",	"Metal-Bat",	"Sledgehammer","Nunchucks", "Fire-Axe","SlayerSword","RiotShield","Chainsaw","Hammer",	"BBaton";"Scythe","Spear","Guitar","Pale-Morning","RailBlade","Karambit"};
		["Scythe"] = 		{"Fists",		"Knuckledusters",	"Wrench",	"Hammer",	"Coal",		"Shiv",	"Bayonet",	"Balisong", "HallowsBlade", "BlackBayonet",	"Rambo",	"Taiga",	"Fire Axe",	"Crowbar",	"Golfclub","Bat",		"Shovel",	"Machete",	"Katana",	"Metal-Bat",	"Nunchucks", "Fire-Axe","SlayerSword","RiotShield","Chainsaw","Hammer",	"BBaton";"Scythe","Spear","Guitar","Pale-Morning","RailBlade","Karambit"};

		["RiotShield"] = 	{"Fists",		"Knuckledusters",	"Wrench",	"Hammer",	"Coal",		"Shiv",	"Bayonet",	"Balisong", "HallowsBlade", "BlackBayonet",	"Rambo",	"Taiga",	"Fire Axe",	"Crowbar",	"Golfclub","Bat",		"Shovel",	"Machete",	"Katana",	"Metal-Bat",	"Sledgehammer","Nunchucks", "Fire-Axe","SlayerSword","Chainsaw","Hammer", "BBaton";"Scythe","Spear","Guitar","Pale-Morning","RailBlade","Karambit"};
		["RCU_RiotShield"] =	{"Fists",		"Knuckledusters",	"Wrench",	"Hammer",	"Coal",		"Shiv",	"Bayonet",	"Balisong", "HallowsBlade", "BlackBayonet",	"Rambo",	"Taiga",	"Fire Axe",	"Crowbar",	"Golfclub","Bat",		"Shovel",	"Machete",	"Katana",	"Metal-Bat","Sledgehammer",	"Nunchucks", "Fire-Axe","SlayerSword","Chainsaw","Hammer", "BBaton";"Scythe","Spear","Guitar","Pale-Morning","RailBlade","Karambit"};
		["__RiotShield"] ={"Fists",		"Knuckledusters",	"Wrench",	"Hammer",	"Coal",		"Shiv",	"Bayonet",	"Balisong", "HallowsBlade", "BlackBayonet",	"Rambo",	"Taiga",	"Fire Axe",	"Crowbar",	"Golfclub","Bat",		"Shovel",	"Machete",	"Katana",	"Metal-Bat",	"Sledgehammer","Nunchucks", "Fire-Axe","SlayerSword","Chainsaw","Hammer", "BBaton";"Scythe","Spear","Guitar","Pale-Morning","RailBlade","Karambit"};

		["_PurpleGuysAxe"] = 	{"All"};
		["GOD_FISTS"] = 			{"All"};
		["_KJFists"] = 			{"All"};
		["BRUHBAR"] = 			{"All"};
		["SakuUWUbar"] = {"All"};
		["ERADICATOR"] = 		{"All"};
		["ERADICATOR2"] = 		{"All"};
		["_BFists"] = 			{"Fists","Knuckledusters","Wrench","Hammer","Coal","Crowbar","Golfclub","Bat","Shovel","Nunchucks","BBaton","Hammer","Guitar"};
		["_Sledge"] =		{"All"};
		["Divine-GreatAxe"] =		{"All"};
		["Divine-GreatSword"] =		{"All"};
		["Legion-Cestus"] =		{"All"};
		["Crypt-Blade"] =		{"All"};
		["Rendbreaker"] = {"All"};
		["Pale-Morning"] = {"All"};
		["RailBlade"] = {"All"};
		--	["Bat"] =				{"Fists","Bat","Bayonet","Machete","Katana","Nunchucks","Metal-Bat","Taiga","Rambo","Crowbar"};
		--	["Crowbar"] =			{"Fists","Bayonet","Machete","Katana","Nunchucks","Taiga","Rambo","Crowbar"};
		--	["Machete"] = 	{"Fists","Bayonet","Machete","Bat","Katana","Nunchucks","Taiga","Rambo","Crowbar"};
		--	["Katana"] = 			{"Fists","Bayonet","Machete","Bat","Katana","Nunchucks","Taiga","Rambo","Crowbar"};
		--	["Nunchucks"] = 		{"Fists","Bayonet","Machete","Bat","Katana","Nunchucks","Taiga","Rambo","Crowbar"};
		--	["Metal-Bat"] = 		{"Fists","Metal-Bat","Machete","Fists","Bat","Katana","Nunchucks","Taiga","Rambo","Crowbar"};

	}

for i,v in pairs(b) do
	table.insert(v,"__ZombieFists1")
	table.insert(v,"__ZombieFists2")
	table.insert(v,"Ballbusters")
	table.insert(v,"Legion-Cestus")
	table.insert(v,"Crypt-Blade")

	if i ~= "Fists" then
		table.insert(v,"__ZombieFists3")
	end
	if i~="Fists" and i~="Knuckledusters" and i~="Ballbusters" and i~="Nunchucks" then
		table.insert(v,"Divine-Dagger")
	end
end

return b