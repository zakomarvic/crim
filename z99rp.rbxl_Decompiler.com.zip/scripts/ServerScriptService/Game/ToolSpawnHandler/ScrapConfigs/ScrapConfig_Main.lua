return {
	
	["MaxItems"] = 1;
	["StoredAmmo_TakePerc"] = {33,200}; -- Up to this % of the stored ammo can be taken
	["Ammo_TakePerc"] = {33,200}; -- Up to this % of the ammo can be taken
	
	["ItemsTable"] = {
		["val_Lighter"] = {
			Chance = 9;
		};
		["val_Battery"] = {
			Chance = 8;
		};
		["val_Wires"] = {
			Chance = 8;
		};
		["val_Cloth"] = {
			Chance = 8;
		};
		["val_Gunpowder"] = {
			Chance = 7;
		};
		["val_MilitaryCable"] = {
			Chance = 7;
		};
		["val_WeaponParts"] = {
			Chance = 7;
		};

		--v 46%
		
		["val_Watch"] = {
			Chance = 3;
		};
		["val_SkullRing"] = {
			Chance = 3;
		};
		["val_Dogtag"] = {
			Chance = 3;
		};
		["val_Keytool"] = {
			Chance = 3;
		};
		
		
		["val_Jerrycan"] = {
			Chance = 3;
		};
		["val_FloppyDrive"] = {
			Chance = 3;
		};
		["val_Blueprint"] = {
			Chance = 2;
		};
		["val_Documents"] = {
			Chance = 1;
		};
		
		--v 25%

		["Lockpick"] = {
			Chance = 4; -- %
		};
		
		["Shiv"] = {
			Chance = 2; -- %
		};
		
		["Wrench"] = {
			Chance = 2; -- %
		};
		
		["Bayonet"] = {
			Chance = 2; -- %
		};
		
		["BBaton"] = {
			Chance = 2; -- %
		};
		
		["Golfclub"] = {
			Chance = 2; -- %
		};
		
		["Shovel"] = {
			Chance = 2; -- %
		};
		
		["Crowbar"] = {
			Chance = 2; -- %
		};
		
		["Bat"] = {
			Chance = 2; -- %
		};

		["Balisong"] = {
			Chance = 1; -- %
		};

		["Rambo"] = {
			Chance = 1; -- %
		};
		
		["Beretta"] = {
			Chance = 1; -- %
			IsGun = true;
		};
		
		["G-17"] = {
			Chance = 1; -- %
			IsGun = true;
		};
		
		["Uzi"] = {
			Chance = 1; -- %
			IsGun = true;
		};
	};
}