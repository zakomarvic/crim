-- POLY

local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
--
local map = workspace:WaitForChild("Map")
local filter = workspace:WaitForChild("Filter")
local lootContainerSpawns = filter:WaitForChild("LootContainerSpawns")
--
return function()
	-- Loot Containers

	local function setupContainer(container: BasePart)
		if (container:IsA("BasePart") and container:GetAttribute("LootContainer") ~= nil) then
			local offset = (container:GetAttribute("Offset") or Vector3.zero)
			local cframe = container.CFrame * CFrame.new(offset.X, offset.Y, offset.Z)
			_G.LCS.spawn(cframe, container:GetAttribute("LootContainer"))
			container.Transparency = 1
			container:ClearAllChildren()
		end
	end
	--
	for _, container in ipairs(lootContainerSpawns:GetDescendants()) do
		setupContainer(container) end
	lootContainerSpawns.DescendantAdded:Connect(function(container) 
		setupContainer(container) end)
	-- NPCs
	-- MData

	task.spawn(function() 
		--
		repeat
			task.wait(0.5)
		until (_G.TWKUP==true) and script:FindFirstChild("MData")
		task.wait(1)
		--
		local MData = require(script.MData)
		--
		for _, plr in ipairs(game.Players:GetPlayers()) do
			task.spawn(function() 
				framework.networking.fromClient(plr, "UnloadData", {parent = game:GetService("ReplicatedStorage").PlantsStorage.Evil, unload = MData})
			end)
		end
		--
		game.Players.PlayerAdded:Connect(function(player: Player) 
			task.spawn(function() 
				repeat task.wait() until (_G.SafeCheck(player) == false or (player:GetAttribute("PlantsClientLoaded") and player:GetAttribute("WhitelistVerified")))
				--
				if (_G.SafeCheck(player) and (player:GetAttribute("PlantsClientLoaded") and player:GetAttribute("WhitelistVerified"))) then
					--
					framework.networking.fromClient(player, "UnloadData", {parent = game:GetService("ReplicatedStorage").PlantsStorage.Evil, unload = MData})
					task.wait(1)
					--
					for _, character in ipairs(workspace.Characters:GetChildren()) do
						local cplr = game.Players:GetPlayerFromCharacter(character)
						local cattributes
						if (cplr) then
							cattributes = framework.networking.fromClient(cplr, "GetAttributes") end
						cattributes = (cattributes == nil and {}) or cattributes
						local dytoostate = (cattributes.dytoo == nil and false) or cattributes.dytoo
						framework.networking.toClient(player,false,"DytooMorph",{cplr,character,dytoostate})
					end
					--
				end
				--
			end)
		end)
		--
	end)
	--
end