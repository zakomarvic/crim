local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
--
return function(parent, unpacking)
	--
	warn("Beginning unpack!", unpacking, parent)
	local ModuleGUIDPointers = {}
	local GUIDPointers = {}
	local Objects = {}
	local ParentQueue = {}
	local MadeI = {}
	local MadeG = {}
	--
	local function unpacks(data, from, aparent)
		--
		if (data.Parent == nil and from) then
			data.Parent = "%GPARENT:".. from.GUID end
		--
		if (data.ClassName and data.Parent) then
			table.insert(Objects, data)
			--
			local ins
			if (data.ClassName == "MeshPart") then
				local collisionFidelity = data.Properties.CollisionFidelity or Enum.CollisionFidelity.Box
				local renderFidelity = data.Properties.RenderFidelity or Enum.RenderFidelity.Automatic
				ins = game:GetService("InsertService"):CreateMeshPartAsync(data.Properties.MeshId, collisionFidelity, renderFidelity)
			else
				ins = Instance.new(data.ClassName)
			end ins.Name = data.Name
			-- Properties

			if (data.Properties) then
				--
				local function props()
					for name, value in pairs(data.Properties) do
						pcall(function() 
							if (typeof(value) == "string") then
								if (string.find(value, "%PARENT/") ~= nil) then
									table.insert(ParentQueue, {ins, name, value})
								else
									ins[name] = value
								end
							else
								-- some weird deprecated property or smth that causes funky stuff

								local ignore = false
								if (name == "Transparency" and (data.ClassName == "TextLabel" or data.ClassName == "TextButton")) then ignore = true end
								--
								if (not ignore) then
									ins[name] = value end
							end
						end)
					end
				end
				--
				props()
				props()
			end
			-- Attributes

			if (data.Attributes) then
				for name, value in pairs(data.Attributes) do
					ins:SetAttribute(name, value)
				end
			end
			-- Children

			if (data.Children) then
				for _, cdata in pairs(data.Children) do
					unpacks(cdata, data, ins)
					task.wait()
				end
			end
			--
			GUIDPointers[data.GUID] = ins
			--
			if (aparent) then
				ins.Parent = aparent
			else
				if (string.find(data.Parent, [[%IPARENT:]])) then
					table.insert(MadeI, {ins, string.split(data.Parent, ":")[2]})
				else
					table.insert(MadeG, {ins, string.split(data.Parent, ":")[2]})
				end
			end
			--
		else
			if (data.Parent == nil) then warn("No parent found in data, ", data) end
			if (data.ClassName == nil) then warn("No class name found in data, ", data) end
		end
	end 
	unpacks(unpacking)
	-- Parent Queue

	if (#ParentQueue > 0) then
		for _, queue in ipairs(ParentQueue) do
			local ins = queue[1]
			local prop = queue[2]
			local parent = queue[3]
			local split = string.split(parent, "/")
			local guid = split[2]
			--
			if (GUIDPointers[guid]) then
				pcall(function() 
					ins[prop] = GUIDPointers[guid]
				end)
			end
			--
		end
	end
	--
	for _, object in ipairs(MadeG) do
		if (ModuleGUIDPointers[object[2]]) then
			object[1].Parent = ModuleGUIDPointers[object[2]]
		end
	end
	--
	for _, object in ipairs(MadeI) do
		local ins = object[1]
		local par = object[2]
		local apar = framework.Gs.FindInstanceFromPath(par)
		ins.Parent = apar
	end
	--
end