local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
--
return function()
	local hooks = game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Hooks")
	--
	local function grabAnyWithin(within: Instance, to)
		for _, m: ModuleScript in ipairs(within:GetChildren()) do
			if (m:IsA("ModuleScript")) then
				for i, f in pairs(require(m)) do
					to[i] = f end end end
		within.ChildAdded:Connect(function(m: ModuleScript) 
			if (m:IsA("ModuleScript")) then
				for i, f in pairs(require(m)) do
					to[i] = f end end end)
	end
	-- Remote Events
	
	local remotes = require(script:WaitForChild("Remotes"))
	hooks:WaitForChild("remote").OnServerEvent:Connect(function(plr, action, data) 
		remotes[action](plr, data) end)
	hooks.remote:WaitForChild("unreliableRemote").OnServerEvent:Connect(function(plr, action, data) 
		remotes[action](plr, data) end)
	grabAnyWithin(script.Remotes, remotes)
	-- Remote Functions
	
	local remoteFunctions = require(script:WaitForChild("RemoteFunctions"))
	hooks:WaitForChild("remoteFunction").OnServerInvoke = function(plr, action, data)
		return remoteFunctions[action](plr, data) end
	grabAnyWithin(script.RemoteFunctions, remoteFunctions)
	-- Events
	
	local events = require(script:WaitForChild("Events"))
	hooks:WaitForChild("event").Event:Connect(function(action, data) 
		events[action](data) end)
	grabAnyWithin(script.Events, events)
	--
end
--