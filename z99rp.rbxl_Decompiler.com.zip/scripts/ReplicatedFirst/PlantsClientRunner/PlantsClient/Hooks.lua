local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
--
return function()
	local hooks = game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Hooks")
	-- Remote Events
	
	local remotes = require(script:WaitForChild("Remotes"))
	hooks:WaitForChild("remote").OnClientEvent:Connect(function(action, data) 
		remotes[action](data) end)
	hooks:WaitForChild("remote"):WaitForChild("unreliableRemote").OnClientEvent:Connect(function(action, data) 
		remotes[action](data) end)
	-- Remote Functions
	
	local remoteFunctions = require(script:WaitForChild("RemoteFunctions"))
	hooks:WaitForChild("remoteFunction").OnClientInvoke = function(action, data)
		return remoteFunctions[action](data) end
	-- Events
	
	local events = require(script:WaitForChild("Events"))
	hooks:WaitForChild("event").Event:Connect(function(action, data) 
		events[action](data) end)
	--
end
--