-- CLIENT

local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
--
local player = game.Players.LocalPlayer
local plantsGui = _G.PlantsGui
local emotesGui = plantsGui:WaitForChild("Emotes")
local emotesMedia = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Media"):WaitForChild("Emotes"))
--
local emotes = {
	--
	menuKeyPressed = false,
	menuKeyAt = -1,
	menuOpen = "",
	--
	isBusy = false,
	inSelection = false,
	selectionSlotChosen = nil,
	--
	selectionSlots = {},
	inventorySlots = {},
	emotesEquipped = {},
	emotesOwned = {},
	--
}
--
function emotes.init()
	-- Input Began
	
	framework.services.UserInputService.InputBegan:Connect(function(input, ge) 
		if (ge) then return end
		if (player.Character == nil or not framework.Gs.SafeCheck({player:FindFirstChild("Humanoid"), player:FindFirstChild("HumanoidRootPart")}) or player.Character.Humanoid.Health <= 0 or player.Character:FindFirstChildOfClass("Tool") ~= nil) then return end
		--
		if (input.KeyCode == Enum.KeyCode.T) then
			emotes.menuKeyPressed = true
			emotes.menuKeyAt = os.clock()
		end
		--
	end)
	-- Input Ended
	
	framework.services.UserInputService.InputEnded:Connect(function(input, ge) 
		if (input.KeyCode == Enum.KeyCode.T and emotes.menuKeyPressed) then
			emotes.menuKeyPressed = false
			local passed = (os.clock() - emotes.menuKeyAt)
			emotes.toggle((passed >= 0.3 and "inventory") or "selection")
		end
	end)
	--
	_G.EmotesSystem = emotes
	emotes.gui_init()
end
--
function emotes.gui_make_slot(data)
	--
	local slot: Frame = (data.mode == "inventory" and emotesGui.Templates.InventorySlot:Clone()) or emotesGui.Templates.Slot:Clone()
	slot.Position = data.position
	slot.Name = "Slot".. data.index
	slot.Visible = true
	slot.Parent = data.parent
	if (data.mode == "inventory") then slot = slot.Holder end
	local camera_cframe = script:GetAttribute("SlotCameraCFrame")
	local camera = Instance.new("Camera")
	camera.Parent = slot.Viewport
	camera.CFrame = camera_cframe
	camera.FieldOfView = 10
	camera:SetAttribute("Default", camera_cframe)
	slot.Viewport.CurrentCamera = camera
	local button: TextButton = slot.Button
	--
	if (data.mode == "inventory") then
		slot.EmoteName.Position = UDim2.new(0.5, 0, 1, 15)
		slot.EmoteName.Size = UDim2.new(1.1, 0, 0, 25)
		slot.EmoteName.TextSize = 12
	end
	--
	local slot_data = {
		data = nil,
		emote = "",
		slot = slot,
		animation = nil,
		pressed_at = os.clock(),
	}
	-- Cancel Hover
	
	local function cancel_hover()
		framework.services.TweenService:Create(slot.Background, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {BorderSizePixel = 1, BorderColor3 = Color3.fromRGB(200, 200, 200)}):Play()
		--
		if (slot_data.animation) then
			local new_animation = slot_data.slot.Viewport.World.Rig.Humanoid:LoadAnimation(slot_data.data.animation)
			new_animation:Play(0.3, 1, 0)
			new_animation.TimePosition = 0
			slot_data.animation:Stop(0.3)
			slot_data.animation = new_animation
		end
		--
		if (slot_data.emote_music) then
			framework.services.TweenService:Create(slot_data.emote_music, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {Volume = 0}):Play()
			framework.Gs.SafeDestroy(slot_data.emote_music, 0.5)
			slot_data.emote_music = nil
		end
		--
		if (slot_data.track_camera) then
			slot_data.track_camera:Disconnect()
			slot_data.track_camera = nil
			slot_data.camera_tween = framework.services.TweenService:Create(slot_data.slot.Viewport.CurrentCamera, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {CFrame = slot_data.slot.Viewport.Camera:GetAttribute("Default")})
			slot_data.camera_tween:Play()
		end
		--
	end
	-- Mouse Enter
	
	button.MouseEnter:Connect(function() 
		--
		_G.PlayGuiSound("hover")
		framework.services.TweenService:Create(slot.Background, TweenInfo.new(0.3, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {BorderSizePixel = 2, BorderColor3 = Color3.fromRGB(255, 255, 255)}):Play()
		--
		if (slot_data.animation) then
			slot_data.animation:AdjustSpeed(1)
		elseif (slot_data.animation == nil and slot_data.data) then
			slot_data.animation = slot_data.slot.Viewport.World.Rig.Humanoid:LoadAnimation(slot_data.data.animation)
			slot_data.animation:Play(0, 1, 1)
		end
		--
		if (slot_data.camera_tween ~= nil) then
			slot_data.camera_tween:Pause()
			slot_data.camera_tween = nil
		end
		--
		if (slot_data.animation and slot_data.track_camera == nil) then
			slot_data.track_camera = framework.services.RunService.RenderStepped:Connect(function(delta) 
				if not (slot_data.slot and slot_data.slot:FindFirstChild("Viewport")) then slot_data.track_camera:Disconnect() return end
				--
				local viewport_camera = slot_data.slot.Viewport.CurrentCamera
				local viewport_rig = slot_data.slot.Viewport.World.Rig
				local origin_position = script:GetAttribute("SlotCameraCFrame").Position
				local track_position = ((viewport_rig.Torso.Position - Vector3.new(0, 1, 0)) + viewport_rig.Head.Position) / 2
				local track_cframe = CFrame.new(origin_position, track_position)
				local track_blend = 1 - math.pow(1 - 0.08, delta * 60)
				viewport_camera.CFrame = viewport_camera.CFrame:Lerp(track_cframe, track_blend)
				--
			end)
		end
		--
		if (slot_data.data) then
			-- Music

			if (slot_data.data.music) then
				local emote_music = slot_data.data.music:Clone()
				local base_volume = emote_music.Volume
				emote_music.Volume = 0
				emote_music.Parent = game.Players.LocalPlayer
				framework.services.TweenService:Create(emote_music, TweenInfo.new(0.3, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {Volume = base_volume*0.6}):Play()
				emote_music:Play()
				slot_data.emote_music = emote_music
			end
			--
		end
		--
	end)
	-- Mouse Leave
	
	button.MouseLeave:Connect(function() 
		cancel_hover()
	end)
	-- Mouse Click
	
	button.MouseButton1Down:Connect(function() 
		_G.PlayGuiSound("click")
		framework.services.TweenService:Create(slot.Background, TweenInfo.new(0.1, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {BorderSizePixel = 1, BorderColor3 = Color3.fromRGB(55, 255, 55)}):Play()
		slot_data.pressed_at = os.clock()
	end)
	-- Mouse Un-Click
	
	button.MouseButton1Up:Connect(function() 
		framework.services.TweenService:Create(slot.Background, TweenInfo.new(0.3, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {BorderSizePixel = 2, BorderColor3 = Color3.fromRGB(255, 255, 255)}):Play()
		--
		if (data.mode == "inventory") then
			if (emotes.inSelection) then
				--
				task.spawn(function() 
					emotes.isBusy = true
					framework.networking.fromServer("ChooseEmoteForSlot", {slot = emotes.selectionSlotChosen, emote = slot_data.emote})
					emotes.isBusy = false
					emotes.toggle("selection", true)
				end)
				--
			else
				framework.networking.toServer(false, "UseEmote", {emote = slot_data.emote})
				emotes.toggle("", false)
				cancel_hover()
			end
		else
			if ((os.clock() - slot_data.pressed_at) >= 0.3) then
				emotes.inSelection = true
				emotes.selectionSlotChosen = data.index
				emotes.toggle("inventory", true)
			else
				framework.networking.toServer(false, "UseEmote", {emote = slot_data.emote})
				emotes.toggle("", false)
				cancel_hover()
			end
		end
		--
	end)
	--
	return slot_data
end
--
function emotes.gui_init()
	-- Selection Slots
	
	emotes.selectionSlots["Slot1"] = emotes.gui_make_slot({index = 1, parent = emotesGui.Selection.Slots, position = UDim2.new(0.5, 0, 0.5, -85)})
	emotes.selectionSlots["Slot2"] = emotes.gui_make_slot({index = 2, parent = emotesGui.Selection.Slots, position = UDim2.new(0.5, 85, 0.5, 0)})
	emotes.selectionSlots["Slot3"] = emotes.gui_make_slot({index = 3, parent = emotesGui.Selection.Slots, position = UDim2.new(0.5, 0, 0.5, 85)})
	emotes.selectionSlots["Slot4"] = emotes.gui_make_slot({index = 4, parent = emotesGui.Selection.Slots, position = UDim2.new(0.5, -85, 0.5, 0)})
	-- Emote Purchasing
	
	local purchase_random_emote = emotesGui.Inventory.PurchaseRandom
	local pre_button: TextButton = purchase_random_emote.Button
	--
	pre_button.MouseEnter:Connect(function() 
		_G.PlayGuiSound("hover")
		framework.services.TweenService:Create(purchase_random_emote, TweenInfo.new(0.3, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {BorderColor3 = Color3.fromRGB(155, 55, 255), BackgroundColor3 = Color3.fromRGB(90, 45, 135), BorderSizePixel = 2}):Play()
	end)
	--
	pre_button.MouseLeave:Connect(function() 
		framework.services.TweenService:Create(purchase_random_emote, TweenInfo.new(0.3, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {BorderColor3 = Color3.fromRGB(100, 0, 200), BackgroundColor3 = Color3.fromRGB(30, 15, 45), BorderSizePixel = 1}):Play()
	end)
	--
	pre_button.MouseButton1Down:Connect(function() 
		task.spawn(function() 
			--
			emotes.isBusy = true
			local success = framework.networking.fromServer("PurchaseRandomEmote")
			emotes.isBusy = false
			--
			if (success) then
				_G.PlayGuiSound("shardconvert")
				_G.PlayGuiSound("successvar2")
				emotesGui.Inventory.BackgroundColor3 = Color3.fromRGB(15, 60, 15)
				emotesGui.Inventory.BorderColor3 = Color3.fromRGB(55, 255, 55)
				framework.services.TweenService:Create(emotesGui.Inventory, TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {BackgroundColor3 = Color3.fromRGB(15, 15, 15), BorderColor3 = Color3.fromRGB(255, 255, 255)}):Play()
			else
				_G.PlayGuiSound("error")
				emotesGui.Inventory.BackgroundColor3 = Color3.fromRGB(60, 15, 15)
				emotesGui.Inventory.BorderColor3 = Color3.fromRGB(255, 55, 55)
				framework.services.TweenService:Create(emotesGui.Inventory, TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {BackgroundColor3 = Color3.fromRGB(15, 15, 15), BorderColor3 = Color3.fromRGB(255, 255, 255)}):Play()
			end
			--
		end)
	end)
	-- End
end
--
function emotes.refresh()
	print("Emotes menu refreshed!")
	-- Selection Slots
	
	for slot_index, slot_data in pairs(emotes.selectionSlots) do
		local emote_in_slot = emotes.emotesEquipped[slot_index]
		--
		if (emote_in_slot ~= "") then
			--
			if (slot_data.animation) then
				slot_data.animation:Stop(0) slot_data.animation = nil end
			--
			local emote_data = emotesMedia[emote_in_slot]
			slot_data.slot.EmoteName.Text = (emote_data.display or "Undefined")
			slot_data.data = emote_data
			slot_data.emote = emote_in_slot
			slot_data.animation = slot_data.slot.Viewport.World.Rig.Humanoid:LoadAnimation(emote_data.animation)
			slot_data.animation:Play(0, 1, 0)
			slot_data.animation.TimePosition = 0
			print(string.format("Configured slot '%s' with emote '%s'", slot_index, emote_in_slot))
			--
		else
			--
			slot_data.data = nil
			slot_data.emote = ""
			slot_data.slot.EmoteName.Text = "Unselected"
			--
			if (slot_data.animation) then
				slot_data.animation:Stop(0) slot_data.animation = nil end
			--
		end
		--
	end
	-- Inventory Slots
	
	for _, slot in ipairs(emotes.inventorySlots) do
		framework.Gs.SafeDestroy(slot.slot.Parent)
		if (slot.emote_music) then slot.emote_music:Destroy() end
	end
	--
	local index = 0
	for emote, data in pairs(emotes.emotesOwned) do
		index += 1
		local slot_data = emotes.gui_make_slot({mode = "inventory", index = index, parent = emotesGui.Inventory.Slots, position = UDim2.new(0, 0, 0, 0)})
		table.insert(emotes.inventorySlots, slot_data)
		local emote_data = emotesMedia[emote]
		slot_data.emote = emote
		slot_data.data = emote_data
		slot_data.animation = slot_data.slot.Viewport.World.Rig.Humanoid:LoadAnimation(emote_data.animation)
		slot_data.animation:Play(0, 1, 0)
		slot_data.slot.EmoteName.Text = (emote_data.display or "Undefined")
	end
	--
end
--
function emotes.toggle(menu: string, forced: boolean)
	if (emotes.isBusy) then return end
	--
	if (emotes.menuOpen == "" or forced) then
		--
		if (emotes.menuOpen == "") then
			emotes.refresh()
		end
		--
		_G.PlayGuiSound("open")
		emotes.menuOpen = menu
		--
		emotesGui[(menu == "selection") and "Selection" or "Inventory"].Visible = true
		emotesGui[(menu == "selection") and "Inventory" or "Selection"].Visible = false
		--
	elseif (emotes.menuOpen ~= "") then
		_G.PlayGuiSound("close")
		emotes.menuOpen = ""
		emotes.inSelection = false
		emotes.selectionSlotChosen = nil
		emotesGui.Selection.Visible = false
		emotesGui.Inventory.Visible = false
	end
	--
end
--
return emotes