return { -- red scraps
	
	["Balisong"] = {
		Rarity = 2;
		Chance = 11; -- %
	};

	["Rambo"] = {
		Rarity = 3;
		Chance = 11; -- %
	};
	
	["Fire-Axe"] = {
		Rarity = 3;
		Chance = 9; -- %
	};
	
	["Machete"] = {
		Rarity = 3;
		Chance = 9; -- %
	};
	
	["Metal-Bat"] = {
		Rarity = 3;
		Chance = 9; -- %
	};
	
	["Chainsaw"] = {
		Rarity = 4;
		Chance = 8;
	};
	
	["M1911"] = {
		Rarity = 4;
		Chance = 9; -- %
	};
	
	["Deagle"] = {
		Rarity = 4;
		Chance = 8; -- %
	};
	["Uzi"] = {
		Rarity = 4;
		Chance = 8; -- %
	};
	
	["MAC-10"] = {
		Rarity = 4;
		Chance = 8; -- %
	};
	
	["Tommy"] = {
		Rarity = 4;
		Chance = 6;
	};

	["C4"] = {
		Rarity = 4;
		Chance = 4; -- %
	};
}