local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework")) -- 
--
local Calls = {}
--
Calls["NewTool"] = function(data)
	require(game:GetService("ReplicatedStorage").PlantsStorage.Objects.Tool).new(data[1], data[2])
end
--
Calls["Collar"] = function(daata)
	--
	local action=daata[1]
	local data=daata[2]
	--
	if action=="lock" then
		--
		local owner=data[1]
		local victim=data[2]
		--
		if not owner:FindFirstChild("Owns") then
			local ownsfolder=Instance.new("Folder",owner)
			ownsfolder.Name="Owns"
		end
		--
		if not owner.Owns:FindFirstChild(victim.Name) and not victim:FindFirstChild("_Collar") and not victim:GetAttribute("Collared") and owner:FindFirstChild("Right Arm") and victim:FindFirstChild("Head") then
			local ownedThing=Instance.new("ObjectValue",owner.Owns)
			ownedThing.Name=victim.Name
			victim:SetAttribute("Collared",owner.Name)
			--
			local collarModel=game.ServerStorage.PlantsStorage.Objects["_Collar"]:Clone()
			collarModel.Parent=victim
			local weld=Instance.new("Weld",collarModel)
			weld.Part0=victim.Head
			weld.Part1=collarModel.Middle
			--
			local att0=Instance.new("Attachment",owner["Right Arm"])
			att0.Position=Vector3.new(0, -1, 0)
			--
			local att1=collarModel.AttachmentPart.Attachment
			--
			framework.networking.toClients(nil,false,"Collar",{"Replicate",{att0,att1}})
			framework.networking.toClient(game:GetService("Players"):GetPlayerFromCharacter(victim),false,"Collar",{"lock",{owner}})
			--
			repeat
				game:GetService("RunService").Heartbeat:Wait()
			until (owner==nil or owner.Parent==nil) or (victim==nil or victim.Parent==nil) or not victim:GetAttribute("Collared") or victim.Humanoid.Health<=0 or owner.Humanoid.Health<=0
			--
			att0:Destroy()
			att1:Destroy()
			--
			collarModel:Destroy()
			--
			ownedThing:Destroy()
			if victim and victim.Parent then
				victim:SetAttribute("Collared",nil)
			end
		end
	elseif action=="unlock" then
		--
		local owner=data[1]
		local victim=data[2]
		--
		if owner.Owns:FindFirstChild(victim.Name) and victim:GetAttribute("Collared") then
			owner.Owns[victim.Name]:Destroy()
			victim:SetAttribute("Collared",nil)
		end
	end
	--
end
--
Calls["GoonRewards"] = function(data)
	--
	local TopPlr=data[1]
	local BottomPlr=data[2]
	--
	local TopChar=TopPlr.Character
	local BottomChar=BottomPlr.Character
	--
	if framework.Gs.SafeCheck({TopChar,BottomChar}) then
		--
		if not BottomChar:GetAttribute("GRewardCD") then
			BottomChar:SetAttribute("GRewardCD",true)
			--
			game.ServerStorage.Events3.nBount:Fire("KLGHJRKR90U3893KJZDGNKDFZJKNWU9023JKWRG02",TopPlr,50,true)
			game.ServerStorage.Events3.AyuP:Fire("KLJ8902209SANK8234LDFG0OKJAKA984231ZZ04LGXBNBZ1U912",TopPlr,800)
			--
			task.delay(180,function()
				BottomChar:SetAttribute("GRewardCD",nil)
			end)
			--
		end
	end
end
--
Calls["ApplyDeathLegitimacy"] = function(data)
	local char = data[1]
	local tag = data[2]
	local legit = data[3]
	local duration = data[4]
	--
	if (typeof(char) == "Instance") then char = char.Name end
	if (tag == nil) then tag = "LEGITMACY" end
	if (legit == nil) then legit = true end
	if (duration == nil) then duration = 3 end
	if (_G.GVF(char) == nil) then warn("No Valid VF Folder when applying death legitmacy.") return end
	--
	local vf = _G.GVF(char)
	local dl = vf.DeathLegitimacy
	--
	if (dl:FindFirstChild(tag)) then
		dl[tag]:Destroy() end
	--
	local legitmacy = _G.Create("BoolValue", tag, dl, {{"Value", legit}})
	local dduration = _G.Create("NumberValue", "Duration", legitmacy)
	dduration.Value = duration
	--
	task.spawn(function() 
		--
		repeat
			local d = task.wait()
			--
			if (vf and vf:FindFirstChild("Downed") and not vf.Downed.Value) then
				dduration.Value -= d end
			--
		until (vf == nil or vf.Parent == nil or legitmacy == nil or legitmacy.Parent == nil or dduration == nil or dduration.Parent == nil) or dduration.Value <= 0
		--
		_G.SafeDestroy(legitmacy)
	end)
	--
end
--
return Calls