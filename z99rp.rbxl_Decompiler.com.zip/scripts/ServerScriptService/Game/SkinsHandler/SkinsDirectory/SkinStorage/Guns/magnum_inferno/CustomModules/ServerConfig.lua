return function(config,tool)
	config.Customs = {
		["FlameHit"] = {
			Time = 1;
			DPS = 5;
		};
	}	
	
	config.HeadshotMultiplier *= 1.02
	config.Dropoff *= 1.2
	
	return config
end