-- CLIENT

local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
local globals = require(game:GetService("ReplicatedStorage").Modules.GetGlobals)
local characters = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Objects"):WaitForChild("Character"))
--
local grabbables = {
	--
	isM1Down = false,
	hasGrabbed = false,
	held = nil,
	holdRange = 0,
	mouseDelta = Vector2.zero,
	--
	hovered = nil,
	highlight = nil,
	--
}
--
function grabbables.init()
	--
	framework.services.RunService.Heartbeat:Connect(function(delta) 
		grabbables.update(delta)
	end)
	--
	framework.services.UserInputService.InputBegan:Connect(function(input, ge) 
		--
		if (ge) then return end
		local handler = characters.getCharacterBy(game.Players.LocalPlayer.Character)
		if (handler == nil) or (handler.character:FindFirstChildOfClass("Tool")) then return end
		--
		if (input.UserInputType == Enum.UserInputType.MouseButton1) then
			grabbables.isM1Down = true
			grabbables.grab()
		end
		--
	end)
	--
	framework.services.UserInputService.InputEnded:Connect(function(input) 
		if (input.UserInputType == Enum.UserInputType.MouseButton1) then
			grabbables.isM1Down = false
		end
	end)
	--
	framework.services.UserInputService.InputChanged:Connect(function(input) 
		--
		if (input.UserInputType == Enum.UserInputType.MouseMovement) then
			grabbables.mouseDelta = input.Delta
		end
		--
	end)
	--
end
--
function grabbables.removeHoverHighlight()
	if (grabbables.highlight) then
		framework.services.TweenService:Create(grabbables.highlight, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {OutlineTransparency = 1}):Play()
		globals.SafeDestroy(grabbables.highlight, 0.5)
		grabbables.highlight = nil
	end
end
--
function grabbables.grab()
	local handler = characters.getCharacterBy(game.Players.LocalPlayer.Character)
	if (handler == nil) or (grabbables.hasGrabbed or grabbables.hovered == nil) or (handler.character:FindFirstChildOfClass("Tool")) then return end
	--
	task.spawn(function() 
		--
		local grabbed: BasePart = grabbables.hovered
		local object: BasePart = grabbables.hovered
		local succ = game:GetService("ReplicatedStorage").PlantsStorage.Hooks.systems.grabbable:InvokeServer("grab", {object = grabbables.hovered})
		--
		if (not object:HasTag("Grabbable")) then
			if (object.Parent:HasTag("Grabbable")) then
				object = object.Parent
			end
		end
		--
		if (succ) then
			--
			grabbables.removeHoverHighlight()
			grabbables.hasGrabbed = true
			grabbables.held = grabbables.hovered
			--
			local ghl = globals.Create("Highlight", "hover", object, {{"Adornee", object}, {"FillTransparency", 1}, {"OutlineTransparency", 1}, {"OutlineColor", Color3.fromRGB(50, 50, 200)}})
			framework.services.TweenService:Create(ghl, TweenInfo.new(0.1, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {OutlineTransparency = 0.2}):Play()
			local at0: Attachment = globals.Create("Attachment", "at0", grabbed)
			local at1: Attachment = globals.Create("Attachment", "at1", workspace.Terrain, {{"WorldCFrame", grabbed.CFrame}, {"Visible", script:GetAttribute("DebugGoal")}})
			local ap = globals.Create("AlignPosition", "ap", grabbed, {{"Attachment0", at0}, {"Attachment1", at1}, {"Responsiveness", 100}, {"MaxForce", 1000}, {"MaxVelocity", 50}})
			local ao = globals.Create("AlignOrientation", "ao", grabbed, {{"Attachment0", at0}, {"Attachment1", at1}, {"Responsiveness", 100}, {"MaxTorque", 1000}, {"MaxAngularVelocity", 80}})
			grabbables.holdRange = (grabbed.Position - handler.character.Head.Position).Magnitude
			--
			local camera = workspace.CurrentCamera
			local isRotating = false
			local rotatingAffect = nil
			local anim = handler.humanoid:LoadAnimation(script.Grab)
			anim:Play(0.1)
			--
			repeat
				task.wait()
				--
				local inset = game:GetService("GuiService"):GetGuiInset().Y
				local mouse = game.Players.LocalPlayer:GetMouse()
				local ray = workspace.CurrentCamera:ViewportPointToRay(mouse.X, mouse.Y + inset)
				--
				local at1pos = handler.character.Head.Position + (ray.Direction.Unit * grabbables.holdRange)
				local at1dis = (at1pos - at0.WorldPosition).Magnitude
				local at1dir = (at1pos - at0.WorldPosition).Unit
				--
				local gaxis = object:GetAttribute("GrabbableAxis")
				if (gaxis) then
					local gdir = (object.CFrame.RightVector.Unit * gaxis.X) + (object.CFrame.UpVector.Unit * gaxis.Y) + (object.CFrame.LookVector.Unit * gaxis.Z)
					at1dir = globals.ConfineToAxis(at1dir, gdir)
					local npos = (at0.WorldPosition + at1dir)
					at1dis = (npos - at0.WorldPosition).Magnitude
				end
				--
				at1pos = (at0.WorldPosition + (at1dir.Unit * at1dis))
				at1.WorldPosition =  at1pos
				--
				if (game:GetService("UserInputService"):IsKeyDown(Enum.KeyCode.LeftAlt)) then
					--
					if (not isRotating) then
						isRotating = true
						rotatingAffect = _G.AffectChar("DISCAMPAN", math.huge)
					end
					--
					local right = camera.CFrame.RightVector
					local up = camera.CFrame.UpVector
					local rx = CFrame.fromAxisAngle(up, math.rad(grabbables.mouseDelta.X * 0.2))
					local ry = CFrame.fromAxisAngle(right, math.rad(grabbables.mouseDelta.Y * 0.2))
					local rotation = rx * ry
					local currentPos = at1.WorldPosition
					local rotatedCFrame = rotation * at1.WorldCFrame
					at1.WorldCFrame = CFrame.new(currentPos) * rotatedCFrame.Rotation
					grabbables.mouseDelta = Vector2.zero
					--
				else
					isRotating = false
					grabbables.mouseDelta = Vector2.zero
					globals.SafeDestroy(rotatingAffect)
				end
				--
			until (not object:GetAttribute("IsGrabbed") or not grabbables.isM1Down)
			--
			anim:Stop(0.3)
			framework.services.TweenService:Create(ghl, TweenInfo.new(0.3, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {OutlineTransparency = 1}):Play()
			globals.SafeDestroy(ghl, 0.3)
			globals.SafeDestroy({at0, at1, ap, ao, rotatingAffect})
			grabbables.hasGrabbed = false
			grabbables.held = nil
			--
			if (object:GetAttribute("IsGrabbed")) then
				task.spawn(function() 
					game:GetService("ReplicatedStorage").PlantsStorage.Hooks.systems.grabbable:InvokeServer("ungrab", {object = object})
				end)
			end
			--
		end
		--
	end)
	--
end
--
function grabbables.update(delta: number)
	local handler = characters.getCharacterBy(game.Players.LocalPlayer.Character)
	if (handler == nil) or (handler.character:FindFirstChildOfClass("Tool")) then return end
	--
	if (not grabbables.hasGrabbed) then
		--
		local inset = game:GetService("GuiService"):GetGuiInset().Y
		local mouse = game.Players.LocalPlayer:GetMouse()
		local ray = workspace.CurrentCamera:ViewportPointToRay(mouse.X, mouse.Y + inset)
		local range = (handler.character.Head.Position - workspace.CurrentCamera.CFrame.Position).Magnitude
		local results = framework.raycast(ray.Origin, ray.Origin + (ray.Direction.Unit*(10 + range)), game:GetService("CollectionService"):GetTagged("Grabbable"), {filterType = Enum.RaycastFilterType.Include, tags = {Grabbable = true, DefaultIgnore = false}}, false)
		--
		if (results) then
			--
			if (grabbables.hovered ~= results.Instance) then
				--
				grabbables.removeHoverHighlight()
				grabbables.hovered = results.Instance
				local object = results.Instance
				grabbables.highlight = globals.Create("Highlight", "hover", object, {{"Adornee", object}, {"FillTransparency", 1}, {"OutlineTransparency", 1}, {"OutlineColor", Color3.fromRGB(200, 200, 200)}})
				framework.services.TweenService:Create(grabbables.highlight, TweenInfo.new(0.3, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {OutlineTransparency = 0.2}):Play()
				--
			end
			--
		else
			grabbables.removeHoverHighlight()
			grabbables.hovered = nil
		end
		--
	end
	--
end
--
return grabbables