local TweenService = game:GetService("TweenService")
local ServerStorage = game:GetService("ServerStorage")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local M = {}

math.randomseed(tick() / 3)

M.Settings = {}

M.__index = M

M.ActiveBoxes = {}

local deepCopy = require(ReplicatedStorage.Modules.DeepCopy)

function M:Destroy(explode)
	if self.destroying then return end
	self.destroying = true
	
	self.active = false
	self.activeV.Value = false
	
	if explode then
		--self:Close()
		local a = Instance.new("Attachment")
		game.Debris:AddItem(a,15)
		a.Parent = workspace.Terrain
		a.WorldCFrame = self.mainPart.CFrame
		
		self.mainPart.Laugh.Parent = a
		
		local s = script.LeaveSound:Clone()
		s.Parent = a
		s:Play()
		
		--task.wait(0.25)
		
		local beamPart2 = script.BeamPart2:Clone()
		game.Debris:AddItem(beamPart2,1.15)
		beamPart2.CFrame = self.mainPart.CFrame + Vector3.new(0,2000,0)
		beamPart2.Parent = workspace.Debris
		
		TweenService:Create(beamPart2,TweenInfo.new(1.1,Enum.EasingStyle.Linear,Enum.EasingDirection.Out),{CFrame = self.mainPart.CFrame - Vector3.new(0,10,0)}):Play()
		
		--task.wait(0.5)
		
		if self.teddyModel and self.teddyModel.Parent then
			for i,v in pairs(self.teddyModel:GetChildren()) do
				if v:IsA("BasePart") then
					TweenService:Create(v,TweenInfo.new(0.7,Enum.EasingStyle.Quint,Enum.EasingDirection.In),{Transparency = 1;Color = Color3.new()}):Play()
				end
			end
		end
		
		self:Close()
		
		task.wait(0.5)
		
		--local s2 = script.StrikeSound:Clone()
		--s2.Parent = a
		--s2:Play()
		
		local l = self.model.FillParticle.SurfaceLight:Clone()
		l.Range *= 3
		l.Parent = self.model.FillParticle
		game.Debris:AddItem(l,0.15)
		
		local sa = self.mainPart.SpawnAttachment
		game.Debris:AddItem(sa,5)
		
		sa.Parent = workspace.Terrain
		sa.WorldCFrame = self.mainPart.CFrame
		sa.ParticleEmitter2:Emit(50)
		
		local exp = ServerStorage.Projectiles.MysteryBox_StrikeExplosion:Clone()
		exp.CFrame = self.mainPart.CFrame + Vector3.new(0,1,0)
		game.Debris:AddItem(exp,10)
		exp.Parent = workspace.Debris
		exp.Main.Disabled = false
	end
	
	self.destroyed = true
	
	self.destroyedEvent:Fire()
	
	self.model:Destroy()
	
	delay(2,function()
		self.destroyedEvent:Destroy()
		M.ActiveBoxes[self.model] = nil
		
		for i,v in pairs(self) do
			self[i] = nil
		end
		self = nil
	end)
end

local function CheckNotCap(player,found)
	if not found then return true end

	local inventoryCap = found:FindFirstChild("MaxBuy") and found.MaxBuy.Value
	if inventoryCap then
		local gotCount = 0
		local function check(c)
			for _,v in pairs(c:GetChildren()) do
				if v:IsA("Tool") and v.Name == found.Name then
					gotCount += 1
				end
			end
		end

		check(player.Character)
		check(player.Backpack)

		if gotCount + 1 > inventoryCap then
			return false
		end
	end

	return true
end

function M:TakeItem(player)
	--print(8888)
	if not self.active or not self.isOpen then return end
	--print(999)
	if not self.itemName then return end
	
	--print(12200)
	
	local itemName = self.itemName
	local actualTool = ServerStorage.Tools:FindFirstChild(itemName)
	
	if player ~= self.openPlayer then
		warn("MysteryBoxM: cant take item cause didnt buy it")
		return
	end
	
	if not actualTool then
		warn("MysteryBoxM: no tool found called:",itemName)
		return
	end
	
	local slotUsage = 0
	local iStats
	
	for _,z in pairs(ReplicatedStorage.Storage.ItemStats:GetDescendants()) do
		for _,v in pairs(z:GetChildren()) do
			if v.Name == itemName then
				iStats = v
				slotUsage = v.SlotUsage.Value
				break
			end
		end
	end
	
	local char = player.Character
	local vF = _G.GVF(player.Name)
	
	if not vF then
		warn("MysteryBoxM: no VF for player:",tostring(player))
		return
	end
	
	if vF.InventorySlots.Value + slotUsage > vF.InventorySlots.MaxValue then
		return false,"Item exceeds inventory slots!"
		--ReplicatedStorage.Events.ClientWarn:FireClient(player,{"Item exceeds inventory slots!",1,Color3.fromRGB(255, 121, 121),Color3.new(0,0,0),"lost"})  -- "You are over-encumbered!"
		--return	
	end
	
	if iStats and not CheckNotCap(player,iStats) then
		return false,"You cannot carry more of this item!"
		--ReplicatedStorage.Events.ClientWarn:FireClient(player,{"You cannot carry more of this item!",1,Color3.fromRGB(255, 121, 121),Color3.new(0,0,0),"lost"})  -- "You are over-encumbered!"
		--return
	end
	
	if iStats and iStats:FindFirstChild("ResupplyArmor") then
		if iStats.ResupplyArmor.Type.Value == "Head" and (_G.SMains.IsArmored(player.Character,"Head") or not require(iStats.BuyCheck)(player)) then
			return false, "Helmet slot in use!"
		elseif iStats.ResupplyArmor.Type.Value == "Body" and (_G.SMains.IsArmored(player.Character,"Torso") or not require(iStats.BuyCheck)(player)) then
			return false,"Vest slot in use!"			
		end
	end
	
	local tool = actualTool:Clone()
	tool:SetAttribute("StoreBought",true)
	tool:SetAttribute("CrateFound",true)
	tool:SetAttribute("MysteryBoxFound",true)
	
	tool.Parent = player.Backpack
	ServerStorage.Events3.AddBoughtTool:Fire(player,tool)
	ServerStorage.Events3.UpdateInv:Fire(player)
	
	self.itemGrabbed = true
	
	if char.Torso:FindFirstChild("Grab") then
		char.Torso.Grab:Play()
	end
	
	self.mainPart.Heartbeat:Play()
	
	char.Humanoid:UnequipTools()
	char.Humanoid:EquipTool(tool)
	
	return true
end

function M:Open(player)
	if self.isOpen then return end
	if not self.active then return end
	
	self.isOpen = true
	self.openPlayer = player
	self.playerV.Value = player
	self.openV.Value = true
	self.busyV.Value = true
	self.canTakeV.Value = false
	
	self.itemName = nil
	
	self.uses -= 1
	
	warn(player,"opened MysteryBoxM")
	
	local toolsFolder = ServerStorage.Tools
	
	local function DoClickS()
		local s = self.mainPart.Click:Clone()
		s.Parent = self.mainPart
		game.Debris:AddItem(s,0.5)

		s:Play()
	end
	
	local function OpenAnim()
		local inf = TweenInfo.new(1,Enum.EasingStyle.Quart,Enum.EasingDirection.Out)

		TweenService:Create(self.mainPart.Music.EqualizerSoundEffect,inf,{HighGain = 0;MidGain = 0;LowGain = 10}):Play()

		local cfOffset = CFrame.new(1,1,0) * CFrame.Angles(0,0,math.rad(-90))

		for i,v in pairs(self.topParts) do
			local t = TweenService:Create(v,inf,{CFrame = v.CFrame * cfOffset}):Play()
		end

		for i,v in pairs(self.model.FillParticle:GetChildren()) do
			if (v:IsA("Light") or v:IsA("ParticleEmitter")) and not v:GetAttribute("NoAuto") then
				v.Enabled = true
			end
		end

		self.mainPart.Open:Play()
	end
	
	local activeItems = deepCopy(M.Settings.LootPool)
	local activeModels = {}
	
	local d2 = {}
	
	local function GetActiveModels()
		local t2 = deepCopy(activeItems)
		
		if M.Settings.Custom1Percent then
			for i,v in pairs(M.Settings.Custom1Percent) do
				table.insert(t2,v)
			end
		end
		
		for i,v in pairs(t2) do
			if d2[v] then
				continue
			end
			
			d2[v] = true
			
			local oTool = ServerStorage.Tools:FindFirstChild(v)
			if not oTool then
				print("MysteryBoxHandler: no tool found for",v,", skipping")
				continue
			else
				local m = Instance.new("Model")

				local handle
				
				local isHelmet = table.find(M.Settings.ArmorItems,v)

				if isHelmet then
					handle = toolsFolder[v]:FindFirstChild("Parts") and toolsFolder[v].Parts:FindFirstChild("Head") and toolsFolder[v].Parts.Head:FindFirstChild("OriginPart")
				else
					handle = toolsFolder[v]:FindFirstChild("WeaponHandle") or toolsFolder[v]:FindFirstChild("Handle") or toolsFolder[v]:FindFirstChild("HHandle") or toolsFolder[v]:FindFirstChild("Handle1")
				end

				if handle and handle:IsA("BasePart") then
					local handle2 = toolsFolder[v]:FindFirstChild("Handle2")
					if handle then
						handle = handle:Clone()
						handle.Parent = m
						m.PrimaryPart = handle
					end
					if handle2 then
						if handle2:GetAttribute("NoSpawnItemClone") then
							handle2 = nil
						else
							handle2 = handle2:Clone()
							handle2.Parent = m
						end
					end

					local __X = {}
					

					if isHelmet then
						for i,v in pairs(toolsFolder[v].Parts.Head:GetChildren()) do
							if v:IsA("BasePart") and v.Name ~= handle.Name then
								v:Clone().Parent = m
							end
						end
						handle.Transparency = 1
					end

					for _,v in pairs(m:GetDescendants()) do
						if not v:IsA("BasePart") then
							if v:IsA("Weld") or v:IsA("ManualWeld") or  (v.Name ~= "IMW" and not v:FindFirstChildWhichIsA("BasePart") and not v:IsA("SpecialMesh")) then
								v:Destroy()
							end
						else
							v.Anchored = true
							v.CanCollide = false
							v.CanQuery = false
							v.CanTouch = false
							v.Massless = true
							
							v.Parent = m

							if v ~= handle then
	
								table.insert(__X,v)
							end
						end
					end		

					handle.CanQuery = false
					handle.Massless = true
					handle.Parent = nil
					
					m.Parent = workspace
					
					handle.CFrame = m:GetModelCFrame()
					
					handle.Parent = m
					
					m.PrimaryPart = handle
					
					m.Parent = nil
			
					for _,v in pairs(m:GetDescendants()) do
						if v:IsA("BasePart") then
							v.Parent = m
						end
					end
					
					for i,v in pairs(m:GetChildren()) do
						if v ~= handle and v:IsA("BasePart") and v.Transparency >= 1 then
							v:Destroy()
						end
					end
					
					for i,v in pairs(__X) do
						v.Anchored = true

						local w = Instance.new("ManualWeld")
						w.Name = "IMW"
						w.Part0 = handle
						w.Part1 = v
						w.C0 = v.CFrame:toObjectSpace(handle.CFrame):Inverse()

						w.Parent = handle
					end
					
					activeModels[v] = m
				end
			end
		end
	end

	local function ClearActiveModels()
		for i,v in pairs(activeModels) do
			v:Destroy()
		end
		activeModels = nil
		activeItems = nil
	end
	
	local function ChooseRandomItem()
		local item = activeItems[math.random(1,#activeItems)]
		
		local z = table.find(activeItems,item)
		if z then
			table.remove(activeItems,z)
		end
		
		return item
	end
	
	local function GetDisplayModel(itemName)
		local m = activeModels[itemName]:Clone()
		return m
	end
	
	local t1 = tick()
	
	GetActiveModels()
	
	--print(tick() - t1)
	
	OpenAnim()

	wait(0.25)

	local c = 25
	local w = 0.065
	local mult = 1.075
	--w *= 20

	local part = Instance.new("Part")
	part.Size = Vector3.new(1,1,1)
	part.CanCollide = false
	part.CanTouch = false
	part.CanQuery = false
	part.Anchored = true
	part.Transparency = 1
	part.Name = "_"

	part.CFrame = self.model.SpawnCF.CFrame

	part.Parent = self.model
	
	local tw
	tw = TweenService:Create(part,TweenInfo.new(4.5,Enum.EasingStyle.Quad,Enum.EasingDirection.Out),{CFrame = part.CFrame + Vector3.new(0,2,0)})
	tw:Play()

	local t = tick()
	
	local lastItem,lastItemModel
	
	for i = 1,c do
		local _s,_e = pcall(function()
			DoClickS()

			if lastItemModel and lastItemModel.Parent then
				lastItemModel:Destroy()
			end
			
			if self.justBlowUp then
				self.uses = 0
			end
			
			if i == c and self.nextTainted then
				lastItem = self.nextTainted
				
				print("got tainted",self.nextTainted)
				
				print(lastItem)
				
				self.nextTainted = nil
				
				
			elseif M.Settings.Custom1Percent and #M.Settings.Custom1Percent > 0 and i == c and math.random(1,200) == 1 then
				print("CUSTOM 1% HIT")
				lastItem = M.Settings.Custom1Percent[math.random(1,#M.Settings.Custom1Percent)]
			else
				lastItem = ChooseRandomItem()
			end

			lastItemModel = GetDisplayModel(lastItem)

			local nCF = part.CFrame * CFrame.Angles(0,math.rad(90),0)

			--print(lastItem)
			
			if M.Settings.LootOffset[lastItem] then
				--print("got offset!")
				nCF *= M.Settings.LootOffset[lastItem]
			end

			lastItemModel:SetPrimaryPartCFrame(nCF)

			local last,v = part,lastItemModel.PrimaryPart
			local we = Instance.new("Weld")
			we.Part0,we.Part1 = last,v
			we.C0 = v.CFrame:toObjectSpace(last.CFrame):inverse()
			we.Parent = last

			for i,v in pairs(lastItemModel:GetDescendants()) do 
				if v:IsA("BasePart") then
					v.CanCollide = false
					v.CanTouch = false
					v.CanQuery = false
					v.Anchored = false
				end
			end

			lastItemModel.Parent = workspace

			task.wait(w)
			w *= mult
		end)
		if not _s then
			warn("MysteryBoxM Error 5:",_e)
		end
	end
	
	self.itemModel = lastItemModel
	
	--print(tick() - t)	
	
	if tw then
		tw:Cancel()
	end
	
	if self.uses < 0 then
		self.active = false
		
		wait(math.random(75,105) / 100)
		
		if lastItemModel and lastItemModel.Parent then
			lastItemModel:Destroy()
		end
		ClearActiveModels()
		
		self.teddyModel = script.Teddy:Clone()
		self.teddyModel:SetPrimaryPartCFrame(part.CFrame)
		self.teddyModel.Parent = self.model
		
		self.teddyModel.PrimaryPart.Jumpscare:Play()

		self.model.FillParticle.Flame3:Emit(100)

		self.model.FillParticle.Flame2.Rate *= 5
		
		local l = self.model.FillParticle.SurfaceLight:Clone()
		l.Range *= 2
		l.Parent = self.model.FillParticle
		game.Debris:AddItem(l,0.15)
		
		delay(0.5,function()
			self.mainPart.Laugh:Play()
			
			for i,v in pairs(self.teddyModel:GetChildren()) do
				v.Anchored = false
			end
			
			local bv = Instance.new("BodyVelocity")
			bv.MaxForce = Vector3.new(10e10,10e10,10e10)
			bv.Velocity = Vector3.new(0,0,0)
			bv.P = 0.1
			
			local ba = Instance.new("BodyAngularVelocity")
			ba.MaxTorque = Vector3.new(50,50,50)
			ba.P = 1
			ba.AngularVelocity = Vector3.new(0,100,0)
			
			local bg = Instance.new("BodyGyro")
			bg.CFrame = part.CFrame
			bg.MaxTorque = Vector3.new(10e10,0,10e10)
			
			ba.Parent = self.teddyModel.PrimaryPart
			bv.Parent = self.teddyModel.PrimaryPart
			bg.Parent = self.teddyModel.PrimaryPart
			
			TweenService:Create(bv,TweenInfo.new(4,Enum.EasingStyle.Quart,Enum.EasingDirection.In,0,false,0.5),{Velocity = Vector3.new(0,10,0)}):Play()
		end)
		
		wait(2.5)
		part:Destroy()
		
		self:Destroy(true)
	else
		tw = TweenService:Create(part,TweenInfo.new(M.Settings.ItemDespawnTime - 1,Enum.EasingStyle.Linear,Enum.EasingDirection.InOut,0,false,1),{CFrame = part.CFrame - Vector3.new(0,2.25,0)})
		tw:Play()
		self.tw = tw
		
		self.canTakeV.Value = true
		
		self.itemName = lastItem
		self.model.FillParticle.Flame4:Emit(10)
		self.mainPart.Flame2:Play()
		
		if lastItemModel and lastItemModel.Parent then
			local h = Instance.new("Highlight")
			h.FillTransparency = 1
			h.OutlineTransparency = 1
			
			h.FillColor = Color3.fromRGB(255, 255, 0) -- Color3.fromRGB(179, 0, 255)
			
			h.Adornee = lastItemModel
			h.Parent = lastItemModel
			h.DepthMode = Enum.HighlightDepthMode.Occluded
			
			game.Debris:AddItem(h,2)
			
			TweenService:Create(h,TweenInfo.new(0.25,Enum.EasingStyle.Quint,Enum.EasingDirection.Out,0,true),{FillTransparency = 0}):Play()
		end
		
		self.canTakeItem = true
		
		local tim = tick()
		
		repeat task.wait(0.2)
			
		until tick() - tim >= M.Settings.ItemDespawnTime or self.itemGrabbed
		
		self.itemGrabbed = false
		self.canTakeItem = false
		self.openPlayer = nil
		self.playerV.Value = nil
		self.canTakeV.Value = false
		
		if lastItemModel and lastItemModel.Parent then
			lastItemModel:Destroy()
		end
		part:Destroy()
		
		ClearActiveModels()
		self:Close()
	end

	self.isOpen = false
	
	if self.active then
		delay(M.Settings.CooldownTime,function()
			self.busyV.Value = false
		end)
	end
end

function M:Close()
	if self.destroyed then return end
	if not self.isOpen then return end
	
	self.isOpen = false
	self.openV.Value = false
	
	local function CloseAnim()
		local inf = TweenInfo.new(1,Enum.EasingStyle.Quart,Enum.EasingDirection.In,0,false,0.1)
		local inf2 = TweenInfo.new(0.5,Enum.EasingStyle.Quint,Enum.EasingDirection.In)

		delay(0.25,function()
			self.mainPart.Close:Play()
		end)

		TweenService:Create(self.mainPart.Music.EqualizerSoundEffect,inf,{HighGain = self.originHighGain;MidGain = self.originMidGain;LowGain = self.originLowGain}):Play()

		for i,v in pairs(self.topParts) do
			local t = TweenService:Create(v,inf2,{CFrame = self.originCFs[v]}):Play()
		end

		for i,v in pairs(self.model.FillParticle:GetChildren()) do
			if (v:IsA("Light") or v:IsA("ParticleEmitter")) then
				v.Enabled = false
			end
		end
	end
	
	CloseAnim()
end

M.new = function(spawnFolder)
	if not M.isSetUp then
		warn("MysteryBoxHandler NewBox, not SetUp?")
		return
	end	
	
	if M.ActiveBoxes[spawnFolder] then
		warn("Box already active here!")
		return
	end
	
	local self = {}
	setmetatable(self, M)
	
	self.spawnFolder = spawnFolder
	self.model = script.MysteryBox:Clone()
	self.mainPart = self.model.PrimaryPart

	M.ActiveBoxes[self.model] = self
	
	local eventsF = Instance.new("Folder")
	eventsF.Name = "Events"
	
	self.openEvent = Instance.new("BindableEvent")
	self.openEvent.Name = "Open"
	self.openEvent.Parent = eventsF

	self.takeEvent = Instance.new("BindableEvent")
	self.takeEvent.Name = "Take"
	self.takeEvent.Parent = eventsF
	
	local valuesF = Instance.new("Folder")
	valuesF.Name = "Values"
	
	self.priceV = Instance.new("IntValue")
	self.priceV.Name = "Price"
	self.priceV.Parent = valuesF
	
	self.activeV = Instance.new("BoolValue")
	self.activeV.Name = "Active"
	self.activeV.Value = true
	self.activeV.Parent = valuesF
	
	self.busyV = Instance.new("BoolValue")
	self.busyV.Name = "Busy"
	self.busyV.Value = false
	self.busyV.Parent = valuesF
	
	self.openV = Instance.new("BoolValue")
	self.openV.Name = "Open"
	self.openV.Value = false
	self.openV.Parent = valuesF
	
	self.canTakeV = Instance.new("BoolValue")
	self.canTakeV.Name = "CanTake"
	self.canTakeV.Value = false
	self.canTakeV.Parent = valuesF
	
	self.playerV = Instance.new("ObjectValue")
	self.playerV.Name = "UsePlayer"
	self.playerV.Value = nil
	self.playerV.Parent = valuesF

	valuesF.Parent = self.model	
	eventsF.Parent = self.model
	
	local music = self.mainPart.Music
	local equalizer = music.EqualizerSoundEffect
	
	self.priceV.Value = M.Settings.Price
	
	self.setUses = math.random(M.Settings.Uses[1],M.Settings.Uses[2])
	self.uses = self.setUses
	
	self.originHighGain,self.originLowGain,self.originMidGain = equalizer.HighGain,equalizer.LowGain,equalizer.MidGain
	
	self.model:SetPrimaryPartCFrame(self.spawnFolder.SpawnPart.CFrame)
	self.model.Parent = workspace.Map.MysteryBoxes

	self.topParts = {self.model.Parts.crate_top;self.model.Parts.crate_top.Q}
	self.originCFs = {}
	for i,v in pairs(self.topParts) do
		self.originCFs[v] = v.CFrame
	end

	--local function MainFunc()
	--	self:Open()
	--	wait(3)
	--	self:Close()
	--end
	--spawn(function()
	--	while wait(3) do
	--		MainFunc()
	--	end
	--end)
	
	self.destroyedEvent = Instance.new("BindableEvent")
	
	self.openEvent.Event:Connect(M.Open)
	self.takeEvent.Event:Connect(M.TakeItem)
	
	music:Play()
	self.mainPart.Spawn:Play()
	self.mainPart.SpawnAttachment.ParticleEmitter:Emit(100)

	self.mainPart.SpawnAttachment.PointLight.Enabled = true
	game.Debris:AddItem(self.mainPart.SpawnAttachment.PointLight,0.35)
	
	self.active = true
	warn("MYSTERY BOX SPAWNED, USES:",self.uses)
	
	ServerStorage.Events3.MysteryBox_Taint.Event:Connect(function(arg,arg2)
		if self.active then
			self.nextTainted = arg
			self.justBlowUp = arg2 == true
		end
	end)
	
	return self
end

M.SetUp = function(boxSettings)
	if M.isSetUp then return end
	
	M.Settings = boxSettings
	
	M.isSetUp = true	
end


return M