return function()
	--[[ InGameExplorer Server 

	READ InGameExplorer.README for setup instructions!
	
]]

	local HttpService = game:GetService("HttpService")

	local LogService = game:GetService("LogService")
	local ReplicatedFirst = game:GetService("ReplicatedFirst")
	local ReplicatedStorage = game:GetService("ReplicatedStorage")
	local RunService = game:GetService("RunService")
	local Players = game:GetService("Players")

	--[[ Periodically retry getting the latest API dump ]]

	warn("Fetching latest API dump for In-Game explorer. Make sure Http Requests are enabled! This won't work without it!")

	local APIDump
	while true do
		success,APIDump = pcall(function() return HttpService:GetAsync("https://github.com/MaximumADHD/Roblox-Client-Tracker/raw/roblox/API-Dump.json") end)
		if success and APIDump then
			APIDump = HttpService:JSONDecode(APIDump)
			break
		end
		task.wait(1)
	end

	local Reflection
	while true do
		success,Reflection = pcall(function() return HttpService:GetAsync("https://raw.githubusercontent.com/MaximumADHD/Roblox-Client-Tracker/roblox/ReflectionMetadata.xml") end)
		if success and Reflection then
			break
		end
		task.wait(1)
	end
	warn("Fetched latest API dump for In-Game explorer")


	print("Server InGameExplorer loaded")

	local Internal = script.Internal
	local InGameExplorerShared = Instance.new("Folder",ReplicatedStorage)
	InGameExplorerShared.Name = "InGameExplorer_Shared"
	script.Keybind.Parent = InGameExplorerShared
	local RepShared = Internal.InGameExplorerShared

	local Maid = require(RepShared.Maid)
	local loadString = require(Internal.ClientReplicatorHandler.vLuau)
	local LogShared = require(RepShared.LogShared)

	RepShared.LogShared.Parent = InGameExplorerShared

	RepShared.Parent = InGameExplorerShared

	local ReplicatorModule = Internal.Replicator
	ReplicatorModule.Parent = InGameExplorerShared

	local Replicator = require(ReplicatorModule)

	RepShared = require(RepShared)


	local RemoteFunction = Instance.new("RemoteFunction")
	RemoteFunction.Parent = InGameExplorerShared
	RemoteFunction.Name = "InGameExplorer_RemoteFunction"

	local RemoteEvent = Instance.new("RemoteEvent")
	RemoteEvent.Parent = InGameExplorerShared
	RemoteEvent.Name = "InGameExplorer_RemoteEvent"

	--[[ Parse API dump ]]
	local ExplorerOrder = {}
	for match in Reflection:gmatch("<Properties>(.-)</Properties>") do
		local name = match:match([=[<string name="Name">(.-)</string>]=])
		local order = match:match([=[<string name="ExplorerOrder">(.-)</string>]=])
		if name and order then
			ExplorerOrder[name] = order
		end
	end
	local Classes = {}
	local Enums = {}
	for i,class in APIDump.Classes do
		Classes[class.Name] = class
	end
	for i,enum in APIDump.Enums do
		local items = {}
		for i,v in enum.Items do
			table.insert(items,v.Name)
		end
		Enums[enum.Name] = items
	end

	for className,class in Classes do
		local properties = {}
		for i,property in class.Members do 
			if property.MemberType ~= "Property" then
				continue
			end
			local Tags = property.Tags
			if Tags then
				local temp = {}
				for i,v in Tags do 
					temp[v] = true
				end
				Tags = temp
			end
			local name = property.Name
			properties[name] = {property.Category,property.ValueType.Name,Tags,name}
		end
		table.sort(properties,function(a,b) return a.name < b.name end)
		class.Properties = properties
	end
	for className,class in Classes do
		local explorerOrder = ExplorerOrder[className]
		if explorerOrder then
			class.ExplorerOrder = explorerOrder
		end
		local categorizedProperties = {}
		local properties = class.Properties
		local superClass = class 
		while true do
			if not superClass.Superclass then
				break
			end
			superClass = Classes[superClass.Superclass]
			if not superClass then
				break
			end
			for i,v in superClass.Properties do 
				properties[i] = v
			end
		end

		local map = {}
		for propertyName,v in properties do
			local category,valueType,Tags,name = unpack(v)
			local categoryList = map[category]
			if not categoryList then
				categoryList = {}
				map[category] = categoryList
			end
			table.insert(categoryList,{propertyName = propertyName,valueType = valueType,tags = Tags})
		end

		for category,list in map do
			table.sort(list,function(a,b) return a.propertyName < b.propertyName end)
			table.insert(categorizedProperties,{name = category,list = list})
		end

		table.sort(categorizedProperties,function(a,b) return a.name < b.name end)
		class.Categorized_Properties = categorizedProperties
	end
	--

	local function ChildSortFunction(a, b)
		local aClass = a.ClassName and Classes[a.ClassName]
		local bClass = b.ClassName and Classes[b.ClassName]

		local aOrder = tonumber((aClass and aClass.ExplorerOrder) or 2^53)
		local bOrder = tonumber((bClass and bClass.ExplorerOrder) or 2^53)

		return if aOrder ~= bOrder then aOrder < bOrder else a.Name < b.Name
	end


	local PermissionsFunction = require(script.Permissions)

	local ServerReplicator = Replicator.new(RemoteEvent,RemoteFunction,Classes,RepShared)
	ServerReplicator.Server = true

	local Replicators = {
		ServerReplicator
	}


	local AdminReplicators = {}
	local AdminConsolesEnabled = {}

	local function playerAdded(player)
		AdminReplicators[player] = nil
		local screenGui = Instance.new("ScreenGui")
		screenGui.Name = "InGameExplorerClient"
		screenGui.ResetOnSpawn = false
		screenGui.Parent = player.PlayerGui
		Internal.ClientReplicatorHandler:Clone().Parent = screenGui
		if PermissionsFunction(player) then
			Internal.InGameExplorerClient:Clone().Parent = screenGui
		end
	end

	Players.PlayerAdded:Connect(playerAdded)
	for i,player in Players:GetPlayers() do
		playerAdded(player)
	end
	Players.PlayerRemoving:Connect(function(player)
		AdminReplicators[player] = nil
		for i,replicator in Replicators do 
			replicator:StopListening(player,nil)
			if replicator.Owner == player then
				replicator:Cleanup()
				local index = table.find(Replicators,replicator)
				if index then
					table.remove(Replicators,index)
				end
			end
		end
	end)

	local function validTarget(player)
		local playerFound
		local potentialAdmins = {}
		for admin,replicator in AdminReplicators do 
			if replicator.replicator == player then
				playerFound = true
				potentialAdmins[admin] = true
			end
		end
		return playerFound, potentialAdmins
	end
	RemoteEvent.OnServerEvent:Connect(function(player,message,...)
		if typeof(message) ~= "string" then
			return
		end

		if message == "InitHistory" then
			local admin,history = ... 

			local replicator = AdminReplicators[admin] 
			if replicator and replicator.replicator == player then
				RemoteEvent:FireClient(admin,"LogHistory",history)
			end
		elseif message == "LogHistoryEntry" then
			local admin,entry = ... 

			local replicator = AdminReplicators[admin] 
			if replicator and replicator.replicator == player then
				RemoteEvent:FireClient(admin,"LogHistoryEntry",entry)
			end
		end


		if message == "SendCode" then
			local admin = player 
			if not admin:IsA("Player") then
				return
			end
			if not PermissionsFunction(admin) then
				return
			end

			local replicator = AdminReplicators[admin]
			if replicator then
				if replicator.replicator == ServerReplicator then
					loadString(...)()
				else
					RemoteEvent:FireClient(replicator.replicator,admin,"SendCode",...)
				end
			end
			return
		end


		if message == "SetReplicator" then

			local admin = player 
			if not admin:IsA("Player") then
				return
			end
			if not PermissionsFunction(admin) then
				return
			end

			local playerName = ... 

			local replicator = AdminReplicators[player]
			if replicator then
				replicator.maid:Cleanup()

				if replicator.replicator ~= ServerReplicator then
					RemoteEvent:FireClient(replicator.replicator,admin,"AdminStoppedListening")
				end

				replicator = nil
			end

			if playerName == "Server" or playerName == player.Name then	
				replicator = ServerReplicator
			elseif playerName then
				local playerFound = Players:FindFirstChild(playerName)
				if playerFound then
					replicator = playerFound
				end
			end

			if replicator then
				local server
				if replicator ~= ServerReplicator then
					RemoteEvent:FireClient(replicator,admin,"StartListening",nil)
				else
					server = true
					ServerReplicator.StartListening(ServerReplicator,admin,nil)
				end
				replicator = {
					replicator = replicator,
					maid = Maid.new()
				}

				if server then
					local logHistory = LogShared:GetHistory()
					RemoteEvent:FireClient(player,"LogHistory",logHistory)
					LogShared:AddEvent(replicator.maid,function(entry)
						RemoteEvent:FireClient(player,"LogHistoryEntry",entry)
					end)
				else
					RemoteEvent:FireClient(replicator.replicator,admin,"AdminListen")
				end
				AdminReplicators[player] = replicator 
			end	
			return
		end

		if message == "FireClient" then		
			local playerFound, potentialAdmins = validTarget(player)
			local allowedSecondArguments = {"Update", "Init", "Remove", "OpenProperties"}
			if playerFound then
				local args = {...}
				-- logic checking to ensure they're playing nice
				local admin, proxyMessage = ...
				-- Just to make sure they at least exist
				if not admin or not proxyMessage then
					return
				end
				-- Ensure they're passing a player through
				if typeof(admin) ~= 'Instance' or not admin:IsA("Player") then
					return
				end
				-- Ensure they pass a legit admin through
				if not potentialAdmins[admin] then
					return
				end
				-- Lock them to specific pre-set arguments 
				if typeof(proxyMessage) ~= "string" or not table.find(allowedSecondArguments, proxyMessage) then
					return
				end

				-- Now they're good to go, send it through! 
				RemoteEvent:FireClient(admin, proxyMessage, select(3,unpack(args)))
			end
			return
		else
			local admin = player 
			if not admin:IsA("Player") then
				return
			end
			if not PermissionsFunction(admin) then
				return
			end

			local replicatorOwner = AdminReplicators[admin]

			if replicatorOwner then
				if replicatorOwner.replicator ~= ServerReplicator then
					RemoteEvent:FireClient(replicatorOwner.replicator,admin,message,...)
				else
					if ServerReplicator[message] then
						ServerReplicator[message](ServerReplicator,player,...)
					end
				end
			end
		end
	end)
	RemoteFunction.OnServerInvoke = function(admin)
		if not admin:IsA("Player") then
			return
		end
		return {Classes,Enums}
	end

end