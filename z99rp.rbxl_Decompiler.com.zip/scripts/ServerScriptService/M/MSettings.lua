return {
	KickBanned = true;
}