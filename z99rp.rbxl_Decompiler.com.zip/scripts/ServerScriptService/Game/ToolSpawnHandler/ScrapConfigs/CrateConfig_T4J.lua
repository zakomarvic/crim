return { -- grey crates
	
	["MaxItems"] = 4;
	["ReRollRate"] = 40;
	
	["StoredAmmo_TakePerc"] = {0,33}; -- Up to this % of the stored ammo can be taken
	["Ammo_TakePerc"] = {0,0}; -- Up to this % of the ammo can be taken
	
	["ItemsTable"] = {
		--["__NecromancerKit"] = {
		--	Chance = 1;
		--	Weight = 100;
		--	IsHelmet = true;
		--	IsVest = true;
		--	MaxDrops = 1;
		--	CustomSlotUsage = 9;
		--};
		
		--// armor
		
		["HelmetB_2"] = {
			Chance = 9;
			Weight = 35;
			IsHelmet = true;
			MaxDrops = 1;
		};
		["VestB_2"] = {
			Chance = 9;
			Weight = 50;
			IsVest = true;
			MaxDrops = 1;
		};
		
		["VestB_3"] = {
			Chance = 2;
			Weight = 70;
			IsVest = true;
			MaxDrops = 1;
		};
		
		
		--// guns 
		["M1911"] = {
			Chance = 8;
			Weight = 34;
			IsGun = true;
			MaxDrops = 1;
		};

		["Deagle"] = {
			Chance = 8;
			Weight = 34;
			IsGun = true;
			MaxDrops = 1;
		};

		["Magnum"] = {
			Chance = 8;
			Weight = 34;
			IsGun = true;
			MaxDrops = 1;
		};
		
		["FNP-45"] = {
			Chance = 8;
			Weight = 34;
			IsGun = true;
			MaxDrops = 1;
		};
		
		["G-18"] = {
			Chance = 6;
			Weight = 34;
			IsGun = true;
			MaxDrops = 1;
		};

		
		----
		

		["M4A1-1"] = {
			Chance = 6 * 1.5;
			Weight = 51;
			IsGun = true;
			MaxDrops = 1;
		};

		["Mare"] = {
			Chance = 6;
			Weight = 51;
			IsGun = true;
			MaxDrops = 1;
		};
		
		["M320-1"] = {
			Chance = 6;
			Weight = 51;
			IsGun = true;
			MaxDrops = 1;
		};

		["Scout"] = {
			Chance = 6;
			Weight = 51;
			IsGun = true;
			MaxDrops = 1;
		};
		
		["AWP"] = {
			Chance = 5;
			Weight = 65;
			IsGun = true;
			MaxDrops = 1;
		};
		
		["BFG-1"] = {
			Chance = 3;
			Weight = 80;
			IsGun = true;
			MaxDrops = 1;
		};
		
		["Photon-Alternator"] = {
			Chance = 2;
			Weight = 80;
			IsGun = true;
			MaxDrops = 1;
		};
		
		----

		
		["G-18-X"] = {
			Chance = 6;
			Weight = 34;
			IsGun = true;
			MaxDrops = 1;
		};

		["M4A1-S"] = {
			Chance = 6 * 1.5;
			Weight = 51;
			IsGun = true;
			MaxDrops = 1;
		};
		
		["SCAR-H-X"] = {
			Chance = 6;
			Weight = 51;
			IsGun = true;
			MaxDrops = 1;
		};
		
		["FireworkLauncher"] = {
			Chance = 6 * 4;
			Weight = 1;
			IsGun = true;
			MaxDrops = 1;
		};
		
		

		--["CursedDagger"] = {
		--	Chance = 2;
		--	Weight = 60;
		--	--IsGun = false;
		--	MaxDrops = 1;
		--};
		---------------------
		
		--v 83%
		--// melees
		
		--["Fire-Axe"] = {
		--	Chance = 10;
		--	Weight = 65;
		--};
		
		--["Rambo"] = {
		--	Chance = 10;
		--	Weight = 35;
		--};
		
		--["Metal-Bat"] = {
		--	Chance = 10;
		--	Weight = 65;
		--};
		
		--["Machete"] = {
		--	Chance = 10;
		--	Weight = 65;
		--};
		
		--["Katana"] = {
		--	Chance = 10;
		--	Weight = 65;
		--};

		--["Chainsaw"] = {
		--	Chance = 10;
		--	Weight = 65;
		--};
		---------------------
		
		
		--// throwables
		
		["Molotov"] = {
			Chance = 10;
			Weight = 10;
		};
		["Smoke-Grenade"] = {
			Chance = 10;
			Weight = 10;
		};
		["Grenade"] = {
			Chance = 10;
			Weight = 10;
		};
		["Flashbang"] = {
			Chance = 10;
			Weight = 10;
		};
		["CS-Grenade"] = {
			Chance = 10;
			Weight = 10;
		};
		["Stun-Grenade"] = {
			Chance = 10;
			Weight = 10;
		};
		["Incendiary-Grenade"] = {
			Chance = 10;
			Weight = 10;
		};
		["C4"] = {
			Chance = 10;
			Weight = 15;
			MaxDrops = 2;
		};
		--
		
		--// Extras
		
		["X24"] = {
			Chance = 10;
			Weight = 10;
			MaxDrops = 1;
		};
		--
		["L-X"] = {
			Chance = 10;
			Weight = 10;
			MaxDrops = 1;
		};
	};
}