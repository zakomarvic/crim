local M = {}

local ServerStorage = game:GetService("ServerStorage")

M.TypeModules = {}
M.ConvulseM = require(script.Convulse)

local function Lerp(a, b, c)
	return a + ((b - a) * c)
end

function M.new(Config,char,infectedType)
	local plr = game.Players:GetPlayerFromCharacter(char)
	local hum = char.Humanoid
	
	if hum:GetAttribute("NoRandomAvatar") then
		if not plr:HasAppearanceLoaded() then
			plr.CharacterAppearanceLoaded:Wait(2)
		end
	elseif not hum:GetAttribute("HasRandomAvatar") then
		hum:GetAttributeChangedSignal("HasRandomAvatar"):Wait(2)
	end
	
	hum:SetAttribute("NoInteract",true)
	hum:SetAttribute("NoDeathIcon",true)
	hum:SetAttribute("Infected_ExplodeHead",true)
	hum:SetAttribute("InfectedType",infectedType)
	
	hum:SetAttribute("N_WTR_SD",true) -- no sewer water slowdown
	
	hum:SetAttribute("REGEN_STEP",Config.INFECTED_REGEN_STEP)
	hum:SetAttribute("REGEN_RATE",Config.INFECTED_REGEN_RATE)
	
	hum:SetAttribute("NoOnFireAnim",true)
	char:SetAttribute("N_RGP_H",true)
	char:SetAttribute("IsInfected",true)
	
	local vF = _G.GVF(char.Name)
	
	if vF then
		vF.NoDowned.Value = true
		vF.InventorySlots.MaxValue = 0
		vF.InventorySlots.Value = 0
		
		local function createV(name,value)
			local v
			if typeof(value) == "Color3" then
				v = Instance.new("Color3Value")
			else
				v = Instance.new("NumberValue")
			end

			v.Name = name
			v.Value = value
			v.Parent = vF.Currents
		end

		createV("CC_Saturation",-0.5)
		createV("CC_Contrast",1)
		createV("CC_Brightness",0.65)
		createV("CC_DenseAdd",-0.3)
		createV("CC_TintColor",Color3.fromRGB(255,193,193))
		createV("CLMB_SD",Config.INFECTED_CLIMB_SD)
		
		createV("SRV_SD_",-10)

		_G.AffectChar(char,"B",math.huge)
	end
	
	if plr:FindFirstChild("Backpack") then
		plr.Backpack:WaitForChild("Fists"):Destroy()
	end
	if plr.Backpack:FindFirstChild("Radio") then
		plr.Backpack.Radio:Destroy()
	end
	
	if hum:GetAttribute("HasRandomAvatar") then
		local anim = hum:LoadAnimation(script.ShakeAnim)
		anim:Play(0.5,0.05,1)
		anim:SetAttribute("IsShakeAnim",true)
	end
	
	local dd = false
	
	hum.Died:Connect(function()
		if dd then return end
		dd = true
		
		local hl = Instance.new("Highlight")
		hl.DepthMode = Enum.HighlightDepthMode.Occluded

		hl.OutlineTransparency = 1
		hl.FillColor = Color3.new(0,0,0)

		hl.FillTransparency = 1

		hl.Parent = char
		hl.Adornee = char
		
		for i,v in pairs(hum:GetAccessories()) do
			for _,z in pairs(v:GetDescendants()) do
				if z:IsA("BasePart") and z:GetAttribute("IsEyePart") then
					z.Color = Color3.new(0,0,0)
				end
			end
		end

		game:GetService("TweenService"):Create(hl,TweenInfo.new(1,Enum.EasingStyle.Linear,Enum.EasingDirection.Out),{FillTransparency = 0.25}):Play()
		
		if Config.InfecedExplode and Config.InfecedExplode.Enabled and not hum:GetAttribute("IsRagerInfected") then
			local MPLAYERS = (ServerStorage.Values:FindFirstChild("MaxPlayers") and ServerStorage.Values.MaxPlayers.Value) or game.Players.MaxPlayers
			local PLAYER_COUNT = #game.Teams.Infected:GetPlayers()

			local c = PLAYER_COUNT / MPLAYERS

			if Config.ForceMaxInfectedCountThing then
				c = 1
			else
				c = math.clamp(1 - c,0,1)
				c = 1 - c
			end

			local MIN,MAX = Config.InfecedExplode.Chance[1],Config.InfecedExplode.Chance[2]

			local chosenChance = Lerp(MIN,MAX,c)
			chosenChance = math.floor(chosenChance)
			chosenChance = math.max(chosenChance,1)
			local chosenRandom = math.random(1,chosenChance)
			
			if math.random(1,chosenRandom) == 1 then
				--print("convulse",1)
				plr:SetAttribute("RespawningPaused",true)
				
				task.wait(math.random(Config.InfecedExplode.Delay[1] * 100,Config.InfecedExplode.Delay[2] * 100) / 100)
				
				if plr.Parent and char.Parent then
					--print("convulse",2)
					M.ConvulseM(char,infectedType)

					if plr.Parent then
						plr:SetAttribute("RespawningPaused",nil)
					end
				end
			end
		end	
	end)
	
	if script.TypeModules:FindFirstChild(infectedType) then
		if not M.TypeModules[infectedType] then
			M.TypeModules[infectedType] = require(script.TypeModules[infectedType])
		end
		M.TypeModules[infectedType].new(char)
	else
		warn("No infected type:",infectedType)
	end
end

return M