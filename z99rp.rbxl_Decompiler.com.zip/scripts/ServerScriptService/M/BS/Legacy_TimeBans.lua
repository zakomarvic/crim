return {
	{
		EndTime = 2247230605;
		Name = "evilteddybear13";
		Reason = "Exploiting";
		StartTime = 1616510605;
		UserId = 7548981
	}
}