local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local dependencies: types.client_dependencies = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Dependencies"))
local character = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Objects"):WaitForChild("Character"))
--
return function()
	game:GetService("RunService").Heartbeat:Connect(function(delta) 
	end)
end
--