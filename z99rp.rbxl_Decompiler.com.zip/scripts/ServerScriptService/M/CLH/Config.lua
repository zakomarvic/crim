


return {
	Command =	"n";
	Command2 =	"n";
	Command4 =	"n";
	Command3 = "n";

	Mod		=	"n";
	Ban = 		"n";

	Unban = 		"n";
	AutoUnban = 	"n";

	Buy 	=	"n";
	GiftProduct = "n";
	FailedPurchaseLog = "n";

	Money 	=	"n";

	Exploit =	"n";
	Movement =	"n";

	AntiBan =	"n";
	BanWave = "n";

	Barcode =	"n";	
	Sus = 		"n";

	Test =		"n";

	Report =	"n";

	NewReport_Feed =			"n";
	NewReport_MultiLog =		"n";

	NewReport_Feed_Prime =		"n";
	NewReport_MultiLog_Prime =	"n";

	NewReport_TimeOut_Prime =	"n";
	NewReport_TimeOut =			"n";

	Data =		"n";

	Dupe = "n";

	TimeOut_Expire = 	"n";

	AltRestrict = "n";

	Blackout = "n";

	Perms = "n";

	AutoUnWarn = "n";

	Warn = "n";

	BountyClaim = "n";

	SafeFarm = "n";
	AltKillFarm = "n";	

	ShopUnlockLog = "n";

	-----

	Cosmetics_CaseCreated = "n";
	Cosmetics_CasePurchased = "n";
	Cosmetics_CaseUnbox = "n";
	Cosmetics_CaseUnbox2 = "n";
	Cosmetics_CaseSpawned = "n";
	Cosmetics_ItemSold = "n";
	Cosmetics_ItemSold2 = "n";
	Cosmetics_LimitedUnboxed = "n";
	Cosmetics_SkinSpawned = "n";


}



