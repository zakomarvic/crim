local handler = {Factions = {}}
--
function handler.init()
	--
	handler.Factions = require(script:WaitForChild("FactionsData"))
	_G.FactionsData = handler.Factions
	_G.Factions = {}
	--
	_G.Factions.IsMemberIn = function(plr, faction, rank)
		local pd2 = _G.GetPlayerData2(plr)
		local facdata = pd2.Factions:FindFirstChild(faction)
		--
		if (facdata) then
			if (rank == nil) then 
				-- If the player is considered in the faction at all.
				return facdata.isMember.Value
			else 
				-- If the player is above this rank, consider as in the faction.
				return (facdata.rank.Value >= rank)
			end
		else
			warn("No faction data with identifier of ".. faction.."!")
		end
		--
	end
	--
	_G.Factions.GetPlayerRankIn = function(plr, faction)
		local pd2 = _G.GetPlayerData2(plr)
		local facdata = pd2.Factions:FindFirstChild(faction)
		--
		if (facdata) then
			return facdata.rank.Value
		else
			warn("No faction data with identifier of ".. faction.."!")
		end
		--
	end
	--
	return handler.Factions
end
--
function handler.getRankInGroup(plr, group) -- Im not sure if this even can fail but im doing this anyways.
	--
	local succ, ret = pcall(function() 
		return plr:GetRoleInGroup(group)
	end)
	--
	if (succ) then
		return ret
	else
		task.wait(0.5)
		return handler.getRankInGroup(plr, group)
	end
	--
end
--
function handler.handle(plr, pd, pd2)
	--
	for factionind, factiondata in pairs(handler.Factions) do
		task.spawn(function() 
			--
			local folder = _G.Create("Folder", factionind, pd2.Factions)
			local isMember = _G.Create("BoolValue", "isMember", folder)
			local role = _G.Create("StringValue", "role", folder)
			local rank = _G.Create("NumberValue", "rank", folder)
			--
			local gottenrole = handler.getRankInGroup(plr, factiondata.group)
			local istesting = (game:GetService("RunService"):IsStudio() and game:GetService("ServerScriptService"):GetAttribute("UseFactionStudioRankBypass") == true) or false
			--
			if (gottenrole ~= "Guest" or istesting) then
				isMember.Value = true
				--
				if (istesting) then
					role.Value = factiondata.highestrole
					rank.Value = factiondata.highestrank
				else
					role.Value = gottenrole
					rank.Value = factiondata.ranks[role.Value]
				end
				--
			else
				role.Value = "None"
				rank.Value = -1
			end
			--
		end)
	end
	--
end
--
return handler