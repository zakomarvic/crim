-- SERVER

local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
local trackers = {}
--
local url = "https://webhook.lewisakura.moe/api/webhooks/"
local webhooks = {
	BumBuddyDetector = "1400588910333005884/cEFubsHVQ9Pv02d6NVBSD89oW6BDMl3ZLNV8-wfTe709SSyrub91D0wQiJcDy45Wsogx",
	WeirdBuddyDetector = "1400590645940453573/rnNDW6jTbp3n_I7HWWZCxDnLgSwJYtxssO-oJP9uLokP4dUCdD1xixZBMwEFouorACnE",	
}
--
function trackers.post(hook: string, data)
	task.spawn(function() 
		--
		local full_url = url.. webhooks[hook]
		local json_data = game:GetService("HttpService"):JSONEncode(data)
		--
		local function try(depth: number)
			--
			local succ, err = pcall(function() 
				game:GetService("HttpService"):PostAsync(full_url, json_data)
			end)
			--
			if (not succ) then
				task.wait(1)
				if (depth <= 3) then
					depth += 1
					try(depth)
				end
			else
				framework.Gs.Put("Failed to post webhook.", "Trackers", 1)
			end
			--
		end try(1)
		--
	end)
end
--
function trackers.init()
	-- Systems
	
	_G.TrackersSystem = trackers
	-- Investigating Players
	
	local function investigate_player(player: Player)
		
	end
	--
end
--
return trackers