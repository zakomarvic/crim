return function(config,tool)
	--config.Customs = {
	--	LimbDamage2 = {
	--		Dmg = 200;

	--		HeadMultiplier = 1;
	--		Multiplier = 1;

	--		LimbBreakType = "Destroy";
	--		HeadBreakType = "Explode";
	--	};

	--	["ExplosiveHit"] = {
	--		Type = "BFG_Explosion";
	--		Offset = Vector3.new(0,0,0);
	--		MinRange = 5;
	--	};

	--	NecroDmgMulti = 0.75;	
	--}	
	
	config.HeadshotMultiplier *= 1.05
	config.Dropoff *= 1.2
	config.Recoil /= 1.3
	
	return config
end