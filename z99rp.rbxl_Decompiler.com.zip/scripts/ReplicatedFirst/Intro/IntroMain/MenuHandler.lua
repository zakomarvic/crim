local m = {}

function m.Start()
	m.CharacterHandler.Start()
	task.wait(0.15)
	m.CameraHandler.Start()
end

function m.SetUp(scene,config)
	m.scene = scene
	m.config = config
	
	m.CameraHandler = require(script.CameraHandler)
	m.CameraHandler.SetUp(scene,config)
	
	m.CharacterHandler = require(script.CharacterHandler)
	m.CharacterHandler.SetUp(scene,config)
end

return m
