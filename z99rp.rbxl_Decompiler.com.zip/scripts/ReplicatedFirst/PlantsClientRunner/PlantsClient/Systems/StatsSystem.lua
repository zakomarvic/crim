-- CLIENT

local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
--
local plantsLocalData = _G.PlantsLocalData
local traitsMedia = require(game:GetService("ReplicatedStorage").PlantsStorage.Media.Traits)
local coreGui = game.Players.LocalPlayer.PlayerGui:WaitForChild("CoreGUI")
local plantsGui = _G.PlantsGui
local statsMenuButtonsGui = plantsGui.Stats.menuButtons
local statsMenusGui = plantsGui.Stats.menus
local traitsGui = plantsGui:WaitForChild("Stats").menus.traits
--
local statsSystem = {
	--
	selected = "",
	options = {},
	attributes = {},
	blur = nil,
	--
	isOpened = false,
	isServerRegistering = false,
	--
}
-- Refreshing Traits

function statsSystem.refreshTraits()
	--
	for _, op in ipairs(statsSystem.options) do
		op.ui:Destroy() end
	statsSystem.options = {}
	--
	local points = plantsLocalData.Traits.Points
	local text = (points == 1 and " Point") or " Points"
	traitsGui.points.Text = tostring(points).. text
	--
	for _, entry in ipairs(traitsMedia.list) do
		--
		local _e = {connections = {}}
		local trait = entry.trait
		local name = entry.name
		local display = entry.display
		local points = entry.points
		local traitsList = (trait == "Boon" and "Boons") or "Flaws"
		local parent = (trait == "Boon" and traitsGui.boons.list) or traitsGui.flaws.list
		local isSelected = (table.find(plantsLocalData.Traits[traitsList], name) and true) or false
		local isDisabled = not _G.CanAllowTrait(name, _G.CombineArrays({plantsLocalData.Traits.Boons, plantsLocalData.Traits.Flaws}))
		--
		local color = (isSelected and Color3.fromRGB(200, 50, 50)) or Color3.fromRGB(50, 200, 50)
		local ui = plantsGui.Templates.Trait:Clone()
		local button: TextButton = ui.toggle.button
		ui.Parent = parent
		ui.Visible = true
		ui.label.Text = display
		ui.toggle.points.Text = (trait == "Boon" and "-".. points) or "+".. points
		ui.LayoutOrder = ((isDisabled and 256) or 0) + ((isSelected and -points) or points)
		ui.toggle.button.Text = (isSelected and "LOSE") or "GAIN"
		ui.toggle.BorderColor3 = color
		ui.label:SetAttribute("MouseTip", entry.description)
		button.TextColor3 = color
		--
		if (isDisabled) then
			button.Text = "..."
			button.TextColor3 = Color3.fromRGB(125, 125, 125)
			ui.toggle.BorderColor3 = Color3.fromRGB(125, 125, 125)
			ui.label.TextColor3 = Color3.fromRGB(150, 150, 150)
		end
		--
		table.insert(_e.connections, button.MouseEnter:Connect(function() 
			framework.Gs.PlayGuiSound("hover")
		end))
		--
		table.insert(_e.connections, button.MouseButton1Click:Connect(function() 
			if (not statsSystem.isServerRegistering and not isDisabled) then
				task.spawn(function() 
					statsSystem.isServerRegistering = true
					button.Text = "..."
					button.TextColor3 = Color3.fromRGB(125, 125, 125)
					ui.toggle.BorderColor3 = Color3.fromRGB(125, 125, 125)
					--
					local ret = framework.networking.fromServer("Traits", {mode = (isSelected and "Lose") or "Gain", trait = name})
					if (ret.success) then
						framework.Gs.PlayGuiSound("click")
						plantsLocalData.Traits = ret.data
						statsSystem.refreshTraits()
					else
						framework.Gs.PlayGuiSound("error")
						statsSystem.refreshTraits()
					end
					--
					statsSystem.isServerRegistering = false
				end)
			end
		end))
		--
		_e.ui = ui
		table.insert(statsSystem.options, _e)
	end
	--
end
-- Refreshing Attributes

local attributesMedia = require(game:GetService("ReplicatedStorage").PlantsStorage.Media.Attributes)
function statsSystem.refreshAttributes()
	--
	for _, at in ipairs(statsSystem.attributes) do
		at.ui:Destroy() end
	statsSystem.attributes = {}
	--
	local vf = _G.GVF(game.Players.LocalPlayer.Name)
	for atname, atdata in pairs(attributesMedia) do
		--
		local _a = {}
		local ui = plantsGui.Templates.Attribute:Clone()
		ui.Parent = statsMenusGui.attributes.list
		ui.LayoutOrder = atdata.order
		ui.label.Text = atdata.display or string.upper(atname)
		ui.Visible = true
		--
		local value = vf.Attributes:FindFirstChild(atname)
		if (value) then
			local percentage = (value.Value / value.MaxValue)
			ui.bar.inner.Size = UDim2.new(percentage, 0, 1, 0) 
			--
			local text = "XP: ".. _G.PRound(percentage*100, 2, 2).."%\n\n".. (atdata.description or "")
			ui.label:SetAttribute("MouseTip", text)
			--
		end
		--
		_a.ui = ui
		table.insert(statsSystem.attributes, _a)
	end
	--
end
-- Selecting Menu

function statsSystem.selectMenu(menuSelected)
	statsSystem.selected = menuSelected
	plantsGui.Stats.background.header.Text = string.upper(menuSelected)
	--
	for _, menu in ipairs(statsMenusGui:GetChildren()) do
		menu.Visible = (menu.Name == menuSelected) end
	for _, button in ipairs(statsMenuButtonsGui:GetChildren()) do
		if (button:GetAttribute("menu") ~= nil) then
			local isSelected = (button:GetAttribute("menu") == menuSelected)
			button.BorderColor3 = (isSelected and button:GetAttribute("borderColor")) or button:GetAttribute("borderUnselectedColor") 
			button.button.TextColor3 = (isSelected and Color3.fromRGB(255, 255, 255)) or Color3.fromRGB(200, 200, 200)
		end
	end
	--
	if (menuSelected == "traits") then
		if (plantsLocalData.Traits == nil) then
			plantsLocalData.Traits = framework.networking.fromServer("Traits", {mode = "Get"}) end
		statsSystem.refreshTraits()
	elseif (menuSelected == "attributes") then
		statsSystem.refreshAttributes()
	end
	--
end
-- Toggling

function statsSystem.toggle(state: boolean)
	statsSystem.isOpened = (state or not statsSystem.isOpened)
	plantsGui.Stats.Visible = statsSystem.isOpened
	--
	if (statsSystem.isOpened) then
		framework.Gs.PlayGuiSound("open")
		statsSystem.blur = framework.Gs.Create("BlurEffect", "blur", game.Lighting, {{"Size", 0}})
		framework.services.TweenService:Create(statsSystem.blur, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {Size = 10}):Play()
		--
		if (statsSystem.selected == "") then
			statsSystem.selectMenu("traits") 
		else
			statsSystem.selectMenu(statsSystem.selected)
		end
		--
	else
		framework.Gs.PlayGuiSound("close")
		framework.services.TweenService:Create(statsSystem.blur, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {Size = 0}):Play()
		_G.SafeDestroy(statsSystem.blur)
	end
	--
end
-- Menu Button Toggles

for _, button in ipairs(statsMenuButtonsGui:GetChildren()) do
	if (button:GetAttribute("menu") ~= nil) then
		local rbutton: TextButton = button.button
		--
		rbutton.MouseEnter:Connect(function() 
			framework.Gs.PlayGuiSound("hover")
		end)
		--
		button.button.MouseButton1Click:Connect(function() 
			if (statsSystem.selected ~= button:GetAttribute("menu")) then
				framework.Gs.PlayGuiSound("open") end
			statsSystem.selectMenu(button:GetAttribute("menu"))
			framework.Gs.PlayGuiSound("click")
		end)
		--
	end
end
-- Menu Toggle

local statsToggleButton: TextButton = coreGui:WaitForChild("StatsFrame"):WaitForChild("Frame2"):WaitForChild("Frame"):WaitForChild("Container"):WaitForChild("Stats"):WaitForChild("ToggleButton")
statsToggleButton.MouseButton1Click:Connect(function() 
	statsSystem.toggle() end)
--
_G.statsSystem = statsSystem
return statsSystem