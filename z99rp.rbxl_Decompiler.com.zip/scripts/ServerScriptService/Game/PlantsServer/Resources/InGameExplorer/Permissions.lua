--[[ Set up whether or not a player has access to the explorer 
	! WARNING !
	SHOULD ONLY RETURN TRUE FOR DEVELOPERS OF AN EXPERIENCE
]]

return function(player)
	repeat task.wait() until (_G.cmdrGetRank ~= nil)
	return (_G.cmdrGetRank(player) >= 10)
end