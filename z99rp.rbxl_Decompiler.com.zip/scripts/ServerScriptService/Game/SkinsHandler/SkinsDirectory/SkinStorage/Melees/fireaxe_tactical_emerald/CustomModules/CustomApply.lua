

return function(model)
	if model.ClassName == "Tool" then
		model:SetAttribute("customModel", "fireaxe_tactical")
		
		local Directory = game:GetService("ReplicatedStorage"):WaitForChild("Storage"):WaitForChild("SkinVariants")
		local Replicated = Directory.Melees.fireaxe_tactical:Clone()
		local Handle = model:WaitForChild("WeaponHandle")
		local SA = script.Parent.Parent.SurfaceAppearance:Clone()
		SA.Parent = Replicated.WeaponHandle.TacticalFireAxeMesh
		Replicated.WeaponHandle.TacticalFireAxeMesh.TextureID = "rbxassetid://15448202220"

		Replicated.Parent = Handle
		Replicated:PivotTo(Handle.CFrame)
		Handle.ManualWeld:Destroy()
		local weld = Instance.new("WeldConstraint")
		weld.Parent = Handle
		weld.Part0 = Handle
		weld.Part1 = Replicated.WeaponHandle
		Handle.KilltrackPlacementAttachment:Destroy()
		Replicated.WeaponHandle.KilltrackPlacementAttachment.Parent = Handle
		
		Handle.Axe:Destroy()
	end
	return true
end