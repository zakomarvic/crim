--!nocheck
local messagingService = game:GetService("MessagingService")
local httpsService = game:GetService("HttpService")
local runService = game:GetService("RunService")
--
local serverCommunication = {
	inited = false,
	config = require(script:WaitForChild("config")),
	playersSet = {},
	topicsRegistry = {},
	topicsAmount = 0,
	topicsLimit = 5,
}
--
local topicObject = {}
topicObject.__index = topicObject
--
local function compileServiceData(t)
	t = httpsService:JSONEncode(t)
	return t
end
--
local function handleMessage(topicObject, topicData)
	local trueData = topicData.Data
	--trueData = compression.decompress(trueData)
	trueData = httpsService:JSONDecode(trueData)
	--
	if (serverCommunication.config.showDebug) then
		warn("Received message data: ")
		print(trueData)
	end
	--
	if (trueData.ir) then
		--
		local request = nil
		for _, greq in pairs(topicObject.requests) do if greq.key == trueData.k then request = greq end end
		if (request) then
			if (request.isBatch) then
				for vn, vv in pairs(trueData.d) do
					if typeof(vn) == "number" then
						table.insert(request.data, vv)
					elseif (typeof(vn) == "string") then
						request.data[vn] = vv
					end
				end
			else
				request.data = trueData.d
			end
		end
		--
	else
		if (trueData.ig == true) then
			if (topicObject.onGet) then
				print(topicObject.name..", onGet: ".. trueData.m)
				local returned = topicObject.onGet({msg = trueData.m, data = trueData.d, serverJobId = trueData.sji})
				if (returned) then
					--
					if (serverCommunication.config.showDebug) then
						warn("Returned data: ")
						print(returned)
					end
					--
					messagingService:PublishAsync(trueData.f, compileServiceData({ir = true, d = returned, k = trueData.k}))
				end
			else
				warn("No on get for topic ".. '"'.. topicObject.name.. '"!')
			end
		else
			if (topicObject.onSent) then
				print(topicObject.name..", onSent: ".. trueData.m)
				topicObject.onSent({msg = trueData.m, data = trueData.d, serverJobId = trueData.sji})
			else
				warn("No on sent for topic ".. '"'.. topicObject.name.. '"!')
			end
		end
	end
	--
end
--
function publishMessage(topic, dataToSend, try)
	try = try or 1
	--
	local succ = pcall(function() messagingService:PublishAsync(topic, dataToSend) end)
	if (not succ) then
		try += 1
		if (try > serverCommunication.config.failSafeMaximum) then
			warn("Publish message async failed!")
			return false
		else
			task.wait(serverCommunication.config.failSaveInterval)
			publishMessage(topic, dataToSend, try)
		end
	end
	--
	return true
end
--
function topicObject:send(msg: string, data: {}, to: string | nil): nil
	to = to or self.name
	if (to) then
		--
		local jobid
		if (game.JobId == nil or game.JobId == "" or game.JobId == " ") then
			jobid = "SERVERSTUDIO"
		else
			jobid = game.JobId
		end
		--
		print(self.name..", sending: ".. msg)
		local dataToSend = compileServiceData({ig = false, m = msg, d = data, sji = jobid})
		publishMessage(to, dataToSend)
	else
		warn("No topic defined!")
	end
end
--
function topicObject:get(msg: string, data: {}, from: string | nil, timeout: number | nil): {}
	from = from or self.name
	if (from) then
		--
		self.latestkey += 1
		local key = self.latestkey
		local strkey = game.JobId
		if (strkey == "" or strkey == " " or strkey == nil) then strkey = "STUDIOSERVER" end
		strkey = strkey.. "_".. key
		--
		local jobid
		if (game.JobId == nil or game.JobId == "" or game.JobId == " ") then
			jobid = "SERVERSTUDIO"
		else
			jobid = game.JobId
		end
		--
		local dataToSend = compileServiceData({ig = true, m = msg, d = data, k = strkey, f = self.name, sji = jobid})
		local request = {key = strkey, data = nil, isBatch = false}
		table.insert(self.requests, request)
		--
		print(self.name..", getting: ".. msg)
		local publishValidated = publishMessage(from, dataToSend)
		--
		if (publishValidated == false) then
			return "ERROR"
		else
			local timeoutos = os.clock()
			repeat
				runService.Heartbeat:Wait()
			until ((os.clock() - timeoutos) >= (timeout or serverCommunication.config.maximumTimeForGetRequests) or request.data ~= nil)
			--
			if (request.data) then
				local givendata = request.data
				table.remove(self.requests, table.find(self.requests, request))
				return givendata
			else
				warn("Nothing received from get request.")
				return nil
			end
		end
		--
	else
		warn("No get from topic defined!")
	end
end
--
function topicObject:getBatch(msg: string, data: {}, from: string | nil, cookTime: number): {}
	cookTime = cookTime or 1
	from = from or self.name
	if (from) then
		--
		self.latestkey += 1
		local key = self.latestkey
		local strkey = game.JobId
		if (strkey == "" or strkey == " " or strkey == nil) then strkey = "STUDIOSERVER" end
		strkey = strkey.. "_".. key
		--
		local jobid
		if (game.JobId == nil or game.JobId == "" or game.JobId == " ") then
			jobid = "SERVERSTUDIO"
		else
			jobid = game.JobId
		end
		--
		local dataToSend = compileServiceData({ig = true, m = msg, d = data, k = strkey, f = self.name, sji = jobid})
		local batch = {key = strkey, data = {}, isBatch = true,}
		table.insert(self.requests, batch)
		--
		print(self.name..", getting batch: ".. msg)
		publishMessage(from, dataToSend)
		local cookos = os.clock()
		repeat
			runService.Heartbeat:Wait()
		until ((os.clock() - cookos) >= cookTime)
		--
		return batch.data
	else
		warn("No get from topic defined!")
	end
end
--
function topicObject:remove()
	self.subscription:Disconnect()
	serverCommunication.topicsRegistry[self.name] = nil
end
--
function serverCommunication.init()
	if (serverCommunication.inited == false) then
		serverCommunication.inited = true
		--
		local function playerAdding(plr)
			if (serverCommunication.playersSet[plr] ~= true) then
				serverCommunication.playersSet[plr] = true
				serverCommunication.topicsLimit += 2
			end
		end
		--
		local function playerRemoving(plr)
			if (serverCommunication.playersSet[plr] == true) then
				serverCommunication.playersSet[plr] = nil
				serverCommunication.topicsLimit -= 2
			end
		end
		--
		for _, p in pairs(game.Players:GetChildren()) do playerAdding(p) end
		game.Players.PlayerAdded:Connect(playerAdding)
		game.Players.PlayerRemoving:Connect(playerRemoving)
		--
	end
end
--
function serverCommunication:createTopic(topicName)
	if (self.topicsAmount < self.topicsLimit) then
		if (self.topicsRegistry[topicName] == nil) then
			--
			local newTopicOBJ = {
				name = topicName,
				requests = {},
				latestkey = 0,
				onSent = nil,
				onGet = nil,
				subscription = nil,
			}
			--
			self.topicsAmount += 1
			newTopicOBJ.__index = topicObject
			setmetatable(newTopicOBJ, topicObject)
			self.topicsRegistry[topicName] = newTopicOBJ
			--
			task.spawn(function() 
				local subscription = messagingService:SubscribeAsync(topicName, function(d) handleMessage(newTopicOBJ, d) end)
				newTopicOBJ.subscription = subscription
			end)
			--
			return newTopicOBJ
			--
		else
			warn("Can not create topic, one already exists with the name of ".. '"'.. topicName.. '"!')
		end
	else
		warn("Can not create topic, exceeds subscription limit.")
	end
end
--
function serverCommunication:getTopic(topicName)
	for _, topic in pairs(self.topicsRegistry) do
		if (topic.name == topicName) then
			return topic
		end
	end
	--
	warn("No topic object found by name of ".. '"'.. topicName.. '"!')
end
--
return serverCommunication