local SmartBone = require(game:GetService("ReplicatedStorage"):WaitForChild("Modules"):WaitForChild("SmartBone"))

SmartBone.Start()  