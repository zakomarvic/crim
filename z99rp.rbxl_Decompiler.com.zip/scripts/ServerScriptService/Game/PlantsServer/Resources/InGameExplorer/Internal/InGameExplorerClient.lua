local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")
local HttpService = game:GetService("HttpService")
local CollectionService = game:GetService("CollectionService")
local UserInputService = game:GetService("UserInputService")

local Modules = script.Modules
local Explorer = require(script.Explorer)
local Console = require(script.Console)
local PropertiesExplorer = require(script.PropertiesExplorer)
local Maid = require(Modules.Maid)
local Fusion = require(Modules.Fusion)
local Components = script.Components

local StudioComponents = Components.StudioComponents
local Checkbox = require(StudioComponents.Checkbox)

local Player = Players.LocalPlayer
local PlayerGui = Player.PlayerGui

local UI = script.UI
UI.Enabled = false
UI.Parent = PlayerGui

--[[ Wait for Remotes ]]

local InGameExplorerShared = ReplicatedStorage:WaitForChild("InGameExplorer_Shared")
local Keybind = InGameExplorerShared:WaitForChild("Keybind")
local RemoteFunction = InGameExplorerShared:WaitForChild("InGameExplorer_RemoteFunction")
local RemoteEvent = InGameExplorerShared:WaitForChild("InGameExplorer_RemoteEvent")
local RepShared = require(InGameExplorerShared:WaitForChild("InGameExplorerShared"))

--[[ Loaded ]]

local Classes,Enums = unpack(RemoteFunction:InvokeServer())
UI.Enabled = true

local Shared = require(script.Shared)
Shared.Keybind = require(Keybind)
Shared.RemoteEvent = RemoteEvent
Shared.RemoteFunction = RemoteFunction

local ExportFrame = UI.ExportFrame
Fusion.Hydrate(ExportFrame)
{
	Visible = Shared.ExportFrameEnabled
}
local ExportBox = ExportFrame.TextBox
Fusion.Observer(Shared.ExportFrameEnabled):onChange(function()
	local enabled = Shared.ExportFrameEnabled:get()
	if enabled then
		ExportBox.Text = HttpService:JSONEncode(RepShared.PropertyChanges)
		ExportBox:CaptureFocus()
		ExportBox.SelectionStart = 0
		ExportBox.CursorPosition = #ExportBox.Text + 1
	end
end)
local ExportClose = ExportFrame.Button
ExportClose.MouseButton1Down:Connect(function()
	Shared.ExportFrameEnabled:set(false)
end)


local DropdownEnabled = Fusion.Value(false)

local function Dropdown(obj,value)
	local listFrame = obj.List 
	local listFrameTemplate = listFrame.TextButton:Clone()
	listFrame.TextButton:Destroy()

	local label = obj.DropdownHeader.Selected
	Fusion.Hydrate(label)
	{
		Text = value
	}

	local maid = Maid.new()

	local function refresh()
		maid:Cleanup()

		local options = {"Server",Players.LocalPlayer.Name}
		for i,v in Players:GetPlayers() do 
			if v ~= Players.LocalPlayer then
				table.insert(options,v.Name)	
			end
		end

		for i,v in options do 
			if v == value:get() then
				continue
			end
			local template = listFrameTemplate:Clone()
			maid:Add(template)
			template.Text = v
			template.Parent = listFrame
			template.MouseButton1Click:Connect(function()
				value:set(template.Text)
				label.Text = template.Text
				listFrame.Visible = false
				DropdownEnabled:set(false)
			end)
		end
		listFrame.Size = UDim2.new(1,0,0,math.min(listFrame.UIListLayout.AbsoluteContentSize.Y,200))
	end

	Players.PlayerAdded:Connect(refresh)
	Players.PlayerRemoving:Connect(function(oldPlayer)
		if oldPlayer.Name == value:get() then 
			value:set(Players.LocalPlayer.Name)
		end
		refresh()
	end)

	obj.WholeDropdownInput.MouseButton1Click:Connect(function()
		listFrame.Visible = not listFrame.Visible
		DropdownEnabled:set(listFrame.Visible)
		if listFrame.Visible then
			refresh()
		end
	end)
end

local TopBar = UI.Explorer.Body.TopBar
local ReplicatorDropdown = Dropdown(TopBar.Replicator,Shared.CurrentReplicator)

local OutputCheckbox = Checkbox{
	Parent = TopBar,
	AnchorPoint = Vector2.new(0,0.5),
	Position = UDim2.new(0,80,0.5,0),
	Size = UDim2.fromOffset(100,15),
	Text = "Console",
	Value = Shared.ConsoleEnabled
}
OutputCheckbox.Box.BackgroundColor3 = Color3.fromRGB(83, 83, 83)

Fusion.Observer(Shared.CurrentReplicator):onChange(function()
	local replicatorName = Shared.CurrentReplicator:get()
	if replicatorName == Players.LocalPlayer.Name then
		Shared.ListeningReplicator:set(false)
	else
		Shared.ListeningReplicator:set(replicatorName)	
	end
end)


Fusion.Hydrate(UI.Explorer.Body.ScrollingFrame)
{
	Visible = Fusion.Computed(function() return not DropdownEnabled:get() end)
}

Console:Init(UI)
Explorer:Init(UI,Classes)
PropertiesExplorer:Init(UI,Classes,Enums)

local Mouse = Player:GetMouse()

local draggables = CollectionService:GetTagged("InGameExplorer_Draggable")
local function getUIObjectWithHighestZIndex()
	local highestZIndexUI = nil
	local highestZIndex = -math.huge

	for _, obj in draggables do
		local objPos = obj.AbsolutePosition
		local objSize = obj.AbsoluteSize
		local mousePosition = UserInputService:GetMouseLocation()

		if mousePosition.X >= objPos.X and mousePosition.Y >= objPos.Y and mousePosition.X <= objPos.X + objSize.X and mousePosition.Y <= objPos.Y + objSize.Y then
			if obj.ZIndex > highestZIndex then
				highestZIndex = obj.ZIndex
				highestZIndexUI = obj
			end
		end
	end
	return highestZIndexUI
end
for i,frame in draggables do 

	local Holding = false
	local MoveCon = nil

	local InitialX, InitialY, UIInitialPos

	local lastPos = frame.AbsolutePosition


	local function Drag()
		if Holding == false then MoveCon:Disconnect() return end

		local ViewportSize = UI.AbsoluteSize

		local mousePos = UserInputService:GetMouseLocation()
		local mouseX = mousePos.X 
		local mouseY = mousePos.Y

		local halfWidth = frame.AbsoluteSize.X/2
		local halfHeight = frame.AbsoluteSize.Y/2

		local distanceMoved = mousePos - Vector2.new(InitialX, InitialY)
		local newPos = UIInitialPos + Vector2.new(distanceMoved.X,distanceMoved.Y)		

		lastPos = newPos 

		local newX = math.clamp(newPos.X, 0, ViewportSize.X - frame.AbsoluteSize.X)
		local newY = math.clamp(newPos.Y, 0, ViewportSize.Y - frame.AbsoluteSize.Y)

		frame.Position = UDim2.new(0,newX,0,newY)
	end

	UI:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
		local ViewportSize = UI.AbsoluteSize
		local newX = math.clamp(lastPos.X, 0, ViewportSize.X - frame.AbsoluteSize.X)
		local newY = math.clamp(lastPos.Y, 0, ViewportSize.Y - frame.AbsoluteSize.Y)
		frame.Position = UDim2.new(0,newX,0,newY)
	end)


	frame.InputBegan:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
			if getUIObjectWithHighestZIndex() ~= frame then
				return
			end
			Holding = true
			local mousePos = UserInputService:GetMouseLocation()
			InitialX, InitialY = mousePos.X,mousePos.Y
			UIInitialPos = frame.AbsolutePosition
			MoveCon = Mouse.Move:Connect(Drag)
		end
	end)
	frame.InputEnded:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
			Holding = false
			if MoveCon then
				MoveCon:Disconnect()
			end
		end
	end)
end

