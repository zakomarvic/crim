local M = {}

M.PS = function(soundName,attachment,handle,magPart)
	if soundName == "BarrelClose" then
		local s = script.Ching:Clone()
		game.Debris:AddItem(s,2)
		s.Parent = attachment
		s:Play()
	end
end

return M