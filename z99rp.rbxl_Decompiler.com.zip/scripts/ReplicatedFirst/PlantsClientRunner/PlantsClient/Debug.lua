local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
--
return function()
	--
	local uis = framework.services.UserInputService
	uis.InputBegan:Connect(function(input) 
		if (uis:IsKeyDown(Enum.KeyCode.LeftAlt)) then
			if (input.KeyCode == Enum.KeyCode.P) then
				--
				--
				require(game:GetService("ReplicatedStorage").PlantsStorage.Objects.ContextMenus).new("Hi Lol", {{mode = "button", text = "Hello Everyone"}, {mode = "button", text = "Held Hello Everyone", clickDuration = 2}})
			end
		end
	end)
	--
end
--