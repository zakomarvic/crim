local Handler = script.Parent.Parent.Handler

local running = false

script.Do.Event:Connect(function(c,...)
	if running then return end
	running = true
	
	local con
	con = c.AncestryChanged:Connect(function(_,parent)
		if not parent then
			con:Disconnect()
			game.Debris:AddItem(script,0)
		end
	end)
	
	require(Handler)(c,...)
end)