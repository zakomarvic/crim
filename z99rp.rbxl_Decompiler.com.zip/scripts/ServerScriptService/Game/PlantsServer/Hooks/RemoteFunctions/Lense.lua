local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
local players = require(game:GetService("ServerStorage").PlantsStorage.Objects.Player)
-- HELPER

local token = "gjxFR70EvB8plX8cdz4NaRkOCSyry93CP3flNMM_5iQbfAmgOKjGVe1nYBMrY8fB-eX8X9tsJTvJxYCAdeRl5Q"
local httpService = game:GetService("HttpService")
local QRHelper = require(game:GetService("ReplicatedStorage"):WaitForChild("Modules"):WaitForChild("QRCodeHelper"))
--
local function httpPost(url, data)
	--
	print("HTTP POST CALLED")
	data = (data == nil and {}) or data
	data.token = _G.ScrambleText(token, -16)
	data.v = "1"
	--
	local succ, ret = pcall(function() 
		data = httpService:JSONEncode(data)
		return httpService:PostAsync(url, data)
	end)
	--
	if (succ) then
		framework.Gs.Put("HTTP Post success.", "LENSE", 0)
		return ret
	else
		framework.Gs.Put("HTTP Post call failed, retrying.", "LENSE", 1)
		task.wait(1)
		return httpPost(url, data)
	end
	--
end
--
local function generateQRFor(plr: Player)
	--
	local function generateQR()
		local data = {uid = tostring(plr.UserId)}
		local ret = httpService:JSONDecode(httpPost(_G.ScrambleText("nzzvy://gvo.rubktyk-gvo.ius/gvo/rgt/mkzWxIujk", -6), data))
		--
		if (ret.code == 200 or ret.code == 0) then
			_G.LenseQRCache[tostring(plr.UserId)] = {link = ret.message, qr = nil}
			--
			local function decodeQR(depth)
				depth = (depth == nil and 1) or depth
				--
				local succ, ret = pcall(function() 
					local qrLinkReadApi = "http://api.qrserver.com/v1/read-qr-code/?fileurl="
					local qrRet = httpService:GetAsync(qrLinkReadApi.. ret.message)
					return qrRet
				end)
				--
				local dret = (succ and httpService:JSONDecode(ret))
				--
				if (succ and (dret[1].symbol and dret[1].symbol[1] and dret[1].symbol[1].data)) then
					ret = httpService:JSONDecode(ret)
					local content = httpService:JSONDecode(ret[1].symbol[1].data).data
					local _, qr = QRHelper.encode(content)
					_G.LenseQRCache[tostring(plr.UserId)].qr = qr
				else
					if (depth < 3) then
						warn("Failed to decode qr data content, retrying.")
						task.wait(1)
						decodeQR(depth + 1)
					else
						warn("Failed to decode qr data content, depth limited reached.")
					end
				end 
				--
			end decodeQR()
			--
			print("Succesfully generated qr code, ", _G.LenseQRCache)
		else
			warn("Failed QR Code generate, retrying.")
			task.wait(1)
			return generateQR()
		end
		--
	end generateQR()
	--
end
--
local lense = {}
--
lense["CancelPair"] = function(plr: Player)
	if (plr:FindFirstChild("LPairing")) then
		plr.LPairing:Destroy() end
end
--
lense["Pair"] = function(plr: Player)
	--
	if (_G.LenseQRCache == nil) then
		_G.LenseQRCache = {} end
	--
	if (_G.LenseQRCache[tostring(plr.UserId)] == nil) then
		generateQRFor(plr) end
	--
	task.spawn(function() 
		--
		local hasPaired = false
		local pairing = Instance.new("NumberValue")
		pairing.Name = "LPairing"
		pairing.Parent = plr
		pairing.Value = 240
		local testBuzzOs = os.clock()
		--
		repeat
			local delta = task.wait()
			pairing.Value -= delta
			--
			if (os.clock() - testBuzzOs) >= 3 then
				testBuzzOs = os.clock()
				--
				pcall(function() 
					local ret = httpService:JSONDecode(httpPost(_G.ScrambleText("nzzvy://gvo.rubktyk-gvo.ius/gvo/rgt/b2/iussgtj", -6), {uid = tostring(plr.UserId), command = "Function", action = "All:5", timeSec = 1, apiVer = 1}))
					print(ret)
					if (ret.code == 200) then hasPaired = true end
				end)
				--
			end
			--
		until (pairing == nil or pairing.Parent == nil) or (framework.Gs.SafeCheck({plr, pairing}) == false or pairing.Value <= 0 or hasPaired) 
		--
		_G.SafeDestroy(pairing)
		if (hasPaired) then
			local plrObj = players.getPlayerBy(plr)
			plrObj.data.other.LensePaired = true
			plr:SetAttribute("LPaired", true)
		end
		--
	end)
	--
	return _G.LenseQRCache[tostring(plr.UserId)]
end
-- SERVER

local server_lense = {}
--
server_lense.give = function(character: Model, duration: number, intensity: number)
	local values = framework.Gs.GVF(character.Name)
	if (values:FindFirstChild("Lense")) then
		values.Lense.Duration.Value += duration
		values.Lense.Intensity.Value += intensity
		task.delay(duration, function() values.Lense.Intensity.Value -= intensity end)
	end
end
--
server_lense.start = function(player: Player, intensity: number)
	task.spawn(function() 
		intensity = (intensity == nil and 1) or math.clamp(intensity, 0, 20)
		local ret = httpPost(_G.ScrambleText("nzzvy://gvo.rubktyk-gvo.ius/gvo/rgt/b2/iussgtj", -6), {uid = tostring(player.UserId), command = "Function", action = "All:".. tostring(intensity), timeSec = 0, apiVer = 1})
		print(httpService:JSONDecode(ret))
	end)
end
--
server_lense.stop = function(player: Player)
	task.spawn(function() 
		local ret = httpPost(_G.ScrambleText("nzzvy://gvo.rubktyk-gvo.ius/gvo/rgt/b2/iussgtj", -6), {uid = tostring(player.UserId), command = "Function", action = "Stop", timeSec = 0, apiVer = 1})
		print(httpService:JSONDecode(ret))
	end)
end
--
_G.slense = server_lense
return lense