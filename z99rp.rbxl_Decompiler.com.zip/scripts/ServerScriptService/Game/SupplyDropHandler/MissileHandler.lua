local RunService = game:GetService("RunService")
local TS = game:GetService("TweenService")

local MissileH = {
	Settings = {
		Speed = 1000;
		GyroD = 200;
	}
}

local M = require(script.Parent)

function MissileH.new(spawnCF,targetModel)
	print("Missile time")
	local missile = script.Missile:Clone()
	delay(60,function()
		if missile and missile.Parent then
			missile:Destroy()
		end
	end)
	
	missile.PrimaryPart.CFrame = spawnCF
	
	missile.TargetVal.Value = targetModel
	missile.SpeedVal.Value = MissileH.Settings.Speed
	
	missile.PrimaryPart.BodyGyro.D = MissileH.Settings.GyroD
	
	missile.Parent = workspace.Debris.VParts
	
	for i,v in pairs(missile:GetDescendants()) do
		if v:IsA("BasePart") and v:CanSetNetworkOwnership() then
			v:SetNetworkOwner(nil)
		end
	end
	
	missile.MissileHandlerScript.Disabled = false
	
	return missile
end


return MissileH