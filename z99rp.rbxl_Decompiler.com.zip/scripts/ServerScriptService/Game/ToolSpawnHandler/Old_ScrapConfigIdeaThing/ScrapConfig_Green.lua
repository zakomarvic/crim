return { -- green scraps
	
	["val_Gunpowder"] = {
		Rarity = 1;
		Chance = 10;
	};
	["val_MilitaryCable"] = {
		Rarity = 1;
		Chance = 10;
	};
	["val_Cloth"] = {
		Rarity = 1;
		Chance = 10;
	};
	["val_WeaponParts"] = {
		Rarity = 1;
		Chance = 10;
	};
	["val_Watch"] = {
		Rarity = 1;
		Chance = 8;
	};
	["val_SkullRing"] = {
		Rarity = 1;
		Chance = 8;
	};
	["val_Dogtag"] = {
		Rarity = 1;
		Chance = 5;
	};
	["val_Keytool"] = {
		Rarity = 1;
		Chance = 5;
	};
	["val_Jerrycan"] = {
		Rarity = 1;
		Chance = 5;
	};
	
	--v 31
	
	["Lockpick"] = {
		Rarity = 1;
		Chance = 5;
	};
	
	["Bayonet"] = {
		Rarity = 2;
		Chance = 3; -- %
	};
	
	["Crowbar"] = {
		Rarity = 2;
		Chance = 3; -- %
	};
	
	["Shovel"] = {
		Rarity = 2;
		Chance = 3; -- %
	};
	
	["Bat"] = {
		Rarity = 2;
		Chance = 3; -- %
	};
	
	["Golfclub"] = {
		Rarity = 1;
		Chance = 3; -- %
	};
	
	["Taiga"] = {
		Rarity = 2;
		Chance = 3; -- %
	};
	
	["Molotov"] = {
		Rarity = 2;
		Chance = 3; -- %
	};
	
	["Grenade"] = {
		Rarity = 2;
		Chance = 2; -- %
	};
	["Sawn-Off"] = {
		Rarity = 4;
		Chance = 1;
	};
	["Beretta"] = {
		Rarity = 4;
		Chance = 1; -- %
	};
	["TEC-9"] = {
		Rarity = 4;
		Chance = 1; -- %
	};
	["Uzi"] = {
		Rarity = 4;
		Chance = 1;
	};
}