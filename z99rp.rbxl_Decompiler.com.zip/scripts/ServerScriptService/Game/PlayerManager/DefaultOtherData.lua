return {
	
	GameDataTransferred = false,
	Reimbursement = {};
	
	Traits = {
		Points = 0,
		Boons = {},
		Flaws = {},
	},

	Attributes = {
		Strength = 0,
		Endurance = 0,
		Agility = 0,
		Altruism = 0,
	},

	Society = {
		Reputation = 0,
		Temp = {},
		--
		DamagedOtherTick = -1,
		DownedOtherTick = -1,
		KilledOtherTick = -1,
		--
		ConsistentKills = 0,
		ConsistentKillsTick = -1,
		KillThreshold = 2,
		KillThresholdTick = -1,
		--
	},
	
	EmotesEquipped = {Slot1 = "", Slot2 = "", Slot3 = "", Slot4 = ""},
	EmotesOwned = {},
	
}