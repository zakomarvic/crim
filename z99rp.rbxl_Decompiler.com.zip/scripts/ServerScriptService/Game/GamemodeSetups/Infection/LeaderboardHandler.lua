local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local TS = game:GetService("TweenService")
local MemoryStoreService = game:GetService("MemoryStoreService")
local DatastoreService = game:GetService("DataStoreService")
local MarketplaceService = game:GetService("MarketplaceService")

local M = {}
M.__index = M

local PlayerbaseData = ServerStorage:WaitForChild("PlayerbaseData")
local PlayerbaseData2 = ReplicatedStorage:WaitForChild("PlayerbaseData2")

local IS_STUDIO = RunService:IsStudio()

local function addComas(x)
	local str = tostring(x)
	return #str % 3 == 0 and str:reverse():gsub("(%d%d%d)", "%1,"):reverse():sub(2) or str:reverse():gsub("(%d%d%d)", "%1,"):reverse()
end

function M:UpdateLeaderboardData(plr)
	local data = self.activePlayers[plr]
	
	if not data or not data.SaveData or not data.SaveData.OtherStats then
		return
	end

	local wins
	if data.SaveData.LeaderboardWins and data.SaveData.LeaderboardWins[self.Config.Leaderboards.WinsKey] then
		wins = data.SaveData.LeaderboardWins[self.Config.Leaderboards.WinsKey]
	end
	if wins then
		local _s,_e = pcall(function()
			M.LeaderboardStore_Wins:UpdateAsync(
				tostring(plr.UserId),
				function(oldValue)
					return wins
				end
			)
		end)
		if not _s then
			warn("UpdateLeaderboardData1 Error:",plr,_e)
		end
	end
	
	local _s,_e = pcall(function()
		M.LeaderboardStore_Kills:UpdateAsync(
			tostring(plr.UserId),
			function(oldValue)
				return data.SaveData.OtherStats.TotalKills 
			end    
		)
	end)
	if not _s then
		warn("UpdateLeaderboardData2 Error:",plr,_e)
	end
end

function M:WipeLeaderboardData(userId)
	local _s,_e = pcall(function()
		M.LeaderboardStore_Wins:RemoveAsync(
			tostring(userId)
		)
	end)
	if not _s then
		warn("WipeLeaderboardData1 Error:",userId,_e)
	end
	local _s,_e = pcall(function()
		M.LeaderboardStore_Kills:RemoveAsync(
			tostring(userId)
		)
	end)
	if not _s then
		warn("WipeLeaderboarData2 Error:",userId,_e)
	end
	
	if _s then
		warn("Successfully wiped infection leaderboard data",userId)
	end
end

function M:UpdateLeaderboards()
	if not M.IsSetUp then return end
	
	for i,v in pairs(M.WinsFrame:GetChildren()) do
		if v:IsA("Frame") then
			v:Destroy()
		end
	end
	for i,v in pairs(M.KillsFrame:GetChildren()) do
		if v:IsA("Frame") then
			v:Destroy()
		end
	end
	
	local _s,_e = pcall(function()
		local results = M.LeaderboardStore_Wins:GetSortedAsync(false, self.Config.Leaderboards.MaxItems, self.Config.Leaderboards.MinValueDisplay, self.Config.Leaderboards.MaxValueDisplay):GetCurrentPage()
		for i, v in pairs(results) do
			local playerName = nil

			pcall(function()
				playerName = Players:GetNameFromUserIdAsync(v.key)
			end)

			if playerName then		
				local frame = script.Frame:Clone()
				local txt = ""

				if i <= 3 then
					txt = txt .. '<font color="rgb(255,165,0)">'
				else
					txt = txt .. '<font color="rgb(255,255,255)">'
				end

				txt = txt .. '#' .. i .. '</font>' .. '  ' .. '@' .. playerName .. '  ' .. '<font color="rgb(170,170,170)">' .. addComas(v.value) .. '</font>'

				frame.TextLabel.Text = txt

				frame.Parent = M.WinsFrame
			end
		end
		
		local results = M.LeaderboardStore_Kills:GetSortedAsync(false, self.Config.Leaderboards.MaxItems, self.Config.Leaderboards.MinValueDisplay, self.Config.Leaderboards.MaxValueDisplay):GetCurrentPage()
		
		--print(results)
		for i, v in pairs(results) do
			local playerName = nil

			pcall(function()
				playerName = Players:GetNameFromUserIdAsync(v.key)
			end)

			if playerName then		
				local frame = script.Frame:Clone()
				local txt = ""

				if i <= 3 then
					txt = txt .. '<font color="rgb(255,165,0)">'
				else
					txt = txt .. '<font color="rgb(255,255,255)">'
				end

				txt = txt .. '#' .. i .. '</font>' .. '  ' .. '@' .. playerName .. '  ' .. '<font color="rgb(170,170,170)">' .. addComas(v.value) .. '</font>'

				frame.TextLabel.Text = txt

				frame.Parent = M.KillsFrame
			end
		end
	end)
	
	if not _s then
		warn("LeaderboardUpdate:",_e)
	end
end


function M.new(self)
	if M.IsSetUp then return end
	M.IsSetUp = true
	
	M.CurrentSelf = self
	
	M.PlayerHandler = require(script.Parent.PlayerHandler)
	
	if self.Config.Leaderboards and self.Config.Leaderboards.Enabled then
		local _s,_e = pcall(function()
			M.LeaderboardStore_Wins = DatastoreService:GetOrderedDataStore(self.Config.Leaderboards.Key .. "_Wins")
			M.LeaderboardStore_Kills = DatastoreService:GetOrderedDataStore(self.Config.Leaderboards.Key .. "_Kills")
			
			M.KillsBoard = script.KillsBoard:Clone()
			M.WinsBoard = script.WinsBoard:Clone()
			
			M.WinsFrame = M.WinsBoard.UIPart.SurfaceGui.Frame.ScrollingFrame
			M.KillsFrame = M.KillsBoard.UIPart.SurfaceGui.Frame.ScrollingFrame
			
			M.KillsBoard.Parent = workspace.Map
			M.WinsBoard.Parent = workspace.Map
		end)
		
		self.I.eventsFolder.RMVILB.Event:Connect(function(plr)
			M.WipeLeaderboardData(self,plr.UserId)
		end)
		
		ServerStorage.Events3.ONPLRBANNED.Event:Connect(function(code,userId)
			if code ~= "K9W0SLKDJI0SDSD09IF9ISO" then return end
			
			M.WipeLeaderboardData(self,userId)
		end)
		
		spawn(function()
			M.UpdateLeaderboards(self)
			
			while wait(60) do
				M.UpdateLeaderboards(self)
			end
		end)
	end
end

return M