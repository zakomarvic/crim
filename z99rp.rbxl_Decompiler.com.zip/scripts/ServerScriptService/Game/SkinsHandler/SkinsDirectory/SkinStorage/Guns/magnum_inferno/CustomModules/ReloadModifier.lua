local M = {}

local TweenService = game:GetService("TweenService")

local COLOR_BEFORE = Color3.fromRGB(147, 85, 52)
local COLOR_FULL = Color3.fromRGB(188, 111, 66)
local COLOR_BLACK = Color3.fromRGB(49, 49, 49)

local function DoBulletTween(part,info,result)
	if M.bulletTween then
		M.bulletTween:Cancel()
		M.bulletTween = nil
	end
	
	M.bulletTween = TweenService:Create(part,info,result)
	M.bulletTween:Play()
end

M.PS = function(soundName,attachment,handle,magPart)
	if soundName == "ShellsOut" then
		DoBulletTween(handle.Parts.BulletsRealPart,TweenInfo.new(0.3,Enum.EasingStyle.Quint,Enum.EasingDirection.Out),{Color = COLOR_BLACK})
		
		local a = Instance.new("Attachment")
		a.Position = Vector3.new(0, 0.4, -0.065)
		game.Debris:AddItem(a,5)
		
		local x = false
		if _G.FP and _G.VM and _G.VM.Check(handle.Parent) and _G.VM.Enabled and _G.VM.CloneTool and _G.VM.CloneTool.Parent and _G.VM.CloneTool:FindFirstChild("Thing") then
			a.Parent = _G.VM.CloneTool.Thing
			x = true
		else
			a.Parent = handle.Parts.Thing
		end
		
		local sm = script.Smoke:Clone()
		if x then
			sm.LockedToPart = true
		end
		sm.Parent = a
		sm:Emit(100)
		
		local s = script.Extinguish:Clone()
		game.Debris:AddItem(s,4)
		s.Parent = attachment
		s:Play()
	elseif soundName == "CylOpen" then
		DoBulletTween(handle.Parts.BulletsRealPart,TweenInfo.new(0.75,Enum.EasingStyle.Quint,Enum.EasingDirection.Out),{Color = COLOR_FULL})
	elseif soundName == "ShellsIn" then
		if M.bulletTween then
			M.bulletTween:Cancel()
			M.bulletTween = nil
		end

		handle.Parts.BulletsRealPart.Color = COLOR_BEFORE
	end
end

M.Start = function(attachment,handle,magPart)
	if M.bulletTween then
		M.bulletTween:Cancel()
		M.bulletTween = nil
	end
	
	handle.Parts.BulletsRealPart.Color = COLOR_BEFORE
end

return M