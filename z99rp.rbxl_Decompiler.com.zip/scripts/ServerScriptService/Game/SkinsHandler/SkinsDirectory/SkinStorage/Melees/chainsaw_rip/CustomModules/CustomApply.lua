
return function(model)
	if model.ClassName == "Tool" then
		model:SetAttribute("ripper", true)
		
		local Directory = game:GetService("ReplicatedStorage"):WaitForChild("Storage"):WaitForChild("SkinVariants")
		local Replicated = Directory.Melees.chainsaw_rip:Clone()
		local Handle = model:WaitForChild("WeaponHandle")
		
		for _, v in pairs(Replicated.WeaponHandle:GetChildren()) do
			
			if Handle:FindFirstChild(v.Name) then
				Handle:FindFirstChild(v.Name):Destroy()
			end
			
			if v:IsA("Motor6D") then
				v.Part0 = Handle
			end
			
			v.Parent = Handle
		end
		
		Replicated:Destroy()
	end
	return true
end