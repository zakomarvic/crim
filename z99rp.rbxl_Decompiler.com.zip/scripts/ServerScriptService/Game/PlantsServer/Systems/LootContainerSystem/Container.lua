-- SERVER

local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
--
local data = require(script:WaitForChild("Data"))
local container = {bucket = {}}
local static = {}
static.__index = static
--
function container.new(lootcontainer, variant)
	--
	local object = {
		model = nil,
		container = lootcontainer,
		variant = variant,
		variant_data = nil,
		--
		isOpened = false,
		isGenerated = false,
		generationPower = 0,
		inventory = {},
		searching = {},
		--
		open = 0,
		tickOs = os.clock(),
		tickTime = 0,
		regenerationTime = 0,
		--
	}
	--
	setmetatable(object, static)
	object.__index = static
	object:init()
	table.insert(container.bucket, object)
	--
	return object
end
--
function container.sortLootModules()
	-- Loot Sorting

	for _, lootmod in ipairs(script.Loot:GetChildren()) do
		local loot = require(lootmod)
		table.sort(loot, function(a, b) 
			return (a.weight > b.weight) end)
	end
	--
end
--
function container.pickRandomQuality()
	--
	local qualities = require(script:WaitForChild("Qualities"))
	local qualityWeightTotal = 0
	for _, quality in ipairs(qualities) do
		qualityWeightTotal += quality.weight end
	--
	local chosen = nil
	local weight = math.random(1, qualityWeightTotal)
	for _, quality in ipairs(qualities) do
		weight -= quality.weight
		if (weight <= 0) then
			chosen = quality
			break end end
	return chosen.quality
	--
end
--
function static:init()
	--
	local data = require(script.Variants[self.variant])
	self.variant_data = data
	--
	self.container.Pivot.PromptAttachment.Position += (data.poffset or Vector3.zero)
	local model: Model = data.model:Clone()
	model.Parent = self.container
	model:PivotTo(self.container.Pivot.CFrame)
	self.model = model
	--
	self.container.Pivot.PromptAttachment.Prompt.Triggered:Connect(function(plr) 
		self:generateLoot(plr)
		self:openContainer(plr) end)
	-- Remote

	self.container.remote.OnServerEvent:Connect(function(plr, action, data) 
		if (action == "close") then
			self.searching[plr] = false
		end
	end)
	-- Remote Function

	self.container.remoteFunction.OnServerInvoke = function(plr, action, data)
		if (action == "take") then
			--
			for _, item in ipairs(self.inventory) do
				if (item.id == data.id) then
					local succ, reason = self:take(plr, item)
					return {succ, self.inventory, reason}
				end
			end
			--
			return {false, self.inventory}
		end
	end
	--
	self:regenerated()
end
--
function static:cycle(delta)
	local data = self.variant_data
	--
	if (not self.isGenerated) then
		if ((os.clock() - self.tickOs) >= self.tickTime) then
			self.tickOs = os.clock()
			self.tickTime = math.random(data.powerTickEverySeconds[1], data.powerTickEverySeconds[2])
			local power = math.random(data.powerTickIncreaseRange[1], data.powerTickIncreaseRange[2])
			self.generationPower = math.clamp((self.generationPower + power), data.minPower, (data.absoluteMaxPower or data.maxPower))
		end
	elseif (self.isGenerated) then
		self.regenerationTime -= delta
		if (self.regenerationTime <= 0 and self.open <= 0) then
			self.isGenerated = false
			self.generationPower = 0
			self.inventory = {}
			self:regenerated()
			self.container.Pivot.PromptAttachment.Prompt:SetAttribute("_enabled", true)
			self.container.Pivot.PromptAttachment.Prompt.Enabled = true
			if (data.onClose and self.isOpened) then
				data.onClose(self, self.model) end
		end
	end

	--
end
--
function static:take(plr, item)
	--
	local vf = _G.GVF(plr.Name)
	local char = plr.Character
	local tool = game:GetService("ServerStorage").Tools[item.name]
	local toolweight = _G.GetWeightOfItem(tool, plr)
	--
	if ((vf.InventorySlots.Value + toolweight) <= vf.InventorySlots.MaxValue) then
		--
		if (self.variant_data.isTheft ~= false) then
			local tag = string.format("lct_%s_cooldown", char.Name)
			local lctc = self.container:GetAttribute(tag)
			if (lctc == nil or (os.clock() - lctc) >= 20) then
				_G.AffectReputation(plr, -1, "Theft.")
				self.container:SetAttribute(tag, os.clock())
			end
		end
		--
		tool = tool:Clone()
		tool:SetAttribute("ScrapFound", true)
		tool:SetAttribute("StoreBought", true)
		tool:SetAttribute("Quality", item.quality)
		--
		if (item.isScrap) then
			--
			local multiplier = math.random(85, 115)/100
			if (_G.CharHasTrait(plr, "keeneye")) then
				multiplier += 0.30 end
			--
			multiplier += (self.variant_data.cashBoost or 0)
			tool:SetAttribute("SellPriceMultiplier", multiplier) 
		end
		--
		if (item.isGun) then
			-- Ammo

			local ammoQualityData = data.gunQualityAmmo[item.quality + 1]
			tool:SetAttribute("TakeStoredAmmoPerc", _G.Random(ammoQualityData[1], ammoQualityData[2], 100))
			tool:SetAttribute("TakeAmmoPerc", 0)
			-- Price

			local priceQualityData = data.gunQualityPrice[item.quality + 1]
			tool:SetAttribute("SellPriceMultiplier", _G.Random(priceQualityData[1], priceQualityData[2], 100))
			--
		end
		--
		tool.Parent = plr.Backpack
		_G.RemoveFromArray(self.inventory, item)
		_G.PlaySound(script.TakeSound, plr.Character.HumanoidRootPart, math.random(90, 110)/100)
		if (#self.inventory <= 0) then
			self.container.Pivot.PromptAttachment.Prompt.Enabled = false
			self.container.Pivot.PromptAttachment.Prompt:SetAttribute("_enabled", false) end
		return true, ""
	else
		return false, "NOT ENOUGH INVENTORY SPACE"
	end
	--
end
--
function static:openContainer(plr)
	if (#self.inventory > 0) then
		task.spawn(function() 
			--
			game:GetService("ReplicatedStorage").PlantsStorage.Hooks.remote:FireClient(plr, "OpenLootContainer", {container = self.container, inventory = self.inventory})
			self.searching[plr] = true
			--
			if (self.open <= 0 and self.variant_data.onOpen) then
				self.isOpened = true
				self.variant_data.onOpen(self, self.model) end
			self.open += 1
			--
			local endthis = false
			repeat
				--
				if (plr.Character.HumanoidRootPart.Position - self.container.Pivot.PromptAttachment.WorldPosition).Magnitude >= 9 then
					endthis = true end
				--
				task.wait()
			until (plr.Character == nil or plr.Character:FindFirstChild("HumanoidRootPart") == nil) or (endthis or #self.inventory <= 0 or self.searching[plr] ~= true)
			--
			self.open -= 1
			if (self.open <= 0 and #self.inventory > 0 and self.variant_data.onClose) then
				self.isOpened = false
				self.variant_data.onClose(self, self.model) end
			--
			game:GetService("ReplicatedStorage").PlantsStorage.Hooks.remote:FireClient(plr, "CloseLootContainer", {})
		end)
	end
end
--
function static:regenerated()
	local data = self.variant_data
	--
	local power = math.floor(math.random(data.minPower, data.maxPower)*data.powerStartMultiplier)
	power = math.clamp(power, data.minPower, data.maxPower)
	self.generationPower = power
	self.tickOs = os.clock()
	self.tickTime = math.random(data.powerTickEverySeconds[1], data.powerTickEverySeconds[2])
	--
end
--
function static:chooseItem(loot)
	--
	local totalweight = 0
	for _, item in ipairs(loot) do
		totalweight += item.weight end
	--
	local weight = math.random(1, totalweight)
	for _, item in ipairs(loot) do
		weight -= item.weight
		if (weight <= 0) then
			return item
		end end
	--
end
--
function static:makeItem(item, id)
	--
	local invitem = {
		id = id,
		name = item.name,
		icon = game:GetService("ServerStorage").Tools[item.name].TextureId,
		quality = (item.isGun or item.isScrap and container.pickRandomQuality()) or 0,
		rarity = item.weight,
		--
		isScrap = item.isScrap,
		isMelee = item.isMelee,
		isGun = item.isGun,
		--
	}
	--
	return invitem
end
--
function static:generateLoot(player)
	if (not self.isGenerated) then
		self.isGenerated = true
		local data = self.variant_data
		self.regenerationTime = math.random(data.regenerationTime[1], data.regenerationTime[2])
		--
		local loot_mod = (script.Loot:FindFirstChild(data.loot or "Scrap"))
		local loot = _G.DeepCopy(require(loot_mod))
		local lootind = {}
		for _, item in ipairs(loot) do
			lootind[item.name] = item end
		--
		local function overwriteFunction(overwrite)
			for _, oitem in ipairs(overwrite) do
				if (lootind[oitem.name]) then
					local aitem = lootind[oitem.name]
					-- Weight
					
					if (oitem.weight) then
						aitem.weight = oitem.weight end
					if (oitem.weight_multiplier) then
						aitem.weight = math.round(aitem.weight*oitem.weight_multiplier) end
					-- Power
					
					if (oitem.power) then
						aitem.power = oitem.power end
					if (oitem.power_multiplier) then
						aitem.power = math.round(aitem.power*oitem.power_multiplier) end
					--
				else
					local toitem = _G.DeepCopy(oitem)
					table.insert(loot, _G.DeepCopy(toitem))
					lootind[oitem.name] = toitem
				end
			end
		end
		--
		if (data.overwriteLoot) then
			overwriteFunction(data.overwriteLoot) end
		--
		local items = 0
		local power = self.generationPower
		while (power > 0 and items < data.maxItems) do
			local chosen = self:chooseItem(loot)
			if (chosen ~= nil) then
				items += 1
				local invitem = self:makeItem(chosen, items)
				power -= chosen.power
				table.insert(self.inventory, invitem)
			end
			--
		end
		--
		if (player and _G.CharHasTrait(player, "scavenger") and math.random(1, 100) <= 65) then
			table.insert(self.inventory, self:makeItem(self:chooseItem(loot), items+1))
		end
		--
	end
end
--
return container