local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
local dependencies: types.client_dependencies = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Dependencies"))
--
return function()
	local this = {
		lookControlOs = 0,
		IKParts = {},
		LastOffset = Vector3.new(),
	} -- chill im lazy
	game:GetService("RunService").RenderStepped:Connect(function(delta) 
		--
		-- Look Control
		if (os.clock() - this.lookControlOs)>=1/40 then
			this.lookControlOs = os.clock()
			--
			local succ, err = pcall(function()
				for i,vPerson in pairs(workspace.Characters:GetChildren()) do
					if vPerson:IsA("Model") then
						local personHum = vPerson:FindFirstChild("Humanoid")
						local personHead = vPerson:FindFirstChild("Head")
						if personHead and personHum then
							if personHum:GetAttribute("LookVector") and personHum:FindFirstChild("LookControl") and personHead then
								--
								if not this.IKParts[vPerson] or (not framework.Gs.SafeCheck(this.IKParts[vPerson])) then
									this.IKParts[vPerson]=framework.Gs.Create("Part","LookPart",workspace.Debris)
									this.IKParts[vPerson].Transparency=1
									this.IKParts[vPerson].Anchored=true
									this.IKParts[vPerson].CanCollide=false
									this.IKParts[vPerson].CanQuery=false
									this.IKParts[vPerson].CanTouch=false
									this.IKParts[vPerson].Massless=true
								end
								--
								if this.IKParts[vPerson] then
									this.IKParts[vPerson].Position=personHead.Position+personHum:GetAttribute("LookVector")*personHum:GetAttribute("Multiplier")
									personHum.LookControl.Weight = 1 + personHum:GetAttribute("LookVector"):Dot(vPerson.HumanoidRootPart.CFrame.LookVector)
									personHum.LookControl.Target=this.IKParts[vPerson]
								end
							elseif this.IKParts[vPerson] then
								this.IKParts[vPerson]:Destroy()
								this.IKParts[vPerson]=nil
							end
						end
					end
				end
				--
			end)
			--
			if err then
				-- lol literally NOTHING
			end
			--
			if framework.Gs.SafeCheck(game.Players.LocalPlayer.Character) and game.Players.LocalPlayer.Character:FindFirstChild("Humanoid") then
				if game.Players.LocalPlayer.Character.Humanoid:FindFirstChild("LookControl") then
					if game.Players.LocalPlayer.Character.Humanoid:GetAttribute("LookVector")~=this.LastOffset then
						game:GetService("ReplicatedStorage").PlantsStorage.Hooks.remote:FireServer("LookVector",workspace.CurrentCamera.CFrame.LookVector)
					end
				end
			end
			--
		end
		--
		this.LastOffset=workspace.CurrentCamera.CFrame.LookVector
		--
	end)
end
--