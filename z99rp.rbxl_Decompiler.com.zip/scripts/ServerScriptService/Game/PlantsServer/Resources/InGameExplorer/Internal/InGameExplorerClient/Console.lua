local Console = {}

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ContextAction = game:GetService("ContextActionService")
local LogService = game:GetService("LogService")

local InGameExplorerShared = ReplicatedStorage:WaitForChild("InGameExplorer_Shared")
local LogShared = require(InGameExplorerShared:WaitForChild("LogShared"))

local Shared = require(script.Parent.Shared)
local Components = script.Parent.Components
local Modules = script.Parent.Modules

local Fusion = require(Modules.Fusion)
local Maid = require(Modules.Maid)
local Highlighter = require(script.Highlighter)

local StudioComponents = Components.StudioComponents
local Checkbox = require(StudioComponents.Checkbox)

local loadString = require(script.vLuau)

function Console:Init(UI)
	
	local ConsoleFrame = UI.Console
	
	local CommandBarFrame = ConsoleFrame.BottomBar
	local CommandBar = CommandBarFrame.TextBox
	local TitleLabel = ConsoleFrame.Body.TopBar.TextLabel

	local function UpdateCommandBar()
		CommandBarFrame.Size = UDim2.new(1,0,0,math.clamp(CommandBar.TextBounds.Y,30,100))
		CommandBarFrame.CanvasSize = UDim2.new(0,0,0,CommandBar.TextBounds.Y)
	end
	CommandBar:GetPropertyChangedSignal("TextBounds"):Connect(UpdateCommandBar)
	

	CommandBar.FocusLost:Connect(function(enterPressed)
		if enterPressed then
			if Shared.ListeningReplicator:get() then 
				Shared.RemoteEvent:FireServer("SendCode",CommandBar.Text)
			else
				loadString(CommandBar.Text)()
			end
			CommandBar.Text = ""
		end
	end)
	
	Fusion.Hydrate(TitleLabel)
	{
		Text = Fusion.Computed(function() 
			local replicator = Shared.CurrentReplicator:get()
			return replicator == "Server" and "Server Output" or string.format("Client Output for %s",replicator)
		end)
		
	}
	
	local ScrollingFrame = ConsoleFrame.Body.ScrollingFrame
	local TopBar = ConsoleFrame.Body.TopBar2
	local MessageTemplate = ScrollingFrame.MessageTemplate:Clone()
	ScrollingFrame.MessageTemplate:Destroy()
	
	local LogHistory = {}
	
	local OutputType = {
		Output = Fusion.Value(true),
		Information = Fusion.Value(false),
		Warning = Fusion.Value(true),
		Error = Fusion.Value(true)
	}
	local EnumToOutputType = {
		[Enum.MessageType.MessageInfo] = OutputType.Information,
		[Enum.MessageType.MessageError] = OutputType.Error,
		[Enum.MessageType.MessageWarning] = OutputType.Warning,
		[Enum.MessageType.MessageOutput] = OutputType.Output,
	}
	local Colors = {
		[Enum.MessageType.MessageInfo] = Color3.fromRGB(55, 142, 255),
		[Enum.MessageType.MessageError] = Color3.fromRGB(221, 0, 0),
		[Enum.MessageType.MessageWarning] = Color3.fromRGB(255, 207, 87),
		[Enum.MessageType.MessageOutput] = Color3.fromRGB(223, 223, 223),
	}

	local x = 0
	for i,val in OutputType do 
		x+=1
		local checkBox = Checkbox{
			Parent = TopBar,
			Size = UDim2.new(0,0,0,15),
			AnchorPoint = Vector2.new(0,0.5),
			Value = val,
			Text = i,
			OnChange = function(newValue)
				val:set(newValue)
			end,
		}		
		checkBox.AutomaticSize = Enum.AutomaticSize.X
		checkBox.CheckBoxInput.Size = UDim2.new(0,50,1,0)
		checkBox.TextLabel.Size = UDim2.new(0,0,1,0)
		checkBox.TextLabel.AutomaticSize = Enum.AutomaticSize.X
		checkBox.TextLabel.Position = UDim2.new(0,20,0,0)
		checkBox.TextLabel.AnchorPoint = Vector2.new(0,0)
		checkBox.Box.BackgroundTransparency = 0
		checkBox.Box.BackgroundColor3 = Color3.fromRGB(83, 83, 83)
	end
	
	local OutputMaid = Maid.new()
	
	local LocalEventMaid = Maid.new()
	
	local function ClearMaids()
		OutputMaid:Cleanup()
		LocalEventMaid:Cleanup()
	end
	local function ClearHistory()
		table.clear(LogHistory)
		ClearMaids()
	end
	
	
	local function AddEntry(entry)
		local newEntry = MessageTemplate:Clone()
		newEntry.Parent = ScrollingFrame 
		newEntry.Frame.Text = string.format("%s -- %s",entry.timestamp,entry.message)
		local outputValue = EnumToOutputType[entry.messageType]
		
		newEntry.Frame.TextColor3 = Colors[entry.messageType]
		
		Fusion.Hydrate(newEntry)
		{
			Visible = outputValue
		}
		OutputMaid:Add(newEntry)
	end
	local function AddLogEntries()
		for i = 1,#LogHistory do 
			AddEntry(LogHistory[i])
		end
	end
	
		
	local function StartListeningLocal()
		ClearMaids()
		local logHistory = LogShared:GetHistory()
		LogHistory = logHistory
		AddLogEntries()
		
		LogShared:AddEvent(LocalEventMaid,function(entry)
			table.insert(LogHistory,entry)
			AddEntry(entry)
		end)
	end
	StartListeningLocal()
	
	Fusion.Hydrate(ConsoleFrame)
	{
		Visible = Shared.ConsoleEnabled
	}
	Fusion.Observer(Shared.ConsoleEnabled):onChange(function()
		local enabled = Shared.ConsoleEnabled:get()
		ClearMaids()
		if enabled then
			if not Shared.ListeningReplicator:get() then
				StartListeningLocal()
			else
				AddLogEntries()
			end
		end
	end)
	Fusion.Observer(Shared.ListeningReplicator):onChange(function()
		local listening = Shared.ListeningReplicator:get()
		ClearHistory()
		if not listening then
			StartListeningLocal()
		end
	end)
	
	Shared.RemoteEvent.OnClientEvent:Connect(function(message,...)
		if message == "LogHistory" then
			ClearHistory()
			local history = ...
			
			LogHistory = ...
			AddLogEntries()
		elseif message == "LogHistoryEntry" then
			local entry = ...
			table.insert(LogHistory,entry)
			AddEntry(entry)
		end
	end)
end
return Console 