local m = {}

function m.Start()
	local function A()
		--warn("Camera sequencing..")
		m.anims.sequence:Play()

		task.delay(m.anims.sequence.Length - 0.1,function()
			m.anims.idle:Play()
		end)
	end
	task.spawn(A)
end

function m.SetUp(scene,config)
	m.scene = scene
	m.config = config
	
	m.cameraF = scene.Camera
	m.anim_controller = m.cameraF.AnimationController
	m.anims = {}
	m.anims.sequence = m.anim_controller:LoadAnimation(script.INTRO_CAMERASEQUENCE:Clone())
	m.anims.idle = m.anim_controller:LoadAnimation(script.INTRO_CAMERAIDLE:Clone())
	
	script:ClearAllChildren()
	
	--warn("Setup CameraHandler...")
end

return m