--// Interface:

export type AppObject = {
	hi: string
}

--// End:

return {}