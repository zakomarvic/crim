--[[ 
	Copyright (C) 2024 xewadev - All Rights Reserved
	
	You may not use, distribute and modify this code without
	proper permission from the original author.
--]]

local HTTPs = {}
HTTPs.__index = HTTPs

--// Folders:

local Interfaces = script.Parent.Parent:WaitForChild("Interfaces")

--// References:

local App = require(Interfaces.App)

--// Types:

type appObj = App.AppObject

--// Functions:

--// Module:

HTTPs.new = function(app: appObj)
	local self = setmetatable({}, HTTPs)
	self.__init = true
	self.__app = app
	
	return self
end

--// End:

return HTTPs