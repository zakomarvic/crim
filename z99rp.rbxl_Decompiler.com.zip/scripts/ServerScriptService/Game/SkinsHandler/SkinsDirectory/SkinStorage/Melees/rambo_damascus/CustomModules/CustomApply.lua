
return function(model)
	if model.ClassName == "Tool" then
		model:SetAttribute("bowiedamascus", true)
		model:SetAttribute("exotic", true)
		model.WeaponHandle:FindFirstChild("Rambo"):Destroy()
		
		for _, v in pairs(script:GetChildren()) do
			if v:IsA("MeshPart") then
				local mesh = v:Clone()
				mesh.Parent = model.WeaponHandle
				mesh.Weld.Part0 = mesh
				mesh.Weld.Part1 = model.WeaponHandle
			end
		end
	end
	return true
end