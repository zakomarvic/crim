local ServerStorage =		game:GetService("ServerStorage")
local ReplicatedStorage =	game:GetService("ReplicatedStorage")
local HttpService = 		game:GetService("HttpService")
local Players = 			game:GetService("Players")
local RunService = 			game:GetService("RunService")
local ServerScriptService = game:GetService("ServerScriptService")

local events3 = ServerStorage.Events3
local logRemote = events3:WaitForChild("OLGR")
local repr = require(ServerScriptService.repr)

local config = require(script:WaitForChild("Config"))


local CLH = {
	Config = {
		StudioLog = true;
		IsTestMode = false;
	};

	Colors = {
		red = 16711680;
		green = 65280;
		blue = 255;
		black = 0;
		white = 16777215;
		grey = 8421504;
		orange = 15105570;
	};

	Webhooks = config;
}

local serverId = ""

local uid_cache = {}


local _s,_e = pcall(function()
	local c = script.Config
	c.Name = ""
	c:Destroy()
end)
--------------------------------------------------------------------------------------------------------


local function NewWebhook(webhook,Data)
	if CLH.Config.IsTestMode then
		webhook = CLH.Webhooks.Test
	end

	return true
end

local function updateServerId()
	serverId = ""

	local tests
	if game.GameId ~= 1494262959 then
		tests = true
		serverId = serverId .. "TESTP | "
	end

	if ReplicatedStorage.Values.IsVipServer.Value then
		serverId = serverId .. "VIP | "
	end

	if ReplicatedStorage.Values.PrimeServer.Value then
		serverId = serverId .. "PRIME | "
	end

	serverId = serverId .. ReplicatedStorage.Values.ServerId.Value .. " | " .. ReplicatedStorage.Values.GameMode.Value 

	if not tests then
		serverId = serverId .. " | "  .. ReplicatedStorage.Values.VersionNumber.Value
	end
end

local function parseDateTime()
	local function format(num, digits)
		return string.format("%0" .. digits .. "i", num)
	end

	local osDate = os.date("!*t")
	local year, mon, day = osDate["year"], osDate["month"], osDate["day"]
	local hour, min, sec = osDate["hour"], osDate["min"], osDate["sec"]
	return year .. "-" .. format(mon, 2) .. "-" .. format(day, 2) .. "T" .. format(hour, 2) .. ":" .. format(min, 2) .. ":" .. format(sec, 2) .. "Z"
end

local function randomCode(len,isUpper)
	local t = {1,2,3,4,5,6,7,8,9,0,"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"}
	local n = ""

	for i = 1,len do
		n = n .. tostring(t[math.random(1,#t)])
	end

	if isUpper then
		n = string.upper(n)
	end

	return n
end

local function getUserIdFromUsername(name)
	-- First, check if the cache contains the name
	if uid_cache[name] then return true,uid_cache[name] end
	-- Second, check if the user is already connected to the server
	local player = Players:FindFirstChild(name)
	if player then
		uid_cache[name] = player.UserId
		return true,player.UserId
	end 
	-- If all else fails, send a request
	local success,id = pcall(function()
		return Players:GetUserIdFromNameAsync(name)
	end)
	uid_cache[name] = id

	return success,id
end

local function SanityCheck(code)
	local ignore = RunService:IsStudio() and not CLH.Config.StudioLog
	return code == "ZKLFXG890ZDFGJKN43SU8IOG" and not ignore
end


--------------------------------------------------------------------------------------------------------





CLH.Functions = {
	["CmdLog"] = function(plrName,cmdTxt,is2nd)
		local realPlr = Players:FindFirstChild(plrName)
		local _success,userId = getUserIdFromUsername(plrName)

		if not _success then
			userId = 1
		end

		local nameLine = plrName .. " | " .. userId

		local level = "N/A"

		if realPlr then
			level = tostring((_G.Adonis and _G.Adonis.GetLevel(realPlr) > 10) or "N/A")
		end

		local gTime = parseDateTime()

		local options = {}
		options.timestamp = gTime
		options.type = "rich"
		options.description = cmdTxt	

		--local logID = randomCode(6)

		options.fields = {
			{
				["name"] = "Mod:",
				["value"] = nameLine,
				["inline"] = false
			},
		}

		local url = 'https://www.roblox.com/users/'..tostring(userId)..'/profile';
		local icon_url = 'https://www.roblox.com/headshot-thumbnail/image?userId='.. tostring(userId) .. '&width=180&height=180&format=png'

		options.author = {
			name = "Executed:",
			url = url,
		}

		options.footer = {
			icon_url = icon_url,
			text = "ServerID: " .. tostring(serverId) 
			--.. " | " .. "logID: " .. tostring(logID)
		}

		local Data = {
			["content"] = "",
			["embeds"] = {options},
		}

		if _success then
			Data["username"] = plrName
			Data["avatar_url"] = icon_url
		end

		local wh = (is2nd == 4 and CLH.Webhooks.Command4) or (is2nd == 3 and CLH.Webhooks.Command3) or (is2nd == 2 and CLH.Webhooks.Command2) or CLH.Webhooks.Command
		NewWebhook(wh,Data)

		return true
	end,








	["ModLog"] = function(plrName,modName,typ,txt,reason,isBan,customWebhook)
		if modName then
			modName = tostring(modName)
		end

		plrName = tostring(plrName)
		typ = tostring(typ)
		typ = string.upper(typ)
		txt = tostring(txt)
		reason = tostring(reason)

		local realPlr = Players:FindFirstChild(plrName)
		local success1,userId = getUserIdFromUsername(plrName)
		if not success1 then
			userId = 1
		end

		local realModPlr,success2,modUserId,nameLine2,icon_url2,url2

		if modName then
			realModPlr = Players:FindFirstChild(modName)

			success2,modUserId = getUserIdFromUsername(modName)
			if not success2 then
				modUserId = 1
			end
		end

		local nameLine1 = plrName .. " | " .. tostring(userId)

		if modName then
			nameLine2 = modName .. " | " .. tostring(modUserId)
		end

		local level = "N/A"

		if realPlr and modName and realModPlr then
			level = tostring((_G.Adonis and _G.Adonis.GetLevel(realModPlr) > 10) or "N/A")
		end

		local gTime = parseDateTime()

		local options = {}
		options.timestamp = gTime
		options.type = "rich"
		options.description = txt

		local color

		if typ == "EXPLOIT-BAN" or typ == "CRASH" or typ == "MANUAL-TIMEOUT" or typ == "KICK" or typ == "SERVER-BAN" or typ == "TEMP-BAN" or typ == "TEMP-BLACKLIST" or typ == "GLOBAL-KICK" or typ == "PERM-BAN" or typ == "WARN" or typ == "MUTE" or typ == "TIMEOUT" then
			color = CLH.Colors.red
		elseif typ == "BAN-ENDED" or typ == "UN-BAN" or typ == "UN-TEMP-BLACKLIST" or typ == "UN-SERVER-BAN" or typ == "UN-TEMP-BAN" or typ == "UN-PERM-BAN" or typ == "UN-MUTE" or typ == "UN-ANTICHEAT-BAN" or typ == "UN-AC-BAN" or typ == "WARNING-REMOVED" or typ == "UN-TIMEOUT" then
			color = CLH.Colors.green
		elseif typ == "SERVER-LOG" then
			color = CLH.Colors.white
		elseif typ == "WARNING-ABIDED" then
			color = CLH.Colors.orange
		end

		if color then
			options.color = color
		end

		--local logID = randomCode(6)

		local fields = {}

		fields = {
			{
				["name"] = "User:",
				["value"] = nameLine1,
				["inline"] = false
			},
		}

		if modName then
			table.insert(fields,{
				["name"] = "Mod:",
				["value"] = nameLine2,
				["inline"] = false
			})
		end

		if reason and typ ~= "WARNING-ABIDED" then
			table.insert(fields,{
				["name"] = "Reason:",
				["value"] = reason,
				["inline"] = false
			})
		end

		options.fields = fields


		local url1 = 'https://www.roblox.com/users/'..tostring(userId)..'/profile';
		local icon_url1 = 'https://www.roblox.com/headshot-thumbnail/image?userId='.. tostring(userId) .. '&width=180&height=180&format=png'

		if modName then
			url2 = 'https://www.roblox.com/users/'..tostring(modUserId)..'/profile';	
			icon_url2 = 'https://www.roblox.com/headshot-thumbnail/image?userId='.. tostring(modUserId) .. '&width=180&height=180&format=png'
		end

		options.author = {
			name = typ,
			url = url1,
		}

		options.thumbnail = {
			url = icon_url1
		}

		local footer = {
			text = "ServerID: " .. tostring(serverId)
			--.. " | " .. "logID: " .. tostring(logID)
		}

		if modName then
			footer.icon_url = icon_url2
		end

		options.footer = footer

		local Data = {
			["content"] = "",
			["embeds"] = {options},
		}

		if modName and success2 then
			Data["username"] = modName
			Data["avatar_url"] = icon_url2
		end

		local wh = (isBan and CLH.Webhooks.Ban) or CLH.Webhooks.Mod

		if customWebhook then
			wh = CLH.Webhooks[customWebhook] or wh
		end

		NewWebhook(wh,Data)

		return true
	end,







	["ExploitLog"] = function(plrName,titl,typ,txt,moode)
		plrName = tostring(plrName)
		txt = tostring(txt)
		typ = tostring(typ)

		local realPlr = Players:FindFirstChild(plrName)
		local success1,userId = getUserIdFromUsername(plrName)
		if not success1 then
			userId = 1
		end

		local nameLine1 = plrName .. " | " .. userId

		local gTime = parseDateTime()

		local options = {}
		options.timestamp = gTime
		options.type = "rich"
		options.description = typ

		local color
		color = CLH.Colors.red
		if color then
			options.color = color
		end

		--local logID = randomCode(6)

		options.fields = {
			{
				["name"] = "User:",
				["value"] = nameLine1,
				["inline"] = false
			},
			{
				["name"] = "Log:",
				["value"] = txt,
				["inline"] = false
			},
		}

		local url1 = 'https://www.roblox.com/users/'..tostring(userId)..'/profile';
		local icon_url1 = 'https://www.roblox.com/headshot-thumbnail/image?userId='.. tostring(userId) .. '&width=180&height=180&format=png'

		options.author = {
			name = titl,
			url = url1,
		}

		options.thumbnail = {
			url = icon_url1
		}


		options.footer = {
			text ="ServerID: " .. tostring(serverId) 
			--"InfCount: " .. "N/A" .. " | " .. 
			--.. " | " .. "logID: " .. tostring(logID)
		}

		local Data = {
			["content"] = "",
			["embeds"] = {options},
		}

		local w =  (moode == "Banwave" and CLH.Webhooks.BanWave) 
			or (moode == "Ban" and CLH.Webhooks.AntiBan) 
			or (moode == "Movement" and CLH.Webhooks.Movement) 
			or (moode == "Dupe" and CLH.Webhooks.Dupe) 
			or (moode == "BountyClaimed" and CLH.Webhooks.BountyClaim) 
			or (moode == "SafeFarm" and CLH.Webhooks.SafeFarm)
			or (moode == "AltKillFarm" and CLH.Webhooks.AltKillFarm)
			or (moode == "ShopUnlockLog" and CLH.Webhooks.ShopUnlockLog)
			or CLH.Webhooks.Exploit

		NewWebhook(w,Data)

		return true
	end,


	["BuyLog"] = function(plrName,txt,playerProductKey,robuxSpent,giftedPlrName,giftedIsGamepass)
		plrName = tostring(plrName)
		txt = tostring(txt)

		local realPlr = Players:FindFirstChild(plrName)
		local success1,userId = getUserIdFromUsername(plrName)
		if not success1 then
			userId = 1
		end

		local nameLine1 = plrName .. " | " .. userId
		local gTime = parseDateTime()

		local options = {}
		options.timestamp = gTime
		options.type = "rich"

		local color = CLH.Colors.white
		if color then
			options.color = color
		end

		--local logID = randomCode(6)

		local fields  = {
			{
				["name"] = "User:",
				["value"] = nameLine1,
				["inline"] = false
			},
			{
				["name"] = "Log:",
				["value"] = txt,
				["inline"] = false
			},
			{
				["name"] = "PlayerProductKey:",
				["value"] = tostring(playerProductKey),
				["inline"] = false
			},
			{
				["name"] = "CurrencySpent:",
				["value"] = tostring(robuxSpent),
				["inline"] = false
			},
		}

		if giftedPlrName then
			local realPlr2 = Players:FindFirstChild(giftedPlrName)
			local success2,userId2 = getUserIdFromUsername(giftedPlrName)
			if not success2 then
				userId2 = 1
			end

			local nameLine2 = giftedPlrName .. " | " .. userId2

			table.insert(fields,{
				["name"] = "Gifted User:",
				["value"] = nameLine2,
				["inline"] = false
			})

			table.insert(fields,{
				["name"] = "Gift Type:",
				["value"] = (giftedIsGamepass and "gamepass") or "devproduct",
				["inline"] = false
			})
		end

		options.fields = fields

		local url1 = 'https://www.roblox.com/users/'..tostring(userId)..'/profile';
		local icon_url1 = 'https://www.roblox.com/headshot-thumbnail/image?userId='.. tostring(userId) .. '&width=180&height=180&format=png'

		options.author = {
			name = ((giftedPlrName and "GIFT-PURCHASE") or "PURCHASE") .. " LOG",
			url = url1,
		}

		options.thumbnail = {
			url = icon_url1
		}

		options.footer = {
			text = "ServerID: " .. tostring(serverId) 
			--.. " | " .. "logID: " .. tostring(logID)
		}

		local Data = {
			["content"] = "",
			["embeds"] = {options},
		}

		NewWebhook((giftedPlrName and CLH.Webhooks.GiftProduct) or CLH.Webhooks.Buy,Data)

		return true
	end,

	["BuyLogFail"] = function(plrName,txt,playerProductKey)
		plrName = tostring(plrName)
		txt = tostring(txt)

		local realPlr = Players:FindFirstChild(plrName)
		local success1,userId = getUserIdFromUsername(plrName)
		if not success1 then
			userId = 1
		end

		local nameLine1 = plrName .. " | " .. userId
		local gTime = parseDateTime()

		local options = {}
		options.timestamp = gTime
		options.type = "rich"

		local color = CLH.Colors.white
		if color then
			options.color = color
		end

		--local logID = randomCode(6)

		options.fields = {
			{
				["name"] = "User:",
				["value"] = nameLine1,
				["inline"] = false
			},
			{
				["name"] = "Log:",
				["value"] = txt,
				["inline"] = false
			},
			{
				["name"] = "PlayerProductKey:",
				["value"] = tostring(playerProductKey),
				["inline"] = false
			},
		}

		local url1 = 'https://www.roblox.com/users/'..tostring(userId)..'/profile';
		local icon_url1 = 'https://www.roblox.com/headshot-thumbnail/image?userId='.. tostring(userId) .. '&width=180&height=180&format=png'

		options.author = {
			name = "FAILED-PURCHASE LOG",
			url = url1,
		}

		options.thumbnail = {
			url = icon_url1
		}


		options.footer = {
			text = "ServerID: " .. tostring(serverId) 
			--.. " | " .. "logID: " .. tostring(logID)
		}

		local Data = {
			["content"] = "",
			["embeds"] = {options},
		}

		NewWebhook(CLH.Webhooks.FailedPurchaseLog,Data)

		return true
	end,

	["MoneyLog"] = function(plrName,txt)
		plrName = tostring(plrName)
		txt = tostring(txt)

		local realPlr = Players:FindFirstChild(plrName)
		local success1,userId = getUserIdFromUsername(plrName)
		if not success1 then
			userId = 1
		end

		local nameLine1 = plrName .. " | " .. userId
		local gTime = parseDateTime()
		--local logID = randomCode(6)

		local options = {}
		options.timestamp = gTime
		options.type = "rich"
		local color = CLH.Colors.red
		if color then
			options.color = color
		end

		options.fields = {
			{
				["name"] = "User:",
				["value"] = nameLine1,
				["inline"] = false
			},
			{
				["name"] = "Log:",
				["value"] = txt,
				["inline"] = false
			},
		}

		local url1 = 'https://www.roblox.com/users/'..tostring(userId)..'/profile';
		local icon_url1 = 'https://www.roblox.com/headshot-thumbnail/image?userId='.. tostring(userId) .. '&width=180&height=180&format=png'

		options.author = {
			name = "MONEY LOG",
			url = url1,
		}

		options.thumbnail = {
			url = icon_url1
		}


		options.footer = {
			text = "ServerID: " .. tostring(serverId) 
			--.. " | " .. "logID: " .. tostring(logID)
		}

		local Data = {
			["content"] = "",
			["embeds"] = {options},
		}
		NewWebhook(CLH.Webhooks.Money,Data)

		return true
	end,

	["BarcodeLog"] = function(typ,plrName,title,txt,tab)
		plrName = tostring(plrName)
		txt = tostring(txt)

		local realPlr = Players:FindFirstChild(plrName)
		local success1,userId = getUserIdFromUsername(plrName)
		if not success1 then
			userId = 1
		end

		local nameLine1 = plrName .. " | " .. userId

		local gTime = parseDateTime()

		local options = {}
		options.timestamp = gTime
		if txt then
			options.description = txt
		end
		options.type = "rich"
		options.fields = tab

		local color = CLH.Colors.red
		if color then
			options.color = color
		end

		--local logID = randomCode(6)

		local url1 = 'https://www.roblox.com/users/'..tostring(userId)..'/profile';
		local icon_url1 = 'https://www.roblox.com/headshot-thumbnail/image?userId='.. tostring(userId) .. '&width=180&height=180&format=png'

		options.author = {
			name = title,
			url = url1,
		}

		options.thumbnail = {
			url = icon_url1
		}


		options.footer = {
			text = "ServerID: " .. tostring(serverId) 
			--.. " | " .. "logID: " .. tostring(logID)
		}

		local Data = {
			["content"] = "",
			["embeds"] = {options},
		}

		local webhook = typ == "Barcode" and CLH.Webhooks.Barcode or CLH.Webhooks.Sus

		NewWebhook(webhook,Data)

		return true
	end,

	["ReportFileLog"] = function(plrName,modName,typ,reportData,isPrime)
		if modName then
			modName = tostring(modName)
		end

		plrName = tostring(plrName)
		typ = tostring(typ)
		typ = string.upper(typ)

		local success1,userId = getUserIdFromUsername(plrName)
		if not success1 then
			userId = 1
		end

		local realModPlr,success2,modUserId,nameLine2,icon_url2,url2

		if modName then
			success2,modUserId = getUserIdFromUsername(modName)
			if not success2 then
				modUserId = 1
			end
		end

		local nameLine1 = plrName .. " | " .. tostring(userId)

		if modName then
			nameLine2 = modName .. " | " .. tostring(modUserId)
		end

		local gTime = parseDateTime()

		local options = {}
		options.timestamp = gTime
		options.type = "rich"

		local desc = "Given info: "

		if reportData.Description and reportData.Description ~= "" then
			desc = desc .. '```' .. tostring(reportData.Description) .. '```'
		else
			desc = desc .. "N/A"
		end

		options.description = desc

		local color

		if typ == "WARNING-ABIDED" then
			color = CLH.Colors.orange
		end

		if color then
			options.color = color
		end

		--local logID = randomCode(6)

		local fields = {}

		table.insert(fields,{
			["name"] = "User:",
			["value"] = nameLine1,
			["inline"] = false
		}
		)

		table.insert(fields,{
			["name"] = "Display Name:",
			["value"] = reportData.displayname or "N/A",
			["inline"] = false
		})


		if modName then
			table.insert(fields,{
				["name"] = "Reporter:",
				["value"] = nameLine2,
				["inline"] = false
			})
		end

		for i,v in pairs(reportData.reportLog) do
			table.insert(fields,{
				["name"] = i .. ":",
				["value"] = tostring(v),
				["inline"] = true
			})
		end

		table.insert(fields,{
			["name"] = "Report ID:",
			["value"] = reportData.ReportID or "N/A",
			["inline"] = true
		})

		options.fields = fields

		local url1 = 'https://www.roblox.com/users/'..tostring(userId)..'/profile';
		local icon_url1 = 'https://www.roblox.com/headshot-thumbnail/image?userId='.. tostring(userId) .. '&width=180&height=180&format=png'

		if modName then
			url2 = 'https://www.roblox.com/users/'..tostring(modUserId)..'/profile';	
			icon_url2 = 'https://www.roblox.com/headshot-thumbnail/image?userId='.. tostring(modUserId) .. '&width=180&height=180&format=png'
		end

		options.author = {
			name = typ,
			url = url1,
		}

		options.thumbnail = {
			url = icon_url1
		}

		local footer = {
			text = "ServerID: " .. tostring(serverId)
			--.. " | " .. "logID: " .. tostring(logID)
		}

		if modName then
			footer.icon_url = icon_url2
		end

		options.footer = footer

		local Data = {
			["content"] = "",
			["embeds"] = {options},
		}

		if modName and success2 then
			Data["username"] = modName
			Data["avatar_url"] = icon_url2
		end

		local wh = config.NewReport_Feed

		if isPrime then
			wh = config.NewReport_Feed_Prime
		end

		NewWebhook(wh,Data)

		return true
	end,

	["ReportMultiLog"] = function(plrName,reportData,isPrime,wasTimeout)
		plrName = tostring(plrName)

		local success1,userId = getUserIdFromUsername(plrName)
		if not success1 then
			userId = 1
		end

		local realModPlr,success2,modUserId,nameLine2,icon_url2,url2

		local nameLine1 = plrName .. " | " .. tostring(userId)

		local gTime = parseDateTime()

		local options = {}
		options.timestamp = gTime
		options.type = "rich"

		local desc =""

		if wasTimeout then
			desc = desc .. "Account temporarily placed on timeout"
			desc = desc .. "\n\n"
		end

		desc = desc .. "Report count:\n**" .. reportData.ReportCount .. "**"

		options.description = desc

		local color

		color = CLH.Colors.orange

		if wasTimeout then
			color = CLH.Colors.red
		end

		if color then
			options.color = color
		end

		--local logID = randomCode(6)

		local fields = {}

		table.insert(fields,{
			["name"] = "User:",
			["value"] = nameLine1,
			["inline"] = false
		}
		)

		table.insert(fields,{
			["name"] = "Display Name:",
			["value"] = reportData.displayname or "N/A",
			["inline"] = false
		})

		for i,v in pairs(reportData.reportLog) do
			table.insert(fields,{
				["name"] = i .. ":",
				["value"] = tostring(v),
				["inline"] = true
			})
		end

		table.insert(fields,{
			["name"] = "Last Report ID:",
			["value"] = reportData.ReportID or "N/A",
			["inline"] = true
		})

		options.fields = fields

		local url1 = 'https://www.roblox.com/users/'..tostring(userId)..'/profile';
		local icon_url1 = 'https://www.roblox.com/headshot-thumbnail/image?userId='.. tostring(userId) .. '&width=180&height=180&format=png'


		local typ = wasTimeout and "AUTO-TIMEOUT" or "MULTI-REPORT"
		options.author = {
			name = typ,
			url = url1,
		}

		options.thumbnail = {
			url = icon_url1
		}

		local footer = {
			text = "ServerID: " .. tostring(serverId)
			--.. " | " .. "logID: " .. tostring(logID)
		}



		options.footer = footer

		local Data = {
			["content"] = "",
			["embeds"] = {options},
		}

		local wh

		if wasTimeout then
			if isPrime then
				wh = config.NewReport_TimeOut_Prime
			else
				wh = config.NewReport_TimeOut
			end
		else
			if isPrime then
				wh = config.NewReport_MultiLog_Prime
			else
				wh = config.NewReport_MultiLog
			end
		end

		NewWebhook(wh,Data)

		return true
	end,

	["OtherLog"] = function(title,txt,customWevhook)
		title = tostring(title)
		txt = tostring(txt)

		local gTime = parseDateTime()
		--local logID = randomCode(6)

		local options = {}
		options.timestamp = gTime
		options.type = "rich"
		--local color = CLH.Colors.red
		--if color then
		--	options.color = gre
		--end

		options.description = txt	

		options.fields = {
		}

		options.author = {
			name = title,
			--url = url1,
		}

		options.footer = {
			text = "ServerID: " .. tostring(serverId) 
			--.. " | " .. "logID: " .. tostring(logID)
		}

		local Data = {
			["content"] = "",
			["embeds"] = {options},
		}

		local wh = CLH.Webhooks.Test
		wh = customWevhook and customWevhook or wh
		NewWebhook(wh,Data)

		return true
	end,

	["CosmeticsLog"] = function(logType,plrName,title,desc,array,color,content)
		assert(CLH.Webhooks[logType],"no log type:",logType)

		plrName = tostring(plrName)

		local success1,userId

		if plrName then
			local realPlr = plrName and Players:FindFirstChild(plrName)

			success1,userId = getUserIdFromUsername(plrName)
			if not success1 then
				userId = 1
			end
		end

		local nameLine1 = "N/A"	
		if plrName and userId then
			nameLine1 = plrName .. " | " .. userId
		end

		local gTime = parseDateTime()

		local options = {}
		options.timestamp = gTime
		options.type = "rich"

		local color2 = (color and CLH.Colors[color]) or CLH.Colors.white
		if color2 then
			options.color = color2
		end

		if desc then
			options.description = tostring(desc)
		end

		--local logID = randomCode(6)

		options.fields = {}

		for i,v in pairs(array) do
			local name = v[1] .. ":"
			local value = tostring(v[2])		

			table.insert(options.fields,{
				["name"] = name;
				["value"] = value;
				["inline"] = false
			})
		end

		local url1 = plrName and 'https://www.roblox.com/users/'..tostring(userId)..'/profile';
		local icon_url1 = plrName and 'https://www.roblox.com/headshot-thumbnail/image?userId='.. tostring(userId) .. '&width=180&height=180&format=png'

		options.author = {
			name = title,
			url = url1 or nil,
		}

		options.thumbnail = {
			url = icon_url1 or nil
		}


		options.footer = {
			text = "ServerID: " .. tostring(serverId) 
			--.. " | " .. "logID: " .. tostring(logID)
		}

		local Data = {
			["content"] = (content and tostring(content)) or "",
			["embeds"] = {options},
		}

		if userId and plrName then
			Data["username"] = plrName
			Data["avatar_url"] = icon_url1
		end


		local wh = CLH.Webhooks[logType]
		NewWebhook(wh,Data)

		return true
	end,
}

logRemote.OnInvoke = function(code,logType,a1,a2,a3,a4,a5,a6,a7,a8)
	if not SanityCheck(code) then return end

	if CLH.Functions[logType] then
		updateServerId()

		local success,response = pcall(function()
			return CLH.Functions[logType](a1,a2,a3,a4,a5,a6,a7,a8)
		end)
		--CLH.Functions[logType](a1,a2,a3,a4,a5,a6,a7,a8)

		if success then
			return true
		else
			warn("error with wh: " .. logType,response)
		end
	end
end

ReplicatedStorage.Values.ServerId.Changed:Connect(function()
	wait()
	updateServerId()
end)

updateServerId()

--AddCommandLog("ZKLFXG890ZDFGJKN43SU8IOG","RVVZ",":kill all")
--AddModLog("ZKLFXG890ZDFGJKN43SU8IOG","ROBLOX","RVVZ","Temp-Ban","Banned for 30 day.","Abusing glitches despite multiple warns")
--AddExploitLog("ZKLFXG890ZDFGJKN43SU8IOG","RVVZ","Action: kick | Tamper Protection 10042")
return CLH