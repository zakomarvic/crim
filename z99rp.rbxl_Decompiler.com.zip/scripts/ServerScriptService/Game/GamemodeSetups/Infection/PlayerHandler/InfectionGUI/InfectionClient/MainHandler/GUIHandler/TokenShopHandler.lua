local TS = game:GetService("TweenService")
local Teams = game:GetService("Teams")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local TSHandler = {}

local uiSoundsF = ReplicatedStorage:WaitForChild("Storage"):WaitForChild("UISounds")

function TSHandler.new(self)
	local frame = self.ui.mF.TokenStoreFrame
	local giftingFrame = frame.Frame2.GiftingFrame
	local giftingScrollFrame = giftingFrame.Frame
	
	local scrollingFrame = frame.Frame2.ScrollingFrame
	local closeButton = frame.Base.Header.CloseButton
	
	local coreGui = self.plr.PlayerGui:WaitForChild("CoreGUI")

	local shopButton
	pcall(function()
		shopButton = coreGui.StatsFrame.Frame2.Frame.Container.Store.ToggleButton
	end)

	local guiOpen = false
	local tokenFrames = {}
	local purchaseBusy = false
	
	local giftBusy =false
	
	if not shopButton then return end
	
	local _oldShopButton = shopButton
	shopButton = _oldShopButton:Clone()
	shopButton.Parent = _oldShopButton.Parent
	_oldShopButton.Visible = false
	
	shopButton.ImageColor3 = Color3.fromRGB(255, 186, 108)
	shopButton.Label.Text = "TOKENS"
	shopButton.Hint.Visible = true
	shopButton.Visible = false
	
	local lastTokenData
	
	local function CanUseCheck()
		return true
	end
	
	local function PlaySound(s)
		if uiSoundsF and uiSoundsF.Parent and uiSoundsF:FindFirstChild(s) then
			uiSoundsF[s]:Play()
		end
	end
	
	local function UpdateAvailableTokens(tokensData)
		lastTokenData = tokensData
		for i,v in pairs(tokensData) do
			local f = tokenFrames[i]
			if f then
				f.Amount.Text = v.Amount
				
				if v.Amount > 0 then
					f.GiftButton.Visible = true
					f.AddButton.Position = UDim2.new(0.769,0,0.5,0)
					f.Amount.Position = UDim2.new(0.66,0,0,0)
					f.Amount.TextColor3 = Color3.fromRGB(207, 255, 213)
				else
					f.GiftButton.Visible = false
					f.AddButton.Position = UDim2.new(0.975,0,0.5,0)
					f.Amount.Position = UDim2.new(0.86,0,0,0)
					f.Amount.TextColor3 = Color3.fromRGB(255, 215, 216)
				end
			end
		end
	end
	

	local function ToggleGifting(m,tokenType,playSound)
		if m then
			for i,v in pairs(giftingScrollFrame:GetChildren()) do
				if v:IsA("Frame") then
					v:Destroy()
				end
			end
			
			local lastClickTing
			
			local b1d = false
			local gc = 0
			
			local function CreateF(p)
				local f = script.GiftFrame:Clone()
				f.NameLabel.Text = "@" .. p.Name

				f.Button1.MouseButton1Down:Connect(function()
					if b1d == f then return end
					if giftBusy == f then return end
					
					if lastClickTing then
						lastClickTing.ConfirmFrame.Visible = false
					end
					lastClickTing = f

					b1d = f
					giftBusy = f
					
					PlaySound("click")
					
					lastClickTing = f
					
					local c = math.random()
					gc = c
					
					f.ConfirmFrame.ConfirmButton.BackgroundColor3 = Color3.fromRGB(154, 154, 154)
					
					f.ConfirmFrame.Visible = true

					task.wait(0.5)
					
					if giftBusy == f and gc == c then
						f.ConfirmFrame.ConfirmButton.BackgroundColor3 = Color3.fromRGB(255, 170, 0)

						giftBusy = false
					end
				end)

				f.ConfirmFrame.ConfirmButton.MouseButton1Down:Connect(function()
					if b1d ~= f then return end
					if giftBusy then return end
					
					PlaySound("click")
					
					giftBusy = f
					purchaseBusy = f

					local result,tokensData = self.I.events.GiftToken:InvokeServer(tokenType,p)

					if result then
						--PlaySound("purchase")

						--if tokensData and typeof(tokensData) == "table" then
						--	UpdateAvailableTokens(tokensData)
						--end
					else
						PlaySound("error")
					end
					
					purchaseBusy = false
					giftBusy = false
					
					ToggleGifting(false)
				end)
				
				f.Parent = giftingScrollFrame
			end

			if playSound then
				PlaySound("open")
			end

			for i,v in pairs(Players:GetPlayers()) do
				if v ~= self.plr and v:GetAttribute("InfectionLoaded") then
					CreateF(v)
				end
			end
			
			scrollingFrame.Visible = false
			giftingFrame.Visible = true
		else
			for i,v in pairs(giftingScrollFrame:GetChildren()) do
				if v:IsA("Frame") then
					v:Destroy()
				end
			end

			giftingFrame.Visible = false
			scrollingFrame.Visible = true

			if playSound then
				PlaySound("close")
			end
		end
	end
	
	local function ToggleGUI(m)
		if not m then
			m = not guiOpen
		end

		if m == guiOpen then
			return
		end

		if m then
			PlaySound("open")
			shopButton.Hint.Visible = false
			frame.Visible = true
		else
			frame.Visible = false
			ToggleGifting(false)
		end

		guiOpen = m
	end
		
	local function SetUp()
		local tokenData = self.I.events.GetTokenData:InvokeServer()
		if tokenData then
			for i,v in pairs(tokenData) do
				local f = script.TokenFrame:Clone()
				f.Title.Text = v.Name .. ":"
				f.LayoutOrder = v.LO or 1000
				
				if v.ProductID then
					f.AddButton.MouseButton1Down:Connect(function()
						if purchaseBusy then return end
						
						if lastTokenData and lastTokenData[i] and lastTokenData[i].Amount >= 3 then
							return
						end
						
						purchaseBusy = true
						
						local result = _G.PromptProductPurchase(v.ProductID)
						
						if result then
							PlaySound("purchase")
						end
						
						purchaseBusy = false
					end)
				end
				
				f.GiftButton.MouseButton1Down:Connect(function()
					ToggleGifting(true,i,true)
				end)
				
				f.Parent = scrollingFrame
				
				tokenFrames[i] = f
			end
			UpdateAvailableTokens(tokenData)
		end
		
		self.I.events.GotTokenData.OnClientEvent:Connect(function(...)
			UpdateAvailableTokens(...)
		end)
		
		shopButton.MouseButton1Down:Connect(function()
			if purchaseBusy then return end
			
			PlaySound("click")
			
			ToggleGUI()
		end)

		closeButton.MouseButton1Down:Connect(function()
			if purchaseBusy then return end
			
			PlaySound("click")
			
			ToggleGUI(false)
		end)
		
		shopButton.Visible = true
	end
	spawn(function()
		if not self.plr:GetAttribute("InfectionLoaded") then
			self.plr:GetAttributeChangedSignal("InfectionLoaded"):Wait()
		end
		if not self.isVipServer then
			SetUp()
		else
			ReplicatedStorage.Values.UI_RemoveStoreButton.Value = true
		end
	end)
end

return TSHandler