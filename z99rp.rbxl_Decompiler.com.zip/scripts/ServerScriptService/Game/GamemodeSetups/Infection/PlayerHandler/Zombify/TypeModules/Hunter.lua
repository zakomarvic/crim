local M = {}

local ServerStorage = game:GetService("ServerStorage")

function M.DoAppearance(char)
	local oldShirt = char:FindFirstChildOfClass("Shirt")
	local oldPants = char:FindFirstChildOfClass("Pants")
	if oldShirt then
		oldShirt:Destroy()
	end
	if oldPants then
		oldPants:Destroy()
	end
	
	for i,v in pairs(char.Humanoid:GetAccessories()) do
		v:Destroy()
	end

	script.Shirt:Clone().Parent = char
	script.Pants:Clone().Parent = char
	
	local ha = script.HoodAccessory:Clone()
	char.Humanoid:AddAccessory(ha)
	
	local bC = char:FindFirstChildOfClass("BodyColors")
	local color = BrickColor.new("Really black")
	
	bC.HeadColor = color
	bC.LeftArmColor = color
	bC.RightArmColor = color
	bC.LeftLegColor = color
	bC.RightLegColor = color
	bC.TorsoColor = color
	
	local h = script.HunterRig:Clone()
	h.Parent = char
	h.Script.Disabled = false
	
	local face = char.Head:FindFirstChild("face")
	if face then
		face.Transparency = 1
	end
	
	local eyes = script.InfectedEyes:Clone()
	char.Humanoid:AddAccessory(eyes)
	
	wait()
	
	local s = ServerStorage.Tools["__RESIZERT"]:Clone()
	s.Perc.Value = 1.1
	s.Parent = char
end

function M.new(char)
	local plr = game.Players:GetPlayerFromCharacter(char)
	local hum = char.Humanoid
	
	local HP = 300
	local SPEED_ADD = -5
	local JUMPADD = 20
	local ACCEL = 10

	local function DoMain()
		if not hum:GetAttribute("DontChangeHP") then
			hum.MaxHealth = HP + 15
			hum.Health = hum.MaxHealth
		end

		local vF = _G.GVF(char.Name)
		
		--local vest = game.ServerStorage.Tools.VestB_1:Clone()
		--vest.Parent = char
		--local helmet = game.ServerStorage.Tools.HelmetB_2:Clone()
		--helmet.Parent = char

		task.wait(0.1)

		if vF then
			if not hum:GetAttribute("DontChangeHP") then
				for _,v in pairs(vF.HealthValues:GetChildren()) do
					local h = HP
					if v.Name == "Head" then
						--h /= 2
					end
					v.MaxValue = h
					v.Value = v.MaxValue
				end
			end	
			
			vF.MovementSoundModifier.Value = 2
			vF.AccelerationModifier.Value = ACCEL
			vF.FallDamageProof.Value = 0.05
			vF.BleedProof.Value *= 2
			
			local ACCEL_MULTI = 2
			local ACCEL_MAX = 15

			--local b = Instance.new("BoolValue")
			--b.Name = "RBTMVB_S"
			--b.Parent = vF.Currents

			local b1 = Instance.new("NumberValue")
			b1.Name = "ACCLTRR"
			b1.Value = ACCEL_MULTI

			local b2 = Instance.new("NumberValue")
			b2.Name = "M"
			b2.Value =ACCEL_MAX
			b2.Parent = b1
			
			b1.Parent = vF.Currents
			
			local r = Instance.new("BoolValue")
			r.Name = "IGZNFD"
			r.Parent = vF.Currents
			
			char:SetAttribute("__INFSTAM",true)
			
			_G.AffectChar(char,"JR",math.huge,"WKVL2",-JUMPADD)
			_G.AffectChar(char,"SD",math.huge,"WKVL2",-SPEED_ADD)
		end

		local zf = game.ServerStorage.Tools["__ZombieFists3"]:Clone()
		zf.Parent = plr.Backpack
		
		delay(1,function()
			if not hum:GetAttribute("NoAutoEquip") and _G.CheckIfCan(char) then
				hum:EquipTool(zf)
			end
			spawn(function()
				while hum and hum.Parent and hum.Health > 0 do
					if zf.Parent and zf.Parent ~= char and not hum:GetAttribute("NoAutoEquip") and _G.CheckIfCan(char) then
						hum:EquipTool(zf)
					elseif not _G.CheckIfCan(char) then
						hum:UnequipTools()
					end
					task.wait(0.35)
				end
			end)
		end)

		hum:SetAttribute("ForceWalkStage",1)
		hum:SetAttribute("ZSPRN_M",1)
		hum:SetAttribute("NACTIVFD",true)
		hum:SetAttribute("NoOnFireAnim",true)
		hum:SetAttribute("NoFireStun",true)
		hum:SetAttribute("IsHighInfected",true)
		hum:SetAttribute("NoGasStun",true)
		
		local animateS = char:WaitForChild("Animate",3)
		if animateS then
			for i,v in pairs({"idle1","idle2","idle3"}) do
				for i,v in pairs(animateS[v]:GetChildren()) do
					v.AnimationId = "rbxassetid://127585051698508"
				end
			end
			for i,v in pairs({"walk1","walk2","walk3"}) do
				for i,v in pairs(animateS[v]:GetChildren()) do
					v.AnimationId = "rbxassetid://106157847668733"
				end
			end
			for i,v in pairs({"run1","run2","run3"}) do
				for i,v in pairs(animateS[v]:GetChildren()) do
					v.AnimationId = "rbxassetid://83810348098685"
				end
			end
		end
		
		for i,v in pairs(hum:GetPlayingAnimationTracks()) do
			if v:GetAttribute("IsShakeAnim") then
				v:Stop()
			end
		end
		
		local RAGE_DMM = 0.5
		local RAGE_SM = 1
		local RAGE_LAST_TIME = 120
		
		local RAGE_DAMAGE_AMT = 1
		local RAGE_DAMAGE_TICK = 0.3
		
		local rage = ServerStorage.Storage.Scripts.RageScript:Clone()
		rage.DMM.Value = RAGE_DMM
		rage.SM.Value = RAGE_SM
		rage.LastTime.Value = RAGE_LAST_TIME

		local color = Color3.fromRGB(255, 181, 53)

		rage.EyeParticle.Color = ColorSequence.new{
			ColorSequenceKeypoint.new(0, color),
			ColorSequenceKeypoint.new(1, color)
		}
		rage.RageParticle.Color = ColorSequence.new{
			ColorSequenceKeypoint.new(0, color),
			ColorSequenceKeypoint.new(1, color)
		}

		rage.Disabled = false
		rage.Parent = char	
		
		delay(0,function()
			if hum.Parent then
				local t = tick()
				repeat
					hum:TakeDamage(RAGE_DAMAGE_AMT)
					task.wait(RAGE_DAMAGE_TICK)
				until not hum.Parent or hum.Health <= 0 or tick() -t >= RAGE_LAST_TIME + 1

				if hum and hum.Parent then
					hum:TakeDamage(10000)
					hum.Health = 0
				end
			end
		end)
		
		local zSounds = script.Parent.Parent.ZombieSounds:Clone()
		script.Sounds:Clone().Parent = zSounds
		zSounds.Parent = char
		zSounds.Disabled = false
		zSounds.Enabled = true
		
		
		local ss = script.SpawnScream:Clone()
		game.Debris:AddItem(ss,15)
		ss.Name = "Sound"
		ss.Parent = workspace.Audio
		ss:Play()
		
		local l = Instance.new("PointLight")
		l.Shadows = true
		l.Color = Color3.new(1,0,0)
		l.Brightness = 30
		l.Range = 6
		l.Parent = char.Torso
		
		delay(1,function()
			if hum and hum.Parent and hum.Health > 0 then
				local sl = script.SYellLoop:Clone()
				sl.Parent = char.Head
				sl:Play()

				hum.Died:Connect(function()
					if sl and sl.Parent then
						sl:Stop()
					end
					if l and l.Parent then
						l:Destroy()
					end
				end)
			end
		end)
	end

	if plr then
		DoMain()
	end
	
	--if not M.NormalM then
	--	M.NormalM = require(script.Parent.Normal)
	--end
	--M.NormalM.DoAppearance(char)
	
	M.DoAppearance(char)
end

return M