-- CLIENT

local types = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Types"))
local framework: types.framework = require(game:GetService("ReplicatedStorage"):WaitForChild("PlantsStorage"):WaitForChild("Framework"))
--
local player = game.Players.LocalPlayer
local playerGui = player.PlayerGui
--
local LCS = {
	--
	opened = false,
	opened_container = nil,
	opened_gui = nil,
	opened_connections = {},
	--
	takeRequestSent = false
	--
}
--
function LCS.init()
	_G.LCS = LCS
end
--
function LCS.openContainer(container, inventory)
	if (not LCS.opened) then
		--
		LCS.opened_container = container
		container.Pivot.PromptAttachment.Prompt.Enabled = false
		_G.PlayGuiSound("open")
		local gui = script.LootGui:Clone()
		gui.Parent = playerGui
		LCS.opened_gui = gui
		local slots = {}
		--
		local function refreshInventory()
			if (LCS.opened_gui and gui and gui:FindFirstChild("main")) then
				gui.main.Size = UDim2.new(0, 300, 0, 100 + math.ceil(#inventory/5)*50)
				--
				for _, cslot in ipairs(slots) do
					cslot.ui:Destroy() end
				slots = {}
				--
				for _, item in ipairs(inventory) do
					--
					local slotui = gui.templates.item:Clone()
					slotui.Parent = gui.main.inventory
					slotui.icon.Image = item.icon
					slotui.icon.iconshad.Image = item.icon
					slotui.Visible = true
					--
					slotui.icon.Size = UDim2.new(0, 38, 0, 38)
					slotui.icon.Rotation = 7
					game:GetService("TweenService"):Create(slotui.icon, TweenInfo.new(0.4, Enum.EasingStyle.Sine,Enum.EasingDirection.Out, 0, false, 0), {Size = UDim2.new(0, 35, 0, 35), Rotation = 5}):Play()
					--
					if (item.quality > 0) then
						for i = 1, item.quality do
							slotui.quality[tostring(i)].Visible = true 
							if (item.quality <= 2) then
								slotui.quality[tostring(i)].Size = UDim2.new(0, 20, 0, 20)
							end
						end 
					end
					--
					slotui.button.MouseEnter:Connect(function() 
						game:GetService("TweenService"):Create(slotui.background, TweenInfo.new(0.3, Enum.EasingStyle.Sine,Enum.EasingDirection.Out, 0, false, 0), {BackgroundColor3 = Color3.fromRGB(65, 65, 65)}):Play()
						_G.PlayGuiSound("hover") end)
					slotui.button.MouseLeave:Connect(function() 
						game:GetService("TweenService"):Create(slotui.background, TweenInfo.new(0.3, Enum.EasingStyle.Sine,Enum.EasingDirection.Out, 0, false, 0), {BackgroundColor3 = Color3.fromRGB(25, 25, 25)}):Play() end)
					slotui.button.MouseButton1Click:Connect(function() 
						_G.PlayGuiSound("click")
						if (not LCS.takeRequestSent) then
							task.spawn(function() 
								LCS.takeRequestSent = true
								local ret = container.remoteFunction:InvokeServer("take", {id = item.id})
								inventory = ret[2]
								--
								if (#inventory > 0) then
									if (_G.SafeCheck(gui) and gui:FindFirstChild("main")) then
										refreshInventory()
										if (ret[1] == true) then
											_G.PlayGuiSound("successvar1")
											gui.main.background.BackgroundColor3 = Color3.fromRGB(15, 35, 15)
											game:GetService("TweenService"):Create(gui.main.background, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {BackgroundColor3 = Color3.fromRGB(15, 15, 15)}):Play()
										elseif (ret[1] == false) then
											_G.PlayGuiSound("error")
											gui.main.background.BackgroundColor3 = Color3.fromRGB(35, 15, 15)
											game:GetService("TweenService"):Create(gui.main.background, TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0), {BackgroundColor3 = Color3.fromRGB(15, 15, 15)}):Play()
										end
									end
								else
									if (ret[1] == true) then
										_G.PlayGuiSound("successvar1") end
								end
								--
								LCS.takeRequestSent = false
							end)
						end
					end)
					--
					table.insert(slots, {ui = slotui})
				end
				--
			end
		end
		--
		gui.main.close.MouseEnter:Connect(function() 
			_G.PlayGuiSound("hover") end)
		gui.main.close.MouseButton1Click:Connect(function() 
			_G.PlayGuiSound("close")
			container.remote:FireServer("close")
			LCS.closeContainer() end)
		--
		refreshInventory()
		LCS.opened = true
	end
end
--
function LCS.closeContainer()
	if (LCS.opened) then
		--
		LCS.opened_container.Pivot.PromptAttachment.Prompt.Enabled = LCS.opened_container.Pivot.PromptAttachment.Prompt:GetAttribute("_enabled")
		LCS.opened_gui:Destroy()
		for _, con in ipairs(LCS.opened_connections) do
			con:Disconnect() end
		LCS.opened_container = nil
		LCS.opened_connections = {}
		--
		LCS.opened = false
	end
end
--
return LCS