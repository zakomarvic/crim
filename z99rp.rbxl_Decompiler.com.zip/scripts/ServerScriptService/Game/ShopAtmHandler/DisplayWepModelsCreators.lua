local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

return function()
	local f = ReplicatedStorage.Storage:WaitForChild("DisplayWepModels",5)
	if not f then
		f = Instance.new("Folder")
		f.Name = "DisplayWepModels"
	end
		
	if not _G.SurfaceAppearanceHandlerDone then
		repeat task.wait(0.2) until _G.SurfaceAppearanceHandlerDone
	end
	
	task.wait(0.2)
	
	for i,v in pairs(ReplicatedStorage.Storage.ItemStats:GetChildren()) do
		for i2,z in pairs(v:GetChildren()) do
			if z:FindFirstChild("IsUpgrade") and z.IsUpgrade.Value or z.Parent.Name == "Guns" or z.Parent.Name == "Melees" then
				
				if z.Parent.Name == "Guns" then
					local tool = ServerStorage.Tools:FindFirstChild(z.Name)

					if tool then
						local m = f:FindFirstChild(tool.Name) or Instance.new("Model")
						m.Name = tool.Name

						local handle = tool:FindFirstChild("Handle") or tool:FindFirstChild("HHandle") or tool:FindFirstChild("Handle1") or tool:FindFirstChild("WeaponHandle")

						local attachments = tool:FindFirstChild("Attachments")

						if handle then
							handle = handle:Clone()
						else
							continue
						end

						if attachments then
							attachments = attachments:Clone()
							attachments.Parent = m
						end

						handle.Parent = m
						m.PrimaryPart = handle
						m.PrimaryPart.Anchored = true

						local __X = {}

						for _,v in pairs(m:GetDescendants()) do
							if not v:IsA("BasePart") then
								--if v.Name ~= "IMW" and not v:FindFirstChildWhichIsA("BasePart") and not v:IsA("SpecialMesh") then
								--	v:Destroy()
								--end
								if v:IsA("BaseValue") then
									v:Destroy()
								end
							else
								v.Anchored = true
								v.CanCollide = false
								v.CanQuery = false
								v.CanTouch = false
								v.Massless = true

								table.insert(__X,v)

								if v ~= handle then

									if tool.Name == "MP7" and v.Name == "StockPart" then
										v.CFrame *= CFrame.new(0,0,-0.908)
									end

									local w = Instance.new("ManualWeld")
									w.Name = "IMW"
									w.Part0 = handle
									w.Part1 = v
									w.C0 = v.CFrame:toObjectSpace(handle.CFrame):Inverse()

									w.Parent = handle

									if v.Parent ~= attachments then
										if not v:GetAttribute("KeepInstanceName") then
											v.Name = ""
										end
										v.Parent = m
									end
								end
							end
						end

						if handle.ClassName == "Part" then
							handle.Size = Vector3.new()
						end

						for i,v in pairs(m:GetDescendants()) do
							if v.Name ~= "KilltrackPlacementAttachment" then
								if not v:IsA("BasePart") or (v ~= handle and v.Transparency >= 1 and not v:GetAttribute("KeepInstanceName")) then
									if not (attachments and (v == attachments or v:IsDescendantOf(attachments))) then
										v:Destroy()
									end
								end
							end
						end

						local cf = CFrame.new(0,5,0) * CFrame.Angles(math.rad(90),0,0)

						m:SetPrimaryPartCFrame(cf)

						m.Parent = f
					end
				elseif z.Parent.Name == "Melees" then
					if f:FindFirstChild(z.Name) then
						local Model = f:FindFirstChild(z.Name)
						local ModelCF = Model.PrimaryPart.CFrame
						
						--local a = 0
						
						--if z.Name == "Shovel" then
						--	a = -90
						--end
						
						--Model:SetPrimaryPartCFrame(cf)
					end
				end
			end
		end
	end

	f.Parent = ReplicatedStorage.Storage
end


