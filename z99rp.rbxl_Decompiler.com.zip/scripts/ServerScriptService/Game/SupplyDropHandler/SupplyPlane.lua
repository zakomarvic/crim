local RunService = game:GetService("RunService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local TS = game:GetService("TweenService")

local SupplyPlane = {
	Config = {
		Health = 500; -- 1000
		MinHealth = -350; -- 250
		
		Rarity = 3;
		
		--MusicVolumeMulti = 3.5;
		--MusicDistanceMulti = 2;
		--MusicPlaybackSpeed = 1;
		--MusicSoundId = 1842368044;
	}
}

local M = require(script.Parent)

local deepCopy = require(ReplicatedStorage.Modules.DeepCopy)

function SupplyPlane.new(totalDrops, custom)
	if not M.DropLocationData then
		warn("M.SupplyPlane no DropLocationData table, forget to SetUp?")
		return
	end

	local map = workspace:FindFirstChild("Map")
	if not map then
		warn("M.SupplyPlane no map found!")
		return
	end

	totalDrops = totalDrops or 5

	local possibleDrops = map:GetAttribute("MapName") and M.DropLocationData[map:GetAttribute("MapName")]
	if possibleDrops then
	else
		warn("M.SupplyPlane no dropData found for",map:GetAttribute("MapName"))
		return
	end

	local planeActive = true
	local cantDrop = false
	local broken = false
	local exploded = false
	local missileHit = false
	local dropsDone = 0

	local dropData = possibleDrops[math.random(1,#possibleDrops)]
	local spawnPart,angleInPart,dropConfig = dropData.SpawnPart,dropData.AngleInPart,dropData.DropConfig
	local spawnCF = spawnPart.CFrame
	
	if custom and custom.Target then
		local dir = Vector3.new(custom.Direction.X,0,custom.Direction.Z).Unit
		local startPos = Vector3.new(custom.Target.X,spawnPart.Position.Y,custom.Target.Z) - dir * (custom.Distance or 450)
		spawnCF = CFrame.lookAt(startPos,startPos + dir)
		angleInPart = nil -- skip the angle-in tween
		totalDrops = 1
	end

	local dropPlane = script.SupplyPlane:Clone()
	delay(120,function()
		if dropPlane and dropPlane.Parent then
			dropPlane:Destroy()
		end
	end)
	
	local mainPart = dropPlane.MainPart
	
	local angleInTween
	local chosenDropsT = {}
	
	local funcs = {}
	
	local playersHit = {}


	local function GetChosenDropTs()
		local gots = {}

		local lastChoI

		local maxPossibleDrop = #dropData.DropGroups
		local dropCount = math.min(totalDrops,maxPossibleDrop)

		local n = maxPossibleDrop
		n -= dropCount
		n = math.max(n,1)

		local t = deepCopy(dropData.DropGroups)
		local c = 0
		for i,v in pairs(t) do
			c += 1
		end
		
		if c > 1 then
			for i = 1,n do
				table.remove(t,math.random(1,#t))
			end
		end

		chosenDropsT = t
	end

	local function GetNextDrop(current)
		local n = current + 1
		if custom and custom.Target then
			return current == 0 and custom.Target or nil
		end

		local drop = chosenDropsT[n]
		if drop then
			return M.GetRandomInPart(drop:GetChildren()[math.random(1,#drop:GetChildren())]).Position
		else
			return nil
		end
	end

	GetChosenDropTs()

	dropPlane:SetPrimaryPartCFrame(spawnCF)

	local bodyVel = Instance.new("BodyVelocity")
	bodyVel.MaxForce = Vector3.new(10e10,10e10,10e10)
	bodyVel.Parent = mainPart

	local bodyGyro = Instance.new("BodyGyro")
	bodyGyro.MaxTorque = Vector3.new(10e10,10e10,10e10)
	bodyGyro.CFrame = mainPart.CFrame
	bodyGyro.Parent = mainPart
	
	local healthValue = Instance.new("DoubleConstrainedValue")
	healthValue.MaxValue = SupplyPlane.Config.Health
	healthValue.MinValue = SupplyPlane.Config.MinHealth
	healthValue.Value = healthValue.MaxValue
	healthValue.Name = "Health"
	healthValue.Parent = dropPlane
	
	local speedVal = Instance.new("NumberValue")
	speedVal.Name = "Speed"
	speedVal.Value = M.Settings.PlaneSettings.Velocity
	speedVal.Parent = dropPlane
	
	local bodyVelForceV = Instance.new("Vector3Value")
	bodyVelForceV.Name = "VelValue"
	bodyVelForceV.Parent = dropPlane
	
	local bodyVelForceAddV = Instance.new("Vector3Value")
	bodyVelForceAddV.Name = "VelAddValue"
	bodyVelForceAddV.Parent = dropPlane
	
	
	for i,v in pairs(dropPlane:GetDescendants()) do
		if v:IsA("BasePart") then
			v:SetAttribute("T7H",true)
		end
	end

	dropPlane.Parent = workspace.Map.SpawnedSupplyPlanes
	
	dropPlane:SetAttribute("IsSupplyPlane",true)

	mainPart.EngineLoop:Play()
	
	mainPart.Music.PlaybackSpeed = (SupplyPlane.Config.MusicPlaybackSpeed or mainPart.Music.PlaybackSpeed)
	mainPart.Music.RollOffMinDistance *= (SupplyPlane.Config.MusicDistanceMulti or mainPart.Music.RollOffMinDistance)
	mainPart.Music.Volume *= (SupplyPlane.Config.MusicVolumeMulti or mainPart.Music.Volume)
	
	if SupplyPlane.Config.MusicSoundId then
		mainPart.Music.SoundId = "rbxassetid://" .. SupplyPlane.Config.MusicSoundId
	end

	
	mainPart.Music:Play()
	mainPart.Music.TimePosition = math.random(40,120)

	
	delay(10,function()
		if planeActive and mainPart.Parent then
			mainPart.Engine2:Play()
		end
	end)

	funcs.SpinOut = function()
		if not planeActive or broken then return end
		
		if angleInTween then
			angleInTween:Cancel()
		end
		
		if bodyGyro and bodyGyro.Parent then
			bodyGyro:Destroy()
		end
		
		cantDrop = true
		
		--print("spin out")
		
		local angularVel = Instance.new("BodyAngularVelocity")
		
		angularVel.MaxTorque = Vector3.new(20000,20000,20000)
		angularVel.P = 10
		
		angularVel.AngularVelocity = Vector3.new(math.random(0,10),math.random(-10,10) / 10,math.random(-40,40) / 10)
		
		angularVel.Parent = mainPart
	end
	
	funcs.Explode = function(wasMissile)
		if exploded or not planeActive then return end
		
		if wasMissile then
			missileHit = true
		end
		exploded = true
		planeActive = false
		dropPlane.Active.Value = false
		dropPlane:SetAttribute("Destroyed",true)
		
		for i,v in pairs(dropPlane:GetDescendants()) do
			if v:IsA("BasePart") then
				v.CanCollide = false
				v.CanTouch = false
				v.CanQuery = false
				v.Size = Vector3.new()
				v.Transparency = 1
				v.Anchored = true
				if v ~= mainPart then
					v:Destroy()
				end
			elseif v:IsA("Sound") and v.Playing then
				v:Stop()
			elseif v:IsA("ParticleEmitter") then
				v.Enabled = false
			end
		end
		
		local s = mainPart["Explode" .. math.random(1,3)]
		s:Play()
		
		mainPart.Explode4:Play()
		
		-------------
		local eSound = mainPart.ExplodeEffectSound
		local Settings = {
			Monitor = {
			RadiusMulti =	5;
			Multi =			4;
			ShakeM =		3;
			BrightM =		2;
			};
		}
		
		eSound:Play()
		ReplicatedStorage.Events.ExplosionEffect:FireAllClients(mainPart,eSound,
			{
				eSound
				,eSound.TimeLength
				,500
				,Settings.Monitor.Multi
				,Settings.Monitor.ShakeM
				,Settings.Monitor.BrightM
			}
		)
		
		if not missileHit then
			for plr,totalDmg in pairs(playersHit) do
				if plr and plr.Parent then
					ServerStorage.Events3.nBount:Fire("KLGHJRKR90U3893KJZDGNKDFZJKNWU9023JKWRG02",plr,totalDmg * 4)
				end
			end
		end
		-------------
	end
	
	funcs.Break = function()
		if broken or exploded or not planeActive then return end
		broken = true

		if angleInTween then
			angleInTween:Cancel()
		end

		--if bodyGyro and bodyGyro.Parent then
		--	bodyGyro:Destroy()
		--end
		
		print("break down")
		
		if mainPart:FindFirstChildOfClass("BodyAngularVelocity") then
			mainPart:FindFirstChildOfClass("BodyAngularVelocity"):Destroy()
		end
		
		local angularVel = Instance.new("BodyAngularVelocity")

		angularVel.MaxTorque = Vector3.new(0, 0, 500000)
		angularVel.P = 10
		
		angularVel.AngularVelocity = Vector3.new(0,0,-10) 

		angularVel.Parent = mainPart
		
		if bodyGyro and bodyGyro.Parent then
			bodyGyro.MaxTorque = Vector3.new(bodyGyro.MaxTorque.X,bodyGyro.MaxTorque.Y,0)
		end
		
		mainPart.Smoke1.Enabled = false
		mainPart.Smoke2.Enabled = true
		mainPart.Flame.Enabled = true
		
		local inf = TweenInfo.new(5,Enum.EasingStyle.Quad,Enum.EasingDirection.Out)
		local inf2 = TweenInfo.new(12,Enum.EasingStyle.Quad,Enum.EasingDirection.In)
		
		TS:Create(mainPart.Engine2,inf,{Pitch = 0.7}):Play()
		TS:Create(mainPart.EngineLoop,inf,{Pitch = 0.7}):Play()
		TS:Create(mainPart.Music,inf,{Pitch = 0}):Play()
		
		TS:Create(speedVal,inf2,{Value = speedVal.Value * 0.6}):Play()
		--TS:Create(bodyGyro,inf2,{CFrame = bodyGyro.CFrame * CFrame.Angles(math.rad(-5),0,0)}):Play()
		TS:Create(bodyVelForceAddV,inf2,{Value = Vector3.new(0,-0.25,0)}):Play()
		
		mainPart.EngineFailing:Play()
		
		delay(math.random(5,12),function()
			funcs.Explode()
		end)
	end
	
	funcs.Damage = function(dmg,pos,normal,player,explosiveHit)
		if explosiveHit then
			dmg *= 5.85 * 0.5
		end
		
		healthValue.Value -= dmg
		
		 --print(dmg,healthValue.Value)
		
		if player then
			if not playersHit[player] then
				ServerStorage.Events3.nBount:Fire("KLGHJRKR90U3893KJZDGNKDFZJKNWU9023JKWRG02",player,250)
				playersHit[player] = 0
			end
			
			playersHit[player] = math.min(playersHit[player] + dmg,healthValue.MaxValue)
			
			_G.CombatTagChar(player,30,"SUPPLYHITT")
		end
		
		local hpPerc = healthValue.Value / healthValue.MaxValue
		
		if planeActive then
			if broken and healthValue.Value <= healthValue.MinValue then
				funcs.Explode()
			elseif healthValue.Value <= 0 then
				delay(0,function()
					funcs.Break()
				end)
			elseif hpPerc <= 0.4 then
				mainPart.Smoke1.Enabled = false
				mainPart.Smoke2.Enabled = true
			elseif hpPerc <= 0.7 then
				mainPart.Smoke1.Enabled = true
				mainPart.Smoke2.Enabled = false
			end
		end
		
		if player and not exploded then
			ReplicatedStorage.Events.ClientWarn:FireClient(player,{"CEASE FIRE!",1,Color3.fromRGB(255, 121, 121),Color3.new(0,0,0),"lost"}) 
		end
	end
	
	--delay(10,function()
	--	funcs.Break()
	--end)
	
	dropPlane.Explode.Event:Connect(funcs.Explode)
	dropPlane.Parts.BaseMesh.OnHitEvent.Event:Connect(funcs.Damage)
	dropPlane.Damage.Event:Connect(funcs.Damage)

	local con
	con = mainPart.AncestryChanged:Connect(function(_,parent)
		if not parent then
			con:Disconnect()
			
			dropPlane.Active.Value = false
			dropPlane:SetAttribute("Destroyed",true)
			planeActive = false
		end
	end)

	local nextDrop = GetNextDrop(dropsDone)
	
	if angleInPart and bodyGyro.Parent then
		local mag = (angleInPart.Position - spawnPart.Position).Magnitude
		local tim = mag / 60

		if dropConfig and dropConfig.TimeAdd then
			tim += dropConfig.TimeAdd
		end

		angleInTween = TS:Create(bodyGyro,TweenInfo.new(tim,Enum.EasingStyle.Linear,Enum.EasingDirection.Out),{CFrame = angleInPart.CFrame})
		angleInTween:Play()
	end
	
	local spv = nil

	spawn(function()
		while planeActive do
			if not broken then
				bodyVelForceV.Value = mainPart.CFrame.LookVector 
				bodyVel.Velocity = bodyVelForceV.Value * speedVal.Value
			else
				if not spv then
					spv = mainPart.CFrame.LookVector
				end
				bodyVelForceV.Value = spv + bodyVelForceAddV.Value
				
				bodyVel.Velocity = bodyVelForceV.Value * speedVal.Value
			end
			
			

			if nextDrop and not cantDrop and not broken then
				local mag = (Vector3.new(mainPart.Position.X,0,mainPart.Position.Z) - Vector3.new(nextDrop.X,0,nextDrop.Z)).Magnitude			
				--print(mag)
				if mag < 300 then
					--print("ez crate")
					dropsDone +=1

					local nDrop = nextDrop

					delay(2,function()
						if planeActive and not cantDrop and not broken then
							M.SupplyCrate(mainPart.CFrame * CFrame.Angles(0,math.random(),0) - Vector3.new(0,3,0),SupplyPlane.Config.Rarity,nDrop,dropPlane)
						end
					end)

					if dropsDone >= totalDrops then
						nextDrop = nil
					else
						nextDrop = GetNextDrop(dropsDone)
					end

				end
			end
			RunService.Heartbeat:Wait()
		end
	end)

	return dropPlane,dropData,funcs
end


return SupplyPlane