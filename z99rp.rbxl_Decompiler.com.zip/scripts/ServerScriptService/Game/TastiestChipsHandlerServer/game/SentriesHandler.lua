-- SERVER

return function()
	local theworkspace = game:GetService("Workspace")
	local themap = theworkspace:WaitForChild("Map")
	--
	local function setupSentry(sentry: Model)
		--
		local remote: RemoteEvent = _G.Create("RemoteEvent", "remote", sentry)
		local pivot: Part = sentry.pivot
		local _ = {
			state = "idle",
			rateos = os.clock(),
			ratehz = 20,
			--
			hasSightOs = os.clock()
			targeting = nil,
			--
		}
		--
		function _:switch(state, ext)
			if (state == "idle") then
			elseif (state == "target") then
				--
				if (self.state == "idle") then
					remote:FireAllClients("target", {target = ext.target})
				end
				--
				self.state = "target"
				self.targeting = ext.target
			end
		end
		--
		function _:cycle(delta)
			if (os.clock() - self.rateos) >= (1/self.ratehz) then
				self.rateos = os.clock()
				-- Getting Nearest Character

				local nearestcharacter = nil
				local nearestdis = 250
				for _, char in ipairs(workspace.Characters:GetChildren()) do
					local croot = char:FindFirstChild("HumanoidRootPart")
					local chum = char:FindFirstChild("Humanoid")
					local cvf = _G.GVF(char.Name)
					if (croot and chum and cvf) then
						local distance = (croot.Position - pivot.Position).Magnitude
						if (nearestdis > distance) then
							nearestcharacter = char
							nearestdis = distance
						end
					end
				end
				-- Rate HZ

				if (nearestcharacter == nil or nearestdis >= 100) then
					self.ratehz = 2
				else
					self.ratehz = 20 end
				-- Detection

				if (nearestcharacter ~= nil and nearestdis <= 50 and _G.BCAST(pivot.Position, nearestcharacter.HumanoidRootPart.Position, {workspace.Characters, sentry}) == nil) then
					print("spotted: ".. nearestcharacter.Name)
					
				end
				--
			end
		end
		--
		game:GetService("RunService").Heartbeat:Connect(function(dt) _:cycle(dt) end)
	end
	--
	for _, m in ipairs(themap:WaitForChild("Security"):WaitForChild("Sentries"):GetChildren()) do
		setupSentry(m) end
	themap.Security.Sentries.ChildAdded:Connect(function(m) setupSentry(m) end)
	--
end