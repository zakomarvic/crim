local function multNumberSequence(sequence,Scale)
	local numberKeypoints2 = {}
	for i = 1, #sequence.Keypoints do
		local currKeypoint = sequence.Keypoints[i]
		table.insert(numberKeypoints2, NumberSequenceKeypoint.new(currKeypoint.Time,currKeypoint.Value*Scale))
	end
	return NumberSequence.new(numberKeypoints2)
end

return function(model)
	--if model.ClassName == "Tool" then
		for i,v in pairs(model:GetDescendants()) do
			if v:IsA("Sound") then
				script.ChorusSoundEffect:Clone().Parent = v
			elseif v:IsA("ParticleEmitter") then
				v.Color = ColorSequence.new{
					ColorSequenceKeypoint.new(0, Color3.fromRGB(255,170,0)),
					ColorSequenceKeypoint.new(1, Color3.fromRGB(255,170,0))
				}
				v.Brightness = 15
				v.LightEmission = 1
				
				local seq = v.Size
				v.Size=multNumberSequence(seq, 2)
				
			elseif v:IsA("BasePart") then
				if v.Name == "Shell1" or v.Name == "Shell2" then
					v.TextureID = ""
					v.Color = Color3.fromRGB(255,170,0)
					v.Material = Enum.Material.Neon
				elseif v.Name == "FabricPart" then
					v.Transparency = 1
				elseif v.Name == "BarrelPart" then
					v.Material = Enum.Material.Metal
				end
				
				if v:GetAttribute("SATP") then
					local sA = script.Value.Value and script.Value.Value:FindFirstChild("SurfaceAppearance")
					if sA then
						sA:Clone().Parent = v
					end
				end
			elseif v:IsA("Attachment") and v.Name == "Muzzle" then
				script.FFireSoundTWO:Clone().Parent = v
			end
		end
	--end
	
	return true
end